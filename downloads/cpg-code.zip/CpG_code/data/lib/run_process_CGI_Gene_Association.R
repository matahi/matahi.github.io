##############################################################################################################
#			Transform TCGA methylation .txt files into .RData files
##############################################################################################################
### Path Setting 
setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/") # Home
#setwd("~/Desktop/CpG/data/") # BIWS machine

### Loading 
load('processed/fData/fData_CGI.RData')

### Process 
CGI_Genes <- sapply(1:length(fData_CGI),
                    function(n){ 
                            print(paste0(n,'/',length(fData_CGI)))
                            Genes_associated <- strsplit(fData_CGI[[n]]$UCSC_RefGene_Name,";")
                            Association <- strsplit(fData_CGI[[n]]$UCSC_RefGene_Group,";")
                            Genes_bis <- Reduce('c',Genes_associated)
                            Association_bis <- Reduce('c',Association)
                            out <- cbind(Genes_bis,Association_bis)
                    })


CGI_Genes_analysis <- sapply(1:length(CGI_Genes),
                             function(n){
                                     print(paste0(n,'/',length(CGI_Genes)))
                                     tmp <- table(CGI_Genes[[n]][,1],CGI_Genes[[n]][,2])
                                     if (nrow(tmp)==0)
                                     {
                                             return(NA)
                                     } else if (nrow(tmp)==1){
                                             tmp2 <- grepl('TSS',colnames(tmp))
                                             if(any(tmp2))
                                             {
                                                     return(data.frame(genes=rownames(tmp),relation="TSS"))
                                             } else
                                             {
                                                     return(data.frame(genes=rownames(tmp),relation="non_TSS"))
                                             }
                                     } else {
                                             tmp2 <- grepl('TSS',colnames(tmp))
                                             if (sum(tmp2)==1)
                                             {
                                                     relation_to_gene <- ifelse(tmp[,tmp2]>0,"TSS","non_TSS")
                                                     return(data.frame(genes=rownames(tmp),relation=relation_to_gene))
                                             
                                             } else if (any(tmp2))
                                             {
                                                     relation_to_gene.tmp <- ifelse(tmp[,tmp2]>0,"TSS","non_TSS")
                                                     relation_to_gene <- sapply(1:nrow(relation_to_gene.tmp),function(n){ ifelse(any(relation_to_gene.tmp[n,]=="TSS"),"TSS","non_TSS")})

                                                     return(data.frame(genes=rownames(tmp),relation=relation_to_gene))

                                             } else {
                                                     return(data.frame(genes=rownames(tmp),relation="non_TSS"))
                                             }

                                                     

                                     }}
                                     )

save(CGI_Genes_analysis,file="processed/fData/CGI_Genes_analysis.RData")

tata <- Reduce('rbind',CGI_Genes_analysis)

GeneList <- na.omit(unique(tata[,1]))

spanningTSS <- sapply(1:length(GeneList), function(n)
                      {
                              print(paste0(n,'/',length(GeneList)))
                              any(tata[tata[,1]==GeneList[n],"relation"]=="TSS")
                      })





