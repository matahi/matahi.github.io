#cut.names <- function(S){substring(S,1,12)} # We will cut the names of CancerousTCGA to the first 12 characters to match the names in the Clinical Annotations File

analyze_GE_CNV <- function (DiseaseName,Type) {
        GE.dat <- get(load(paste0('processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',Type,'Level3GE_processed.RData')))
        Meth.dat <- get(load(paste0('processed/Methylation/TCGA/',DiseaseName,'/',Type,'Level2_processed.RData')))
        CNV.Hg18.dat <- get(load(paste0('processed/CNV/TCGA/',DiseaseName,'/',Type,'Level3CNV_Hg18.RData')))
        CNV.Hg19.dat <- get(load(paste0('processed/CNV/TCGA/',DiseaseName,'/',Type,'Level3CNV_Hg19.RData')))
        CNV.noCNV_Hg18.dat <- get(load(paste0('processed/CNV/TCGA/',DiseaseName,'/',Type,'Level3CNV_nocnv_Hg18.RData')))
        CNV.noCNV_Hg19.dat <- get(load(paste0('processed/CNV/TCGA/',DiseaseName,'/',Type,'Level3CNV_nocnv_Hg19.RData')))

        GE.Names <- sapply(colnames(GE.dat),function(S) {substring(S,1,12)})
        Meth.Names <- sapply(colnames(Meth.dat),function(S) {substring(S,1,12)}) 
        CNV.Names <- sapply(names(CNV.Hg19.dat), function(S) {substring(S,1,12)})

        CommonNames <- intersect(CNV.Names, GE.Names)
        print(paste0("Disease: ",DiseaseName))
        print(paste0("Type: ",Type))
        print(paste0('Taille Initiale: ', length(GE.Names)))
        print(paste0('Taille Finale: ', length(CommonNames)))

        # Sometimes several tissues are sampled from the same patient which leads to having 
        # for example more Meth.Names matching CommonNames since the first 12 string define only the patients
        # To simplify the analysis, we only take the first one.
        MethNew <- Meth.dat[,match(CommonNames, Meth.Names)]
        GENew <- GE.dat[,match(CommonNames, GE.Names)]
        CNV.Hg18.New <- CNV.Hg18.dat[match(CommonNames, CNV.Names)]
        CNV.Hg19.New <- CNV.Hg18.dat[match(CommonNames, CNV.Names)]

        # CNV.Names.New <- sapply(names(CNV.Hg19.New), function(S){substring(S,1,12)})
        # GE.Names.New <- sapply(colnames(GENew), function(S){substring(S,1,12)})
        # all(CNV.Names.New==GE.Names.New)

        CNV.noCNV_Hg18.New <- CNV.noCNV_Hg18.dat[match(CommonNames, CNV.Names)]
        CNV.noCNV_Hg19.New <- CNV.noCNV_Hg19.dat[match(CommonNames, CNV.Names)]

        assign(paste0(DiseaseName,".",Type), MethNew)
        assign(paste0(DiseaseName,".",Type,"GE"), GENew)

        # Saving
        save(list=eval(paste0(DiseaseName,".",Type)),file=paste0("processed/Methylation/TCGA/",DiseaseName,"/",Type,"Level2_processed_bis.RData"))
        save(list=eval(paste0(DiseaseName,".",Type,"GE")),file=paste0("processed/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"Level3GE_processed_bis.RData"))

        save(CNV.Hg18.New,file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level3_CNV_Hg18_processed_bis.RData"))
        save(CNV.Hg19.New,file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level3_CNV_Hg19_processed_bis.RData"))
        save(CNV.noCNV_Hg18.New,file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level3_CNV_nocnv_Hg18_processed_bis.RData"))
        save(CNV.noCNV_Hg19.New,file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level3_CNV_nocnv_Hg19_processed_bis.RData"))

}

