Beta_to_CGI <- function(Betas)
{
        require(reshape)

        CGIs <- list()
        for (k in 1:length(CpGIslands)){
                print(k)
                probes <- rownames(fData450K[fData450K[,"UCSC_CpG_Islands_Name"]==CpGIslands[k],])
                Betas.df <- Betas[probes,]
                Betas.df <- melt(Betas.df)
                CGIs[[k]] <- data.frame(betas=Betas.df$value,patient=Betas.df$variable,location=fData450K[probes,"MAPINFO"],IslandBegin=fData450K[probes,"IslandBegin"],IslandEnd=fData450K[probes,"IslandEnd"],chr=fData450K[probes,"CHR"])
        }

        names(CGIs) <- CpGIslands

        return(CGIs)
}
