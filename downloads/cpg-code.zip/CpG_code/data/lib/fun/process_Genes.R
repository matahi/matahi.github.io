process_Genes = function (DiseaseName, Type, Level,processed=F) {
        if (processed) {
                proc <- '_processed'
        } else {
                proc <- ''
        }

        load(paste0('processed/Methylation/TCGA/',DiseaseName,'/',Type,'Level',Level,proc,'.RData'))

        Dat <- eval(parse(text=paste0(DiseaseName,'.',Type)))

        Genes <- list()
        for (i in 1:length(GeneList)){
                print(paste0(i,'/',length(GeneList)))
                Pos <- GeneProbesList[[i]]

                Probes <- rownames(fData450K[Pos,])
                Genes[[i]] <- Dat[Probes,,drop=F]
        }

        names(Genes) <- GeneList

        assign(paste0(DiseaseName,'.',Type,'Genes'),Genes)

        save(list=eval(paste0(DiseaseName,'.',Type,'Genes')), file=paste0('processed/Methylation/TCGA/',DiseaseName,'/',Type,'Genes',proc,'.RData'))


}
