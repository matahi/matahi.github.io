analyze_Genes_CNV <- function(DiseaseName,Type)
{
        require('GenomicRanges')
        # Hg19.CNV <- get(load(paste0('processed/CNV/TCGA/',DiseaseName,'/',Type,'Level3_CNV_Hg19.RData')))
        Hg19.CNV <- get(load(paste0('processed/CNV/TCGA/',DiseaseName,'/',Type,'Level3_CNV_Hg19_processed_bis.RData')))
        gene.gr <- get(load('../big_data/GenePosition.RData'))

        Dat <- Hg19.CNV[[1]]
        
        Dat$Chromosome <- factor(Dat$Chromosome, levels= c(1:22,"X","Y"))

        library(ggplot2)
        ggplot(Dat) + geom_segment(aes(x=Start,xend=End, y=Segment_Mean, yend=Segment_Mean))+ facet_grid( ~ Chromosome,scales="free_x") + ylim(-1.5,1)

        ######################
        Hg19.CNV.17 <-lapply(1:length(Hg19.CNV), function(k){ return(Hg19.CNV[[k]][  Hg19.CNV[[k]]$Chromosome=="17",   ])})
        Dat.All <- Reduce('rbind',Hg19.CNV.17)
        Patients.All <- sapply(Hg19.CNV.17,nrow)
        Patients <- rep(names(Hg19.CNV), Patients.All)


        Patients.CNV <- substring(names(Hg19.CNV), 1,12)

        Clinical.processed <- get(load('../big_data/BRCA_Clinical_Processed.RData'))
        Patients.Clinical <- substring(rownames(Clinical.processed),1,12)

        Clinical.processed.bis <- Clinical.processed[match(Patients.CNV, Patients.Clinical),]
        HER2 <- rep(Clinical.processed.bis$HER2, Patients.All)


        Dat.All <- cbind(Dat.All, Patients, HER2)

        Dat.All$Chromosome <- factor(Dat.All$Chromosome, levels= c(1:22,"X","Y"))

        dat.vline <- data.frame(x=37844167)

        ggplot(Dat.All) + geom_segment(aes(x=Start,xend=End, y=Segment_Mean, yend=Segment_Mean, colour=factor(HER2))) + ylim(-1.5,1) + geom_vline(aes(xintercept = x), data = dat.vline) 
        ##########################
        CNV.Gene <- get(load('processed/CNV/TCGA/BRCA/CancerousCNV_Genes.RData'))
        CNV.Gene.ERBB2 <- CNV.Gene["ERBB2",]
        Patients.Name <- substring(colnames(CNV.Gene),1,12)

        CNV.cbioportal <- read.csv('~/Desktop/ERBB2_CNV.txt',sep="\t",header=T)

        Patients.Common <- intersect(Patients.Name, CNV.cbioportal$COMMON)

        CNV.Gene.ERBB2.processed <- CNV.Gene["ERBB2",match(Patients.Common,Patients.Name)]
        CNV.cbioportal.processed <- CNV.cbioportal[match(Patients.Common, CNV.cbioportal$COMMON),]

        qplot(CNV.Gene.ERBB2.processed, CNV.cbioportal.processed$ERBB2) + geom_abline(a=0,b=1,col="red")

        Clinical.processed <- get(load('../big_data/BRCA_Clinical_Processed.RData'))
        Patients.Clinical <- substring(rownames(Clinical.processed),1,12)

        Clinical.processed.bis <- Clinical.processed[match(Patients.Common, Patients.Clinical),]

        Dat.df <- data.frame(TCGA=CNV.Gene.ERBB2.processed, CBIOPORTAL = CNV.cbioportal.processed$ERBB2, HER2_bis=Clinical.processed.bis$HER2_bis, HER2 = Clinical.processed.bis$HER2)

        pdf('~/Desktop/TCGA_CBIOPORTAL.pdf')
        ggplot(Dat.df) + geom_point(aes(x=TCGA,y=CBIOPORTAL, colour=factor(HER2_bis)))
        dev.off()


        ########################





        

        Hg19.CNV.gene <- sapply(1:length(Hg19.CNV), function(n)
                                {
                                        print(paste0(n,'/',length(Hg19.CNV)))
                                        Dat <- Hg19.CNV[[n]]

                                        gene.cnv <- sapply(1:length(gene.gr), function(k)
                                                           {
                                                                   # print(k)
                                                                   chr <- substring(as.character(seqnames(gene.gr)[k]),4,nchar(as.character(seqnames(gene.gr)[k]))) # Find the chromosome (remove the chr part)
                                                                   Begin <- ifelse(as.character(strand(gene.gr)[k])=="+",start(gene.gr[k]),end(gene.gr[k])) # Find the beginning of the chromosome (depending of strand/anti-strand)
                                                                   Index <- which((Dat$Chromosome==chr)&(Dat$Start<=Begin)&(Dat$End>Begin))
                                                                   if (length(Index)==0)
                                                                   {
                                                                           return(NA)
                                                                   } else if (length(Index)==1)
                                                                   {
                                                                           return(Dat[Index,"Segment_Mean"])
                                                                   } else if (length(Index)>1)
                                                                   {
                                                                           print('Error ! Returning first index')
                                                                           return(Dat[Index[1],"Segment_Mean"])
                                                                   }
                                                           })
                                })

        colnames(Hg19.CNV.gene) <- names(Hg19.CNV)
        rownames(Hg19.CNV.gene) <- names(gene.gr)
        
        save(Hg19.CNV.gene, file=paste0("processed/CNV/TCGA/", DiseaseName,"/",Type,'CNV_Genes.RData'))
}
