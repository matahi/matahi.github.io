process_CpGIslands = function (DiseaseName, Type, Level,processed=F,bis=F) {
        if (processed) {
                proc <- '_processed'
        } else {
                proc <- ''
        }

        if (bis) {
                proc <- '_processed_bis'
        } else {
        }

        if (DiseaseName != "ES")
        {
                Dat <- get(load(paste0('processed/Methylation/TCGA/',DiseaseName,'/',Type,'Level',Level,proc,'.RData')))
        } else {
                Dat <- get(load('processed/Methylation/TCGA/ES/ES.RData'))
        }

        load('processed/fData/CpGIslands.RData')
        load('processed/fData/fData450K_ordered.RData')

        CGIs <- list()
        for (k in 1:length(CpGIslands)){
                print(paste0(k,'/',length(CpGIslands)))
                Probes <- rownames(fData450K[fData450K$UCSC_CpG_Islands_Name==CpGIslands[k],])
                CGIs[[k]] <- Dat[Probes,,drop=FALSE]
        }

        names(CGIs) <- CpGIslands

        assign(paste0(DiseaseName,'.',Type,'CGIs'),CGIs)

        save(list=eval(paste0(DiseaseName,'.',Type,'CGIs')), file=paste0('processed/Methylation/TCGA/',DiseaseName,'/',Type,'CGIs',proc,'.RData'))

}
