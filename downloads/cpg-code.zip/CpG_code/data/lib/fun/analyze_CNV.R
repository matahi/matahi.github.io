analyze_CNV <- function (DiseaseName,Type,Level=2) {
        ## Find Data Names
        Manifest <- read.table(paste0("raw/CNV/TCGA/",DiseaseName,"/",Type,"/file_manifest.txt"), sep="\t", header=TRUE)
        Manifest$Barcode <- as.character(Manifest$Barcode)
        FileNames <- Manifest[which(Manifest$Level==Level),"File.Name"]
        FileConcordance <- read.table(paste0("raw/CNV/TCGA/",DiseaseName,"/",Type,"/FILE_SAMPLE_MAP.txt"), colClasses=c('character','character'),sep="\t", header=TRUE)
        ### FileConcordance??

        FileNames.Hg18 <- grep("\\.hg18", FileNames)
        FileNames.nocnv_Hg18 <- grep("nocnv_hg18", FileNames)
        FileNames.Hg19 <- grep("\\.hg19", FileNames)
        FileNames.nocnv_Hg19 <- grep("nocnv_hg19", FileNames)

        ### Preprocess
        Dataset.Hg18 <- vector('list', length(FileNames.Hg18))
        Dataset.Hg19 <- vector('list', length(FileNames.Hg19))
        Dataset.nocnv_Hg18 <- vector('list', length(FileNames.nocnv_Hg18))
        Dataset.nocnv_Hg19 <- vector('list', length(FileNames.nocnv_Hg19))

        ### Process
        if (Level==2) {
                print(paste("processing", DiseaseName, Type,":")) 
                for (k in 1:length(FileNames))
                {
                        print(paste0(k,"/",length(FileNames)))

                        ## Read Data
                        #Data <- read.table(paste0("raw/Methylation/TCGA/",DiseaseName,"/",Type,"/DNA_Methylation/JHU_USC__HumanMethylation450/Level_",Level,"/",FileNames[k]), dec='.', sep="\t", header=TRUE,row.names=1,skip=1)

                        ## Compute Beta_Value
                        #Beta_Value <- as.matrix(Data[,"Methylated_Intensity"]/(Data[,"Methylated_Intensity"]+Data[,"Unmethylated_Intensity"]))
                        #rownames(Beta_Value) <- rownames(Data)

                        ## Compute P_Value
                        #P_Value <- as.matrix(Data[,"Detection_P_value"])
                        #rownames(P_Value) <- rownames(Data)

                        ## Find name
                        #SampleID <- read.table(paste0("raw/Methylation/TCGA/",DiseaseName,"/",Type,"/DNA_Methylation/JHU_USC__HumanMethylation450/Level_",Level,"/",FileNames[k]), nrows=1,  sep="\t")

                        ## Create Data
                        #Dataset[,k] <- Beta_Value[OrderCpG,1]
                        #colnames(Dataset)[k] <- as.character(SampleID[1,2])
                        ##colnames(Dataset)[k] <- cut.names(as.character(SampleID[1,2]))

                        #P_Value.Dataset[,k] <- P_Value[OrderCpG,1]
                        #colnames(P_Value.Dataset)[k] <- as.character(SampleID[1,2])
                        ##colnames(P_Value.Dataset)[k] <- cut.names(as.character(SampleID[1,2]))
                }
        } else if (Level==3) {

                ## Hg18
                for (k in 1:(length(FileNames.Hg18)))
                {
                        print(k)
                        Data.Hg18 <- read.table(paste0("raw/CNV/TCGA/",DiseaseName,"/",Type,"/CNV_SNP_Array/BI__Genome_Wide_SNP_6/Level_",Level,"/",FileNames[FileNames.Hg18[k]]), colClasses=c('character','character','numeric','numeric','numeric','numeric'),dec='.', sep="\t", header=TRUE, quote = "")


                        SampleID.Hg18 <- FileConcordance[FileConcordance[,"filename"]==FileNames[FileNames.Hg18[k]], "barcode.s."]

                        Dataset.Hg18[[k]] <- Data.Hg18[,2:6]

                        names(Dataset.Hg18)[k]<- SampleID.Hg18
                }

                ## Hg19
                for (k in 1:(length(FileNames.Hg19)))
                {
                        print(k)
                        Data.Hg19 <- read.table(paste0("raw/CNV/TCGA/",DiseaseName,"/",Type,"/CNV_SNP_Array/BI__Genome_Wide_SNP_6/Level_",Level,"/",FileNames[FileNames.Hg19[k]]), colClasses=c('character','character','numeric','numeric','numeric','numeric'),dec='.', sep="\t", header=TRUE, quote = "")


                        SampleID.Hg19 <- FileConcordance[FileConcordance[,"filename"]==FileNames[FileNames.Hg19[k]], "barcode.s."]
                        #
                        SampleID.Hg19.Manifest <- Manifest[Manifest[,"File.Name"]==FileNames[FileNames.Hg19[k]], "Barcode"]

                        print(SampleID.Hg19==SampleID.Hg19.Manifest)

                        Dataset.Hg19[[k]] <- Data.Hg19[,2:6]

                        names(Dataset.Hg19)[k]<- SampleID.Hg19.Manifest
                }

                ## nocnv_Hg18
                for (k in 1:(length(FileNames.nocnv_Hg18)))
                {
                        print(k)
                        Data.nocnv_Hg18 <- read.table(paste0("raw/CNV/TCGA/",DiseaseName,"/",Type,"/CNV_SNP_Array/BI__Genome_Wide_SNP_6/Level_",Level,"/",FileNames[FileNames.nocnv_Hg18[k]]), colClasses=c('character','character','numeric','numeric','numeric','numeric'),dec='.', sep="\t", header=TRUE, quote = "")


                        SampleID.nocnv_Hg18 <- FileConcordance[FileConcordance[,"filename"]==FileNames[FileNames.nocnv_Hg18[k]], "barcode.s."]

                        Dataset.nocnv_Hg18[[k]] <- Data.nocnv_Hg18[,2:6]

                        names(Dataset.nocnv_Hg18)[k]<- SampleID.nocnv_Hg18
                }

                ## nocnv_Hg19
                for (k in 1:(length(FileNames.nocnv_Hg19)))
                {
                        print(k)
                        Data.nocnv_Hg19 <- read.table(paste0("raw/CNV/TCGA/",DiseaseName,"/",Type,"/CNV_SNP_Array/BI__Genome_Wide_SNP_6/Level_",Level,"/",FileNames[FileNames.nocnv_Hg19[k]]), colClasses=c('character','character','numeric','numeric','numeric','numeric'),dec='.', sep="\t", header=TRUE, quote = "")


                        SampleID.nocnv_Hg19 <- FileConcordance[FileConcordance[,"filename"]==FileNames[FileNames.nocnv_Hg19[k]], "barcode.s."]

                        Dataset.nocnv_Hg19[[k]] <- Data.nocnv_Hg19[,2:6]

                        names(Dataset.nocnv_Hg19)[k]<- SampleID.nocnv_Hg19
                }


        }

        # Post-processing : change the name of the variables
        assign(paste0(DiseaseName,".",Type,"CNV_Hg18"), Dataset.Hg18)
        assign(paste0(DiseaseName,".",Type,"CNV_Hg19"), Dataset.Hg19)
        assign(paste0(DiseaseName,".",Type,"CNV_nocnv_Hg18"), Dataset.nocnv_Hg18)
        assign(paste0(DiseaseName,".",Type,"CNV_nocnv_Hg19"), Dataset.nocnv_Hg19)

        if (Level==2) {
                assign(paste0(DiseaseName,".",Type,"CNV.P_Value"), P_Value.Dataset)
                save(list=eval(paste0(DiseaseName,".",Type,"CNV.P_Value")),file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level",Level,"CNV.P_Value.RData"))
        }

        # Saving
        save(list=eval(paste0(DiseaseName,".",Type,"CNV_Hg18")),file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level",Level,"CNV_Hg18.RData"))
        save(list=eval(paste0(DiseaseName,".",Type,"CNV_Hg19")),file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level",Level,"CNV_Hg19.RData"))
        save(list=eval(paste0(DiseaseName,".",Type,"CNV_nocnv_Hg18")),file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level",Level,"CNV_nocnv_Hg18.RData"))
        save(list=eval(paste0(DiseaseName,".",Type,"CNV_nocnv_Hg19")),file=paste0("processed/CNV/TCGA/",DiseaseName,"/",Type,"Level",Level,"CNV_nocnv_Hg19.RData"))

}

