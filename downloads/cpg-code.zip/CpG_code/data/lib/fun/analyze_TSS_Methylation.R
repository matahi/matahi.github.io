analyze_TSS_Methylation <- function (DiseaseName,Type,Level=c(2,3),processed=T) {

        if (processed)
        {
                processed <- "_processed"
        } else
        {
                processed <- ""
        }

        Meth <- load(paste0('processed/Methylation/TCGA/',DiseaseName,'/',Type,'Level',Level[1],processed,'.RData'))
        Meth.dat <- get(Meth)

        MethNew <- lapply(1:length(Assoc.MethGenes), function(n){ print(paste0(n,'/',length(Assoc.MethGenes)))
                                                                  Meth.dat[Assoc.MethGenes[[n]],]  } )
        
        assign(paste0(DiseaseName,".",Type,"TSS"), MethNew)

        # Saving
        save(list=eval(paste0(DiseaseName,".",Type,"TSS")),file=paste0("processed/Methylation/TCGA/",DiseaseName,"/",Type,"TSS.RData"))

}

