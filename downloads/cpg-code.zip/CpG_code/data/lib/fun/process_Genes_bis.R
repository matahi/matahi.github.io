process_Genes_bis = function (GeneList,fData450K) {

        Probes <- lapply(1:length(GeneList),function(Gene){GeneName <- GeneList[Gene]; 
                                                           grep(paste0('^',GeneName,'$','|', # Contains only the genename
                                                                       '^',GeneName,';','|', # is of the form 'GeneName;...'
                                                                       ';',GeneName,';','|', # is of the form '...;GeneName;...'
                                                                       ';',GeneName,'$'),    # is of the form '...;GeneName'
                                                                       fData450K$UCSC_RefGene_Name)})

        names(Probes) <- GeneList

        return(Probes)

}

