process_BRCA_clinical = function (Preprocessed_clinical,ClinicalInfo,NewClinicalInfo) 
{

        # Preprocessed_clinical <- BRCA.Clinical
        # ClinicalInfo <- c(ClinicalInfo,SurvivalInfo)
        # NewClinicalInfo <- c(NewClinicalInfo, NewSurvivalInfo)

        # Clinical_dataTCGA <- Preprocessed_clinical[,ClinicalInfo]

        colnames(Clinical_dataTCGA) <- NewClinicalInfo 

        # Processing 
        Age_diagnosis <- Preprocessed_clinical[,"age_at_initial_pathologic_diagnosis"]
        Age <- Preprocessed_clinical[,"days_to_birth"]
        LastFUp <- preprocessed_clinical[,"days_to_last_followup"]

        ##
        # ER
        Clin.Dat <- Preprocessed_clinical[,"breast_carcinoma_estrogen_receptor_status"]
        tmp <- as.character(Clin.Dat)
        tmp[na.omit(which(Clin.Dat=="Positive"))] <- 1
        tmp[na.omit(which(Clin.Dat=="Negative"))] <- 0
        tmp[is.na(Clin.Dat)] <- NA
        tmp[na.omit(which(!(Clin.Dat %in% c('Positive','Negative'))))] <- NA

        # PR
        Clin.Dat <- Preprocessed_clinical[,"breast_carcinoma_progesterone_receptor_status"]
        tmp <- as.character(Clin.Dat)
        tmp[na.omit(which(Clin.Dat=="Positive"))] <- 1
        tmp[na.omit(which(Clin.Dat=="Negative"))] <- 0
        tmp[is.na(Clin.Dat)] <- NA
        tmp[na.omit(which(!(Clin.Dat %in% c('Positive','Negative'))))] <- NA

        # HER2
        Clin.Dat <- Preprocessed_clinical[,"her2_immunohistochemistry_level_results"]

        Clinical_dataTCGA$Size <- as.character(Clinical_dataTCGA$Size)


        ##
        Clinical_dataTCGA[which(Clinical_dataTCGA$HER2=="3+"),"HER2"] <- 1
        Clinical_dataTCGA[which(Clinical_dataTCGA$HER2=="2+"),"HER2"] <- 0
        Clinical_dataTCGA[which(Clinical_dataTCGA$HER2=="1+"),"HER2"] <- 0
        Clinical_dataTCGA[which(Clinical_dataTCGA$HER2=="0"),"HER2"] <- 0
        Clinical_dataTCGA[which((Clinical_dataTCGA$HER2!="1")&(Clinical_dataTCGA$HER2!="0")),"HER2"] <- NA

        ###
        # Size
        Clinical_dataTCGA[which(Clinical_dataTCGA$Size %in% c("T1","T1a","T1b","T1c")   ),"Size"] <- "<= 2"
        Clinical_dataTCGA[which(Clinical_dataTCGA$Size %in% c("T2","T2b","T3","T3a","T4","T4b","T4d")   ),"Size"] <- "> 2"
        Clinical_dataTCGA[which(Clinical_dataTCGA$Size == "TX"   ),"Size"] <- NA

        # LymphNode 
        Clinical_dataTCGA$LymphNodeCount <- as.character(Clinical_dataTCGA$LymphNodeCount)
        Clinical_dataTCGA$LymphNodeCount[Clinical_dataTCGA$LymphNodeCount == "[Not Available]"] <- NA
        Clinical_dataTCGA$LymphNodeCount <- as.numeric(Clinical_dataTCGA$LymphNodeCount)
        Clinical_dataTCGA$LymphNodeCount_Class <- Clinical_dataTCGA$LymphNodeCount

        Clinical_dataTCGA$LymphNodeCount_Class[(Clinical_dataTCGA$LymphNodeCount >0)] <- "Positive"
        Clinical_dataTCGA$LymphNodeCount_Class[(Clinical_dataTCGA$LymphNodeCount ==0) ] <- "Negative"

        # Meta
        Clinical_dataTCGA$Metastasis <- as.character(Clinical_dataTCGA$Metastasis)

        Clinical_dataTCGA$Metastasis[(Clinical_dataTCGA$Metastasis == "M1")] <- "Positive"
        Clinical_dataTCGA$Metastasis[(Clinical_dataTCGA$Metastasis %in% c("M0","MX","cM0 (i+)")   ) ] <- "Negative"


        return(Clinical_dataTCGA)

}

