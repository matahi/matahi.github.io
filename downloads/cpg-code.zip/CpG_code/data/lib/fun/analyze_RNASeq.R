#cut.names <- function(S){substring(S,1,12)} # We will cut the names of CancerousTCGA to the first 12 characters to match the names in the Clinical Annotations File

analyze_RNASeq <- function (DiseaseName,Type,Level=3) {
        ## Find Data Names
        Manifest <- read.table(paste0("raw/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"/file_manifest.txt"), sep="\t", header=TRUE)
        FileNames <- Manifest[(Manifest$Level==Level),"File.Name"]
        FileNames <- FileNames[grep('gene',FileNames)]


        ### Preprocess
        Dataset <- matrix(0, nrow= 20532, ncol= length(FileNames)) 
        colnames(Dataset) <- colnames(Dataset,do.NULL=FALSE)
        #         P_Value.Dataset <- matrix(0,nrow=17814, ncol=length(FileNames))
        #         colnames(P_Value.Dataset) <- colnames(P_Value.Dataset,do.NULL=FALSE)

        ### Process
        if (Level==2) {
                print(paste("processing", DiseaseName, Type,":")) 
                for (k in 1:length(FileNames))
                {
                        print(paste0(k,"/",length(FileNames)))

                        ## Read Data
                        #Data <- read.table(paste0("raw/Methylation/TCGA/",DiseaseName,"/",Type,"/DNA_Methylation/JHU_USC__HumanMethylation450/Level_",Level,"/",FileNames[k]), dec='.', sep="\t", header=TRUE,row.names=1,skip=1)

                        ## Compute Beta_Value
                        #Beta_Value <- as.matrix(Data[,"Methylated_Intensity"]/(Data[,"Methylated_Intensity"]+Data[,"Unmethylated_Intensity"]))
                        #rownames(Beta_Value) <- rownames(Data)

                        ## Compute P_Value
                        #P_Value <- as.matrix(Data[,"Detection_P_value"])
                        #rownames(P_Value) <- rownames(Data)

                        ## Find name
                        #SampleID <- read.table(paste0("raw/Methylation/TCGA/",DiseaseName,"/",Type,"/DNA_Methylation/JHU_USC__HumanMethylation450/Level_",Level,"/",FileNames[k]), nrows=1,  sep="\t")

                        ## Create Data
                        #Dataset[,k] <- Beta_Value[OrderCpG,1]
                        #colnames(Dataset)[k] <- as.character(SampleID[1,2])
                        ##colnames(Dataset)[k] <- cut.names(as.character(SampleID[1,2]))

                        #P_Value.Dataset[,k] <- P_Value[OrderCpG,1]
                        #colnames(P_Value.Dataset)[k] <- as.character(SampleID[1,2])
                        ##colnames(P_Value.Dataset)[k] <- cut.names(as.character(SampleID[1,2]))
                }
        } else if (Level==3) {
                if (DiseaseName == "BRCA")
                {
                        for (k in 1:(length(FileNames)))
                        {
                                print(k)
                                Data <- read.table(paste0("raw/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"/RNASeq/UNC__IlluminaHiSeq_RNASeq/Level_",Level,"/",FileNames[k]), dec='.', sep="\t", quote = "",header=T)
                                SampleID <- substring(FileNames[k],14,41) 
                                #Data[Data[,2]=='null',2] <- NA
                                Data[,4] <- as.numeric(Data[,4])
                                Dataset[,k] <- Data[,4]
                                colnames(Dataset)[k] <- SampleID

                        }
                } else if (DiseaseName == "Colon")
                {
                        for (k in 1:length(FileNames))
                        {
                                print(k)
                                Data <- read.table(paste0("raw/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"/RNASeq/UNC__IlluminaGA_RNASeq/Level_",Level,"/",FileNames[k]), dec='.', sep="\t", quote = "",header=T)
                                SampleID <- substring(FileNames[k],14,41) 
                                #Data[Data[,2]=='null',2] <- NA
                                Data[,4] <- as.numeric(Data[,4])
                                Dataset[,k] <- Data[,4]
                                colnames(Dataset)[k] <- SampleID
                        }

                } else if (DiseaseName == "LUAD")
                {
                        for (k in 1:length(FileNames))
                        {
                                print(k)
                                Data <- read.table(paste0("raw/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"/RNASeq/UNC__IlluminaHiSeq_RNASeq/Level_",Level,"/",FileNames[k]), dec='.', sep="\t", quote = "",header=T)
                                SampleID <- substring(FileNames[k],14,41) 
                                #Data[Data[,2]=='null',2] <- NA
                                Data[,4] <- as.numeric(Data[,4])
                                Dataset[,k] <- Data[,4]
                                colnames(Dataset)[k] <- SampleID
                        }
                }
                rownames(Dataset) <- Data[,1]
        }

        # Post-processing : change the name of the variables
        assign(paste0(DiseaseName,".",Type,"GE"), Dataset)

        if (Level==2) {
                assign(paste0(DiseaseName,".",Type,"GE.P_Value"), P_Value.Dataset)
                save(list=eval(paste0(DiseaseName,".",Type,"GE.P_Value")),file=paste0("processed/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"Level",Level,"GE.P_Value.RData"))
        }

        # Saving
        save(list=eval(paste0(DiseaseName,".",Type,"GE")),file=paste0("processed/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"Level",Level,"GE.RData"))

}

