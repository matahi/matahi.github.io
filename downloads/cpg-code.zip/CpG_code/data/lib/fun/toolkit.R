# DistancetoSet: gives the distance between a probe and a CpG Island {{{1
DistancetoSet <- function(A,B)
{
        if (is.na(A)){
                q <- NA
        } else if (sum(is.na(B))>=1){
                q <- NA
        } else if (A < min(B)){
                q <- A-min(B)
        } else if (A > max(B)){
                q <- A-max(B)
        } else if ((A>=min(B))&(A<=max(B))){
                q <- (A-min(B))/(max(B)-min(B))
        } else {
                q <- NA
        }
        return(q)
}

# IslandMAPINFO : reworks the featureData to have num instead of chars {{{1
IslandMAPINFO <- function(fData450K)
{
        OldInfo <- fData450K[,"UCSC_CpG_Islands_Name"]
        TypeInfo <- fData450K[,"Relation_to_UCSC_CpG_Island"]
        MAPInfo <- fData450K[,"MAPINFO"]
        NewInfo <- NULL
        NewInfo$IslandMAPINFO <- matrix(0,nrow=length(OldInfo),ncol=2)
        NewInfo$DistanceIsland <- rep(0,length(OldInfo))
        for (k in 1:length(OldInfo))
        {
                print(k)
                A <- OldInfo[k]
                Pos1 <- gregexpr(":",A)[[1]][1]
                Pos2 <- gregexpr("-",A)[[1]][1]
                NewInfo$IslandMAPINFO[k,]<- c(as.numeric(substr(A,Pos1+1,Pos2-1)),as.numeric(substr(A,Pos2+1,nchar(A))))
                NewInfo$DistanceIsland[k] <- DistancetoSet(MAPInfo[k],NewInfo$IslandMAPINFO[k,])
        }
        return(NewInfo)
}

# IslandSize : Calculates the size of CpGIslands {{{1
IslandSize <- function(CpGIslands){
        NewInfo <- rep(0,length(CpGIslands))
        for (k in 1:length(CpGIslands))
        {
                print(k)
                A <- CpGIslands[k]
                Pos1 <- gregexpr(":",A)[[1]][1]
                Pos2 <- gregexpr("-",A)[[1]][1]
                NewInfo[k] <- as.numeric(substr(A,Pos2+1,nchar(A))) -  as.numeric(substr(A,Pos1+1,Pos2-1))
        }
        return(NewInfo)
}

