Calculate_DistToTSS <- function(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
{
        if (Gene.Strand=="+")
        {

                if (Gene.txStart < Gene.CGIBegin)
                {
                        print('TSS is before the CGI') # Negative Distance to TSS
                        Gene.distToTSS <- -(Gene.CGIBegin - Gene.txStart)
                } else if ((Gene.txStart > Gene.CGIBegin)&(Gene.txStart < Gene.CGIEnd))
                {
                        print('TSS is inside the CGI') # Null Distance
                        Gene.distToTSS <- 0
                } else if (Gene.txStart > Gene.CGIEnd)
                {
                        print('TSS is after the CGI') # Positive Distance to TSS
                        Gene.distToTSS <- - (Gene.CGIEnd - Gene.txStart)
                }
        } else if (Gene.Strand=="-")
        {
                if (Gene.txStart < Gene.CGIBegin)
                {
                        print('TSS is before the CGI') # Negative Distance to TSS
                        Gene.distToTSS <- -(Gene.CGIBegin - Gene.txStart)
                } else if ((Gene.txStart > Gene.CGIBegin)&(Gene.txStart < Gene.CGIEnd))
                {
                        print('TSS is inside the CGI') # Null Distance
                        Gene.distToTSS <- 0
                } else if (Gene.txStart > Gene.CGIEnd)
                {
                        print('TSS is after the CGI') # Positive Distance to TSS
                        Gene.distToTSS <- - (Gene.CGIEnd - Gene.txStart)
                }
        } else
        {
                Gene.distToTSS <- NA
        }

        return(Gene.distToTSS)
}
