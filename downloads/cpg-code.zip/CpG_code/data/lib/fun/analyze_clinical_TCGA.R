position_follow_up <- function(c){
        grepl("follow_up",c)
}

position_patient <- function(c){
        grepl("patient",c)
}

analyze_clinical_TCGA = function (DiseaseName,Center) {
        # DiseaseName <- "BRCA"
        # DiseaseName <- "Colon"
        # DiseaseName <- "LUAD"

        # Center <- "Biotab"

        ## Find Data Names
        Manifest <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/","file_manifest.txt"), sep="\t", header=TRUE)
        FileNames <- Manifest[which(Manifest$Center==Center),"File.Name"]

        ### Preprocess
        k_patient <- which(lapply(FileNames, position_patient)==TRUE)
        k_FollowUp <- which(lapply(FileNames, position_follow_up)==TRUE)

        ### Process
        if (DiseaseName=="tata") ## Obsolete now
        {
                # Careful ! Had to remove all the ' and :
                Data_patient <- read.table("raw/ClinicalAnnotations/TCGA/BRCA/Clinical/Biotab/clinical_patient_brca.txt" ,row.names=1, dec='.', sep="\t", fill=TRUE, header=TRUE)
                Data_FollowUp.1 <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/",Center,"/",FileNames[k_FollowUp[1]]) ,dec='.', sep="\t", header=TRUE)
                Data_FollowUp.2 <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/",Center,"/",FileNames[k_FollowUp[2]]) ,dec='.', sep="\t", header=TRUE)

                rownames(Data_patient) <- Data_patient[,1]
                # Post-processing : change the name of the variables
                assign(paste0(DiseaseName,".Clinical"), Data_patient)
                assign(paste0(DiseaseName,".FollowUp1"), Data_FollowUp.1)
                assign(paste0(DiseaseName,".FollowUp2"), Data_FollowUp.2)


                ## Saving
                save(list=eval(paste0(DiseaseName,".Clinical")),file=paste0("processed/ClinicalAnnotations/TCGA/",DiseaseName,".Clinical.RData"))
                save(list=eval(paste0(DiseaseName,".FollowUp1")),file=paste0("processed/ClinicalAnnotations/TCGA/",DiseaseName,".FollowUp1.RData"))
                save(list=eval(paste0(DiseaseName,".FollowUp2")),file=paste0("processed/ClinicalAnnotations/TCGA/",DiseaseName,".FollowUp2.RData"))

        } else {
                # Data_patient <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/",Center,"/",FileNames[k_patient]) ,dec='.', sep="\t", header=TRUE)
                ###  !!!!! Careful for breast remove all the ' and 
                if (DiseaseName == "LUAD")
                {
                        Data_patient_header <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_patient]) ,dec='.', sep="\t", fill=T,nrows=1, header=F,colClasses="character")
                        Data_patient <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_patient]) ,dec='.', sep="\t", fill=T,skip=3, header=F)
                        colnames(Data_patient) <- as.character(Data_patient_header)

                        Data_FollowUp_header <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_FollowUp]) ,dec='.', sep="\t",nrows=1, header=F,colClasses="character")
                        Data_FollowUp <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_FollowUp]) ,dec='.', sep="\t",skip=3, header=F)
                        colnames(Data_FollowUp) <- as.character(Data_FollowUp_header)

                } else if (DiseaseName == "Colon")
                {
                        Data_patient_header <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_patient]) ,dec='.', sep="\t", fill=T,nrows=1, header=F,colClasses="character")
                        Data_patient <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_patient]) ,dec='.', sep="\t", fill=T,skip=3, header=F)
                        colnames(Data_patient) <- as.character(Data_patient_header)

                        Data_FollowUp_header <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_FollowUp[1]]) ,dec='.', sep="\t",nrows=1, header=F,colClasses="character")
                        Data_FollowUp <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_FollowUp[1]]) ,dec='.', sep="\t",skip=3, header=F)
                        colnames(Data_FollowUp) <- as.character(Data_FollowUp_header)

                } else if (DiseaseName == "BRCA")
                {
                        Data_patient_header <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_patient]) ,dec='.', sep="\t", fill=T,nrows=1, header=F,colClasses="character")
                        Data_patient <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_patient]) ,dec='.', sep="\t", fill=T,skip=3, header=F)
                        colnames(Data_patient) <- as.character(Data_patient_header)

                        ## FollowUp 
                        Data_FollowUp.k <- lapply(1:3, function(k)
                                                  {
                                                          Data_FollowUp_header.dat <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_FollowUp[k]]) ,dec='.', sep="\t",nrows=1, header=F,colClasses="character")
                                                          Data_FollowUp.dat <- read.table(paste0("raw/ClinicalAnnotations/TCGA/",DiseaseName,"/Clinical/",Center,"/",FileNames[k_FollowUp[k]]) ,dec='.', sep="\t",skip=3, header=F)
                                                          colnames(Data_FollowUp.dat) <- as.character(Data_FollowUp_header.dat)

                                                          return(Data_FollowUp.dat)
                                                  })

                        Interesting.cols <- c('bcr_patient_barcode','vital_status','last_contact_days_to', 'death_days_to')

                        Data_FollowUp.Interesting <- lapply(1:3, function(k)
                                                            {
                                                                    return(Data_FollowUp.k[[k]][,Interesting.cols])
                                                            })

                        Data_FollowUp <- do.call('rbind', Data_FollowUp.Interesting)


                }

                # assign(paste0(DiseaseName,".Clinical"), Data_patient)
                # assign(paste0(DiseaseName,".FollowUp1"), Data_FollowUp.1)

                # save(list=eval(paste0(DiseaseName,".Clinical")),file=paste0("processed/ClinicalAnnotations/TCGA/",DiseaseName,".Clinical.RData"))
                # save(list=eval(paste0(DiseaseName,".FollowUp1")),file=paste0("processed/ClinicalAnnotations/TCGA/",DiseaseName,".FollowUp1.RData"))

                save(Data_patient,file=paste0("processed/ClinicalAnnotations/TCGA/",DiseaseName,".Clinical.RData"))
                save(Data_FollowUp,file=paste0("processed/ClinicalAnnotations/TCGA/",DiseaseName,".FollowUp.RData"))


        }


}

