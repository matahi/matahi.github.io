#cut.names <- function(S){substring(S,1,12)} # We will cut the names of CancerousTCGA to the first 12 characters to match the names in the Clinical Annotations File

analyze_GE_Methylation <- function (DiseaseName,Type,Level=c(2,3)) {
        Meth <- load(paste0('processed/Methylation/TCGA/',DiseaseName,'/',Type,'Level',Level[1],'.RData'))
        GE <- load(paste0('processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',Type,'Level',Level[2],'GE.RData'))
        #GE <- load(paste0('processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',Type,'Level',Level[2],'GE.RData'))

        Meth.dat <- get(Meth)
        GE.dat <- get(GE)

        Meth.Names <- sapply(colnames(Meth.dat),function(S) {substring(S,1,12)})
        GE.Names <- sapply(colnames(GE.dat),function(S) {substring(S,1,12)})

        CommonNames <- intersect(Meth.Names, GE.Names)

        # Sometimes several tissues are sampled from the same patient which leads to having 
        # for example more Meth.Names matching CommonNames since the first 12 string define only the patients
        # To simplify the analysis, we only take the first one.
        A <- match(CommonNames, Meth.Names)
        B <- match(CommonNames, GE.Names)

        #MethInGE <- Meth.Names %in% GE.Names
        #GEInMeth <- GE.Names %in% Meth.Names

        MethNew <- Meth.dat[,A]
        GENew <- GE.dat[,B]

        MethNew.Names <- sapply(colnames(MethNew),function(S) {substring(S,1,12)})
        GENew.Names <- sapply(colnames(GENew),function(S) {substring(S,1,12)})

        assign(paste0(DiseaseName,".",Type), MethNew)
        assign(paste0(DiseaseName,".",Type,"GE"), GENew)

        # Saving
        save(list=eval(paste0(DiseaseName,".",Type)),file=paste0("processed/Methylation/TCGA/",DiseaseName,"/",Type,"Level",Level[1],"_processed.RData"))
        save(list=eval(paste0(DiseaseName,".",Type,"GE")),file=paste0("processed/GeneExpression/RNASeq/TCGA/",DiseaseName,"/",Type,"Level",Level[2],"GE_processed.RData"))

}

