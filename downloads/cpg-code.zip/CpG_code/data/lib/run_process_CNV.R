##############################################################################################################
#			Transform TCGA methylation .txt files into .RData files
##############################################################################################################
### Path Setting {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/") # Home
setwd("~/Desktop/CpG/data/") # BIWS machine

### Loading {{{1
source("lib/fun/analyze_CNV.R")
source("lib/fun/analyze_GE_CNV.R")
source("lib/fun/analyze_Genes_CNV.R")

### Process {{{1
DiseaseList <- c("BRCA") 
#DiseaseList <- c("LUAD","Colon","Glioblastoma") 
#DiseaseList <- c("BRCA","Colon","Kidney","STAD","UCEC","Lung","Glioblastoma")

# analyze_CNV(DiseaseName="BRCA", Type="Cancerous",Level=3)
# analyze_CNV(DiseaseName="BRCA", Type="Normal",Level=3)
# 
# analyze_CNV(DiseaseName="Colon", Type="Cancerous",Level=3)
# 
# analyze_CNV(DiseaseName="LUAD", Type="Cancerous",Level=3)
# analyze_CNV(DiseaseName="LUAD", Type="Normal",Level=3)
# 
# #### 
# ## Then Process CNV
# analyze_GE_CNV(DiseaseName="BRCA", Type="Cancerous")
# analyze_GE_CNV(DiseaseName="BRCA", Type="Normal")
# 
# analyze_GE_CNV(DiseaseName="Colon", Type="Cancerous")
# 
# analyze_GE_CNV(DiseaseName="LUAD", Type="Cancerous")
# analyze_GE_CNV(DiseaseName="LUAD", Type="Normal")


## Also process the genes
# analyze_Genes_CNV(DiseaseName="BRCA", Type="Cancerous")
# analyze_Genes_CNV(DiseaseName="BRCA", Type="Normal")
# 
# analyze_Genes_CNV(DiseaseName="Colon", Type="Cancerous")

analyze_Genes_CNV(DiseaseName="LUAD", Type="Cancerous")
#analyze_Genes_CNV(DiseaseName="LUAD", Type="Normal")

