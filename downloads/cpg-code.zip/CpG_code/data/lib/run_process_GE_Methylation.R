##############################################################################################################
#			Transform TCGA methylation .txt files into .RData files
##############################################################################################################
### Path Setting {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/") # Home
setwd("~/Desktop/CpG/data/") # BIWS machine

## Source {{{1
source('lib/fun/analyze_GE_Methylation.R')

### Process {{{1
DiseaseList <- c("BRCA","Colon","LUAD") 
#DiseaseList <- c("LUAD","Colon","Glioblastoma") 
#DiseaseList <- c("BRCA","Colon","Kidney","STAD","UCEC","Lung","Glioblastoma")

for (DiseaseName in DiseaseList)
{
        analyze_GE_Methylation(DiseaseName,"Cancerous")
        if (DiseaseName != "Colon") # Colon has no normal gene expression
                analyze_GE_Methylation(DiseaseName,"Normal")
}

