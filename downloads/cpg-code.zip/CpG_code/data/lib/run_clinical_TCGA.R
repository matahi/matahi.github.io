######################################################################################################
#			Pattern Recognition in CpG Islands
######################################################################################################

### Preloading {{{1
# Path Setting : Put the correct paths
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data")
setwd("~/Desktop/CpG/data")

# load toolkit
source("lib/fun/toolkit.R")

# load analyze_clinical_TCGA.R
source("lib/fun/analyze_clinical_TCGA.R")

# analyze_clinical_TCGA("BRCA",Center="biotab")
analyze_clinical_TCGA("LUAD",Center="Biotab")
analyze_clinical_TCGA("BRCA",Center="Biotab")
analyze_clinical_TCGA("Colon",Center="Biotab")

### Process BRCA
load("processed/Methylation/TCGA/BRCA/CancerousLevel2.RData")
load("processed/ClinicalAnnotations/TCGA/BRCA.Clinical.RData")
source("lib/fun/process_BRCA_clinical.R")
cut.names <- function(S){substring(S,1,12)} # We will cut the names of BRCA.Cancerous to the first 12 characters to match the names in the Clinical Annotations File

# Correspondence <- rep(0,length(colnames(BRCA.Cancerous)))
# MoreThanOneCorrespondence <- 0
# for (k in 1:length(Correspondence))
# {
#         print(paste0(k,"/",length(Correspondence)))
# 	sublist <- which(grepl(cut.names(colnames(BRCA.Cancerous)[k]),rownames(BRCA.Clinical))==TRUE)
# 	sublist <- which(grepl(cut.names(colnames(BRCA.Cancerous)[k]),rownames(BRCA.Clinical))==TRUE)
#         if (length(sublist)==1)
#         {
#                 Correspondence[k] <- sublist
#         } else if (length(sublist)==0) {
#                 Correspondence[k] <- NA 
#         } else {
#                 print("More than one correspondence")
#                 Correspondence[k] <- sublist[[1]]
#                 MoreThanOneCorrespondence <- MoreThanOneCorrespondence + 1
#                 
#         }
# }

# BRCA.Clinical.ter <- BRCA.Clinical[Correspondence,]
# rownames(BRCA.Clinical.ter) <- colnames(BRCA.Cancerous)

## 60 cancerous patients without clinical informations
## 99 patients with the same clinical info
## What would be interesting is to look at the difference of methylation for tissues from the same patient

## names 
Patients.Meth <- substring(colnames(BRCA.Cancerous),1,12)
Patients.Clinical <- rownames(BRCA.Clinical)

BRCA.Clinical.bis <- BRCA.Clinical[match(Patients.Meth, Patients.Clinical),]

# her2.val <- grep('her2',colnames(BRCA.Clinical.bis))
# 
# table(BRCA.Clinical.bis$her2_immunohistochemistry_level_result, BRCA.Clinical.bis$lab_proc_her2_neu_immunohistochemistry_receptor_status)
# 
# table(BRCA.Clinical.bis$her2_immunohistochemistry_level_result, BRCA.Clinical.bis$lab_procedure_her2_neu_in_situ_hybrid_outcome_type)


ClinicalInfo <-  c("age_at_initial_pathologic_diagnosis",
                   "days_to_birth",
                   "days_to_last_followup",
                   "breast_carcinoma_estrogen_receptor_status",
                   "breast_carcinoma_progesterone_receptor_status",
                   "her2_immunohistochemistry_level_result",
                   "vital_status",
                   "days_to_last_followup")

SurvivalInfo <- c("ajcc_cancer_metastasis_stage_code", 
                  "ajcc_neoplasm_disease_stage", 
                  'ajcc_tumor_stage_code',
                  'ajcc_neoplasm_disease_lymph_node_stage',
                  "number_of_lymphnodes_positive_by_he",
                  'breast_cancer_optical_measurement_histologic_type')

NewClinicalInfo <- c("Age_diagnosis",
                     "Age",
                     "LastFUp",
                     "ER",
                     "PR",
                     "HER2",
                     "OS_STATUS",
                     "days_to_last_followup")

NewSurvivalInfo <- c('Metastasis',
                     'Stage',
                     'Size',
                     'LymphNode',
                     "LymphNodeCount",
                     'histo')

BRCA.Clinical.processed <- process_BRCA_clinical(BRCA.Clinical.bis,c(ClinicalInfo, SurvivalInfo),c(NewClinicalInfo,NewSurvivalInfo))

save(BRCA.Clinical.bis, file="processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

### We should process them

