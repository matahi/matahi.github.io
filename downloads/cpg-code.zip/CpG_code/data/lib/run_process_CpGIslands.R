##############################################################################################################
#			Transform TCGA methylation .txt files into .RData files
##############################################################################################################
### Path Setting {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/") # Home
setwd("~/Desktop/CpG/data/") # BIWS machine

### Loading {{{1
load("processed/fData/OrderCpG.RData")
load('processed/fData/fData450K_ordered.RData')
load('processed/fData/CpGIslands.RData')

#source("lib/fun/analyze_TCGA.R")
source('lib/fun/process_CpGIslands.R')

### Process {{{1
DiseaseList <- c("BRCA","Colon","LUAD") ## LUAD, Colon
# DiseaseList <- c("LUAD","Colon","Glioblastoma") ## LUAD, Colon

#process_CpGIslands("ES","Normal",Level=2, processed=F)
DiseaseList <- "LUAD"

for (DiseaseName in DiseaseList)
{
        ###   if (DiseaseName != "Colon")
        ###   {
        ###   #process_CpGIslands(DiseaseName=DiseaseName, Type="Normal",Level=2,processed=T)
        ###   process_CpGIslands(DiseaseName=DiseaseName, Type="Normal",Level=2,processed=T,bis=T)
        ###   }
        ###   #process_CpGIslands(DiseaseName=DiseaseName, Type="Normal",Level=2,processed=F)
        ###   #process_CpGIslands(DiseaseName=DiseaseName, Type="Cancerous",Level=2,processed=F)
        ###   # process_CpGIslands(DiseaseName=DiseaseName, Type="Cancerous",Level=2,processed=T)
        #process_CpGIslands(DiseaseName=DiseaseName, Type="Cancerous",Level=2,processed=T,bis=T)
        process_CpGIslands(DiseaseName=DiseaseName, Type="Cancerous",Level=2,processed=F,bis=F)
}
#
#load('processed/fData/fData_CGI.RData')
#CGI.Chr <- sapply(1:length(fData_CGI), function(n){fData_CGI[[n]][1,"CHR"]})
#A <- table(CGI.Chr)
#library(reshape2)
#A.m <- melt(A)
#
#library(ggplot2)
#pdf('../results/CGIs_infos/CGI_by_chr.pdf')
#ggplot(A.m) + geom_histogram(aes(x=factor(CGI.Chr, levels=c(1:22,'X','Y')), y=value)) + xlab('Number of CGIs') + ylab('Count')
#dev.off()
#
#
#load('processed/fData/CpGIslands_probe_size.RData')
#list_big_island <- which(CpGIslands.probesize >=20)
#CGI.Chr_big_island <-sapply(1:length(fData_CGI[list_big_island]), function(n){fData_CGI[[list_big_island[n] ]][1,"CHR"]})
#A <- table(CGI.Chr_big_island)
#A.m <- melt(A)
#
#pdf('../results/CGIs_infos/CGI_big_island_by_chr.pdf')
#ggplot(A.m) + geom_histogram(aes(x=factor(CGI.Chr_big_island, levels=c(1:22,'X','Y')), y=value)) + xlab('Number of Big CGIs') + ylab('Count')
#dev.off()



