################## Human 450K Processing #########################
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data")

#####   ### fData450K {{{1
#####   fDataClasses <- c(rep('character',12),'numeric',rep('character',20))
#####   
#####   fData450K <- read.csv('raw/fData/fData450K.csv', skip=7, nrows=486428, header=TRUE, colClasses=fDataClasses, row.names=1)
#####   save(fData450K, file='processed/fData/fData450K_with_control_probes.RData')
#####   
#####   # nrows(fData450K)= 486428 
#####   # End of Probes ? = 485512
#####   # Rest = Control?
#####   # fData450K <- read.csv('../../../../data/Methylation/Human450k/Private/raw_data/Annotations450k/RawData/450K_Manifest_header_Descriptions.xlsx')
#####   
#####   # load toolkit
#####   source("lib/fun/toolkit.R")
#####   
#####   ### Processing {{{1
#####   load("raw/TCGAguide/not_controls.RData")
#####   # Among the probes some are controls, and some are mapped on the genome : 485577 / 486428.
#####   fData450K <- fData450K[not_controls,]
#####   save(fData450K,file='processed/fData/fData450K.RData')
#####   
#####   # New fData450K {{{2
#####   NewInfo <- IslandMAPINFO(fData450K) # process the fData to add some infos about CpG Islands
#####   
#####   fData450K[,"IslandBegin"] <- NA
#####   fData450K[,"IslandEnd"] <- NA
#####   fData450K[,"IslandDist"] <- NA
#####   
#####   fData450K[,"IslandBegin"]  <- NewInfo$IslandMAPINFO[,1]
#####   fData450K[,"IslandEnd"]  <- NewInfo$IslandMAPINFO[,2]
#####   fData450K[,"IslandDist"]  <- NewInfo$DistanceIsland
#####   
#####   save(fData450K,file="processed/fData/fData450K_IslandInfo.RData")
#####   
#####   # New fData450K no SNPs {{{2
#####   
#####   fData450K.snp <- fData450K[fData450K$CHR=="",]
#####   fData450K <- fData450K[!(fData450K$CHR==""),]
#####   
#####   save(fData450K.snp,file="processed/fData/fData450K_SNPs.RData")
#####   save(fData450K,file="processed/fData/fData450K_noSNPs.RData")
#####   
#####   ## Order Probes by Chromosome and Location {{{2
#####   library(gtools)
#####   fData450K <- fData450K[order(fData450K$CHR,fData450K$MAPINFO),]
#####   fData450K <- fData450K[mixedorder(fData450K$CHR),]
#####   
#####   save(fData450K,file="processed/fData/fData450K_noSNPs_ordered.RData")
#####   
#####   OrderCpG.noSNPs <- rownames(fData450K)
#####   save(OrderCpG.noSNPs, file="processed/fData/OrderCpG_noSNPs.RData")
#####   
#####   OrderCpG <- c(OrderCpG.noSNPs, rownames(fData450K.snp))
#####   save(OrderCpG, file="processed/fData/OrderCpG.RData")
#####   
#####   load('processed/fData/fData450K_IslandInfo.RData')
#####   fData450K <- fData450K[OrderCpG,]
#####   
#####   save(fData450K, file="processed/fData/fData450K_ordered.RData")
#####   
#####   # CpG Islands List {{{2
#####   CpGIslands <- unique(fData450K[,"UCSC_CpG_Islands_Name"])
#####   CpGIslands <- CpGIslands[-which(CpGIslands=='')] # To remove the size of '' (corresponding to CpGs not belonging to an Island).
#####   # -> 27176 CpG Islands
#####   save(CpGIslands,file="processed/fData/CpGIslands.RData")
#####   
#####   # CpG Size {{{2
#####   CpGIslands.size <- IslandSize(CpGIslands)
#####   save(CpGIslands.size,file="processed/fData/CpGIslands_size.RData")
#####   # pdf("../../results/Relation_to_CpG_Island/hist_CpGIslands_size.pdf", width=10, height=10, pointsize=10)
#####   # hist(CpGIslands.size, breaks=100) 
#####   # dev.off()
#####   
#####   # Probe Size {{{2
#####   CpGIslands.probesize <- rep(0,length(CpGIslands))
#####   for (k in 1:length(CpGIslands))
#####   {
#####           CpGIslands.probesize[k] <- sum(fData450K[,"UCSC_CpG_Islands_Name"]==CpGIslands[k])
#####   }
#####   # pdf("../../results/Relation_to_CpG_Island/hist_CpGIslands_probe_size.pdf", width=10, height=10, pointsize=10)
#####   # hist(CpGIslands.probesize) 
#####   # dev.off()
#####   save(CpGIslands.probesize,file="processed/fData/CpGIslands_probe_size.RData")

## Process CpG Islands List {{{2
setwd('~/Desktop/CpG/data')
load('processed/fData/fData450K_ordered.RData')
load('processed/fData/CpGIslands.RData')

fData_CGI <- lapply(1:length(CpGIslands), function(n){print(paste0(n,'/',length(CpGIslands)));fData450K[fData450K[,"UCSC_CpG_Islands_Name"]==CpGIslands[n],]})
save(fData_CGI,file="processed/fData/fData_CGI.RData")

fData_CGIOnly <- fData450K[  fData450K[,"UCSC_CpG_Islands_Name"] != ""    , c("UCSC_CpG_Islands_Name","UCSC_RefGene_Group") ]
save(fData_CGIOnly,file="processed/fData/fData_CGIOnly.RData")

RefGene_Groups <- sapply(1:nrow(fData_CGIOnly),function(n){print(paste0(n,'/',nrow(fData_CGIOnly)));strsplit(fData_CGIOnly[n,"UCSC_RefGene_Group"],";")})
save(RefGene_Groups, file= "processed/fData/RefGene_Groups.RData")

TSS_CGIs <- sapply(1:length(RefGene_Groups), function(n){ print(paste0(n,'/',length(RefGene_Groups))); length(grep('TSS',RefGene_Groups[[n]]))==0})
save(TSS_CGIs, file= "processed/fData/TSS_CGIs.RData")

#length(unique(fData_CGIOnly$UCSC_CpG_Islands_Name[ TSS_CGIs==FALSE]))

#####   ## Process Gene List  {{{2
#####   # Process
#####   setwd('~/Desktop/CpG/data')
#####   load('processed/fData/fData450K_ordered.RData')
#####   GeneList <- sapply(1:nrow(fData450K),function(n){print(paste0(n,'/',nrow(fData450K)));strsplit(fData450K[n,"UCSC_RefGene_Name"],";")})
#####   print('Processed Gene List!')
#####   print('Reducing List...')
#####   Reduced.GeneList <- Reduce('c',GeneList)
#####   save(Reduced.GeneList,file="processed/fData/ReducedGeneList.RData")
#####   print('taking unique list....')
#####   GeneList <- unique(Reduced.GeneList)
#####   save(GeneList,file="processed/fData/GeneList.RData")
#####   print('done processing genelist')
#####   
#####    # -> 21231 Genes
#####    
#####   # Process Gene Probes List
#####   setwd('~/Desktop/CpG/data')
#####   load('processed/fData/fData450K_ordered.RData')
#####   load('processed/fData/GeneList.RData')
#####   source('lib/fun/process_Genes_bis.R')
#####   GeneProbesList <- process_Genes_bis(GeneList,fData450K)
#####   save(GeneProbesList,file='processed/fData/GeneProbesList.RData')
#####   print('Processed Gene Probes List !')
#####   
#####   ## Process fData450K_Genes.RData
#####   setwd('~/Desktop/CpG/data')
#####   load('processed/fData/fData450K_ordered.RData')
#####   load('processed/fData/GeneList.RData')
#####   load('processed/fData/GeneProbesList.RData')
#####   
#####   fData450K_Gene <- list()
#####   for (i in 1:length(GeneList)){
#####           print(paste0(i,'/',length(GeneList)))
#####           Pos <- GeneProbesList[[i]]
#####   
#####           Probes <- rownames(fData450K[Pos,])
#####           fData450K_Gene[[i]] <- fData450K[Probes,]
#####   }
#####   
#####   names(fData450K_Gene) <- GeneList
#####   save(fData450K_Gene, file='processed/fData/fData450K_Gene.RData')







