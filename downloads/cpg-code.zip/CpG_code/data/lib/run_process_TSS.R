#setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/')
setwd('~/Desktop/CpG/data/')

RefSeq <- read.csv('raw/TSS/RefSeq.txt', header=T, sep="\t")
UCSC <- read.csv('raw/TSS/UCSC.txt', header=T, sep="\t")


UCSC <- UCSC[,1:5]

## Need association UCSC and gene symbols

Assoc.Symbol_UCSC <- read.csv('raw/TSS/Association_UCSC_Symbol.txt', header =T, sep="\t",row.names=1)

UCSC <- data.frame(UCSC, geneSymbol=Assoc.Symbol_UCSC[UCSC[,1],"geneSymbol"])

fData.big_island <- get(load('processed/fData/fData_CGI_big_island.RData'))
Promoter.Assoc <- get(load('../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
AllCGIs.Assoc <- get(load('../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
CommonGenes <- get(load('../big_data/CommonGenes.RData'))

source('lib/fun/Calculate_DistToTSS.R')

### 1) First Look at gene symbols
Gene.distToTSS <- sapply(1:length(CommonGenes), function(n){
                         print(n)
                         Gene <- CommonGenes[n]

                         Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                         Gene.info <- which(RefSeq$name2==Gene)

                         # RefSeq[Gene.info,c(2:6,13)]
                         # Gene.CGI_info[,c('CHR','UCSC_RefGene_Name','UCSC_RefGene_Accession','UCSC_RefGene_Group','IslandBegin','IslandEnd')]

                         if (length(Gene.info)!=0)
                         {
                                 Gene.info.num <- 1 ## Default Just take 1 variant
                                 if (Gene == "SDK1")
                                 {
                                         Gene.info.num <- 2
                                 }
                                 Gene.txStart <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="+",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### TSS Site
                                 Gene.txEnd <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="-",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### End of Transcription (End Codon)
                                 Gene.Strand <- RefSeq[Gene.info[Gene.info.num],"strand"]

                                 Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                 Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]

                                 ### TO VERIFY ########
                                 Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                 return(Gene.distToTSS)

                         } else {
                                 print('NO INFO')
                                 Gene.distToTSS <- NA
                         }

                         return(Gene.distToTSS)})


### Lots of NA (212)
NA.distToTSS <- which(is.na(Gene.distToTSS))

### 2) Second Look at RefGene Accession Numbers
Missing.distToTSS <- sapply(1:length(NA.distToTSS), function(k){
                            n <- NA.distToTSS[k]
                            Gene <- CommonGenes[n]

                            Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                            #Gene.info <- which(RefSeq$name2==Gene)

                            Decompose.GeneName <- strsplit(Gene.CGI_info$UCSC_RefGene_Name,";")
                            Decompose.RefGene_Accession <- strsplit(Gene.CGI_info$UCSC_RefGene_Accession,";")

                            Find.GeneName <- lapply(1:length(Decompose.GeneName), function(n){grep(Gene,Decompose.GeneName[[n]])})
                            RefGene_Accession <- unique(Reduce('c',lapply(1:length(Decompose.RefGene_Accession), function(n){ Decompose.RefGene_Accession[[n]][ Find.GeneName[[n]] ] } ) ) )

                            Gene.info <- which(RefSeq$name %in% RefGene_Accession)

                            # RefSeq[Gene.info,c(2:6,13)]
                            # Gene.CGI_info[,c('CHR','UCSC_RefGene_Name','UCSC_RefGene_Accession','UCSC_RefGene_Group','IslandBegin','IslandEnd')]

                            if (length(Gene.info)!=0)
                            {
                                    Gene.info.num <- 1 ## Default Just take 1 variant
                                    if (Gene == "SDK1")
                                    {
                                            Gene.info.num <- 2
                                    }
                                    Gene.txStart <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="+",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### TSS Site
                                    Gene.txEnd <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="-",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### End of Transcription (End Codon)
                                    Gene.Strand <- RefSeq[Gene.info[Gene.info.num],"strand"]

                                    Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                    Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]


                                    ### TO VERIFY ########
                                    Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                    return(Gene.distToTSS)
                            } else {
                                    print('NO INFO')
                                    Gene.distToTSS <- NA
                            }

                            return(Gene.distToTSS)})

Gene.distToTSS[NA.distToTSS] <- Missing.distToTSS

## Now only few NAs (11)
NA.distToTSS <- which(is.na(Gene.distToTSS))

Missing.distToTSS <- sapply(1:length(NA.distToTSS), function(k){
                            n <- NA.distToTSS[k]
                            Gene <- CommonGenes[n]

                            if (Gene=="C10orf93")
                            {
                                    Gene <- "TTC40"
                            } else if (Gene=="C17orf65")
                            {
                                    Gene <- "ASB16-AS1"
                            } else if (Gene=="C1orf84")
                            {
                                    Gene <- "SZT2"
                            } else if (Gene=="C6orf114")
                            {
                                    Gene <- "GFOD1"
                            } else if (Gene=="KIAA0495")
                            {
                                    Gene <- "TP73-AS1"
                            } else if (Gene=="LBXCOR1")
                            {
                                    Gene <- "SKOR1"
                            } else if (Gene=="C4orf42") 
                            {
                                    Gene.txStart <- 1234177
                                    Gene.Strand <- "+"
                                    Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                                    Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                    Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]
                                    ##
                                    Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                    return(Gene.distToTSS)

                            } else if (Gene=="C11orf92")
                            {
                                    Gene.txStart <- 110675749
                                    Gene.Strand <- "-"
                                    Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                                    Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                    Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]
                                    ##
                                    Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                    return(Gene.distToTSS)

                            } else if (Gene=="C14orf181")
                            {
                                    Gene.txStart <- 68332943
                                    Gene.Strand <- "-"
                                    Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                                    Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                    Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]
                                    ##
                                    Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                    return(Gene.distToTSS)

                            } else if (Gene=="PPP1R2P1")
                            {
                                    Gene.txStart <- 32955872
                                    Gene.Strand <- "-"
                                    Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                                    Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                    Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]
                                    ##
                                    Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                    return(Gene.distToTSS)

                            } else if (Gene=="SPATA1")
                            {
                                    Gene.txStart <- 84744562
                                    Gene.Strand <- "+"
                                    Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                                    Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                    Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]
                                    ##
                                    Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                    return(Gene.distToTSS)

                            }

                            Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                            Gene.info <- which(RefSeq$name2==Gene)

                            if (length(Gene.info)!=0)
                            {
                                    Gene.info.num <- 1 ## Default Just take 1 variant
                                    if (Gene == "SDK1")
                                    {
                                            Gene.info.num <- 2
                                    }
                                    Gene.txStart <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="+",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### TSS Site
                                    Gene.txEnd <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="-",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### End of Transcription (End Codon)
                                    Gene.Strand <- RefSeq[Gene.info[Gene.info.num],"strand"]

                                    Gene.CGIBegin <- Gene.CGI_info[1,"IslandBegin"]
                                    Gene.CGIEnd <- Gene.CGI_info[1,"IslandEnd"]

                                    ### TO VERIFY ########
                                    Gene.distToTSS <- Calculate_DistToTSS(Gene.txStart, Gene.Strand, Gene.CGIBegin, Gene.CGIEnd)
                                    return(Gene.distToTSS)

                            } else {
                                    print('NO INFO')
                                    Gene.distToTSS <- NA
                            }

                            return(Gene.distToTSS)
                            })

Gene.distToTSS[NA.distToTSS] <- Missing.distToTSS
save(Gene.distToTSS, file="processed/TSS/CommonGenesTSS.RData")






