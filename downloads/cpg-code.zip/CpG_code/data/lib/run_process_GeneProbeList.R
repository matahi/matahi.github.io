######################################################################################################
#			run_analysis.R
######################################################################################################

### Data Loading {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data") # Home
setwd("~/Desktop/CpG/data") # BIWS machine

# load featureData
load("processed/fData/fData450K_ordered.RData")

load("processed/fData/GeneList.RData")

#function Gene_list
source('lib/fun/process_Genes_bis.R')

### Process {{{1
GeneProbesList <- process_Genes_bis(GeneList,fData450K)

save(GeneProbesList,file='processed/fData/GeneProbesList.RData')

print('DONE !')

