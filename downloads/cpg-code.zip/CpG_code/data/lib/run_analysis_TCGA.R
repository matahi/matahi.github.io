##############################################################################################################
#			Transform TCGA methylation .txt files into .RData files
##############################################################################################################
### Path Setting {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/") # Home
setwd("~/Desktop/CpG/data/") # BIWS machine

### Loading {{{1
load("processed/fData/OrderCpG.RData")

source("lib/fun/analyze_TCGA.R")

### Process {{{1
#DiseaseList <- c("BRCA") 
DiseaseList <- c("Colon") 
#DiseaseList <- c("LUAD","Colon","Glioblastoma") 
#DiseaseList <- c("BRCA","Colon","Kidney","STAD","UCEC","Lung","Glioblastoma")
DiseaseList <- c('LUAD')

for (DiseaseName in DiseaseList)
{
        analyze_TCGA(DiseaseName=DiseaseName, Type="Normal",Level=2)
        analyze_TCGA(DiseaseName=DiseaseName, Type="Cancerous",Level=2)
}

### Post-Process BRCA {{{1
# Problem : BRCA.Cancerous contains BRCA.Normal data
load("processed/Methylation/TCGA/BRCA/CancerousLevel2.RData")
load("processed/Methylation/TCGA/BRCA/NormalLevel2.RData")

VerifyType <- function(S)
{
        Identifier <- substring(S,14,15)
        Identifier <- as.numeric(Identifier)
        if ((Identifier>=1) &  (Identifier <=9)) {
                Type <- "Cancerous"
        } else if ((Identifier>=10) & (Identifier <=19)) {
                Type <- "Normal"
        } else if ((Identifier>=20) & (Identifier <=29)) {
                Type <- "Control"
        }
        return(Type)
} 

Normal.Type <- sapply(colnames(BRCA.Normal),VerifyType)
Cancerous.Type <- sapply(colnames(BRCA.Cancerous),VerifyType)

BRCA.Normal <- BRCA.Normal[,Normal.Type=="Normal"]
BRCA.Cancerous <- BRCA.Cancerous[,Cancerous.Type=="Cancerous"]

save(BRCA.Cancerous,file="processed/Methylation/TCGA/BRCA/CancerousLevel2.RData")

save(BRCA.Normal,file="processed/Methylation/TCGA/BRCA/NormalLevel2.RData")




