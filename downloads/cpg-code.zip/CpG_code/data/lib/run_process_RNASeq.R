##############################################################################################################
#			Transform TCGA methylation .txt files into .RData files
##############################################################################################################
### Path Setting {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/") # Home
setwd("~/Desktop/CpG/data/") # BIWS machine

### Loading {{{1
#load("processed/fData/GeneList.RData")

source("lib/fun/analyze_RNASeq.R")

### Process {{{1
DiseaseList <- c("BRCA","Colon","LUAD") 
#DiseaseList <- c("LUAD","Colon","Glioblastoma") 
#DiseaseList <- c("BRCA","Colon","Kidney","STAD","UCEC","Lung","Glioblastoma")

#DiseaseName <- "LUAD"

for (DiseaseName in DiseaseList)
{
        analyze_RNASeq(DiseaseName=DiseaseName, Type="Cancerous",Level=3)
        if (DiseaseName != "Colon")
        {
        analyze_RNASeq(DiseaseName=DiseaseName, Type="Normal",Level=3)
        }
}


###  VerifyType <- function(S)
###  {
###          Identifier <- substring(S,14,15)
###          Identifier <- as.numeric(Identifier)
###          if ((Identifier>=1) &  (Identifier <=9)) {
###                  Type <- "Cancerous"
###          } else if ((Identifier>=10) & (Identifier <=19)) {
###                  Type <- "Normal"
###          } else if ((Identifier>=20) & (Identifier <=29)) {
###                  Type <- "Control"
###          }
###          return(Type)
###  } 

###   load('processed/GeneExpression/TCGA/BRCA/CancerousLevel3GE.RData')
###   
###   Type <- sapply(colnames(BRCA.CancerousGE),VerifyType)
###   
###   BRCA.NormalGE <- BRCA.CancerousGE[,Type=="Normal"]
###   BRCA.CancerousGE <- BRCA.CancerousGE[,Type=="Cancerous"]
###   
###   save(BRCA.CancerousGE, file="processed/GeneExpression/TCGA/BRCA/CancerousLevel3GE.RData")
###   save(BRCA.NormalGE, file="processed/GeneExpression/TCGA/BRCA/NormalLevel3GE.RData")

