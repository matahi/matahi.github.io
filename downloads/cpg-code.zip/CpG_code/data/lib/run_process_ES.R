#setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/')
setwd('~/Desktop/CpG/data/')

load("processed/fData/OrderCpG.RData")

all_files <- list.files(path="raw/Methylation/TCGA/ES")

files.txt <- all_files[grep(".txt",all_files)]

ES.dat <- matrix(0,nrow=485577, ncol=length(files.txt))
ES.pval <- matrix(0,nrow=485577, ncol=length(files.txt))

colnames(ES.dat) <- colnames(ES.dat,do.NULL=FALSE)
colnames(ES.pval) <- colnames(ES.pval,do.NULL=FALSE)
rownames(ES.dat) <- OrderCpG
rownames(ES.pval) <- OrderCpG

for (k in 1:length(files.txt))
{
        print(paste0(k,"/", length(files.txt)))
        A <- read.csv(paste0('raw/Methylation/TCGA/ES/',files.txt[k]), sep="\t", skip=3,row.names=1)
        ES.dat[,k] <- A[OrderCpG,1]
        ES.pval[,k] <- A[OrderCpG,2]
        tmp <- colnames(A)[2]
        new.name <- substring(tmp,1,nchar(tmp)-15)
        colnames(ES.dat)[k] <- new.name 
        colnames(ES.pval)[k] <- new.name 
}

save(ES.dat,file="processed/Methylation/TCGA/ES/ES.RData")
save(ES.pval,file="processed/Methylation/TCGA/ES/ES_pval.RData")


