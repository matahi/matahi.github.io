setwd('~/Desktop/CpG/data')


#print(' Analyzing RNA Seq...')
#source('lib/run_process_RNASeq.R')
#
#print(' Matching GE Sets and Methylation Sets...')
#source('lib/run_process_GE_Methylation.R')

print(' Transforming Methylation in CpG Islands...')
source('lib/run_process_CpGIslands.R')

#print('Processing Methylation in Genes...')
#source('lib/run_process_Genes.R')

print('DONE !')
