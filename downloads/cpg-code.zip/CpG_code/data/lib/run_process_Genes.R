######################################################################################################
#			run_analysis.R
######################################################################################################

### Data Loading {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data") # Home
setwd("~/Desktop/CpG/data") # BIWS machine

# load featureData
load("processed/fData/fData450K_ordered.RData")

load("processed/fData/GeneList.RData")
load("processed/fData/GeneProbesList.RData")

#function Gene_list
source('lib/fun/process_Genes.R')

### Process {{{1
#DiseaseList <- c("BRCA","Colon") ## LUAD, Colon
DiseaseList <- c('BRCA')
# DiseaseList <- c("LUAD","Colon","Glioblastoma") ## LUAD, Colon

for (DiseaseName in DiseaseList)
{
        if (DiseaseName != "Colon")
        {
        #process_Genes(DiseaseName=DiseaseName, Type="Normal",Level=2,processed=T)
        }
        # process_Genes(DiseaseName=DiseaseName, Type="Normal",Level=2,processed=F)
        #process_Genes(DiseaseName=DiseaseName, Type="Cancerous",Level=2,processed=T)
        process_Genes(DiseaseName=DiseaseName, Type="Cancerous",Level=2,processed=F)
}

