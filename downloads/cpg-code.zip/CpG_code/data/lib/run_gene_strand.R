#setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/')
setwd('~/Desktop/CpG/data/')

RefSeq <- read.csv('raw/TSS/RefSeq.txt', header=T, sep="\t")
UCSC <- read.csv('raw/TSS/UCSC.txt', header=T, sep="\t")


UCSC <- UCSC[,1:5]

## Need association UCSC and gene symbols

Assoc.Symbol_UCSC <- read.csv('raw/TSS/Association_UCSC_Symbol.txt', header =T, sep="\t",row.names=1)

UCSC <- data.frame(UCSC, geneSymbol=Assoc.Symbol_UCSC[UCSC[,1],"geneSymbol"])

fData.big_island <- get(load('processed/fData/fData_CGI_big_island.RData'))
Promoter.Assoc <- get(load('../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
AllCGIs.Assoc <- get(load('../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
CommonGenes <- get(load('../big_data/CommonGenes.RData'))

### 1) First Look at gene symbols
Gene.Strand <- sapply(1:length(CommonGenes), function(n){
                         print(n)
                         Gene <- CommonGenes[n]

                         Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                         Gene.info <- which(RefSeq$name2==Gene)

                         if (length(Gene.info)!=0)
                         {
                                 Gene.info.num <- 1 ## Default Just take 1 variant
                                 if (Gene == "SDK1")
                                 {
                                         Gene.info.num <- 2
                                 }

                                 Gene.Strand <- as.character(RefSeq[Gene.info[Gene.info.num],"strand"])

                                 return(Gene.Strand)

                         } else {
                                 print('NO INFO')
                                 return(NA)
                         }

})


### Lots of NA (212)
NA.Strand <- which(is.na(Gene.Strand))

### 2) Second Look at RefGene Accession Numbers
Missing.GeneStrand <- sapply(1:length(NA.Strand), function(k){
                            n <- NA.Strand[k]
                            Gene <- CommonGenes[n]

                            Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]

                            Decompose.GeneName <- strsplit(Gene.CGI_info$UCSC_RefGene_Name,";")
                            Decompose.RefGene_Accession <- strsplit(Gene.CGI_info$UCSC_RefGene_Accession,";")

                            Find.GeneName <- lapply(1:length(Decompose.GeneName), function(n){grep(Gene,Decompose.GeneName[[n]])})
                            RefGene_Accession <- unique(Reduce('c',lapply(1:length(Decompose.RefGene_Accession), function(n){ Decompose.RefGene_Accession[[n]][ Find.GeneName[[n]] ] } ) ) )

                            Gene.info <- which(RefSeq$name %in% RefGene_Accession)

                            if (length(Gene.info)!=0)
                            {
                                    Gene.info.num <- 1 ## Default Just take 1 variant
                                    
                                    Gene.Strand <- as.character(RefSeq[Gene.info[Gene.info.num],"strand"])

                                    return(Gene.Strand)
                            } else {
                                    print('NO INFO')
                                    return(NA)
                            }

})

Gene.Strand[NA.Strand] <- Missing.GeneStrand

## Now only few NAs (11)
NA.Strand_bis <- which(is.na(Gene.Strand))

Missing.GeneStrand_bis <- sapply(1:length(NA.Strand_bis), function(k){
                            n <- NA.Strand_bis[k]
                            Gene <- CommonGenes[n]

                            if (Gene=="C10orf93")
                            {
                                    Gene <- "TTC40"
                            } else if (Gene=="C17orf65")
                            {
                                    Gene <- "ASB16-AS1"
                            } else if (Gene=="C1orf84")
                            {
                                    Gene <- "SZT2"
                            } else if (Gene=="C6orf114")
                            {
                                    Gene <- "GFOD1"
                            } else if (Gene=="KIAA0495")
                            {
                                    Gene <- "TP73-AS1"
                            } else if (Gene=="LBXCOR1")
                            {
                                    Gene <- "SKOR1"
                            } else if (Gene=="C4orf42") 
                            {
                                    Gene.Strand <- "+"
                                    return(Gene.Strand)

                            } else if (Gene=="C11orf92")
                            {
                                    Gene.Strand <- "-"
                                    return(Gene.Strand)

                            } else if (Gene=="C14orf181")
                            {
                                    Gene.Strand <- "-"
                                    return(Gene.Strand)
                            } else if (Gene=="PPP1R2P1")
                            {
                                    Gene.Strand <- "-"
                                    return(Gene.Strand)
                            } else if (Gene=="SPATA1")
                            {
                                    Gene.Strand <- "+"
                                    return(Gene.Strand)
                            }

                            Gene.info <- which(RefSeq$name2==Gene)

                            if (length(Gene.info)!=0)
                            {
                                    Gene.info.num <- 1 ## Default Just take 1 variant
                                    
                                    Gene.Strand <- as.character(RefSeq[Gene.info[Gene.info.num],"strand"])
                                    return(Gene.Strand)

                            } else {
                                    print('NO INFO')
                                    return(NA)
                            }

})

Gene.Strand[NA.Strand_bis] <- Missing.GeneStrand_bis
save(Gene.Strand, file="processed/TSS/GeneStrand.RData")






