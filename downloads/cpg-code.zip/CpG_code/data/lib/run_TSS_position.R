#setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/')
setwd('~/Desktop/CpG/data/')

RefSeq <- read.csv('raw/TSS/RefSeq.txt', header=T, sep="\t")
UCSC <- read.csv('raw/TSS/UCSC.txt', header=T, sep="\t")


UCSC <- UCSC[,1:5]

## Need association UCSC and gene symbols

Assoc.Symbol_UCSC <- read.csv('raw/TSS/Association_UCSC_Symbol.txt', header =T, sep="\t",row.names=1)

UCSC <- data.frame(UCSC, geneSymbol=Assoc.Symbol_UCSC[UCSC[,1],"geneSymbol"])

fData.big_island <- get(load('processed/fData/fData_CGI_big_island.RData'))
Promoter.Assoc <- get(load('../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
AllCGIs.Assoc <- get(load('../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
CommonGenes <- get(load('../big_data/CommonGenes.RData'))

source('lib/fun/Calculate_DistToTSS.R')

### 1) First Look at gene symbols
Gene.TSS <- sapply(1:length(CommonGenes), function(n){
                         print(n)
                         Gene <- CommonGenes[n]

                         Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                         Gene.info <- which(RefSeq$name2==Gene)

                         # RefSeq[Gene.info,c(2:6,13)]
                         # Gene.CGI_info[,c('CHR','UCSC_RefGene_Name','UCSC_RefGene_Accession','UCSC_RefGene_Group','IslandBegin','IslandEnd')]

                         if (length(Gene.info)!=0)
                         {
                                 Gene.info.num <- 1 ## Default Just take 1 variant
                                 if (Gene == "SDK1")
                                 {
                                         Gene.info.num <- 2
                                 }
                                 Gene.txStart <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="+",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### TSS Site

                                 return(Gene.txStart)

                         } else {
                                 print('NO INFO')
                                 Gene.txStart <- NA
                                 return(Gene.txStart)
                         }
})

### Lots of NA (212)
NA.TSS <- which(is.na(Gene.TSS))

### 2) Second Look at RefGene Accession Numbers
Missing.TSS <- sapply(1:length(NA.TSS), function(k){
                            n <- NA.TSS[k]
                            Gene <- CommonGenes[n]

                            Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                            #Gene.info <- which(RefSeq$name2==Gene)

                            Decompose.GeneName <- strsplit(Gene.CGI_info$UCSC_RefGene_Name,";")
                            Decompose.RefGene_Accession <- strsplit(Gene.CGI_info$UCSC_RefGene_Accession,";")

                            Find.GeneName <- lapply(1:length(Decompose.GeneName), function(n){grep(Gene,Decompose.GeneName[[n]])})
                            RefGene_Accession <- unique(Reduce('c',lapply(1:length(Decompose.RefGene_Accession), function(n){ Decompose.RefGene_Accession[[n]][ Find.GeneName[[n]] ] } ) ) )

                            Gene.info <- which(RefSeq$name %in% RefGene_Accession)

                            # RefSeq[Gene.info,c(2:6,13)]
                            # Gene.CGI_info[,c('CHR','UCSC_RefGene_Name','UCSC_RefGene_Accession','UCSC_RefGene_Group','IslandBegin','IslandEnd')]

                            if (length(Gene.info)!=0)
                            {
                                    Gene.info.num <- 1 ## Default Just take 1 variant
                                    if (Gene == "SDK1")
                                    {
                                            Gene.info.num <- 2
                                    }

                                    Gene.txStart <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="+",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### TSS Site

                                    return(Gene.txStart)
                            } else {
                                    print('NO INFO')
                                    Gene.txStart <- NA
                                    return(Gene.txStart)
                            }

                            })

Gene.TSS[NA.TSS] <- Missing.TSS

## Now only few NAs (11)
NA.TSS <- which(is.na(Gene.TSS))

Missing.TSS <- sapply(1:length(NA.TSS), function(k){
                            n <- NA.TSS[k]
                            Gene <- CommonGenes[n]

                            if (Gene=="C10orf93")
                            {
                                    Gene <- "TTC40"
                            } else if (Gene=="C17orf65")
                            {
                                    Gene <- "ASB16-AS1"
                            } else if (Gene=="C1orf84")
                            {
                                    Gene <- "SZT2"
                            } else if (Gene=="C6orf114")
                            {
                                    Gene <- "GFOD1"
                            } else if (Gene=="KIAA0495")
                            {
                                    Gene <- "TP73-AS1"
                            } else if (Gene=="LBXCOR1")
                            {
                                    Gene <- "SKOR1"
                            } else if (Gene=="C4orf42") 
                            {
                                    Gene.txStart <- 1234177
                                    return(Gene.txStart)

                            } else if (Gene=="C11orf92")
                            {
                                    Gene.txStart <- 110675749
                                    return(Gene.txStart)

                            } else if (Gene=="C14orf181")
                            {
                                    Gene.txStart <- 68332943
                                    return(Gene.txStart)

                            } else if (Gene=="PPP1R2P1")
                            {
                                    Gene.txStart <- 32955872
                                    return(Gene.txStart)

                            } else if (Gene=="SPATA1")
                            {
                                    Gene.txStart <- 84744562
                                    return(Gene.txStart)
                            }

                            Gene.CGI_info <- fData.big_island[[Promoter.Assoc[n]]]
                            Gene.info <- which(RefSeq$name2==Gene)

                            if (length(Gene.info)!=0)
                            {
                                    Gene.info.num <- 1 ## Default Just take 1 variant
                                    Gene.txStart <- ifelse(RefSeq[Gene.info[Gene.info.num],"strand"]=="+",RefSeq$txStart[Gene.info[Gene.info.num]], RefSeq$txEnd[Gene.info[Gene.info.num]]) ### TSS Site
                                    return(Gene.txStart)

                            } else {
                                    print('NO INFO')
                                    Gene.txStart <- NA
                                    return(Gene.txtStart)
                            }

                            })

Gene.TSS[NA.TSS] <- Missing.TSS
save(Gene.TSS, file="processed/TSS/TSS_position.RData")



