##############################################################################################################
#			Transform TCGA methylation .txt files into .RData files
##############################################################################################################
### Path Setting {{{1
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/") # Home
setwd("~/Desktop/CpG/data/") # BIWS machine

## Source {{{1
source('lib/fun/analyze_TSS_Methylation.R')

load('processed/fData/AssocMethGenes.RData')

### Process {{{1
DiseaseList <- c("BRCA","Colon") 
#DiseaseList <- c("LUAD","Colon","Glioblastoma") 
#DiseaseList <- c("BRCA","Colon","Kidney","STAD","UCEC","Lung","Glioblastoma")

for (DiseaseName in DiseaseList)
{
        analyze_TSS_Methylation(DiseaseName,"Cancerous",processed=T)
        if (DiseaseName != "Colon") # Colon has no normal gene expression
                analyze_TSS_Methylation(DiseaseName,"Normal",processed=T)
}

