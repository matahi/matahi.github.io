#setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data/')
setwd('~/Desktop/CpG/data/')

RefSeq <- read.csv('raw/TSS/RefSeq.txt', header=T, sep="\t")
UCSC <- read.csv('raw/TSS/UCSC.txt', header=T, sep="\t")
PcG.Targets <- read.table('raw/PcG/PcGTargets.csv', sep=";", skip=1)


PcG.Targets$name2 <- as.character(RefSeq$name2[match(PcG.Targets[,1], RefSeq$name)])


save(PcG.Targets,file='processed/TSS/PcGTargets.RData')

