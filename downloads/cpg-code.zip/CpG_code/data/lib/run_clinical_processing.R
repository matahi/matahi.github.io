##########################################################################################################
########		Tumor Progression : Clinical Analysis
##########################################################################################################
### Preloading {{{1
# Path Setting : Put the Path according to your directories (Data, Working, ...)
# PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/data"
PATH <- "~/Desktop/CpG/data" # Curie Machines path
#args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

######BRCA.Clinical <- get(load('../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData'))
####################################################################################################

# Loading Data
DiseaseList <- c('BRCA','LUAD','Colon') #'Glioblastoma'

### Statistical Analysis {{{1
# load the used packages
library(cgdsr)

# Create CGDS object
mycgds = CGDS("http://www.cbioportal.org/public-portal/")

test(mycgds)

# Get list of cancer studies at server
# getCancerStudies(mycgds)

# Get available case lists (collection of samples) for a given cancer study
#Index <- list(BRCA=9:13, LUAD=33:36, Colon=16:18, STAD=53)
#Index <- list(BRCA=13:14, LUAD=37:38, Colon=18:19, STAD=65)
Index <- list(BRCA=13:14, LUAD=38:40, Colon=18:19, STAD=65)
# Index <- list(BRCA=13:14, LUAD=37:38, Colon=17:20, STAD=65)

# Index.Mutation <- list(BRCA=c(5,8), LUAD=c(8,8), Colon=c(7,8), STAD=c(9))
# Index.mRNA <- list(BRCA=c(10,13), LUAD=c(10,10), Colon=c(11,13), STAD=c(3))
## STAD = RNA Seq RPKM
## Others = mRNA Expression Array
Clinical.Info <- list()
# Genetic.Info <- list()
# Mutation.Info <- list()

for (Disease in DiseaseList)
{
        print(Disease)
        Clinical.Info[[Disease]] <- c()
        #Genetic.Info[[Disease]] <- c()
        
        for (k in 1:length(Index[[Disease]]))
        {
                print(paste0(k,'/',length(Index[[Disease]])))
                mycancerstudy = getCancerStudies(mycgds)[Index[[Disease]][k],1]

                ### TO VERIFY CASE LIST
                mycaselist = getCaseLists(mycgds,mycancerstudy)[1,1]

                # Get MutationData
                # mutationProfiles = getGeneticProfiles(mycgds,mycancerstudy)[Index.Mutation[[Disease]][k],1]

                # Get ExpressionData
                # expressionProfiles = getGeneticProfiles(mycgds,mycancerstudy)[Index.mRNA[[Disease]][k],1]

                # Get data slices for a specified list of genes, genetic profile and case list
                #mygeneticdata = getProfileData(mycgds,c('BRCA1','BRCA2'),mygeneticprofile,mycaselist)
                # mymutationdata = getProfileData(mycgds,c('BRCA1','BRCA2','IDH1','TET2','MLH1','BRAF','KRAS','ESR1','PGR'),mutationProfiles,mycaselist)
                # myexpressiondata = getProfileData(mycgds,c('BRCA1','BRCA2','IDH1','TET2','MLH1','BRAF','KRAS','ESR1','PGR'),expressionProfiles,mycaselist)

                # Get clinical data for the case list
                myclinicaldata = getClinicalData(mycgds,mycaselist)
                if ((Disease=="BRCA")&(k==length(Index[[Disease]])))
                        myclinicaldata <- data.frame(myclinicaldata, SUBTYPE= rep(NA,nrow(myclinicaldata)))

                ## Gather with others
                Clinical.Info[[Disease]] <- rbind(Clinical.Info[[Disease]], myclinicaldata)
                #Genetic.Info[[Disease]] <- rbind(Genetic.Info[[Disease]], myexpressiondata)
                #Mutation.Info[[Disease]] <- rbind(Mutation.Info[[Disease]], mymutationdata)
        }

        rownames(Clinical.Info[[Disease]]) <- gsub(".", "-", rownames(Clinical.Info[[Disease]]), fixed=T)
        #rownames(Genetic.Info[[Disease]]) <- gsub(".", "-", rownames(Genetic.Info[[Disease]]), fixed=T)

}


## Now Compare substring(colnames(Disease.Cancerous),1,12) and rownames(Clinical.Info[[Disease]])
NewInfo.Clinical <- list()
#NewInfo.Genetic <- list()
for (Disease in DiseaseList)
{
        print(Disease)

        GE.Dat <- get(load(paste0("processed/GeneExpression/RNASeq/TCGA/",Disease,"/CancerousLevel3GE_processed.RData")))
        #CGI.Dat <- get(load(paste0("processed/Methylation/TCGA/",Disease,"/CancerousCGIs.RData")))
        CGI.Dat <- get(load(paste0("processed/Methylation/TCGA/",Disease,"/CancerousLevel2.RData")))

        Present.Clinical <- substring(colnames(CGI.Dat),1,12) %in% substring(rownames(Clinical.Info[[Disease]]),1,12)
        # table(nchar(rownames(Clinical.Info[[Disease]])))
        #Present.Genetic <- substring(colnames(GE.Dat),1,12) %in% rownames(Genetic.Info[[Disease]])

        Tot <- ncol(CGI.Dat)

        print(paste0(sum(Present.Clinical), " clinical info out of ", Tot, " samples"))
        #print(paste0(sum(Present.Genetic), " genetic info out of ", Tot, " samples"))

        NewInfo.Clinical[[Disease]] <- Clinical.Info[[Disease]][ match(substring(colnames(GE.Dat),1,12), rownames(Clinical.Info[[Disease]])),]
        #NewInfo.Genetic[[Disease]] <- Genetic.Info[[Disease]][ match(substring(colnames(Dat),1,12), rownames(Genetic.Info[[Disease]])),]

        rownames(NewInfo.Clinical[[Disease]]) <- colnames(GE.Dat)
        #rownames(NewInfo.Genetic[[Disease]]) <- colnames(Dat)
}

for (Disease in DiseaseList)
{
        assign(paste0(Disease,".Clinical"), NewInfo.Clinical[[Disease]])
        #assign(paste0(Disease,".Genetic"), NewInfo.Genetic[[Disease]])
        save(list=eval(paste0(Disease,".Clinical")), file=paste0("processed/ClinicalAnnotations/TCGA/",Disease,"_Clinical_cBioPortal.RData"))
        #save(list=eval(paste0(Disease,".Genetic")), file=paste0("../../data/processed/GeneExpression/TCGA/",Disease,"/Genetic_cBioPortal.RData"))
}


tata <- get(load("processed/ClinicalAnnotations/TCGA/LUAD_Clinical_cBioPortal.RData"))



