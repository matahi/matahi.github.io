######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

## Data Loading {{{2
### Methylation 
# All
load("../../data/processed/Methylation/TCGA/BRCA/CancerousLevel2.RData")
load("../../data/processed/Methylation/TCGA/BRCA/NormalLevel2.RData")
# CGI processed
load("../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs.RData")
load("../../data/processed/Methylation/TCGA/BRCA/NormalCGIs.RData")

### Gene Expression

# load clinicalinfo
load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
#load("../../data/processed/fData/fData450K.RData") # 486428 lines
load("../../data/processed/fData/fData450K_ordered.RData") # 485577 lines (removed SNPs) . Reordered by chromosomes. New featureData added Island infos : IslandBegin, IslandEnd, IslandDist
load("../../data/processed/fData/fData450K_Genes.RData") # 

# load Genes
load("../../data/processed/fData/GeneList.RData")

# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox {{{1
## load the used packages {{{2
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
require('CGHpack')
require('reshape2') #for Melt for data.frame
require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions{{{2
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene.R") # plot_gene function
source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos

### Statistical Analysis {{{1
## Analysis of the specific CpG Islands form for one specific gene {{{2
# length(Genes) = 21232
# plot {{{3
# One CGI analysis
BigIslands <- which(CpGIslands.probesize>=60)
# For example the maximum # probes for 1 CGI is 117 and is achieve for Island 7869 (associated with genes NEU1 and SLC44A4) and 7875 (associated with genes STK19 and DOM3Z).
method <- "kmeans"

for (Ind in BigIslands){
        # Cancerous vs Normal
        pdf(paste0("../../results/CGIs/",CpGIslands[Ind],'.pdf'),pointsize=10, bg="white")
        plot_CGI(CpGIslands[Ind],Disease="BRCA",type="BOTH")
        dev.off()

        # Apply kmeans
        output <- analyze_CGI_patterns(CpGIslands[Ind],Disease="BRCA",type="Cancerous", nclusts = 2, method=method)
        pdf(paste0('../../results/CGIs/',CpGIslands[Ind],'_patterns_',method,'.pdf'),pointsize=10, bg="white")
        grid.arrange(output$p,output$p_modes,ncol=1)
        dev.off()
}

## PCA {{{3
## res.pca <- PCA(gene.df$betas) ### To see : we also need the submatrix of betas instead of the data.frame
## par(mfrow=c(2,1))
## plot(gene.df$Location,res.pca$var$coord[,1],main ="PC1")
## plot(gene.df$Location,res.pca$var$coord[,2],main ="PC2")
## 
### Analysis of the specific CpG Islands form for "BIG" Islands {{{2
#Chrom <- "1"
#for (chr in unique(fData450K$CHR)){
#analyze_CpG_Islands(Disease="BRCA",Chrom=chr,type="Cancerous")
#}
#
### Analysis of the methylation distribution between Islands/Shores/Shelves .... {{{2
#analyze_CpG_distance(Disease="BRCA",type="Cancerous")
#
#

##
