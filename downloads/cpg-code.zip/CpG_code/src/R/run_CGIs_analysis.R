######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

# Gene processed
###   load("../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs_processed.RData")
###   load("../../data/processed/Methylation/TCGA/BRCA/NormalCGIs_processed.RData")

# load clinicalinfo
#load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
#load("../../data/processed/fData/GeneList.RData")
#load("../../data/processed/fData/GeneProbesList.RData")

# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox {{{1
## load the used packages {{{2
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA
#require('dtw') # for dynamic time warping

## Useful functions{{{2
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source('lib/toolkit/adaptiveStats.R') # standard functions (mean, PC,Score)
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos

## Analysis {{{1
list_big_island <- which(CpGIslands.probesize >=20)
DiseaseList <- c('BRCA','Colon')
DiseaseList <- c('LUAD')

### Goal : Calculate Mean profiles for each CGIs
## source('fun/calculate_Mean_PC.R')
## for (DiseaseName in DiseaseList)
## {
##         out <- calculate_Mean_PC(Disease=DiseaseName,type="Cancerous")
##         if (DiseaseName != "Colon")
##         {
##                 out <- calculate_Mean_PC(Disease=DiseaseName,type="Normal")
##         } else {
##                 out <- calculate_Mean_PC(Disease=DiseaseName,type="Normal",proc=F)
##         }
## }

#### Goal : Calculate the distance between 2 CGIs using dtw
# source('fun/calculate_distanceMatrices.R')
# for (DiseaseName in DiseaseList)
# {
#         # print(DiseaseName)
#         out <- calculate_distanceMatrices(Disease=DiseaseName,type="Cancerous")
#         out <- calculate_distanceMatrices(Disease=DiseaseName,type="Normal")
# }
 
# DiseaseList <- c('BRCA')

### Goal :  Compare CGIs between normal and tumoral
## source('fun/compare_CGIs.R')
## for (DiseaseName in DiseaseList)
## {
##         out <- compare_CGIs(Disease=DiseaseName, method="L2")
##         # out <- compare_CGIs(Disease=DiseaseName, method="dtw")
## }

## load('../../big_data/CGIs/BRCA_Cancerous_Normal_DistanceCGIMeanNorm.RData') 
## load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean_updown.RData')
## 
## DistanceCGI <- data.frame(distance=BRCA.Cancerous_Normal.distanceCGIMean.Norm, cluster=BRCA.Cancerous.clustersMean)
## 
## pdf('../../results/clustering/BRCA/Mean/distance_CGI.pdf')
## ggplot(DistanceCGI) + geom_boxplot(aes(x=cluster,y=distance))
## dev.off()
 
## CGI Analysis
#### Goal : cluster CGIs, look at clusters characteristic profiles and their position on the genome.

load('../../data/processed/fData/fData_CGI_big_island.RData')
load('../../data/processed/fData/hg19.RData')

## DiseaseList <- c('BRCA','Colon')

source('fun/CGI_analysis.R')

DiseaseList <- c('BRCA','LUAD','Colon')

for (DiseaseName in DiseaseList)
{
        print(DiseaseName)
        out <- analyze_CGI_clusters(Disease=DiseaseName,type="Cancerous")
        # out <- analyze_CGI_clusters(Disease=DiseaseName,type="Normal")
}


###############
## Create one panel for each clusters
###############
# Disease <- "BRCA"
# Disease <- "Colon"
Disease <- "LUAD"
# type <- "Cancerous"
type <- "Normal"
method <- "Mean"

### Restrict to the top 10 characteristic profiles
index_characteristics <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type,'CGIs_characteristics.RData')))
index_characteristics_bis <- lapply(1:length(index_characteristics), function(n)
                                    {
                                            index_characteristics[[n]][1:10]
                                    })
names(index_characteristics_bis) <- names(index_characteristics)
index_characteristics <- index_characteristics_bis

CGI.dat <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type,'CGIs_',method,'.RData')))

CGI.dat_big_island <- CGI.dat[list_big_island]

load('../../data/processed/fData/fData_CGI_big_island.RData')

Dat.char <- vector('list')

#clusters <- c('1','2','3','4')
if (type=="Normal")
{
        #clusters <- c('1','2','3')
        clusters <- c('1','2')
} else {
        #clusters <- c('1','2','3','4down','4up')
        clusters <- c('1','2','3up','3down')
}

## For Normal colon invert clusters
# index_characteristics_bis <- index_characteristics
# index_characteristics_bis[[3]] <- index_characteristics[[2]]
# index_characteristics_bis[[2]] <- index_characteristics[[3]]
# index_characteristics <- index_characteristics_bis

for (k in 1:length(clusters))
{
        Dat.char[[k]] <- data.frame(methylation=Reduce('c', CGI.dat_big_island[ index_characteristics[[clusters[k]]]]) , 
                                    position = Reduce('c',lapply(1:length(index_characteristics[[clusters[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[clusters[k]]][n]]][ ,"MAPINFO"    ]})) , 
                                    CGI =  Reduce('c',lapply(1:length(index_characteristics[[clusters[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[clusters[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                    IslandBegin= Reduce('c',lapply(1:length(index_characteristics[[clusters[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[clusters[k]]][n]]][ ,"IslandBegin"]})), 
                                    IslandEnd=Reduce('c',lapply(1:length(index_characteristics[[clusters[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[clusters[k]]][n]]][ ,"IslandEnd"]})),
                                    IslandDist=Reduce('c',lapply(1:length(index_characteristics[[clusters[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[clusters[k]]][n]]][ ,"IslandDist"]})),
                                    cluster=paste0('Cluster ',clusters[k]) )

        Dat.char[[k]]$IslandDist[Dat.char[[k]]$IslandDist >1] <- Dat.char[[k]]$IslandDist[Dat.char[[k]]$IslandDist >1]+1000
        Dat.char[[k]]$IslandDist[(Dat.char[[k]]$IslandDist <=1) & (Dat.char[[k]]$IslandDist >0)] <-  Dat.char[[k]]$IslandDist[(Dat.char[[k]]$IslandDist <=1) & (Dat.char[[k]]$IslandDist >0)] * 1000
}

### tmp1 <- Dat.char[[1]][ Dat.char[[1]]$CGI == unique(Dat.char[[1]]$CGI)[1], "methylation"]
### tmp3 <- Dat.char[[1]][ Dat.char[[1]]$CGI == unique(Dat.char[[1]]$CGI)[1], "methylation"]
### tmp2 <- Dat.char[[1]][ Dat.char[[1]]$CGI == unique(Dat.char[[1]]$CGI)[2], "methylation"]
### 
### library(dtw)
### 
### alignment <- dtw(tmp1, tmp2, open.end=T, open.begin=T, step=asymmetric,keep=T)
### 
### ### Euclidean Distance
### plot(tmp2) ### tmp2 is longer than tmp1
### lines(tmp1)
### 
### 
### ### Dynamic Time Warping
### plot(alignment, type="two", off=1)
### 
### plot(alignment$index1, alignment$index2)


Dat.char.tot <- Reduce('rbind',Dat.char)

#         colour_region <- c('N_Shelf' = '#91bfdb',
#                            'N_Shore' = '#ffffbf',
#                            'Island' = '#fc8d59',
#                            'S_Shore' = '#ffffbf',
#                            'S_Shelf' = '#91bfdb')
# 

#geom_point(aes(colour=CGI)) + geom_line(aes(colour=CGI))+ geom_vline(aes(xintercept=0),colour="black",linetype="longdash") +
# pdf(paste0("../../results/clustering/",Disease,"/",method,"/clusters_profiles_",type,".pdf"), width=10, height=10, pointsize=10)
#p <- ggplot(Dat.char.tot,aes(x=IslandDist,y=methylation,colour=CGI))+ 
colour_scale <- c('Cluster 1' = '#225ea8',
                  'Cluster 2' = 'gold2',
                  'Cluster 3down' = '#66c2a4',
                  'Cluster 3up' = '#238b45')


p <- ggplot(Dat.char.tot,aes(x=IslandDist,y=methylation))+ 
geom_point(aes(colour=cluster)) + geom_line(aes(group=CGI,colour=cluster),alpha=0.8,size=0.7)+ scale_colour_manual(values=colour_scale) +
# geom_point() + geom_line(aes(group=CGI),alpha=0.8) +
geom_vline(aes(xintercept=0),colour="#fc8d59",linetype="dashed",size=1) +
geom_vline(aes(xintercept=+1000),colour="#fc8d59",linetype="dashed",size=1)+ 
geom_vline(aes(xintercept=-2000),colour="#91bfdb",linetype="dashed",size=1)+
geom_vline(aes(xintercept=+3000),colour="#91bfdb",linetype="dashed",size=1)+ 
facet_wrap( ~ cluster ,ncol=2) + 
ylab("Methylation") +
xlab('') +
coord_cartesian(ylim=c(0, 1)) +
scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
scale_x_continuous(breaks=c(-4000,-2000,0,1000,3000,5000),label=c('-4kb','-2kb','','','2kb','4kb')) +
theme(panel.grid=element_blank(),
      panel.margin = unit(1, "lines"),
      # axis.ticks.margin = unit(1, "lines"),
      legend.position="none",
      text = element_text(size=20),
      panel.background=element_rect(fill="white"),
      axis.text=element_text(colour="black",size=rel(0.8)),
      axis.ticks=element_line(colour="black"),
      panel.border=element_rect(fill=NA, colour="black",size=0.7),
      axis.title.y = element_text(vjust=0.6),
      strip.background = element_rect(colour="black",fill="white"),
      axis.line = element_line(colour = "black",size=0.3))



# ggsave("~/Desktop/Profile3.pdf",p, dpi=300)
#if (type == "Cancerous")
#{
#        ggsave(paste0("../../results/clustering/",Disease,"/",method,"/clusters_profiles_",type,".pdf"),p, dpi=300, width=12, height=14)
#} else {
#        ggsave(paste0("../../results/clustering/",Disease,"/",method,"/clusters_profiles_",type,".pdf"),p, dpi=300, width=12, height=7)
#}
ggsave(paste0("../../results/clustering/",Disease,"/",method,"/clusters_profiles_",type,".pdf"),p, dpi=300)
## 11.4 x 4.36 for normal
## 11.4 x 7.76 for cancerous



#####################################
#####################################
#####################################
### Comparing cluster 1/2  shores
Shores_regions.1 <- ((Dat.char[[1]]$IslandDist <=0) & (Dat.char[[1]]$IslandDist >-2000)) | ((Dat.char[[1]]$IslandDist <=3000) & (Dat.char[[1]]$IslandDist >0))
Dat.char.shores.1 <- Dat.char[[1]][Shores_regions.1,"methylation"]

Shores_regions.2 <- ((Dat.char[[2]]$IslandDist <=0) & (Dat.char[[2]]$IslandDist >-2000)) | ((Dat.char[[2]]$IslandDist <=3000) & (Dat.char[[2]]$IslandDist >0))
Dat.char.shores.2 <- Dat.char[[2]][Shores_regions.2,"methylation"]

Shores.df <- data.frame(methylation= c(Dat.char.shores.1, Dat.char.shores.2),
                        clusters = rep(c(1,2), c(length(Dat.char.shores.1), length(Dat.char.shores.2))))

ggplot(Shores.df) + geom_boxplot(aes(y=methylation, x=factor(clusters)))

wilcox.test(Dat.char.shores.1, Dat.char.shores.2)

#####      ### Supplementary Analysis
#####      
#####      ### All Islands
#####      #for (k in 1:length(list_big_island))
#####      #{
#####      #        pdf(paste0('~/Desktop/Figures/Figure',k,'.pdf'))
#####      #        plot_CGI_info(names(BRCA.CancerousCGIs)[list_big_island[k]],'BRCA',type="Cancerous") 
#####      #        dev.off()
#####      #}
#####      
#####      ## Compare Normal vs Tumoral
#####      source('fun/compare_clusters.R')
#####      
#####      DiseaseList <- c('BRCA','Colon','LUAD')
#####      
#####      for (DiseaseName in DiseaseList)
#####      {
#####              compare_clusters(Disease1=DiseaseName,type1="Cancerous")
#####      }
#####      
#####      ## Compare cancer1 vs cancer2
#####      ##  source('fun/compare_clusters.R')
#####      ##  
#####      ##  compare_clusters(Disease1="BRCA",type1="Cancerous", Disease2="Colon")
#####      
#####      ## !! ## Careful PC1 = +/- PC1 careful for DTW
#####      
#####      ###   ## Compare cluster1 and 2 of BRCA
#####      ###   load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean.RData')
#####      ###   #BRCA.Cancerous.clustersMean
#####      ###   Length.Info <- sapply(fData_CGI_big_island, nrow)
#####      ###   cluster.df <- data.frame(cluster=BRCA.Cancerous.clustersMean, length=Length.Info)
#####      ###   pdf('../../results/clustering/BRCA/cluster1_cluster2.pdf')
#####      ###   ggplot(cluster.df) + geom_boxplot(aes(y=length, x=factor(cluster), colour=factor(cluster)))
#####      ###   dev.off()
#####      
#####      ## for (DiseaseName in DiseaseList)
#####      ## {
#####      ##         out <- plot_characteristic_profiles(Disease=DiseaseName,type="Cancerous")
#####      ##         out <- plot_characteristic_profiles(Disease=DiseaseName,type="Normal")
#####      ## }
#####      
#####      ###   CGI.mean <- sapply(CGI.dat_big_island,mean)
#####      ###   
#####      ###   Dat.Mean <- data.frame(mean=CGI.mean, clusters=clusters)
#####      ###   
#####      ###   pdf('../../results/clustering/BRCA/Mean/clusters_mean.pdf')
#####      ###   ggplot(Dat.Mean) + geom_boxplot(aes(x=factor(clusters), y=mean))
#####      ###   dev.off()
#####      ###   
#####      ###   ###
#####      ###   # A1 <- Dat.Mean$mean[Dat.Mean$clusters==1]
#####      ###   # A2 <- Dat.Mean$mean[Dat.Mean$clusters==2]
#####      ###   
#####      ###   ## wilcox.test(A1,A2)$p.value == 8.4e-26
#####      ###   
#####      ###   CGI.Island <- sapply(1:length(CGI.dat_big_island), function(n){sum( grepl("Island",fData450K[names(CGI.dat_big_island[[n]]), "Relation_to_UCSC_CpG_Island"]))})
#####      ###   CGI.Shore <- sapply(1:length(CGI.dat_big_island), function(n){sum( grepl("Shore",fData450K[names(CGI.dat_big_island[[n]]), "Relation_to_UCSC_CpG_Island"]))})
#####      ###   CGI.Shelf <- sapply(1:length(CGI.dat_big_island), function(n){sum( grepl("Shelf",fData450K[names(CGI.dat_big_island[[n]]), "Relation_to_UCSC_CpG_Island"]))})
#####      ###   
#####      ###   Dat.Info <- data.frame(clusters=as.character(clusters), Island=CGI.Island, Shore=CGI.Shore, Shelf=CGI.Shelf) 
#####      ###   
#####      ###   Dat.m <- melt(Dat.Info)
#####      ###   
#####      ###   pdf('../../results/clustering/BRCA/Mean/clusters_info.pdf')
#####      ###   ggplot(Dat.m) + geom_boxplot(aes(x=factor(clusters), y=value,fill=factor(variable)),position="dodge")
#####      ###   dev.off()


