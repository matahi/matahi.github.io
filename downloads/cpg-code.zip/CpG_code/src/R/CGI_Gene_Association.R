load("../../data/processed/fData/fData_CGI.RData") 
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

list_big_island <-which(CpGIslands.probesize>=20)

GE.dat <- get(load('../../data/processed/GeneExpression/RNASeq/TCGA/BRCA/CancerousLevel3GE_processed.RData'))

#########
### FULL ASSOCIATION
#########
Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
CGI.Genes <- unique(Reduce('c',lapply(1:length(fData_CGI),function(n){ Reduce('c', strsplit(fData_CGI[[n]][,"UCSC_RefGene_Name"],";"))})))
save(CGI.Genes, file="../../big_data/GE_prediction/Tools/CGI_Genes.RData")

# GeneList <- get(load('../../data/processed/fData/GeneList.RData'))

Full.CommonGenes <- intersect(Genes.GE, CGI.Genes)
save(Full.CommonGenes, file="../../big_data/GE_prediction/Tools/FullCommonGenes.RData")

AssocGenes_CGI <- lapply(1:length(fData_CGI), function(n)
                         {
                                 print(paste0(n,'/',length(fData_CGI)))
                                 unique(Reduce('c', strsplit(fData_CGI[[n]][,"UCSC_RefGene_Name"],";")))
                         })

AssocCGI_Genes <- lapply(1:length(CGI.Genes), function(n)
                         {
                                 print(paste0(n,'/',length(CGI.Genes)))
                                 # progress <- n*100/length(Genes.GE)
                                 # if (progress %/% length(Genes.GE==0))
                                 # {
                                 #         print(paste0("progress: ", progress,"/100%"))
                                 # }

                                 grep(CGI.Genes[n], AssocGenes_CGI,fixed=T)
                         })
names(AssocCGI_Genes) <- CGI.Genes
save(AssocCGI_Genes, file="../../big_data/GE_prediction/Tools/AssocCGI_Genes.RData")

# Assoc.islandGenes: for each gene, gives the index of the CGI associated
Assoc.islandGenes.Function <- lapply(1:length(AssocCGI_Genes), function(n)
                                     {
                                             print(paste0(n,"/",length(AssocCGI_Genes)))
                                             GeneName <- names(AssocCGI_Genes)[n]
                                             CGIs <- AssocCGI_Genes[[n]]

                                             if (length(CGIs)==0)
                                             {
                                                     Infos <- NA
                                             } else {
                                                     Infos <- sapply(1:length(CGIs), function(k)
                                                                     {
                                                                             index <- CGIs[k]
                                                                             Genes.CGI <- strsplit(fData_CGI[[index]][,"UCSC_RefGene_Name"],";")
                                                                             Infos.CGI <- strsplit(fData_CGI[[index]][,"UCSC_RefGene_Group"],";")

                                                                             Filter.Gene <- lapply(1:length(Genes.CGI), function(j)
                                                                                                   {
                                                                                                           return(grep(GeneName,Genes.CGI[[j]]))
                                                                                                   })

                                                                             return(unique(Reduce('c',lapply(1:length(Filter.Gene),function(i)
                                                                                                             {
                                                                                                                     return(Infos.CGI[[i]][Filter.Gene[[i]]])
                                                                                                             }))))

                                                                     })
                                             }

                                             return(Infos)

                                     })

Assoc.islandGenes.TSS <- lapply(1:length(Assoc.islandGenes.Function), function(n)
                                {
                                        grepl('TSS',Assoc.islandGenes.Function[[n]])
                                })

#### All_CGIs Genes association
Assoc <- lapply(1:length(Full.CommonGenes), function(n) { return( AssocCGI_Genes[[match(Full.CommonGenes[n], names(AssocCGI_Genes))]] ) }) 

# Method 1: Only promoter? {{{2
Full.Promoter.Assoc <- sapply(1:length(Assoc), function(n)
                         { 
                                 if (length(Assoc[[n]])==1) #if only 1 CGI, take it
                                 {
                                         return(Assoc[[n]])
                                 } else if (length(Assoc[[n]]>1))  # if more than 1, several cases
                                 {
                                         print('More than 1 CGI...')
                                         tmp <- Assoc.islandGenes.TSS[[ match(Full.CommonGenes[n], names(AssocCGI_Genes))  ]]
                                         if (sum(tmp)==0) # no CGI related to TSS then just take the first one
                                         {
                                                 print('     Case 1: no CGI related to TSS')
                                                 return(Assoc[[n]][1])
                                         } else if (sum(tmp)==1) # if exactly 1 related to TSS then take it
                                         {
                                                 print('     Case 2: exactly 1 CGI related to TSS')
                                                 return(Assoc[[n]][tmp==1])
                                         } else  #otherwise take the first one
                                         {
                                                 print('     Case 3: more than 1 CGI related to TSS')
                                                 return(Assoc[[n]][which(tmp==1)[1]])
                                         }

                                 }
                         })

save(Full.Promoter.Assoc, file="../../big_data/GE_prediction/Tools/FullPromoterAssoc.RData")

# Remark on CGI Distribution : 
table(sapply(Assoc.islandGenes.TSS,sum), sapply(Assoc.islandGenes,length))

# Method 2: All of them {{{2
Full.AllCGIs.Assoc <- Assoc
save(Full.AllCGIs.Assoc, file="../../big_data/GE_prediction/Tools/FullAllCGIsAssoc.RData")



#########
### BIG ISLAND ONLY {{{1
########
fData.big_island <- fData_CGI[list_big_island]
CGI_big_island.Genes <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

# Find common genes between methylation and expression
Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
CommonGenes <- intersect(Genes.GE, CGI_big_island.Genes)

save(CommonGenes, file="../../big_data/GE_prediction/Tools/CommonGenes.RData")

######
GE.New <- GE.dat[match(CommonGenes,Genes.GE),]
load("../../big_data/AssocIslandGenes.RData")
# Assoc.islandGenes: for each gene, gives the index of the CGI associated
Assoc.islandGenes.Function <- lapply(1:length(Assoc.islandGenes), function(n)
                                     {
                                             GeneName <- names(Assoc.islandGenes)[n]
                                             CGIs <- Assoc.islandGenes[[n]]

                                             Infos <- lapply(1:length(CGIs), function(k)
                                                             {
                                                                     index <- CGIs[k]
                                                                     Genes.CGI <- strsplit(fData.big_island[[index]][,"UCSC_RefGene_Name"],";")
                                                                     Infos.CGI <- strsplit(fData.big_island[[index]][,"UCSC_RefGene_Group"],";")

                                                                     Filter.Gene <- lapply(1:length(Genes.CGI), function(j)
                                                                                           {
                                                                                                   return(grep(GeneName,Genes.CGI[[j]]))
                                                                                           })

                                                                     return(unique(Reduce('c',lapply(1:length(Filter.Gene),function(i)
                                                                                                      {
                                                                                                              return(Infos.CGI[[i]][Filter.Gene[[i]]])
                                                                                                      }))))

                                                             })

                                             return(Infos)

                                     })

Assoc.islandGenes.TSS <- lapply(1:length(Assoc.islandGenes.Function), function(n)
                                {
                                        grepl('TSS',Assoc.islandGenes.Function[[n]])
                                })



#### All_CGIs Genes association
Assoc <- lapply(1:length(CommonGenes), function(n) { return( Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]] ) }) 

# Method 1: Only promoter? 
Promoter.Assoc <- sapply(1:length(Assoc), function(n)
                         { 
                                 if (length(Assoc[[n]])==1) #if only 1 CGI, take it
                                 {
                                         return(Assoc[[n]])
                                 } else if (length(Assoc[[n]]>1))  # if more than 1, several cases
                                 {
                                         print('More than 1 CGI...')
                                         tmp <- Assoc.islandGenes.TSS[[ match(CommonGenes[n], names(Assoc.islandGenes))  ]]
                                         if (sum(tmp)==0) # no CGI related to TSS then just take the first one
                                         {
                                                 print('     Case 1: no CGI related to TSS')
                                                 return(Assoc[[n]][1])
                                         } else if (sum(tmp)==1) # if exactly 1 related to TSS then take it
                                         {
                                                 print('     Case 2: exactly 1 CGI related to TSS')
                                                 return(Assoc[[n]][tmp==1])
                                         } else  #otherwise take the first one
                                         {
                                                 print('     Case 3: more than 1 CGI related to TSS')
                                                 return(Assoc[[n]][which(tmp==1)[1]])
                                         }

                                 }
                         })

save(Promoter.Assoc, file="../../big_data/GE_prediction/Tools/PromoterAssoc.RData")

# Remark on CGI Distribution : 
table(sapply(Assoc.islandGenes.TSS,sum), sapply(Assoc.islandGenes,length))

# Method 2: All of them
AllCGIs.Assoc <- Assoc
save(AllCGIs.Assoc, file="../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData")
