######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

##############
DiseaseList <- c('BRCA','Colon','LUAD')

clusters <- sapply(1:length(DiseaseList), function(n){ return(get(load(paste0('../../big_data/CGIs/',DiseaseList[n],'_Normal_ClustersMean.RData'))))})


##############
DiseaseList <- c('BRCA','Colon','LUAD')

clusters <- sapply(1:length(DiseaseList), function(n){ return(get(load(paste0('../../big_data/CGIs/',DiseaseList[n],'_Cancerous_ClustersMean_updown.RData'))))})
colnames(clusters) <- DiseaseList
clusters <- data.frame(clusters)

cluster.4 <- lapply(1:ncol(clusters), function(n){ names(clusters[,n])[clusters[,n] %in% c('4down','4up')]})
names(cluster.4) <- c('Breast','Colon','Lung') 

library(VennDiagram)

intersect.4.black <- venn.diagram(cluster.4, filename=NULL)

pdf('../../results/GE_CGIs/InterCancer/Venn_4.pdf')
grid.draw(intersect.4.black)
dev.off()

intersect.4.color <- venn.diagram(cluster.4, cat.cex=2.2, cex=3,  cat.fontfamily="",
                                  col = c("cornflowerblue", "green", "red"), fill = c("cornflowerblue", "green", "red"), filename=NULL)

graphics.off()

pdf('../../results/GE_CGIs/InterCancer/Venn_4_color.pdf')
grid.draw(intersect.4.color)
dev.off()


# cluster.4down <- lapply(1:ncol(clusters), function(n){ names(clusters[,n])[clusters[,n] == '4down']})
# cluster.4up <- lapply(1:ncol(clusters), function(n){ names(clusters[,n])[clusters[,n] == '4up']})
# names(cluster.4down) <- DiseaseList
# names(cluster.4up) <- DiseaseList
# 
# library(VennDiagram)
# intersect.4down <- venn.diagram(cluster.4down, filename=NULL)
# intersect.4up <- venn.diagram(cluster.4up, filename=NULL)
# 
# pdf('../../results/GE_CGIs/InterCancer/Venn_4down.pdf')
# grid.draw(intersect.4down)
# dev.off()
# 
# pdf('../../results/GE_CGIs/InterCancer/Venn_4up.pdf')
# grid.draw(intersect.4up)
# dev.off()



#####
Genes.GE <- get(load('../../big_data/GE_prediction/Tools/GE_GeneList.RData')) 
CommonGenes <- get(load('../../big_data/GE_prediction/Tools/CommonGenes.RData')) 

GE.Cancerous <- sapply(1:length(DiseaseList), function(n)
                                { 
                                        Dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseList[n],'/CancerousLevel3GE_processed.RData')))
                                        Dat.CommonGenes <- Dat[match(CommonGenes,Genes.GE),]
                                        Dat.Mean <- apply(Dat.CommonGenes,1,mean)
                                        #
                                        return(Dat.Mean)
                                })
colnames(GE.Cancerous) <- DiseaseList
GE.Cancerous <- data.frame(GE.Cancerous)

GE.Normal <- sapply(1:length(DiseaseList), function(n)
                    { 
                            if (DiseaseList[n] != "Colon") 
                            {
                                    Dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseList[n],'/NormalLevel3GE_processed.RData')))
                                    Dat.CommonGenes <- Dat[match(CommonGenes,Genes.GE),]
                                    Dat.Mean <- apply(Dat.CommonGenes,1,mean)
                            } else {
                                    Dat.Mean <- rep(NA,length(CommonGenes))
                            }
                            #
                            return(Dat.Mean)
                    })
colnames(GE.Normal) <- DiseaseList
GE.Normal <- data.frame(GE.Normal)

############
## Create a New Cluster list including the information from all clusters
Clusters.CGI <- rep('Others',nrow(clusters))

Clusters.CGI[(clusters$BRCA=="4up")&(clusters$Colon!="4up")&(clusters$LUAD!="4up")] <- "4up.BRCA"
Clusters.CGI[(clusters$BRCA!="4up")&(clusters$Colon=="4up")&(clusters$LUAD!="4up")] <- "4up.Colon"
Clusters.CGI[(clusters$BRCA!="4up")&(clusters$Colon!="4up")&(clusters$LUAD=="4up")] <- "4up.LUAD"
Clusters.CGI[(clusters$BRCA=="4up")&(clusters$Colon=="4up")&(clusters$LUAD=="4up")] <- "4up.Common"

save(Clusters.CGI,file="~/Desktop/Clusters_All.RData")

#####
PromoterAssoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
Clusters.New <- sapply(1:length(CommonGenes), function(n) { return( Clusters.CGI[PromoterAssoc[n]]  ) })
## table(Clusters.New)


#############
library(reshape2)
GE.Cancerous.df <- melt(GE.Cancerous)
GE.Cancerous.df <- data.frame(GE=GE.Cancerous.df$value,Disease=rep(DiseaseList,each=length(CommonGenes)),type="Cancerous",Clusters=Clusters.New)

GE.Normal.df <- melt(GE.Normal)
GE.Normal.df <- data.frame(GE=GE.Normal.df$value,Disease=rep(DiseaseList,each=length(CommonGenes)),type="Normal", Clusters=Clusters.New)

GE.df <- rbind(GE.Cancerous.df, GE.Normal.df)
GE.df$GE <- log2(GE.df$GE + 10^-5)

GE.df$Clusters <- factor(GE.df$Clusters, levels=c('4up.BRCA','4up.Colon','4up.LUAD','4up.Common','Others'))

library(ggplot2)
# ggplot(GE.df) + geom_boxplot(aes(y=GE,x=Disease,fill=type)) + facet_wrap( ~ Clusters, scales="free")
pdf(paste0('../../results/GE_CGIs/InterCancer/Mean/Cluster_GEMean_updown.pdf'))
ggplot(GE.df) + geom_boxplot(aes(y=GE,x=Disease,fill=type)) + facet_wrap( ~ Clusters,ncol=5)
dev.off()

#############
# GO
load('../../data/processed/fData/fData_CGI_big_island.RData')
CGI.Genes <- sapply(1:length(fData_CGI_big_island),function(n){ unique(Reduce('c',strsplit(fData_CGI_big_island[[n]][,"UCSC_RefGene_Name"], ";")))   })

unique_clusters <- c('4up.BRCA','4up.Colon','4up.LUAD','4up.Common','Others')
CGI.Genes.clusters <- lapply(1:length(unique_clusters), function(n){ unique(Reduce('c', CGI.Genes[Clusters.CGI==unique_clusters[n]]))})

library(biomaRt)
mart <- useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")
CGI.entrezGenes.clusters <- lapply(1:length(unique_clusters),function(n){getBM(attributes = c("entrezgene"),
                                                                                filters = "hgnc_symbol", values = CGI.Genes.clusters[[n]],
                                                                                mart = mart)[,1]})
names(CGI.entrezGenes.clusters) <- unique_clusters

universe <- unique(Reduce('c',CGI.entrezGenes.clusters))

library('clusterProfiler')
source('lib/fct.plotCompClusterProfiler.R')
xx_bp <- compareCluster(CGI.entrezGenes.clusters, fun="enrichGO", ont="BP",universe=universe)

xx_mf <- compareCluster(CGI.entrezGenes.clusters, fun="enrichGO", ont="MF",universe=universe)

pdf(paste0('../../results/clustering/InterCancer/Gene_Ontology_BP_Cancerous.pdf'),width=10, height=10, pointsize=10, bg="white")
print(plotCompGO(xx_bp,grps=names(CGI.entrezGenes.clusters), sortBy="Count", showCategory=20 ))
dev.off()

pdf(paste0('../../results/clustering/InterCancer/Gene_Ontology_MF_Cancerous.pdf'),width=10, height=10, pointsize=10, bg="white")
print(plotCompGO(xx_mf,grps=names(CGI.entrezGenes.clusters), sortBy="Count", showCategory=20 ))
dev.off()








