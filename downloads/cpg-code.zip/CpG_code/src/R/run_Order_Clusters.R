######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

DiseaseList <- c('BRCA','Colon','LUAD')

#====================#
DiseaseName <- "BRCA"
#====================#
clusters.Normal <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Normal_ClustersMean.RData'))) 
clusters.Cancerous <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean.RData'))) 

Cross <- table(clusters.Normal,clusters.Cancerous)
tmp <- clusters.Cancerous
clusters.Cancerous[tmp==3] <- 4
clusters.Cancerous[tmp==4] <- 3

save(clusters.Cancerous, file=paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean.RData'))

# Creating updown
clusters.Cancerous.updown <- clusters.Cancerous
clusters.Cancerous.updown[(clusters.Cancerous==4)&(clusters.Normal %in% c(1,2))] <- "4up"
clusters.Cancerous.updown[(clusters.Cancerous==4)&(clusters.Normal==3)] <- "4down"

save(clusters.Cancerous.updown, file=paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown.RData'))

#====================#
DiseaseName <- "Colon"
#====================#
clusters.Normal <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Normal_ClustersMean.RData'))) 
clusters.Cancerous <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean.RData'))) 

Cross <- table(clusters.Normal,clusters.Cancerous)
tmp <- clusters.Cancerous
clusters.Cancerous[tmp==3] <- 4
clusters.Cancerous[tmp==4] <- 3
save(clusters.Cancerous, file=paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean.RData'))

# Creating updown
clusters.Cancerous.updown <- clusters.Cancerous
clusters.Cancerous.updown[(clusters.Cancerous==4)&(clusters.Normal %in% c(1,2))] <- "4up"
clusters.Cancerous.updown[(clusters.Cancerous==4)&(clusters.Normal==3)] <- "4down"

save(clusters.Cancerous.updown, file=paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown.RData'))

#====================#
DiseaseName <- "LUAD"
#====================#
clusters.Normal <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Normal_ClustersMean.RData'))) 
clusters.Cancerous <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean.RData'))) 

Cross <- table(clusters.Normal,clusters.Cancerous)
tmp <- clusters.Cancerous
clusters.Cancerous[tmp==3] <- 1
clusters.Cancerous[tmp==1] <- 2
clusters.Cancerous[tmp==2] <- 4
clusters.Cancerous[tmp==4] <- 3

save(clusters.Cancerous, file=paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean.RData'))

# Creating updown
clusters.Cancerous.updown <- clusters.Cancerous
clusters.Cancerous.updown[(clusters.Cancerous==4)&(clusters.Normal %in% c(1,2))] <- "4up"
clusters.Cancerous.updown[(clusters.Cancerous==4)&(clusters.Normal==3)] <- "4down"

save(clusters.Cancerous.updown, file=paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown.RData'))






