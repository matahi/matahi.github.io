######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
#args <- commandArgs(TRUE); PATH = args[1]
#setwd(PATH)

## Gene processed Methylation
#load("../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs_processed.RData")
#load("../../data/processed/Methylation/TCGA/BRCA/NormalCGIs_processed.RData")
#
## Gene Expression
#load("../../data/processed/GeneExpression/TCGA/BRCA/CancerousLevel3GE_processed.RData")
#load("../../data/processed/GeneExpression/TCGA/BRCA/NormalLevel3GE_processed.RData")
#
## load clinicalinfo
#load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
#load("../../data/processed/fData/fData450K_Gene.RData") 
# load("../../data/processed/fData/fData_CGI.RData") 
# load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
load("../../data/processed/fData/GeneList.RData")
load("../../data/processed/fData/GeneProbesList.RData")

# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox {{{1
## load the used packages {{{2
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions{{{2
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos
#source("fun/compare_GE_CGIs.R")
source("fun/compare_GE_clusters.R")

## Analysis {{{1
list_big_island <- which(CpGIslands.probesize >=20)
# plot {{{2

# Statistical Analysis: Use methylation to predict Gene Expression state {{{2
# Method = mean
## DiseaseList <- c('BRCA')
## DiseaseName <- 'BRCA'
## DiseaseName <- 'Colon'
## type <- 'Cancerous'
## # MethylationAnalysis <- 'all'
## # Clinical <- 'F'
## big_island <- T

## compare_GE_Methylation
# compare_GE_CGIs(DiseaseName= "BRCA", type="Cancerous" ,MethylationAnalysis= "all", Clinical=F, big_island=T)

out <- compare_GE_clusters(DiseaseName= "BRCA")

out <- compare_GE_clusters(DiseaseName= "LUAD")

## Finish Colon
out <- compare_GE_clusters(DiseaseName= "Colon")


