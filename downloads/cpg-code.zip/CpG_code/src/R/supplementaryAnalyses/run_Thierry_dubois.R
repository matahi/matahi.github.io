#PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
setwd(PATH)

fData450K_Gene <- get(load('../../data/processed/fData/fData450K_Gene.RData'))

BRCA.Cancerous <- get(load('../../data/processed/Methylation/TCGA/BRCA/CancerousGenes.RData'))

BRCA.Clinical <- get(load('../../data/processed/ClinicalAnnotations/BRCA.Clinical.Cancerous.RData'))

GeneList <- c(
'LRP8',
'STK40',
'FBXO32',
'LGR4',
'LGR5',
'LGR6',
'LRP5',
'LRP6',
'PRMT1',
'PRMT2',
'PRMT3',
'PRMT4',
'PRMT5',
'PRMT6',
'PRMT7',
'PRMT8',
'PRMT9')

################
require(ggbio)
require(GenomicRanges)
source("fun/zoom_region.R")

### Processing 
require(TxDb.Hsapiens.UCSC.hg19.knownGene)
txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene

data(genesymbol, package="biovizBase")

for (Gene in GeneList)
{
        print(Gene)
        gene.gr <- genesymbol[Gene]


        fData.Gene <- fData450K_Gene[[Gene]]

        Dat.Gene <- BRCA.Cancerous[[Gene]]

        Dat.Gene <- na.omit(Dat.Gene)
        Dat.Clinical <- BRCA.Clinical[,c('ER','PR','HER2')]

        Dat.Clinical$Class <- (Dat.Clinical$ER + Dat.Clinical$HER2 ==0)
        Dat.Clinical$Class <- as.character(Dat.Clinical$ER + Dat.Clinical$PR + Dat.Clinical$HER2 ==0)

        library(plyr)
        Dat.Clinical$BRCA.Class <- revalue(Dat.Clinical$Class, replace=c("FALSE"='Other',"TRUE"='Triple Neg'))


        library(reshape2)
        melt.df <- melt(Dat.Gene)

        ########## 
        Dat.df <- data.frame(x = rep(fData.Gene[,"MAPINFO"],ncol(Dat.Gene)), class=rep(Dat.Clinical$BRCA.Class, each=nrow(Dat.Gene)), betas = melt.df$value, sample = melt.df$Var2)

        p2 <- ggplot(Dat.df) + geom_line(aes(x= x, y= betas, colour=class,group=sample)) + geom_point(aes(x= x, y= betas, colour=class)) +
        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + 
        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"]))) #+
        #theme(legend.position="none")  

        p1 <- autoplot(txdb, which=gene.gr)

        pdf(paste0('~/Desktop/Dubois/BRCA_',Gene,'.pdf'), width=10, height=10, pointsize=1)
        print(tracks(p1, p2))
        dev.off()

        promoterRegion <- zoom_region(fData.Gene) # Find a way to automatize the zoom on the promoter regions

        pdf(paste0('~/Desktop/Dubois/BRCA_',Gene,'_promoter.pdf'), width=10, height=10, pointsize=1)
        print(tracks(p1, p2) + xlim(promoterRegion))
        dev.off()

}

