setwd("~/Desktop/CpG/src/R") # for Curie Machines

##### 
# Reviewer 1




##### 
# Reviewer 2
#####
# Major Reviews:
# 1) We filter using CGI size: From 21231 Genes to 2374 Genes which represents 10% of the genes measured. 
# => Verify any functional enrichment analysis bias. 
###
Full.GeneList  <- get(load('../../data/processed/fData/GeneList.RData'))
BigCGI.GeneList <- get(load('../../big_data/GE_prediction/Tools/CommonGenes.RData'))

library(biomaRt)
mart <- useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")

Full.Gene.Symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = Full.GeneList, mart = mart)[,1]
BigCGI.Gene.Symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = BigCGI.GeneList, mart = mart)[,1]

library("clusterProfiler")
enrich.BigCGI <- enrichGO(BigCGI.Gene.Symbol, organism="human", ont="BP", pvalueCutoff=0.05, universe= Full.Gene.Symbol,readable=T)

write.table(summary(enrich.BigCGI),file = "../../results/Reviews/GO_BigCGI.txt",row.names=F, sep="\t", quote=F) 

pdf(paste0('../../results/Reviews/GO_BigCGI.pdf'))
print(plot(enrich.BigCGI,showCategory=10,by="geneRatio"))
dev.off()

# Result: We see that indeed the Genes with large CGI measured are enriched in certain pathways though the enrichment analysis is based on the 2374 genes.

# 2)


###################
###################

## New Ideas to implement


