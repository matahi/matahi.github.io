globalCostMatrix <- function (lm, step.matrix = symmetric1, window.function = noWindow, 
                              native = TRUE, seed = NULL, ...) 
{
        #if (!is.stepPattern(step.matrix)) 
        if (!inherits(step.matrix,"stepPattern")) 
                stop("step.matrix is no stepMatrix object")
        n <- nrow(lm)
        m <- ncol(lm)
        nsteps <- dim(step.matrix)[1]

        if (!is.null(seed)) {
                cm <- seed
        }
        else {
                cm <- matrix(NA, nrow = n, ncol = m)
                cm[1, 1] <- lm[1, 1]
        }

        sm <- matrix(NA, nrow = n, ncol = m)

        if (is.loaded("computeCM") && native) 
        {
                print("computeCM is loaded and native is TRUE")
                wm <- matrix(FALSE, nrow = n, ncol = m)
                wm[window.function(row(wm), col(wm), query.size = n, 
                                   reference.size = m, ...)] <- TRUE
                if (FALSE)
                {
                        out <- .C(computeCM, NAOK = TRUE, PACKAGE = "dtw", 
                                  as.integer(dim(cm)), as.logical(wm), as.double(lm), 
                                  as.integer(nsteps), as.double(step.matrix), costMatrix = as.double(cm), 
                                  directionMatrix = as.integer(sm))
                        dim(out$costMatrix) <- c(n, m)
                        dim(out$directionMatrix) <- c(n, m)
                        warning("You should not be here")
                } else {
                        storage.mode(wm) <- "logical"
                        storage.mode(lm) <- "double"
                        storage.mode(cm) <- "double"
                        storage.mode(step.matrix) <- "double"
                        out <- .Call("computeCM_Call", wm, lm, cm, step.matrix)
                }

        } else {
                warning("Native dtw implementation not available: using (slow) interpreted fallback")
                dir <- step.matrix
                npats <- attr(dir, "npat")
                for (j in 1:m) {
                        for (i in 1:n) {
                                if (!window.function(i, j, query.size = n, reference.size = m, 
                                                     ...)) {
                                        next
                                }
                                if (!is.na(cm[i, j])) {
                                        next
                                }
                                clist <- numeric(npats) + NA
                                for (s in 1:nsteps) {
                                        p <- dir[s, 1]
                                        ii <- i - dir[s, 2]
                                        jj <- j - dir[s, 3]
                                        if (ii >= 1 && jj >= 1) {
                                                cc <- dir[s, 4]
                                                if (cc == -1) {
                                                        clist[p] <- cm[ii, jj]
                                                }
                                                else {
                                                        clist[p] <- clist[p] + cc * lm[ii, jj]
                                                }
                                        }
                                }
                                minc <- which.min(clist)
                                if (length(minc) > 0) {
                                        cm[i, j] <- clist[minc]
                                        sm[i, j] <- minc
                                }
                        }
                }
                out <- list(costMatrix = cm, directionMatrix = sm)
        }
        out$stepPattern <- step.matrix
        return(out)
}
