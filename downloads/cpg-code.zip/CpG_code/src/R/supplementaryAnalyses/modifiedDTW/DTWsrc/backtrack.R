backtrack <- function (gcm) 
{
    dir <- gcm$stepPattern
    npat <- attr(dir, "npat")
    n <- nrow(gcm$costMatrix)
    m <- ncol(gcm$costMatrix)
    i <- n
    j <- gcm$jmin
    nullrows <- dir[, 2] == 0 & dir[, 3] == 0
    tmp <- dir[!nullrows, , drop = FALSE]
    stepsCache <- list()
    for (k in 1:npat) {
        stepsCache[[k]] <- .extractpattern(tmp, k)
    }
    ii <- c(i)
    jj <- c(j)
    ss <- NULL
    repeat {
        if (i == 1 && j == 1) {
            break
        }
        s <- gcm$directionMatrix[i, j]
        if (is.na(s)) {
            break
        }
        ss <- c(s, ss)
        steps <- stepsCache[[s]]
        ns <- nrow(steps)
        for (k in 1:ns) {
            ii <- c(i - steps[k, 1], ii)
            jj <- c(j - steps[k, 2], jj)
        }
        i <- i - steps[ns, 1]
        j <- j - steps[ns, 2]
    }
    out <- list(index1 = ii, index2 = jj, stepsTaken = ss)
    return(out)
}
