globalCostMatrix <- function(x,y,dist.method,lambda, window.function=noWindow, step.matrix = symmetric1)
{
        n <- length(x)
        m <- length(y)
        nsteps <- dim(step.matrix)[1]

        # Construct distance matrix
        #distMat <- proxy::dist(x ,y, method = dist.method)
        lm <- proxy::dist(x ,y)

        cm <- matrix(NA, nrow = n, ncol = m)
        cm[1,1] <- lm[1,1]

        ## Window Matrix
        wm <- matrix(FALSE, nrow = n, ncol = m)
        wm[window.function(row(wm), col(wm), query.size = n,reference.size = m)] <- TRUE

        ## matrix
        sm <- matrix(NA, nrow = n, ncol = m)

        ### Calling C code
        storage.mode(wm) <- "logical"
        storage.mode(lm) <- "double"
        storage.mode(cm) <- "double"
        storage.mode(step.matrix) <- "double"
        out <- .Call("computeCM_Call", wm, lm, cm, step.matrix)

        ### Slow method
        #for (i in 1:n)
        #{
        #        for (j in 1:m)
        #        {
        #                if (i==1)&(j==1)
        #                {
        #                } else if (i==n) {
        #                } else if (j==n) {
        #                } 

        #                costMat[i,j] <- min( costMat[i-1,j-1]   +                    ,
        #                                    costMat[i,j-1]      +                    ,
        #                                    costMat[i-1,j]      +                    )

        #        }
        #}

        ### Slow Method
        warning("Native dtw implementation not available: using (slow) interpreted fallback")
        dir <- step.matrix
        npats <- attr(dir, "npat")

        for (j in 1:m) {
                print(paste0('j = ',j))
                for (i in 1:n) {
                        print(paste0('     i = ',i))
                        if (!window.function(i, j, query.size = n, reference.size = m )) {
                                next
                                print("next")
                        }
                        if (!is.na(cm[i, j])) {
                                next
                                print('next')
                        }
                        clist <- numeric(npats) + NA
                        for (s in 1:nsteps) {
                                p <- dir[s, 1]
                                ii <- i - dir[s, 2]
                                jj <- j - dir[s, 3]
                                if (ii >= 1 && jj >= 1) {
                                        cc <- dir[s, 4]
                                        if (cc == -1) {
                                                clist[p] <- cm[ii, jj]
                                        }
                                        else {
                                                clist[p] <- clist[p] + cc * lm[ii, jj]
                                        }
                                }
                        }
                        minc <- which.min(clist)
                        if (length(minc) > 0) {
                                cm[i, j] <- clist[minc]
                                sm[i, j] <- minc
                        }
                }
        }
        out <- list(costMatrix = cm, directionMatrix = sm)

}
