setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R')


source('fun/modifiedDTW/DTWsrc/modifiedDTW.R')
source('fun/modifiedDTW/DTWsrc/GlobalCostMatrix.R')

## Library
library(dtw)

##### Data
idx<-seq(0,6.28,len=100);
query<-sin(idx)+runif(100)/10;
reference<-cos(idx)

#distMat <- proxy::dist(x ,y, method = dist.method)
distMat <- proxy::dist(reference , query)


##
system.time(
costMat <- globalCostMatrix(distMat, native=F)
)


##
system.time(
costMat <- globalCostMatrix(distMat)
)

image(costMat$costMatrix)

#lambda <- 0.1

costMat <- modifiedGlobalCostMatrix(distMat, lambda=lambda)
