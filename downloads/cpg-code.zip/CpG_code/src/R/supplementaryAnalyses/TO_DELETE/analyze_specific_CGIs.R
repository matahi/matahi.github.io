PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
# PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

## Packages
require('ggplot2')
require('reshape2') #for Melt for data.frame
require('gridExtra') # for plotting several ggplots -> grid.arrange

list_big_island <- which(CpGIslands.probesize >=20)

#### Mean Profiles {{{1
## Colon.instable {{{2
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean.RData'))

Colon.Clusters.updown <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean_updown.RData'))
BRCA.Clusters.updown <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean_updown.RData'))

Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))


#### plot Them
Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)

CGI.BRCA <- get(load('../../big_data/CGIs/BRCA_CancerousCGIs_Mean.RData'))
CGI.Colon <- get(load('../../big_data/CGIs/Colon_CancerousCGIs_Mean.RData'))


CGI.BRCA.big_island <- CGI.BRCA[list_big_island]
CGI.Colon.big_island <- CGI.Colon[list_big_island]

load('../../data/processed/fData/fData_CGI_big_island.RData')


#### Colon.instable size= 219
Colon.instable.colon <- data.frame(methylation=Reduce('c', CGI.Colon.big_island[ Colon.instable]) , 
                            position = Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandEnd"]})))

Colon.instable.brca <- data.frame(methylation=Reduce('c', CGI.BRCA.big_island[ Colon.instable]) , 
                            position = Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandEnd"]})))


CGIsNames <- sapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})


Colon.instable.df <- data.frame(rbind(Colon.instable.colon, Colon.instable.brca),type = c(rep('Colon',nrow(Colon.instable.colon)), rep('BRCA',nrow(Colon.instable.brca))))

num_char <- 12 
n.folds <- ceiling(length(Colon.instable)/num_char)
idx <- split( seq( length(Colon.instable) ), seq(n.folds) )

colour_scale <- c('Colon'='blue','BRCA'='red')

for (k in 1:length(idx))
{


        pdf(paste0("../../results/clustering/InterCancer/Mean/Colon_instable_",k,".pdf"), width=10, height=10, pointsize=10)
        print(ggplot(Colon.instable.df[Colon.instable.df$CGI %in% CGIsNames[idx[[k]]],],aes(x=position,y=methylation))+ geom_point(aes(colour=type)) + geom_line(aes(colour=type, group=type))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1) + scale_colour_manual(values=colour_scale))
        dev.off()
}


### BRCA.instable {{{2
BRCA.instable.colon <- data.frame(methylation=Reduce('c', CGI.Colon.big_island[ BRCA.instable]) , 
                            position = Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandEnd"]})))

BRCA.instable.brca <- data.frame(methylation=Reduce('c', CGI.BRCA.big_island[ BRCA.instable]) , 
                            position = Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandEnd"]})))


CGIsNames <- sapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})

BRCA.instable.df <- data.frame(rbind(BRCA.instable.colon, BRCA.instable.brca),type = c(rep('Colon',nrow(BRCA.instable.colon)), rep('BRCA',nrow(BRCA.instable.brca))))

num_char <- 12 
n.folds <- ceiling(length(BRCA.instable)/num_char)
idx <- split( seq( length(BRCA.instable) ), seq(n.folds) )

for (k in 1:length(idx))
{
        pdf(paste0("../../results/clustering/InterCancer/Mean/BRCA_instable_",k,".pdf"), width=10, height=10, pointsize=10)
        print(ggplot(BRCA.instable.df[BRCA.instable.df$CGI %in% CGIsNames[idx[[k]]],],aes(x=position,y=methylation))+ geom_point(aes(colour=type)) + geom_line(aes(colour=type, group=type))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1) + scale_colour_manual(values=colour_scale))
        dev.off()
}

##### POSITION ON THE GENOME
### Variance Profiles {{{1
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersVar.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersVar.RData'))

Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))

Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)


CGI.BRCA <- get(load('../../big_data/CGIs/BRCA_CancerousCGIs_Var.RData'))
CGI.Colon <- get(load('../../big_data/CGIs/Colon_CancerousCGIs_Var.RData'))


CGI.BRCA.big_island <- CGI.BRCA[list_big_island]
CGI.Colon.big_island <- CGI.Colon[list_big_island]

load('../../data/processed/fData/fData_CGI_big_island.RData')

## Colon.instable {{{2
Colon.instable.colon <- data.frame(methylation=Reduce('c', CGI.Colon.big_island[ Colon.instable]) , 
                            position = Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandEnd"]})))

Colon.instable.brca <- data.frame(methylation=Reduce('c', CGI.BRCA.big_island[ Colon.instable]) , 
                            position = Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][ ,"IslandEnd"]})))


CGIsNames <- sapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})

Colon.instable.df <- data.frame(rbind(Colon.instable.colon, Colon.instable.brca),type = c(rep('Colon',nrow(Colon.instable.colon)), rep('BRCA',nrow(Colon.instable.brca))))

num_char <- 12 
n.folds <- ceiling(length(Colon.instable)/num_char)
idx <- split( seq( length(Colon.instable) ), seq(n.folds) )

colour_scale <- c('Colon'='blue','BRCA'='red')

for (k in 1:length(idx))
{


        pdf(paste0("../../results/clustering/InterCancer/Var/Colon_instable_",k,".pdf"), width=10, height=10, pointsize=10)
        print(ggplot(Colon.instable.df[Colon.instable.df$CGI %in% CGIsNames[idx[[k]]],],aes(x=position,y=methylation))+ geom_point(aes(colour=type)) + geom_line(aes(colour=type, group=type))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,0.1) + scale_colour_manual(values=colour_scale))
        dev.off()
}

##### POSITION ON THE GENOME

## BRCA.instable {{{2
BRCA.instable.colon <- data.frame(methylation=Reduce('c', CGI.Colon.big_island[ BRCA.instable]) , 
                            position = Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandEnd"]})))

BRCA.instable.brca <- data.frame(methylation=Reduce('c', CGI.BRCA.big_island[ BRCA.instable]) , 
                            position = Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][ ,"IslandEnd"]})))


CGIsNames <- sapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})


BRCA.instable.df <- data.frame(rbind(BRCA.instable.colon, BRCA.instable.brca),type = c(rep('Colon',nrow(BRCA.instable.colon)), rep('BRCA',nrow(BRCA.instable.brca))))

num_char <- 12 
n.folds <- ceiling(length(BRCA.instable)/num_char)
idx <- split( seq( length(BRCA.instable) ), seq(n.folds) )

for (k in 1:length(idx))
{


        pdf(paste0("../../results/clustering/InterCancer/Var/BRCA_instable_",k,".pdf"), width=10, height=10, pointsize=10)
        print(ggplot(BRCA.instable.df[BRCA.instable.df$CGI %in% CGIsNames[idx[[k]]],],aes(x=position,y=methylation))+ geom_point(aes(colour=type)) + geom_line(aes(colour=type, group=type))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,0.1) + scale_colour_manual(values=colour_scale))
        dev.off()
}

##### POSITION ON THE GENOME

#### Full Profiles {{{1
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean.RData'))

Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))

#### plot Them
Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)

BRCA.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs_processed.RData'))[list_big_island]
Colon.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/Colon/CancerousCGIs_processed.RData'))[list_big_island]

num_char <- 12 

## BRCA.instable Mean {{{2
n.folds <- ceiling(length(BRCA.instable)/num_char)
idx <- split( seq( length(BRCA.instable) ), seq(n.folds) )

BRCA.char <- vector('list')
Colon.char <- vector('list')

for (k in 1:length(idx))
{
        ## BRCA.char
        Dat.full<- Reduce('rbind', BRCA.dat_big_island[ BRCA.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        BRCA.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(BRCA.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(BRCA.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(BRCA.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(BRCA.dat_big_island[[1]]) ))

        ## Colon.char
        Dat.full<- Reduce('rbind', Colon.dat_big_island[ BRCA.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        Colon.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(Colon.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(Colon.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(Colon.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(Colon.dat_big_island[[1]]) ))


        pdf(paste0("../../results/clustering/InterCancer/Full_Mean/BRCA_instable_BRCA_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(BRCA.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()

        pdf(paste0("../../results/clustering/InterCancer/Full_Mean/BRCA_instable_Colon_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(Colon.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()


}

## Colon.instable Mean {{{2
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean.RData'))

Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))

#### plot Them
Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)

# BRCA.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs_processed.RData'))[list_big_island]
# Colon.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/Colon/CancerousCGIs_processed.RData'))[list_big_island]

num_char <- 12 


#### Colon.instable full
n.folds <- ceiling(length(Colon.instable)/num_char)
idx <- split( seq( length(Colon.instable) ), seq(n.folds) )

BRCA.char <- vector('list')
Colon.char <- vector('list')

for (k in 1:length(idx))
{
        print(paste0(k,'/',length(idx)))
        ## BRCA.char
        Dat.full<- Reduce('rbind', BRCA.dat_big_island[ Colon.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        BRCA.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(BRCA.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(BRCA.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(BRCA.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(BRCA.dat_big_island[[1]]) ))

        ## Colon.char
        Dat.full<- Reduce('rbind', Colon.dat_big_island[ Colon.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        Colon.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(Colon.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(Colon.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(Colon.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(Colon.dat_big_island[[1]]) ))


        pdf(paste0("../../results/clustering/InterCancer/Full_Mean/Colon_instable_BRCA_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(BRCA.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()

        pdf(paste0("../../results/clustering/InterCancer/Full_Mean/Colon_instable_Colon_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(Colon.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()


}

## BRCA.instable var {{{2
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersVar.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersVar.RData'))

Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))

#### plot Them
Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)

num_char <- 12 

n.folds <- ceiling(length(BRCA.instable)/num_char)
idx <- split( seq( length(BRCA.instable) ), seq(n.folds) )

BRCA.char <- vector('list')
Colon.char <- vector('list')

for (k in 1:length(idx))
{
        print(paste0(k,'/',length(idx)))
        ## BRCA.char
        Dat.full<- Reduce('rbind', BRCA.dat_big_island[ BRCA.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        BRCA.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(BRCA.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(BRCA.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(BRCA.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(BRCA.dat_big_island[[1]]) ))

        ## Colon.char
        Dat.full<- Reduce('rbind', Colon.dat_big_island[ BRCA.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        Colon.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(Colon.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(Colon.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(Colon.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(BRCA.instable[idx[[k]]]), function(n){fData_CGI_big_island[[BRCA.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(Colon.dat_big_island[[1]]) ))


        pdf(paste0("../../results/clustering/InterCancer/Full_Var/BRCA_instable_BRCA_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(BRCA.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()

        pdf(paste0("../../results/clustering/InterCancer/Full_Var/BRCA_instable_Colon_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(Colon.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()


}

## Colon.instable var {{{2
# Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersVar.RData'))
# BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersVar.RData'))
# 
Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))

#### plot Them
Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)

num_char <- 12 


#### Colon.instable full
n.folds <- ceiling(length(Colon.instable)/num_char)
idx <- split( seq( length(Colon.instable) ), seq(n.folds) )

BRCA.char <- vector('list')
Colon.char <- vector('list')

for (k in 1:length(idx))
{
        print(paste0(k,'/',length(idx)))
        ## BRCA.char
        Dat.full<- Reduce('rbind', BRCA.dat_big_island[ Colon.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        BRCA.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(BRCA.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(BRCA.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(BRCA.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(BRCA.dat_big_island[[1]]) ))

        ## Colon.char
        Dat.full<- Reduce('rbind', Colon.dat_big_island[ Colon.instable[idx[[k]]]])
        Dat.m <- melt(Dat.full)
        Colon.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"MAPINFO"    ]  })),ncol(Colon.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(Colon.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandBegin"]})),ncol(Colon.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(Colon.instable[idx[[k]]]), function(n){fData_CGI_big_island[[Colon.instable[idx[[k]]][n]]][ ,"IslandEnd"]})),ncol(Colon.dat_big_island[[1]]) ))


        pdf(paste0("../../results/clustering/InterCancer/Full_Var/Colon_instable_BRCA_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(BRCA.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()

        pdf(paste0("../../results/clustering/InterCancer/Full_Var/Colon_instable_Colon_",k,".pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(Colon.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()


}


##### POSITION ON THE GENOME {{{1
## ClustersMean 
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean.RData'))

Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))

Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)


library(GenomicRanges)
library(ggbio)
source('fun/plot_gr.R')
load('../../data/processed/fData/hg19.RData')
CGIsNames.Colon <- sapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})
CGIsNames.BRCA <- sapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})

CGIs.names <- c(CGIsNames.Colon, CGIsNames.BRCA)
clusters <- c(rep('Colon',length(CGIsNames.Colon)), rep('BRCA',length(CGIsNames.BRCA)))
colour_scale <- c('Colon'='blue','BRCA'='red')

output <- plot_gr(CGIs.names,clusters=clusters, colour_scale=colour_scale, fData=fData_CGI_big_island[CGIs.names])

pdf(paste0('../../results/clustering/InterCancer/Mean/position_clusters.pdf'))
print(output$p)
dev.off()

## ClustersVar
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersVar.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersVar.RData'))

Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))

Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)


library(GenomicRanges)
library(ggbio)
source('fun/plot_gr.R')
load('../../data/processed/fData/hg19.RData')
CGIsNames.Colon <- sapply(1:length(Colon.instable), function(n){fData_CGI_big_island[[Colon.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})
CGIsNames.BRCA <- sapply(1:length(BRCA.instable), function(n){fData_CGI_big_island[[BRCA.instable[n]]][1 ,"UCSC_CpG_Islands_Name"]})

CGIs.names <- c(CGIsNames.Colon, CGIsNames.BRCA)
clusters <- c(rep('Colon',length(CGIsNames.Colon)), rep('BRCA',length(CGIsNames.BRCA)))
colour_scale <- c('Colon'='blue','BRCA'='red')

output <- plot_gr(CGIs.names,clusters=clusters, colour_scale=colour_scale, fData=fData_CGI_big_island[CGIs.names])

pdf(paste0('../../results/clustering/InterCancer/Var/position_clusters.pdf'))
print(output$p)
dev.off()


######## GE comparison {{{1
GE.BRCA <- get(load('../../data/processed/GeneExpression/RNASeq/TCGA/BRCA/CancerousLevel3GE_processed.RData'))
GE.Colon <- get(load('../../data/processed/GeneExpression/RNASeq/TCGA/Colon/CancerousLevel3GE_processed.RData'))

BRCA.Mean <- apply(GE.BRCA,1,mean)
Colon.Mean <- apply(GE.Colon,1,mean)

Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean.RData'))

#Colon.Clusters.updown <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean_updown.RData'))
#BRCA.Clusters.updown <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean_updown.RData'))


Colon.Specific <- (Colon.Clusters==3)&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific <- (BRCA.Clusters==3)&(Colon.Clusters %in% c(1,2,4))
Common.Cluster3 <- (Colon.Clusters==3)&(BRCA.Clusters==3)
Common.Cluster4 <- (Colon.Clusters==4)&(BRCA.Clusters==4)

Specific.clusters <- rep("Normal",length(Colon.Clusters))
Specific.clusters[Colon.Specific] <- "Colon.Specific"
Specific.clusters[BRCA.Specific] <- "BRCA.Specific"
Specific.clusters[Common.Cluster3] <- "Cluster3.Common"
Specific.clusters[Common.Cluster4] <- "Cluster4.Common"

#### plot Them
Colon.instable <- which(Colon.Specific)
BRCA.instable <- which(BRCA.Specific)


list_big_island <- which(CpGIslands.probesize >=20)
## Meth.dat <- Meth.dat[list_big_island]
load('../../data/processed/fData/fData_CGI.RData')
fData.big_island <- fData_CGI[list_big_island]
# load('../../data/processed/fData/fData_CGI_big_island.RData')
Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

Genes.GE <- sapply(1:nrow(GE.BRCA), function(n){ tmp <- strsplit(rownames(GE.BRCA)[n],"\\|"); return(tmp[[1]][1])     } ) 

load("../../big_data/AssocIslandGenes.RData")

Assoc.info <- lapply(1:length(Assoc.islandGenes),
                     function(n)
                     {
                             return( which(sapply(1:length(Assoc.islandGenes[[n]]) , function(k){ any(grepl('TSS', fData.big_island[[ Assoc.islandGenes[[n]][k] ]][,"UCSC_RefGene_Group"]))})))
                     })


Genes <- sapply(1:nrow(GE.BRCA), function(n){ tmp <- strsplit(rownames(GE.BRCA)[n],"\\|"); return(tmp[[1]][1])     } ) 

CommonGenes <- intersect(Genes.GE, Genes.big_island)

GE.BRCA.common <- GE.BRCA[match(CommonGenes,Genes),]
GE.Colon.common <- GE.Colon[match(CommonGenes,Genes),]

Clusters.New <- sapply(1:length(CommonGenes), function(n) { return( Specific.clusters[[Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1]]]  ) })

GE.BRCA.Mean <- apply(GE.BRCA.common,1,mean)
GE.Colon.Mean <- apply(GE.Colon.common,1,mean)

GE.BRCA.Var <- apply(GE.BRCA.common,1,var)
GE.Colon.Var <- apply(GE.Colon.common,1,var)

Dat.df.BRCA <- data.frame(Clusters= Clusters.New, Variance= GE.BRCA.Var, Mean= GE.BRCA.Mean) 
Dat.df.Colon <- data.frame(Clusters= Clusters.New, Variance= GE.Colon.Var, Mean= GE.Colon.Mean) 

Dat.df <- data.frame( Clusters= c(as.character(Dat.df.BRCA$Clusters), as.character(Dat.df.Colon$Clusters)),
                     Variance= c(Dat.df.BRCA$Variance, Dat.df.Colon$Variance),
                     Mean= c(Dat.df.BRCA$Mean, Dat.df.Colon$Mean),
                     type= c(rep("BRCA",nrow(Dat.df.BRCA)), rep('Colon',nrow(Dat.df.Colon))) )


Dat.df.scatter <- data.frame(BRCA=log2(GE.BRCA.Mean+10^-5), Colon=log2(GE.Colon.Mean+10^-5), Clusters=Clusters.New)
ggplot(Dat.df.scatter) + geom_point(aes(x=BRCA,y=Colon,colour=Clusters))


Dat.df$Variance <- log2(Dat.df$Variance+10^-5)
Dat.df$Mean <- log2(Dat.df$Mean+10^-5)

Dat.df$Clusters <- factor(Dat.df$Clusters, levels=c('BRCA.Specific', 'Colon.Specific', 'Cluster3.Common', 'Cluster4.Common', 'Normal' ))

pdf(paste0('../../results/GE_CGIs/InterCancer/Mean/Cluster_GEMean_specific.pdf'))
#print(ggplot(Dat.df) + geom_boxplot(aes(x=factor(Clusters),y=Mean,fill=factor(type))) ) #+ coord_trans(y="log2")
print(ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=Mean,fill=factor(type))) ) #+ coord_trans(y="log2")
dev.off()

pdf(paste0('../../results/GE_CGIs/InterCancer/Mean/Cluster_GEVariance_specific.pdf'))
#print(ggplot(Dat.df) + geom_boxplot(aes(x=factor(Clusters),y=Variance,fill=factor(type))) ) 
print(ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=Variance,fill=factor(type))) ) 
dev.off()


######################## UPDOWN

Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean_updown.RData'))
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean_updown.RData'))


Colon.Specific.up <- (Colon.Clusters=="3up")&(BRCA.Clusters %in% c(1,2,4))
Colon.Specific.down <- (Colon.Clusters=="3down")&(BRCA.Clusters %in% c(1,2,4))
BRCA.Specific.up <- (BRCA.Clusters=="3up")&(Colon.Clusters %in% c(1,2,4))
BRCA.Specific.down <- (BRCA.Clusters=="3down")&(Colon.Clusters %in% c(1,2,4))
Common.Cluster3up <- (Colon.Clusters=="3up")&(BRCA.Clusters=="3up")
Common.Cluster3down <- (Colon.Clusters=="3down")&(BRCA.Clusters=="3down")
Common.Cluster4 <- (Colon.Clusters==4)&(BRCA.Clusters==4)

Specific.clusters <- rep("Normal",length(Colon.Clusters))
Specific.clusters[Colon.Specific.up] <- "Colon.Specific.up"
Specific.clusters[Colon.Specific.down] <- "Colon.Specific.down"
Specific.clusters[BRCA.Specific.up] <- "BRCA.Specific.up"
Specific.clusters[BRCA.Specific.down] <- "BRCA.Specific.down"
Specific.clusters[Common.Cluster3up] <- "Cluster3up.Common"
Specific.clusters[Common.Cluster3down] <- "Cluster3down.Common"
Specific.clusters[Common.Cluster4] <- "Cluster4.Common"

Clusters.New <- sapply(1:length(CommonGenes), function(n) { return( Specific.clusters[[Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1]]]  ) })

GE.BRCA.Mean <- apply(GE.BRCA.common,1,mean)
GE.Colon.Mean <- apply(GE.Colon.common,1,mean)

GE.BRCA.Var <- apply(GE.BRCA.common,1,var)
GE.Colon.Var <- apply(GE.Colon.common,1,var)

Dat.df.BRCA <- data.frame(Clusters= Clusters.New, Variance= GE.BRCA.Var, Mean= GE.BRCA.Mean) 
Dat.df.Colon <- data.frame(Clusters= Clusters.New, Variance= GE.Colon.Var, Mean= GE.Colon.Mean) 

Dat.df <- data.frame( Clusters= c(as.character(Dat.df.BRCA$Clusters), as.character(Dat.df.Colon$Clusters)),
                     Variance= c(Dat.df.BRCA$Variance, Dat.df.Colon$Variance),
                     Mean= c(Dat.df.BRCA$Mean, Dat.df.Colon$Mean),
                     type= c(rep("BRCA",nrow(Dat.df.BRCA)), rep('Colon',nrow(Dat.df.Colon))) )


Dat.df.scatter <- data.frame(BRCA=log2(GE.BRCA.Mean+10^-5), Colon=log2(GE.Colon.Mean+10^-5), Clusters=Clusters.New)
ggplot(Dat.df.scatter) + geom_point(aes(x=BRCA,y=Colon,colour=Clusters))


Dat.df$Variance <- log2(Dat.df$Variance+10^-5)
Dat.df$Mean <- log2(Dat.df$Mean+10^-5)

Dat.df$Clusters <- factor(Dat.df$Clusters, levels=c('BRCA.Specific.up', 'BRCA.Specific.down', 'Colon.Specific.up','Colon.Specific.down', 'Cluster3up.Common', 'Cluster3down.Common', 'Cluster4.Common', 'Normal' ))

pdf(paste0('../../results/GE_CGIs/InterCancer/Mean/Cluster_GEMean_specific_updown.pdf'))
#print(ggplot(Dat.df) + geom_boxplot(aes(x=factor(Clusters),y=Mean,fill=factor(type))) ) #+ coord_trans(y="log2")
print(ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=Mean,fill=factor(type))) ) #+ coord_trans(y="log2")
dev.off()

pdf(paste0('../../results/GE_CGIs/InterCancer/Mean/Cluster_GEVariance_specific_updown.pdf'))
#print(ggplot(Dat.df) + geom_boxplot(aes(x=factor(Clusters),y=Variance,fill=factor(type))) ) 
print(ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=Variance,fill=factor(type))) ) 
dev.off()


