PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
# PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

## Packages
require('ggplot2')
require('reshape2') #for Melt for data.frame
require('gridExtra') # for plotting several ggplots -> grid.arrange

list_big_island <- which(CpGIslands.probesize >=20)

## Full Profiles
BRCA.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs_processed.RData'))[list_big_island]
#Colon.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/Colon/CancerousCGIs_processed.RData'))[list_big_island]

## Mean Profiles big_island
CGI.BRCA <- get(load('../../big_data/CGIs/BRCA_CancerousCGIs_Mean.RData'))[list_big_island]
#CGI.Colon <- get(load('../../big_data/CGIs/Colon_CancerousCGIs_Mean.RData'))[list_big_island]

## Distance Matrix
BRCA.DistMatrix <- matrix(0,nrow=length(list_big_island), ncol=ncol(BRCA.dat_big_island[[1]]))

for (CGI in 1:nrow(BRCA.DistMatrix))
{
        BRCA.DistMatrix[CGI,] <- sapply( 1:ncol(BRCA.DistMatrix), function(n){ norm(BRCA.dat_big_island[[CGI]][,n] - CGI.BRCA[[CGI]],"2") } )
}

require('gplots')
BRCA.Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean.RData'))
BRCA.Clusters <- as.character(BRCA.Clusters)
BRCA.Clusters[BRCA.Clusters==1] <- "green"
BRCA.Clusters[BRCA.Clusters==2] <- "red"
BRCA.Clusters[BRCA.Clusters==3] <- "blue"
BRCA.Clusters[BRCA.Clusters==4] <- "black"

pdf('../../results/clustering/BRCA/Mean/Dist_to_Mean.pdf')
heatmap.2(BRCA.DistMatrix, trace="none", hclustfun=function(x){hclust(x,method="ward")} , RowSideColors=BRCA.Clusters)
dev.off()

## Load fData
fData_CGI.big_island <- get(load('../../data/processed/fData/fData_CGI.RData'))[list_big_island]

require('ggplot2')
require('ggbio')
require('GenomicRanges')

output <- NULL
tmp <- strsplit(CGIs,":")
new.names <- sapply(1:length(CGIs), function(n){tmp[[n]][1]})

output$gr <- GRanges(seqnames= new.names, 
                     ranges=IRanges(start=sapply(1:length(CGIs),function(n){fData_CGI.big_island[[n]][1,"IslandBegin"]}),end=sapply(1:length(CGIs),function(n){fData_CGI.big_island[[n]][1,"IslandEnd"]})),
                     clusters = BRCA.Clusters
                     )

output$gr <- keepSeqlevels(output$gr, c(paste0('chr',1:22), "chrX"))

colour_scale <- c('1'='red',
                  '2'='green',
                  '3'='blue',
                  '4'='black')

p <- plotGrandLinear(output$gr, aes(y=clusters,colour=factor(clusters))) + scale_colour_manual(values=colour_scale)


#### Zooming on specific chromosome regions
chr5.dense <- output$gr[(seqnames(output$gr)=="chr5")&(start(output$gr)>0)&(end(output$gr)<1e+07 )]
chr6.dense <- output$gr[(seqnames(output$gr)=="chr6")&(start(output$gr)>1e+07)&(end(output$gr)<5e+07 )]

load('../../data/processed/fData/hg19.RData')
p.chr5 <- plotIdeogram(hg19, "chr5")
p.chr5dense <- ggplot(chr5.dense) + geom_point(aes(x=start,y=clusters,colour=factor(clusters)))
tracks(p.chr5, p.chr5dense, heights = c(1.2, 5))

#df <- data.frame(x = seq(from = 1e+07, to = 9e+07, length = 100), y = rnorm(100))
p.chr6 <- plotIdeogram(hg19, "chr6")
p.chr6dense <- ggplot(chr6.dense) + geom_point(aes(x=start,y=clusters,colour=factor(clusters)))
tracks(p.chr6, p2, heights = c(1.2, 5))

###### Do the Same with Colon

PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
# PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

## Packages
require('ggplot2')
require('reshape2') #for Melt for data.frame
require('gridExtra') # for plotting several ggplots -> grid.arrange

list_big_island <- which(CpGIslands.probesize >=20)

## Full Profiles
Colon.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/Colon/CancerousCGIs_processed.RData'))[list_big_island]
#Colon.dat_big_island <- get(load('../../data/processed/Methylation/TCGA/Colon/CancerousCGIs_processed.RData'))[list_big_island]

## Mean Profiles big_island
CGI.Colon <- get(load('../../big_data/CGIs/Colon_CancerousCGIs_Mean.RData'))[list_big_island]
#CGI.Colon <- get(load('../../big_data/CGIs/Colon_CancerousCGIs_Mean.RData'))[list_big_island]

## Distance Matrix
Colon.DistMatrix <- matrix(0,nrow=length(list_big_island), ncol=ncol(Colon.dat_big_island[[1]]))

for (CGI in 1:nrow(Colon.DistMatrix))
{
        Colon.DistMatrix[CGI,] <- sapply( 1:ncol(Colon.DistMatrix), function(n){ norm(Colon.dat_big_island[[CGI]][,n] - CGI.Colon[[CGI]],"2") } )
}

require('gplots')
Colon.Clusters <- get(load('../../big_data/CGIs/Colon_Cancerous_ClustersMean.RData'))
Colon.Clusters <- as.character(Colon.Clusters)
Colon.Clusters[Colon.Clusters==1] <- "green"
Colon.Clusters[Colon.Clusters==2] <- "red"
Colon.Clusters[Colon.Clusters==3] <- "blue"
Colon.Clusters[Colon.Clusters==4] <- "black"

pdf('../../results/clustering/Colon/Mean/Dist_to_Mean.pdf')
heatmap.2(Colon.DistMatrix, trace="none", hclustfun=function(x){hclust(x,method="ward")} , RowSideColors=Colon.Clusters)
dev.off()

## Load fData
fData_CGI.big_island <- get(load('../../data/processed/fData/fData_CGI.RData'))[list_big_island]

require('ggplot2')
require('ggbio')
require('GenomicRanges')

output <- NULL
tmp <- strsplit(CGIs,":")
new.names <- sapply(1:length(CGIs), function(n){tmp[[n]][1]})

output$gr <- GRanges(seqnames= new.names, 
                     ranges=IRanges(start=sapply(1:length(CGIs),function(n){fData_CGI.big_island[[n]][1,"IslandBegin"]}),end=sapply(1:length(CGIs),function(n){fData_CGI.big_island[[n]][1,"IslandEnd"]})),
                     clusters = Colon.Clusters
                     )

output$gr <- keepSeqlevels(output$gr, c(paste0('chr',1:22), "chrX"))

colour_scale <- c('1'='red',
                  '2'='green',
                  '3'='blue',
                  '4'='black')

p <- plotGrandLinear(output$gr, aes(y=clusters,colour=factor(clusters))) + scale_colour_manual(values=colour_scale)


#### Zooming on specific chromosome regions
chr5.dense <- output$gr[(seqnames(output$gr)=="chr5")&(start(output$gr)>0)&(end(output$gr)<1e+07 )]
chr6.dense <- output$gr[(seqnames(output$gr)=="chr6")&(start(output$gr)>1e+07)&(end(output$gr)<5e+07 )]

load('../../data/processed/fData/hg19.RData')
p.chr5 <- plotIdeogram(hg19, "chr5")
p.chr5dense <- ggplot(chr5.dense) + geom_point(aes(x=start,y=clusters,colour=factor(clusters)))
tracks(p.chr5, p.chr5dense, heights = c(1.2, 5))

#df <- data.frame(x = seq(from = 1e+07, to = 9e+07, length = 100), y = rnorm(100))
p.chr6 <- plotIdeogram(hg19, "chr6")
p.chr6dense <- ggplot(chr6.dense) + geom_point(aes(x=start,y=clusters,colour=factor(clusters)))
tracks(p.chr6, p2, heights = c(1.2, 5))


