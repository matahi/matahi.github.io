######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading 
## Path Setting 
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
#setwd(PATH)
#

# Gene processed Methylation
###   load("../../data/processed/Methylation/TCGA/BRCA/CancerousGenes_processed.RData")
###   load("../../data/processed/Methylation/TCGA/BRCA/NormalGenes_processed.RData")
###   
###   # Gene Expression
###   load("../../data/processed/GeneExpression/TCGA/BRCA/CancerousLevel3GE_processed.RData")
###   load("../../data/processed/GeneExpression/TCGA/BRCA/NormalLevel3GE_processed.RData")
###   
###   # load clinicalinfo
###   load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
###   load("../../data/processed/fData/fData450K_Gene.RData") 
###   load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox 
## load the used packages 
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/adjust_CNV.R")

adjust_CNV(DiseaseName="BRCA",type="Cancerous",MethylationAnalysis="Promoter")
#adjust_CNV(DiseaseName="BRCA",type="Cancerous",MethylationAnalysis="AllCGIs")
adjust_CNV(DiseaseName="BRCA",type="Normal",MethylationAnalysis="Promoter")
#adjust_CNV(DiseaseName="BRCA",type="Normal",MethylationAnalysis="AllCGIs")

## No Info for LUAD
adjust_CNV(DiseaseName="LUAD",type="Cancerous",MethylationAnalysis="Promoter")
#adjust_CNV(DiseaseName="LUAD",type="Cancerous",MethylationAnalysis="AllCGIs")
adjust_CNV(DiseaseName="LUAD",type="Normal",MethylationAnalysis="Promoter")
#adjust_CNV(DiseaseName="LUAD",type="Normal",MethylationAnalysis="AllCGIs")

adjust_CNV(DiseaseName="Colon",type="Cancerous",MethylationAnalysis="Promoter")
#adjust_CNV(DiseaseName="Colon",type="Cancerous",MethylationAnalysis="AllCGIs")

