setwd('~/Desktop/CpG/src/R')

load('../../data/processed/fData/CpGIslands_probe_size.RData')
list_big_island <- which(CpGIslands.probesize >=20)

# required packages
require('ggplot2')
require('reshape2') #for Melt for data.frame
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('ggbio')

source('fun/plot_linear_regression.R')

###################################################################
###### BRCA
DiseaseName <- "BRCA"
type <- "Cancerous"
preprocessing <- "CGIs"

out <- plot_linear_regression(DiseaseName,type,preprocessing)


###################################################################
###### Colon
DiseaseName <- "Colon"
type <- "Cancerous"
preprocessing <- "CGIs"

out <- plot_linear_regression(DiseaseName,type,preprocessing)
