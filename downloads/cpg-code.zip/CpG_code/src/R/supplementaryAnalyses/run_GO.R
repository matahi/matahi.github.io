######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)


DiseaseList <- c('BRCA','LUAD','Colon')

Clusters <- c('1','2','3down','3up')

GO_term_num <- 10
Order_by <- "Count" 

GO <- lapply(1:length(DiseaseList), function(n)
             {
                     tmp <- read.csv(paste0('../../results/clustering/',DiseaseList[n],'/Cancerous_GO_Clusters.txt'),sep="\t",header=T)

                     Infos <- c('Cluster','Description','GeneRatio','BgRatio','pvalue','p.adjust','qvalue','Count')

                     GO.info <- lapply(1:length(Clusters), function(k)
                                       {
                                               tmp.clust <- tmp[tmp$Cluster==Clusters[k], Infos,drop=F]

                                               if (nrow(tmp.clust) > GO_term_num)
                                               {
                                                       tmp.clust <- tmp.clust[ order(tmp.clust[,Order_by],decreasing=T)[1:GO_term_num], , drop=F]
                                               }

                                               return(tmp.clust)
                                       })
                     names(GO.info) <- Clusters

                     return(GO.info)
             })
names(GO) <- DiseaseList

save(GO,file="~/Desktop/GO.RData")



