# Set Path
setwd("~/Desktop/CpG/src/R") # for Curie Machines

# load featureData
###   load("../../data/processed/fData/fData450K_Gene.RData") 
###   load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
load("../../data/processed/fData/GeneList.RData")
#load("../../data/processed/fData/GeneProbesList.RData")


# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

list_big_island <-which(CpGIslands.probesize>=20)

### Toolbox 
## load the used packages 
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos
source("fun/predict_GE.R")
source("fun/linear_model.R")

source('fun/reduce_tools.R')
source("fun/plot_tools.R")

#### List of ERG in Loss et al.
# Loss.list <- c('COL1A2','S100A2','TFF1','INHBA', 'WNT5A', 'GJA1', 'GNG11', 'GSTM3', 'IGFBP5', 'IFI16', 
#                'FDXR', 'CTGF', 'NUPR1','GSTP1', 'CYP1B1', 'TOP2A', 'ESR1', 'IFITM3', 'MX1', 'CDKN2A', 
#                'CD44', 'MTHFD1', 'VAV3', 'TFAP2A', 'HOXA9','DHRS2', 'CBFA2T3', 'ZIC1', 'LITAF', 'ADAM12',
#                'IFITM2', 'EFS', 'TACSTD2', 'GSTO1', 'CGREF1', 'MAFB', 'CAMK2N1', 'SEMA3F', 'RAB25', 'ANXA13',
#                'ALCAM', 'EIF4B', 'GATA3', 'RAB21', 'PTN', 'PYCARD', 'MAPK13', 'IGFBP2', 'S100A6', 'C12orf24',
#                'IGFBP7','ALDH4A1','APITD1','CRABP2','ITGB4', 'BMP1','UNG', 'FAM134A')
# 
# Loss.Score <-  c(0.888, 0.770, 0.764, 0.761, 0.731, 0.722, 0.722, 0.693, 0.685, 0.615, 0.611, 0.594, 0.586, 0.560, 0.550, 0.522,
#                   0.518, 0.514, 0.503, 0.500, 0.496, 0.494, 0.481, 0.474, 0.473, 0.454, 0.443, 0.435, 0.435, 0.428, 0.421, 0.412,
#                   0.408, 0.390, 0.372, 0.366, 0.353, 0.349, 0.347, 0.341, 0.335, 0.328, 0.328, 0.321, 0.320, 0.319, 0.316, 0.315, 
#                   0.311, 0.310, 0.309, 0.303, 0.296, 0.285, 0.281, 0.280, 0.275, 0.268)
# 
# Loss.df <- data.frame(Gene=Loss.list, Score= Loss.Score)
# 
# save(Loss.df, file="../../big_data/Loss.RData")
# Study <- intersect(Loss.list, CommonGenes)
# 
# qplot(Gene.score.intercancer.df[Study,"BRCA"], Loss.Score[Study]) + xlim(0,1) + ylim(0,1) + geom_abline(a=0,b=1,col="red",linetype="longdash") + xlab("R2 predict") + ylab('Loss Score')

Loss.df <- get(load('../../big_data/Loss.RData'))

#### Known genes in litterature
Caren.List <- c('KRT19','PRKCDBP','SCNN1A','POU2F2','TGFBI','COL1A2','DHRS3')
Caren.df <- data.frame(Gene=Caren.List)




###
Meth.dat <- get(load(paste0('../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs_processed.RData')))
GE.dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/BRCA/CancerousLevel3GE_processed.RData')))

load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")
list_big_island <- which(CpGIslands.probesize >=20)

Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
CGI.Genes <- get(load('../../big_data/GE_prediction/Tools/CGI_Genes.RData'))

Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/FullPromoterAssoc.RData'))
Full.CommonGenes <- intersect(Genes.GE, CGI.Genes)

Meth.df <- lapply(1:length(Promoter.Assoc),function(n){ Meth.dat[[Promoter.Assoc[n]]]})
GE.df <- GE.dat[match(Full.CommonGenes,Genes.GE),]

#### 
Article <- "Caren"
GeneList <- Caren.df$Gene

GE.df <- GE.df[match(GeneList,Full.CommonGenes),]
Meth.df <- Meth.df[match(GeneList,Full.CommonGenes)]

n.repeats <- 100
n.folds <- 3
set.seed(1234)
folds <- lapply(seq(n.repeats), function(n){split( sample( seq(ncol(GE.df)) ), seq(n.folds) )})

library(glmnet)
Regression.List <- lapply(seq(n.repeats), function(n.rep)
                          {
                                  print(n.rep)
                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                       {
                                                               # progress <- n*100/nrow(GE.df)
                                                               # if (progress %/% GE.df==0)

                                                               ###
                                                               Y <- t(GE.df[n,,drop=F])
                                                               X <- Meth.df[[n]]
                                                               if (is.null(X))
                                                               {
                                                                       return(c('lasso'=NA,'ridge'=NA))
                                                               } else {
                                                                       X <- t(Meth.df[[n]])

                                                                       ###
                                                                       pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                              {
                                                                                                      Y_train <- Y[-folds[[n.rep]][[n_fold]],,drop=F ]
                                                                                                      X_train <- X[-folds[[n.rep]][[n_fold]],]

                                                                                                      Y_test <- Y[folds[[n.rep]][[n_fold]],,drop=F ]
                                                                                                      X_test <- X[folds[[n.rep]][[n_fold]],]

                                                                                                      if (any(Y_train != Y_train[1]))
                                                                                                      {
                                                                                                              ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                                              lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min
                                                                                                              lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0,nfolds=3)$lambda.min

                                                                                                              ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                              predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)
                                                                                                              predictor.ridge <- glmnet(X_train,Y_train,alpha=0,lambda=lambda.ridge)

                                                                                                              Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)
                                                                                                              Y_predict.ridge <- predict(predictor.ridge,newx=X_test, s= lambda.ridge)

                                                                                                              r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                                                              r2.pearson.ridge <- cor(Y_test,Y_predict.ridge)^2
                                                                                                      } else {
                                                                                                              r2.pearson.lasso <- NA
                                                                                                              r2.pearson.ridge <- NA
                                                                                                      }

                                                                                                      return(c('lasso'=r2.pearson.lasso,'ridge'=r2.pearson.ridge))
                                                                                                      # return(c('lasso'=r2.pearson.lasso))
                                                                                              })

                                                                       pearson.df <- data.frame(t(pearson.fold))

                                                                       return(c('lasso'=mean(na.omit(pearson.df$lasso)),'ridge'=mean(na.omit(pearson.df$ridge) )))
                                                               }
                                                       })

                                  Regression.df <- data.frame(t(Regression))

                                  return(Regression.df)
                          })

Regression.table <- NULL
Regression.table$lasso <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$lasso}) )
Regression.table$ridge <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$lasso}) )
save(Regression.table,file=paste0("../../big_data/GE_prediction/",Article,"_table.RData"))

Regression.Final <- Reduce('+',Regression.List)/n.repeats
save(Regression.Final,file=paste0("../../big_data/GE_prediction/",Article,"_",n.repeats,".RData"))

## ## Compare Loss and our Method
## ##############################
## Article <- "Loss"
## 
## Article.df <- get(load(paste0('../../big_data/',Article,'.Rdata')))
## 
## Article.100 <- get(load(paste0('../../big_data/GE_prediction/',Article,'_100.RData')))
## Article.10 <- get(load(paste0('../../big_data/GE_prediction/',Article,'_10.RData')))
## 
## qplot(Article.100$lasso, Article.df$Score) + geom_abline(a=0,b=1,col="red", linetype="longdash") + xlim(0,1) + ylim(0,1)
## Comparison.df <- data.frame(Article=Article.df$Score, Us=Article.100$lasso)
## summary(lm(Article~Us, Comparison.df))$r.squared
## 
## qplot(Article.100$lasso, Article.10$lasso) + geom_abline(a=0,b=1,col="red", linetype="longdash") + xlim(0,1) + ylim(0,1)
## 
## qplot(Article.100$lasso, Article.100$ridge) + geom_abline(a=0,b=1,col="red", linetype="longdash") + xlim(0,1) + ylim(0,1)
## 
## test.df <- data.frame(lasso= Article.100$lasso, ridge=Article.100$ridge)
## summary(lm(lasso~ridge,test.df))$r.squared


