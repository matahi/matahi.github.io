######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
#args <- commandArgs(TRUE); PATH = args[1]
#setwd(PATH)

# Gene processed
load("../../data/processed/Methylation/TCGA/BRCA/CancerousGenes_processed.RData")
load("../../data/processed/Methylation/TCGA/BRCA/NormalGenes_processed.RData")

# load clinicalinfo
load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
load("../../data/processed/fData/fData450K_Gene.RData") 
load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
load("../../data/processed/fData/GeneList.RData")
load("../../data/processed/fData/GeneProbesList.RData")

# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox {{{1
## load the used packages {{{2
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions{{{2
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source('lib/toolkit/adaptiveStats.R') # standard functions (mean, PC,Score)
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos

## Analysis {{{1
# plot {{{2
# Remark: There is a gene named "T" (to verify) so probes attached to it include all gene which name includes a T.
Genes.Length <- sapply(GeneProbesList,length)

BigGenes <- which(Genes.Length >= 20)

BRCA.CancerousGenes.Mean <- lapply(BRCA.CancerousGenes, adaptativeMean )
BRCA.CancerousGenes.PC <- lapply(BRCA.CancerousGenes, function(x){calculatePC(x,1:2,"normal")} )
BRCA.CancerousGenes.RobustPC <- lapply(BRCA.CancerousGenes, function(x){calculatePC(x,1:2,"robust")} )

### Apply dtw
Loc <- lapply(1:length(list_big_genes), function(x){fData450K[rownames(BRCA.CancerousCGIs.Mean[list_big_genes[x]]), "MAPINFO" ]})
distanceMat <- matrix(0,nrow=length(list_big_genes),ncol=length(list_big_genes))
distanceMat.Normalized <- matrix(0,nrow=length(list_big_genes),ncol=length(list_big_genes))

distancePCMat <- matrix(0,nrow=length(list_big_genes),ncol=length(list_big_genes))
distancePCMat.Normalized <- matrix(0,nrow=length(list_big_genes),ncol=length(list_big_genes))

library(dtw)
for (k in 1:length(list_big_genes))
{
        for (l in k:length(list_big_genes))
        {
                tmp1 <- dtw(BRCA.CancerousCGIs.Mean[[list_big_genes[k]]],BRCA.CancerousCGIs.Mean[[list_big_genes[l]]], open.end=T , open.begin=T, step=asymmetric, distance.only=T)
                distanceMat[k,l] <- tmp1$distance
                distanceMat[l,k] <- tmp1$distance
                distanceMat.Normalized[l,k] <- tmp1$normalizedDistance 
                distanceMat.Normalized[k,l] <- tmp2$normalizedDistance

                tmp2 <- dtw(BRCA.CancerousCGIs.PC[[list_big_genes[k]]]$Score[,1],BRCA.CancerousCGIs.PC[[list_big_genes[l]]]$Score[,1], open.end=T , open.begin=T, step=asymmetric, distance.only=T)
                distancePCMat[k,l] <- tmp2$distance
                distancePCMat[l,k] <- tmp2$distance
                distancePCMat.Normalized[l,k] <- tmp2$normalizedDistance 
                distancePCMat.Normalized[k,l] <- tmp2$normalizedDistance

        }
}

## Save distance Matrix
save(distanceMat, file="~/Desktop/DistanceMatOpenEnd.RData")
save(distanceMat.Normalized, file="~/Desktop/DistanceMatNormOpenEnd.RData")

save(distancePCMat, file="~/Desktop/DistancePCMatOpenEnd.RData")
save(distancePCMat.Normalized, file="~/Desktop/DistanceMatPCNormOpenEnd.RData")

dist.Mat <- dist(distanceMat)
clust.res <- hclust(dist.Mat, method="ward")
pdf('~/Desktop/ClustOpenEnd.pdf')
plot(clust.res)
dev.off()

distNorm.Mat <- dist(distanceMat.Normalized)
clustNorm.res <- hclust(distNorm.Mat, method="ward")
pdf('~/Desktop/ClustNormOpenEnd.pdf')
plot(clustNorm.res)
dev.off()

dist.PCMat <- dist(distancePCMat)
clust.res <- hclust(dist.PCMat, method="ward")
pdf('~/Desktop/ClustPCOpenEnd.pdf')
plot(clust.res)
dev.off()

distNorm.PCMat <- dist(distancePCMat.Normalized)
clustNorm.res <- hclust(distNorm.PCMat, method="ward")
pdf('~/Desktop/ClustPCNormOpenEnd.pdf')
plot(clustNorm.res)
dev.off()

A <- cutree(clustNorm.res,k=3)
write.table(which(A==1),file="~/Desktop/class1_ClustOpenEnd.txt")
write.table(which(A==2),file="~/Desktop/class2_ClustOpenEnd.txt")
write.table(which(A==3),file="~/Desktop/class3_ClustOpenEnd.txt")

