#####################################
#### Plotting the results
#####################################
###  1) LEAST SQUARES RESULTS
# A) Mean CGI1
BRCA.Cancerous.Mean.LS <- get(load('../../big_data/GE_prediction/BRCA_Cancerous_least_squares_mean.RData'))
BRCA.Normal.Mean.LS <- get(load('../../big_data/GE_prediction/BRCA_Normal_least_squares_mean.RData'))

BRCA.Cancerous.Mean.LS.reduced <- reduce_LS(BRCA.Cancerous.Mean.LS)
BRCA.Normal.Mean.LS.reduced <- reduce_LS(BRCA.Normal.Mean.LS)

# sum(BRCA.Cancerous.Mean.LS.reduced$adj.p.value < 0.05) = 1474
# sum(BRCA.Normal.Mean.LS.reduced$adj.p.value < 0.05) = 660

summary(BRCA.Cancerous.Mean.LS.reduced$r.squared)
#     Min.  1st Qu.   Median     Mean  3rd Qu.     Max. 
# 0.000000 0.004152 0.017850 0.044320 0.054590 0.523600

summary(BRCA.Normal.Mean.LS.reduced$r.squared)
#     Min.  1st Qu.   Median     Mean  3rd Qu.     Max.     NA's 
# 0.000000 0.007363 0.032530 0.072330 0.092450 0.656500        1 


# B) Whole CGI1
BRCA.Cancerous.Pattern.LS <- get(load('../../big_data/GE_prediction/BRCA_Cancerous_least_squares_pattern.RData'))
BRCA.Normal.Pattern.LS <- get(load('../../big_data/GE_prediction/BRCA_Normal_least_squares_pattern.RData'))

BRCA.Cancerous.Pattern.LS.reduced <- reduce_LS(BRCA.Cancerous.Pattern.LS)
BRCA.Normal.Pattern.LS.reduced <- reduce_LS(BRCA.Normal.Pattern.LS)

# sum(BRCA.Cancerous.Pattern.LS.reduced$adj.p.value < 0.05) = 2181
# sum(na.omit(BRCA.Normal.Pattern.LS.reduced$adj.p.value) < 0.05) = 1068

summary(BRCA.Cancerous.Pattern.LS.reduced$r.squared)
#     Min.  1st Qu.   Median     Pattern  3rd Qu.     Max. 
#    0.009113 0.136000 0.205100 0.228700 0.298500 0.944500 
# 0.009113 0.138100 0.211100 0.239000 0.311500 0.944500 

summary(BRCA.Normal.Pattern.LS.reduced$r.squared)
#     Min.  1st Qu.   Median     Pattern  3rd Qu.     Max.     NA's 
#    0.1414  0.3881  0.5087  0.5307  0.6496  1.0000       1

# C) All CGIs
BRCA.Cancerous.AllCGIs.LS <- get(load('../../big_data/GE_prediction/BRCA_Cancerous_least_squares_All_CGIs.RData'))
BRCA.Normal.AllCGIs.LS <- get(load('../../big_data/GE_prediction/BRCA_Normal_least_squares_All_CGIs.RData'))

BRCA.Cancerous.AllCGIs.LS.reduced <- reduce_LS(BRCA.Cancerous.AllCGIs.LS)
BRCA.Normal.AllCGIs.LS.reduced <- reduce_LS(BRCA.Normal.AllCGIs.LS)

# sum(BRCA.Cancerous.AllCGIs.LS.reduced$adj.p.value < 0.05) 
# = 2189
# sum(na.omit(BRCA.Normal.AllCGIs.LS.reduced$adj.p.value) < 0.05) 
# = 1031

summary(BRCA.Cancerous.AllCGIs.LS.reduced$r.squared)
#     Min.  1st Qu.   Median     AllCGIs  3rd Qu.     Max. 
#    0.009113 0.136000 0.205100 0.228700 0.298500 0.944500 

summary(BRCA.Normal.AllCGIs.LS.reduced$r.squared)
#     Min.  1st Qu.   Median     AllCGIs  3rd Qu.     Max.     NA's 
#    0.1414  0.3881  0.5087  0.5307  0.6496  1.0000       1

############################
########### R^2 comparison
############################
# Least Squares Only
#######################
R2.LS.Mean <- data.frame(r.squared=c(BRCA.Cancerous.Mean.LS.reduced$r.squared, BRCA.Normal.Mean.LS.reduced$r.squared),adj.r.squared= c(BRCA.Cancerous.Mean.LS.reduced$adj.r.squared, BRCA.Normal.Mean.LS.reduced$adj.r.squared), type=c(rep("Cancerous",nrow(BRCA.Cancerous.Mean.LS.reduced)),rep('Normal',nrow(BRCA.Normal.Mean.LS.reduced))),method="Mean CGI", regression="LS")

R2.LS.Pattern <- data.frame(r.squared=c(BRCA.Cancerous.Pattern.LS.reduced$r.squared, BRCA.Normal.Pattern.LS.reduced$r.squared),adj.r.squared= c(BRCA.Cancerous.Pattern.LS.reduced$adj.r.squared, BRCA.Normal.Pattern.LS.reduced$adj.r.squared), type=c(rep("Cancerous",nrow(BRCA.Cancerous.Pattern.LS.reduced)),rep('Normal',nrow(BRCA.Normal.Pattern.LS.reduced))),method="Whole CGI", regression="LS")

R2.LS.AllCGIs <- data.frame(r.squared=c(BRCA.Cancerous.AllCGIs.LS.reduced$r.squared, BRCA.Normal.AllCGIs.LS.reduced$r.squared),adj.r.squared= c(BRCA.Cancerous.AllCGIs.LS.reduced$adj.r.squared, BRCA.Normal.AllCGIs.LS.reduced$adj.r.squared), type=c(rep("Cancerous",nrow(BRCA.Cancerous.AllCGIs.LS.reduced)),rep('Normal',nrow(BRCA.Normal.AllCGIs.LS.reduced))),method="All CGIs", regression="LS")

### Total
R2.LS <- rbind(R2.LS.Mean, R2.LS.Pattern, R2.LS.AllCGIs)

### Using
pdf('../../results/GE_prediction/BRCA/Comparison/adj_R2_LS.pdf')
ggplot(R2.LS) + geom_boxplot(aes(x=method,y=adj.r.squared, fill=regression)) + facet_grid(.~type) 
dev.off()


