plot_loess_spline <- function(CGI)
{
        source("lib/toolkit/multiplot.R")
        p <- ggplot(CGI,aes(x=location,y=betas)) + geom_point(aes(colour=patient)) + geom_line(aes(colour=patient)) + geom_vline(xintercept=unique(na.omit(CGI$IslandBegin))) + geom_vline(xintercept=unique(na.omit(CGI$IslandEnd))) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank())

        # loess
        p_loess <- ggplot(CGI,aes(x=location,y=betas)) + stat_smooth() + geom_vline(xintercept=unique(na.omit(CGI$IslandBegin))) + geom_vline(xintercept=unique(na.omit(CGI$IslandEnd))) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()) + ggtitle("LOESS")

        # spline regression
        require(splines)
        require(MASS)
        knots.pos <- unique(CGI$location)
        p_spline_stat_smooth <- ggplot(CGI,aes(x=location,y=betas)) + stat_smooth(method = "lm", formula = y ~ ns(x,3)) + geom_vline(xintercept=unique(na.omit(CGI$IslandBegin))) + geom_vline(xintercept=unique(na.omit(CGI$IslandEnd))) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1) + ggtitle("SPLINE STAT SMOOTH")

        # second spline method
        p_spline_bis <- ggplot(CGI,aes(x=location,y=betas)) +geom_point(aes(colour=patient)) + geom_point(data=data.frame(spline(CGI$location,CGI$betas,n=10*length(CGI$location))),aes(x=x,y=y))+geom_line(data=data.frame(spline(CGI$location,CGI$betas,n=10*length(CGI$location))),aes(x=x,y=y)) + geom_vline(xintercept=unique(na.omit(CGI$IslandBegin))) + geom_vline(xintercept=unique(na.omit(CGI$IslandEnd))) + theme(legend.position="none", axis.text.x=element_blank()) + ggtitle("SPLINE BIS")

        multiplot(p,p_loess,p_spline_stat_smooth,p_spline_bis,ncol=1)
        #

}
