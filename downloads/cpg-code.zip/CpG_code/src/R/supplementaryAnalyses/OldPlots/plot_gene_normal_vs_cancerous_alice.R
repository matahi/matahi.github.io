plot_gene_normal_vs_cancerous_alice <- function(Gene,Disease,type,ClinicalInfo=NULL, features=NULL,fData=fData450K)
{
        ## Library Loading 
        require(ggbio)
        require(GenomicRanges)
        source("fun/zoom_region.R")

        ### Processing 
        require(TxDb.Hsapiens.UCSC.hg19.knownGene)
        txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene

        data(genesymbol, package="biovizBase")
        gene.gr <- genesymbol[Gene]

        ## Find Gene probes -> Is there a faster way????
        Id <- gregexpr(Gene,fData[,"UCSC_RefGene_Name"])
        Pos <- c()
        for (k in 1:length(Id))
        {
                print(k)
                if (Id[[k]][1]>0)
                {
                        Pos <- c(Pos,k)
                }
        }

        if (is.null(Pos)){
                return(NULL)
        } else {

                ## Data Processing 
                Dat <- cbind(eval(parse(text=paste0(Disease,'.Cancerous'))), eval(parse(text=paste0(Disease,'.Normal'))))

                fData.Gene <- fData[Pos,]
                Probes <- fData[Pos,"Name"]
                Betas <- Dat[Probes,]
                missingSample <- which(is.na(Betas),arr.ind=TRUE)
                if (nrow(missingSample)!=0){
                        Betas <- Betas[,-unique(missingSample[,2])]
                }
                Betas.df <- melt(Betas)

                if (is.null(ClinicalInfo)){
                        df <- data.frame(x = fData[Pos,"MAPINFO"],Probe = fData[Pos,"MAPINFO"], betas = Betas.df$value, sample = Betas.df$Var2, type=rep(type,each=length(Pos)))
                        df <- df[df$type!="NA",]
                        for (k in 1:length(unique(df$Probe)))
                        {
                                df$Probe[df$Probe==unique(df$Probe)[k]] <- k
                        }

                        p2 <- ggplot(df,aes(x=x,y=betas)) + geom_line(aes(group=sample,colour=factor(type))) + geom_point(aes(colour=factor(type)))  
                        #                         p2_boxplot <- ggplot() + geom_boxplot(data=df,aes(x=x,y=betas,fill=factor(type),group=paste(x,type))) 
                        p2_boxplot <- ggplot() + geom_boxplot(data=df,aes(x=factor(x),y=betas,fill=factor(type))) 


                        if (length(unique(na.omit(fData.Gene[,"IslandBegin"])))!=0){
                        p2 <- p2 + geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + 
                                   geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"])))   
                        #                         p2_boxplot <- p2_boxplot + geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"])))  

                        p2_boxplot_bis <- vector("list",length(unique(na.omit(fData.Gene[,"IslandBegin"]))))
                        for (k in 1:length(unique(na.omit(fData.Gene[,"IslandBegin"]))))
                        {
                                     good_x <- fData.Gene[fData.Gene$IslandBegin==unique(na.omit(fData.Gene[,"IslandBegin"]))[k],"MAPINFO"]
                                     p2_boxplot_bis[[k]] <- ggplot() + geom_boxplot(data=df[df$x %in% good_x,],aes(x=factor(Probe),y=betas,fill=factor(type)))
                        }
                        
                        }

                        p1 <- autoplot(txdb, which=gene.gr)

                        pdf(paste0('../../results/Alice/',Gene,'_Normal_vs_Cancerous.pdf'), width=10, height=10, pointsize=1)
                        print(tracks(p1, p2))
                        dev.off()
                        pdf(paste0('../../results/Alice/',Gene,'_Normal_vs_Cancerous_boxplot.pdf'), width=10, height=10, pointsize=1)
                        #                         print(tracks(p1,p2_boxplot))
                        print(p2_boxplot)
                        dev.off()

                        for (k in 1:length(unique(na.omit(fData.Gene[,"IslandBegin"]))))
                        {
                                pdf(paste0('../../results/Alice/',Gene,'_Normal_vs_Cancerous_boxplot',k,'.pdf'), width=10, height=10, pointsize=1)
                        #                         print(tracks(p1,p2_boxplot))
                                print(p2_boxplot_bis[[k]])
                                dev.off()
                        }


                        if (length(unique(na.omit(fData.Gene[,"IslandBegin"])))!=0){
                                promoterRegion <- zoom_region(fData.Gene) # Find a way to automatize the zoom on the promoter regions

                                pdf(paste0('../../results/Alice/',Gene,'_Normal_vs_Cancerous_promoter.pdf'), width=10, height=10, pointsize=1)
                                print(tracks(p1, p2) + xlim(promoterRegion))
                                dev.off()
                                #                                 pdf(paste0('../../results/Genes/',Disease,"/",Gene,'_Normal_vs_Cancerous_boxplot_promoter.pdf'), width=10, height=10, pointsize=1)
                                #                                 print(tracks(p1, p2_boxplot) + xlim(promoterRegion))
                                #                                 dev.off()
                        }

                } else {
                        df <- data.frame(x = fData[Pos,"MAPINFO"], betas = Betas.df$value, sample = Betas.df$X2 )
                        NewInfo <- ClinicalInfo[as.character(df$sample),features] 
                        df <- cbind(df,NewInfo)

                        for (feature in features){
                                if (length(unique(na.omit(fData.Gene[,"IslandBegin"])))!=0){
                                        p2 <- ggplot(df, aes_string(x="x",y="betas",colour=paste0("as.factor(",feature,")"))) + geom_line(aes(group=sample)) + geom_point(aes(group=sample)) +
                                        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + 
                                        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"])))# +
                                        #                         theme(legend.position="none")  

                                        p1 <- autoplot(txdb, which=gene.gr)

                                        pdf(paste0('../../results/Alice/',Gene,"_",type,"_",feature,'.pdf'), width=10, height=10, pointsize=1)
                                        print(tracks(p1, p2))
                                        dev.off()


                                        promoterRegion <- zoom_region(fData.Gene) # Find a way to automatize the zoom on the promoter regions

                                        pdf(paste0('../../results/Alice/',Gene,"_",type,"_",feature,'promoter.pdf'), width=10, height=10, pointsize=1)
                                        print(tracks(p1, p2) + xlim(promoterRegion))
                                        dev.off()
                                }else{
                                        p2 <- ggplot(df, aes_string(x="x",y="betas",colour=paste0("as.factor(",feature,")"))) + geom_line(aes(group=sample)) + geom_point(aes(group=sample)) 

                                        p1 <- autoplot(txdb, which=gene.gr)

                                        pdf(paste0('../../results/Alice/',Gene,"_",type,"_",feature,'.pdf'), width=10, height=10, pointsize=1)
                                        print(tracks(p1, p2))
                                        dev.off()
                                }
                        }
                }

                # multiplot(p1,p2, cols=1)
                # grid.arrange(p1,p2,ncol=1)

                return(Betas)
        }
}
