load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean_updown.RData')
clusters <- BRCA.Cancerous.clustersMean

distMat.Normalized <- load(paste0('../../big_data/CGIs/',Disease,'_',type,'_DistanceMat',method,'Norm.RData')) 
distanceMat.Normalized <- get(distMat.Normalized)

list_big_island <- which(CpGIslands.probesize >=20)
##
load('../../data/processed/fData/fData_CGI_big_island.RData')

num_char <- 12
#### Plot Characteristic profiles
index_characteristics <- lapply(1:length(unique(clusters)), function(n){
                                tmp.dist <- distanceMat.Normalized[clusters==unique(clusters)[n],clusters==unique(clusters)[n]]
                                dist.cluster <- sapply(1:nrow(tmp.dist),function(k){sum(tmp.dist[k,-k]^2)})
                                #dist.cluster <- sapply(1:nrow(tmp.dist),function(k){sum(tmp.dist[k,-k])}) ## sum of dist or square dist?
                                return(which(clusters==unique(clusters)[n])[order(dist.cluster)[1:num_char]])
})
names(index_characteristics) <- unique(clusters)

load('../../data/processed/Methylation/TCGA/BRCA/CancerousCGIs_processed.RData')
CGI.dat_big_island <- BRCA.CancerousCGIs[list_big_island]

load('../../data/processed/fData/fData_CGI_big_island.RData')

Dat.char <- vector('list')

library(reshape2)
for (k in 1:length(unique(clusters)))
{
        Dat.full<- Reduce('rbind', CGI.dat_big_island[ index_characteristics[[k]]])
        Dat.m <- melt(Dat.full)
        Dat.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"MAPINFO"    ]  })),ncol(CGI.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(CGI.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandBegin"]})),ncol(CGI.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandEnd"]})),ncol(CGI.dat_big_island[[1]]) ))
                                    ## position = Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"MAPINFO"    ],ncol(CGI.dat_big_island[[1]])  )  })) , 
                                    ## CGI =  Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"UCSC_CpG_Islands_Name"],ncol(CGI.dat_big_island[[1]]))})), 
                                    ## IslandBegin= Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandBegin"],ncol(CGI.dat_big_island[[1]]))})), 
                                    ## IslandEnd=Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandEnd"],ncol(CGI.dat_big_island[[1]]))})))


        pdf(paste0("../../results/clustering/",Disease,"/",method,"/full_cluster_",unique(clusters)[k],"_updown.pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(Dat.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()

}



### Look at the same CGI in normal
load('../../data/processed/Methylation/TCGA/BRCA/NormalCGIs_processed.RData')
CGI.dat_big_island <- BRCA.NormalCGIs[list_big_island]

load('../../data/processed/fData/fData_CGI_big_island.RData')

Dat.char <- vector('list')

###### Put all patients !!!
library(reshape2)
for (k in 1:length(unique(clusters)))
{
        Dat.full<- Reduce('rbind', CGI.dat_big_island[ index_characteristics[[k]]])
        Dat.m <- melt(Dat.full)
        Dat.char[[k]] <- data.frame(methylation=Dat.m$value , 
                                    patient =Dat.m$Var2,
                                    position = rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"MAPINFO"    ]  })),ncol(CGI.dat_big_island[[1]])) , 
                                    CGI =  rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"UCSC_CpG_Islands_Name"]})), ncol(CGI.dat_big_island[[1]])), 
                                    IslandBegin= rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandBegin"]})),ncol(CGI.dat_big_island[[1]])), 
                                    IslandEnd=rep(Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandEnd"]})),ncol(CGI.dat_big_island[[1]]) ))
                                    ## position = Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"MAPINFO"    ],ncol(CGI.dat_big_island[[1]])  )  })) , 
                                    ## CGI =  Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"UCSC_CpG_Islands_Name"],ncol(CGI.dat_big_island[[1]]))})), 
                                    ## IslandBegin= Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandBegin"],ncol(CGI.dat_big_island[[1]]))})), 
                                    ## IslandEnd=Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){rep(fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandEnd"],ncol(CGI.dat_big_island[[1]]))})))


        pdf(paste0("../../results/clustering/",Disease,"/",method,"/full_Normal_cluster_",unique(clusters)[k],"_updown.pdf"), width=10, height=10, pointsize=10)
        #pdf(paste0("~/Desktop/test_",unique(clusters)[k],".pdf"))
        print(ggplot(Dat.char[[k]],aes(x=position,y=methylation))+ geom_point(aes(colour=patient)) + geom_line(aes(colour=patient,group=patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
        dev.off()

}



