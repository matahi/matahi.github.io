######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
# setwd(PATH)

## Data Loading {{{2
load("../../data/processed/Methylation/TCGA/BRCA/CancerousLevel2.RData") # cancerous samples
load("../../data/processed/Methylation/TCGA/BRCA/NormalLevel2.RData") # Normal samples
load("../../data/processed/fData/fData450K_ordered.RData") # feature data
load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData") # clinical info
load("../../data/processed/fData/GeneList.RData") # Gene List
# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox {{{1
## load the used packages {{{2
require('ggplot2')
require('reshape2') #for Melt for data.frame
require('gridExtra') # for plotting several ggplots -> grid.arrange

## Useful functions{{{2
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene_alice.R") # plot_gene function
source("fun/plot_gene.R") # plot_gene function
source("fun/plot_gene_normal_vs_cancerous_alice.R") # plot_gene function
source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos

### Statistical Analysis {{{1
GeneList <- c("SESN3","ENDOD1","FAM76B","CEP57","MTMR2","MAML2","CCDC82","JRKL","CNTN5","ARHGAP42","TMEM133","PGR","TRPC6")
GeneList <- c("SESN3")
CancerousTypes <- find_BRCAtype(BRCA.Clinical)

# To accelerate the search we know that all these genes are on Chromosome 11
fData450K_Chr11 <- fData450K[fData450K$CHR=="11",]
for (k in 1:length(GeneList)){
        print(paste0(k,'/',length(GeneList))) 
        gene.df <- plot_gene_alice(Gene=GeneList[k],Disease="BRCA",type="Cancerous",ClinicalInfo=BRCA.Clinical, features=c("ER","PR","HER2"), fData=fData450K_Chr11)
        gene.df <- plot_gene_normal_vs_cancerous_alice(Gene=GeneList[k],Disease="BRCA",type=c(CancerousTypes,rep("Normal",ncol(BRCA.Normal))),ClinicalInfo=NULL, features=NULL, fData=fData450K_Chr11)
}

# Gene INSL4
GeneList <- c("INSL4")
for (k in 1:length(GeneList)){
        print(paste0(k,'/',length(GeneList))) 
        gene.df <- plot_gene_alice(Gene=GeneList[k],Disease="BRCA",type="Cancerous",ClinicalInfo=BRCA.Clinical, features=c("ER","PR","HER2") )
        gene.df <- plot_gene_normal_vs_cancerous_alice(Gene=GeneList[k],Disease="BRCA",type=c(CancerousTypes,rep("Normal",ncol(BRCA.Normal))),ClinicalInfo=NULL, features=NULL)
}


# Gene "EZH2" Région Michel
        gene.df <- plot_gene(Gene="EZH2",Disease="BRCA",type="Cancerous",ClinicalInfo=NULL, features=NULL)
        gene.df <- plot_gene_normal_vs_cancerous(Gene="EZH2",Disease="BRCA",type=c(rep("Cancerous",ncol(BRCA.Cancerous)),rep("Normal",ncol(BRCA.Normal))),ClinicalInfo=NULL, features=NULL)


find_probes <- function(Gene)
{
        Id <- gregexpr(Gene,fData450K[,"UCSC_RefGene_Name"])
        Pos <- c()
        for (k in 1:length(Id))
        {
                print(k)
                if (Id[[k]][1]>0)
                {
                        Pos <- c(Pos,k)
                }
        }
        if (is.null(Pos)){
                return(NULL)
        } else {

                Infos <- fData450K[Pos,c('MAPINFO','Methyl27_Loci','Forward_Sequence')]
                return(Infos)
        }
}

Infos_Regions_Alice <- list()

for (k in (1:length(GeneList))){
        Infos_Regions_Alice[[k]]<- find_probes(GeneList[k])
}

names(Infos_Regions_Alice) <- GeneList
write.table(Infos_Regions_Alice,file="../../results/Alice/Infos_Regions.csv",sep=",",col.names=NA)
