DiseaseName <- "Colon"

######
typeList <- "Cancerous" ## We only look at Cancerous because of CNVs

# AnalysisList <- c('Mean','Promoter','AllCGIs')
AnalysisList <- c('Mean','Promoter')

# Stock the p-values of tests
out <- NULL

# GeneNames
CommonGenes <- get(load('../../big_data/CommonGenes.RData'))

# GenesBigIsland
list_big_island <- which(CpGIslands.probesize >=20)

# CGIs Info
AllCGIs.Assoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
Assoc.Length <- sapply(AllCGIs.Assoc,length)
MultipleCGIs <- (Assoc.Length != 1)

##### Create the dataframes
Gene.score <- Reduce('rbind',lapply(1:length(typeList), function(k)
                                    {
                                            NoCNV.index <- lapply(1:length(AnalysisList),function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_CNV_index.RData')))})

                                            tmp.noCNV <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_table.RData')))})
                                            tmp.CNV <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_table_CNV.RData')))})


                                            ### Process NoCNV
                                            tmp.noCNV.processed <- NULL
                                            tmp.noCNV.processed[[1]] <- as.numeric(apply(tmp.noCNV[[1]],1,function(x){mean(x,na.rm=T)}))
                                            tmp.noCNV.processed[[2]] <- data.frame(Reduce('cbind',lapply(1:length(tmp.noCNV[[2]]), function(n){apply(tmp.noCNV[[2]][[n]],1,function(s){mean(s,na.rm=T)})})))

                                            ### Process CNV
                                            tmp.CNV.processed <- NULL
                                            tmp.CNV.processed[[1]] <- data.frame(Reduce('cbind',lapply(1:length(tmp.CNV[[1]]),function(n){apply(tmp.CNV[[1]][[n]],1,function(s){mean(s,na.rm=T)})})))
                                            colnames(tmp.CNV.processed[[1]]) <- names(tmp.CNV[[1]])
                                            tmp.CNV.processed[[2]] <- data.frame(Reduce('cbind',lapply(1:length(tmp.CNV[[2]]),function(n){apply(tmp.CNV[[2]][[n]],1,function(s){mean(s,na.rm=T)})})))
                                            colnames(tmp.CNV.processed[[2]]) <- names(tmp.CNV[[2]])

                                            ###
                                            tmp.df.noCNV <- Reduce('cbind',tmp.noCNV.processed)
                                            tmp.df.CNV <- Reduce('cbind',tmp.CNV.processed)
                                            NoCNV.index.df <- Reduce('cbind',NoCNV.index)
                                            colnames(NoCNV.index.df) <- AnalysisList

                                            ######
                                            tmp.df <- cbind(tmp.df.noCNV, tmp.df.CNV)

                                            colnames(tmp.df) <- c('LS.Meth_Only','Promoter.Lasso','Promoter.Ridge','LS.Meth_CNV','LS.CNV_Only','Promoter.Lasso.CNV','Promoter.Ridge.CNV')
                                            rownames(tmp.df) <- CommonGenes
                                            tmp.df <- tmp.df[,c(2,4,5,6)]
                                            tmp.m <- melt(tmp.df)
                                            # tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Lasso','LS','Lasso'),each=2374), analysis=rep(c('Methylation','CNV','Methylation + CNV'),each=2374))
                                            tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Lasso','LS','LS','Lasso'),each=2374), analysis=rep(c('Methylation','CNV','Methylation + CNV','Methylation + CNV'),each=2374))

                                            ## Reorder the factors
                                            tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('CNV', 'Methylation', 'Methylation + CNV'))
                                            tmp.melted$method <- factor(tmp.melted$method, levels=c('LS','Lasso'))

                                            out <- NULL
                                            out$df <- tmp.df
                                            out$melted <- tmp.melted
                                            out$NoCNV.index <- NoCNV.index.df
                                            return(out)
                                    }))



# Gene.score$df$LS.CNV_Only
# Gene.score$df$Promoter.Lasso.CNV

library(ggplot2)
# qplot(Gene.score$df$LS.CNV_Only, Gene.score$df$Promoter.Lasso.CNV) + geom_abline(a=0,b=1)
# qplot(Gene.score$df$LS.CNV_Only, Gene.score$df$LS.Meth_CNV) + geom_abline(a=0,b=1)
qplot(Gene.score$df$LS.CNV_Only, Gene.score$df$LS.Meth_CNV) + geom_abline(a=0,b=1)

Gene.score$melted <- Gene.score$melted[ - ((Gene.score$melted$method=="Lasso")&(Gene.score$melted$analysis=="Methylation + CNV")),]

p.GeneScore_CNV <- ggplot(Gene.score$melted) + geom_boxplot(aes(y=r2.predict,x=analysis,fill=analysis)) + scale_fill_manual(values= colour_data) +  ylab('R2 predict') + xlab('') +
                           coord_cartesian(ylim=c(-0.05, 1)) +
                           scale_y_continuous(breaks=c(0,0.5,1), labels=c('0','0.5','1')) +
                           theme(panel.grid=element_blank(),
                                 legend.position="none",
                                 text = element_text(size=20),
                                 panel.background=element_rect(fill="white"),
                                 axis.text=element_text(colour="black",size=rel(0.8)),
                                 axis.ticks=element_line(colour="black"),
                                 panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                 axis.title.y = element_text(vjust=0.35),
                                 strip.background = element_rect(colour="black",fill="white",size=0.7),
                                 axis.line = element_line(colour = "black",size=0.3))







