calculate_regression_matrix <- function(x, method="polynomial", a=1,b=0, p ) ## calculate_regression_matrix {{{1
{
        ## PRM
        if (method=="polynomial")
        {
                require(matrixcalc)
                Ksi <- vandermonde.matrix( a*x - b , p)
                ## SRM
        } else if (method=="spline") {
                ## BSRM
        } else if (method=="Bspline") {
                ## NULL
        } else {
                print('not a valid method')
        }
        return(Ksi)
}

calculate_gamma_m_z <- function(mu, Variance, m) ## calculate_gamma {{{1
{
        if (m==0)
        {
                gamma_m_z <- rep(0,length(mu))
        } else if (m==1) {
                gamma_m_z <- rep(0,length(mu))
        } else {

                G_q <- sapply(1:floor(m/2),function(q){out <- 1;for(j in 1:q){out <- out*(2*j-1)};return(out)})
                C_m_2q <- choose(m,2*(1:floor(m/2)))
                Sigma_2q <- sapply((1:floor(m/2)),function(k){Variance^(k)}) ## Variance = Sigma^2
                mu_m_2q <- sapply(1:floor(m/2),function(k){mu^(m-2*k)})

                gamma_m_z <-sapply(1:length(mu),function(n_i){sum(G_q*C_m_2q*Sigma_2q[n_i,]*mu_m_2q[n_i,])})
        }
        return(gamma_m_z)
}

calculate_V_X_i <- function(x,W,Gamma_ab,p,i) ## calculate_V_X_i {{{1
{
        C_m_p <- lapply(0:p,function(j){choose(j,0:j)})
        minus_m <- lapply(0:p,function(j){(-1)^(0:j)})
        x_p_m <- lapply(0:p,function(j){sapply(j:0,function(k){x^k})})
        V_X_i <- matrix(0,length(x),p+1)
        for (j in 0:p)
        {
                if (j==0)
                {
                        V_X_i[,j+1] <- 0
                } else if (j==1) {
                        V_X_i[,j+1] <- 0
                } else {
                        V_X_i[,j+1] <- W* apply(minus_m[[j+1]]*Gamma_ab[[j+1]][i,]*x_p_m[[j+1]]*C_m_p[[j+1]],1,sum)
                }
        }
        return(V_X_i)
}

calculate_V_XX_i <- function(x,W,Gamma_ab,p,i) ## calculate_V_XX_i {{{1
{
        V_XX_i <- matrix(0,nrow=p+1,ncol=p+1)
        vxx <- calculate_V_X_i(x,W,Gamma_ab,2*p,i) 
        vxx <- apply(vxx,2,sum) 
        for (j in 0:(2*p))
        {
                vxx_j <- vxx[j+1]
                                        
                for (n_row in 1:min(j+1,p+1))
                {
                        #print(paste0("n_row=",n_row))
                        n_col <- j+2-n_row
                        #print(paste0("n_col=",n_col))
                        if (n_col<=(p+1))
                                V_XX_i[n_row,n_col] <- vxx_j
                }
        }

        return(V_XX_i)
}

log_posterior_y_i <- function(a,b,y_i,x_i,Beta,sigma,r,s,p) ## log_posterior {{{1
{
        Ksi <- calculate_regression_matrix(x_i, a=a,b=b,p=p+1)
        return( as.numeric(norm(y_i - Ksi*Beta,"2")/(sigma^2) + (a-1)^2/(r^2) + b^2/(s^2) ))
}

proj_PDC_gaffney <- function(V,max_counter = 5) # Transform V into PSD matrix using gaffney method {{{1
{
        tmp <- eigen(V)
        counter <- 0
        if (any(tmp$values<0)|(counter<=max_counter))
        { 
                counter <- counter + 1
                tmp <- eigen(V)
                diag(V) <- 1.25*diag(V)
        }

        output <- NULL
        if (any(tmp$values<0)) {
                output$keep <- F
        } else {
                output$keep <- T
        }
                
        output$V <- V
        return(output)
}

Initialize_EStep <- function(output,vects) ## Intial parameters {{{1
{

        # Likelihood
        output$Lhood <- -Inf

        # cluster membership
        output$W <- matrix(1/output$nclusts,nrow=output$n,ncol=output$nclusts)

        # alpha_k
        output$alpha <- rep(1/output$nclusts,output$nclusts)
        
        # Noise
        output$Sigma <- rep(0.1,output$nclusts)

        # Transformation priors
        output$r <- rep(0.5,output$nclusts)
        output$s <- rep(0.5,output$nclusts)

        ## Observed parameters
        # Time Transformation
        output$a_hat <- matrix(1,nrow=output$n,ncol=output$nclusts)
        output$b_hat <- matrix(0,nrow=output$n,ncol=output$nclusts)

        output$V_a <- matrix(1,nrow=output$n,ncol=output$nclusts)
        output$V_b <- matrix(1,nrow=output$n,ncol=output$nclusts)
        output$V_a_b <- matrix(0,nrow=output$n,ncol=output$nclusts) ## So that the matrix is positive definite

        # Calculate Likelihood for initial condition : 

        #SumLhood <- matrix(0,output$n,output$nclusts)
        #for (i in 1:output$n)
        #{
        #        for (k in 1:output$nclusts)
        #        {
        #                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(output$r[k]^2,output$s[k]^2)))
        #                Xhat <- lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=output$p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=output$regression_method)})

        #                p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)*(output$n_i[i])*det(output$Sigma[k]^2 * diag(output$n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% output$Beta[,k] )%*%solve(output$Sigma[k]^2 * diag(output$n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% output$Beta[,k]) )})


        #                p_k <- sum(p_k_sum)/MC_runs
        #                output$W[i,k] <- output$alpha[k] * p_k

        #                SumLhood[i,k] <- output$alpha[k] * p_k 
        #        }
        #}
        #NewLhood <- sum(log(apply(SumLhood,1,sum)))
        #output$Lhood <- NewLhood
        #output$W <- output$W/ apply(output$W,1,sum)
        while (1)
        {
                output$W <- matrix(runif(output$n*output$nclusts),nrow=output$n,ncol=output$nclusts)
                output$W <- output$W / apply(output$W,1,sum)
                output$Z <- apply(output$W,1,which.max)

                if (all(1:output$nclusts) %in% output$Z) ## verify that no cluster is empty
                        break
        }

        return(output)

}


CalcPik <- function(output,vects) ## CalcPik and Likelihood {{{1
{
        ### 
        SumLhood <- matrix(0,output$n,output$nclusts)
        #         min_ni <- min(output$n_i)
        #         output$n_i_bis <- output$n_i - min_ni
        for (k in 1:output$nclusts)
        {
                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(output$r[k]^2,output$s[k]^2)))

                for (i in 1:output$n)
                {
                        Xhat <- lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=output$p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=output$regression_method)})

                        #                         p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^(output$n_i_bis[i])*output$Sigma[k]^(2*output$n_i_bis[i])) * exp(-(1/(2*output$Sigma[k]^(2*output$n_i_bis[i])))* t( vects[[i]]$y - Xhat[[m]]%*% output$Beta[,k] )%*%(vects[[i]]$y - Xhat[[m]]%*% output$Beta[,k]) )})
                        p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^output$n_i[i]*det(output$Sigma[k]^2 * diag(output$n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% output$Beta[,k] )%*%solve(output$Sigma[k]^2 * diag(output$n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% output$Beta[,k]) )})


                        p_k <- sum(p_k_sum)/MC_runs
                        output$W[i,k] <- output$alpha[k] * p_k

                        SumLhood[i,k] <- output$alpha[k] * p_k 
                }
        }

        NewLhood <- sum(log(apply(SumLhood,1,sum)))
        output$Lhood <- NewLhood
        output$W <- output$W/ apply(output$W,1,sum)
        return(output)

}

EStep <- function(output,vects) ### EStep {{{1
{
        print("E-step.....")
        neg_var <- F
        for (i in 1:output$n){
                for (k in 1:output$nclusts)
                {
                        ## 1) Estimate a and b 
                        # a) mean with Nelder-Mead
                        res <- optim(c(1,0),function(a_b){ log_posterior_y_i(a_b[1],a_b[2],vects[[i]]$y,vects[[i]]$x,output$Beta[,k],output$Sigma[k],output$r[k],output$s[k],output$p)})
                        output$a_hat[i,k] <- res$par[1]
                        output$b_hat[i,k] <- res$par[2]

                        ## 2) Variance with inverse information
                        Ksi_i <- calculate_regression_matrix(vects[[i]]$x,p=output$p+1,a=output$a_hat[i,k],b=output$b_hat[i,k],method=output$regression_method)
                        Dx <- rep(1,output$n_i[i]) %*% t(0:output$p); # n_i x p+1
                        Dx[,3:(output$p+1)] <- Dx[,3:(output$p+1)] * Ksi_i[ , 2:output$p]  # n_i x p+1
                        D2x <- rep(1,output$n_i[i]) %*% t(c(0,0,2:output$p)) # n_i x p+1
                        D2x[,3:(output$p+1)] <- D2x[,3:(output$p+1)] * Dx[,2:output$p] # n_i x p+1

                        Dx_Beta <- Dx %*% output$Beta[,k]; # nix1
                        Dx_Beta_x <- Dx_Beta * vects[[i]]$x # nix1
                        D2x_Beta <- D2x %*% output$Beta[,k] # nix1
                        D2x_Beta_x <- D2x_Beta * vects[[i]]$x
                        Y_x_Beta <- vects[[i]]$y - Ksi_i %*% output$Beta[,k]

                        # a) Inverse information
                        Ia <- sum(Y_x_Beta * (D2x_Beta_x * vects[[i]]$x)) / output$Sigma[k]^2 - sum(Dx_Beta_x^2)/output$Sigma[k]^2 - 1/output$r[k]^2;
                        Ib <- sum(Y_x_Beta * D2x_Beta) /output$Sigma[k]^2 - sum( Dx_Beta^2 )/output$Sigma[k]^2 - 1/output$s[k]^2;
                        Iab <- - sum(Y_x_Beta * D2x_Beta_x)/ output$Sigma[k]^2 + sum(Dx_Beta *Dx_Beta_x)/output$Sigma[k]^2 ;

                        V <- diag(c(Ia,Ib))
                        V[1,2] <- Iab; V[2,1] <- Iab

                        V_inv <- solve(-V) #

                        output$V_a[i,k] <- V_inv[1,1];
                        output$V_b[i,k] <- V_inv[2,2];

                        ## Verify that no value is negative
                        if (output$V_a[i,k]<0)
                        {
                                #print(paste0('V_a is negative for i=',i,' and for k=',k))
                                output$V_a[i,k] <- abs(V_inv[1,1]);
                                neg_var <- T
                        }
                        if (output$V_b[i,k]<0)
                        {
                                #print(paste0('V_b is negative for i=',i,' and for k=',k))
                                output$V_b[i,k] <- abs(V_inv[2,2]);
                                neg_var <- T
                        }
                        
                        output$V_a_b[i,k] <- V_inv[1,2];

                }
        }
        if (neg_var)
                print('A negative variance was detected...')

        output <- CalcPik(output,vects)

        return(output)
}

MStep <- function(output,vects) ### EStep {{{1
{
                print("M-step.....")
                for (k in 1:output$nclusts)
                {
                        print(paste0('      k=',k))
                        ## Calculating alpha 
                        output$alpha[k] <- 1/output$n*sum(output$W[,k])

                        ## Calculating r, s
                        output$r[k] <- sqrt(sum(output$W[,k] * ((output$a_hat[,k]-1)^2 + output$V_a[,k]))/sum(output$W[,k]))
                        output$s[k] <- sqrt(sum(output$W[,k] * (output$b_hat[,k]^2 + output$V_b[,k]))/sum(output$W[,k]))

                        ## Calculate runs
                        a_runs <- matrix(0,output$n, output$MC_runs)
                        b_runs <- matrix(0,output$n, output$MC_runs)

                        ## Initialization

                        ## run a,b to calculate the moments
                        for (i in 1:output$n)
                        {
                                ## Cov Matrix
                                V <- matrix ( c( output$V_a[i,k]       , output$V_a_b[i,k]    , 
                                                 output$V_a_b[i,k]     , output$V_b[i,k]      ),
                                             nrow=2,ncol=2,byrow=T)
                                
                                # Make sure V is PD
                                out <- proj_PDC_gaffney(V) ## proj on the SDP cone
                                V_est <- out$V
                                #keep <- output$keep

                                #output$keep <- F

                                if (out$keep)
                                {
                                        matrix_runs <- mvrnorm(n = output$MC_runs, mu=c(output$a_hat[i,k],output$b_hat[i,k]) , Sigma=V_est) ##
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                } else {
                                        print('used diagonal matrix')
                                        matrix_runs <- mvrnorm(n = output$MC_runs, mu=c(output$a_hat[i,k],output$b_hat[i,k]) , Sigma=diag(diag(V_est))) 
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                }

                        }

                        ## Estimating the covariances
                        Cov_a_b <- lapply(0:(2*output$p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m),b_runs[i,]^m)})})}) # Cov_a_b[[j+1]] is the matrix of size nx(j+1) that contains all the cov(a_i^(j-r),b_i^r) for r in 0:j

                        ## Estimating the gammas with the covariances
                        gamma_m_b <- sapply(0:(2*output$p), function(j){calculate_gamma_m_z(output$b_hat[,k],output$V_b[,k],j)}) # gamma_m_b[i,j+1] is gamma_j_(b_i) 
                        gamma_m_a <- sapply(0:(2*output$p), function(j){calculate_gamma_m_z(output$a_hat[,k],output$V_a[,k],j)})
                        ## dim(Gamma_ab[[j+1]])= nx(j+1) and  contains all the Gamma_i_m_j for m in 0:j  
                        Gamma_ab <- lapply(0:(2*output$p), function(j){sapply(j:0,function(k_i){output$a_hat[,k]^k_i}) * gamma_m_b[,1:(j+1)] + sapply(0:j,function(k_i){output$b_hat[,k]^k_i}) * gamma_m_a[,(j+1):1] + gamma_m_a[,(j+1):1] * gamma_m_b[,1:(j+1)] + Cov_a_b[[j+1]]})

                        ## Estimating V_XX_i, V_X_i 
                        V_X <- lapply(1:output$n, function(i){calculate_V_X_i(x=vects[[i]]$x,W=output$W[i,k],Gamma_ab=Gamma_ab,p=output$p,i=i)})
                        V_XX <- lapply(1:output$n, function(i){calculate_V_XX_i(x=vects[[i]]$x,W=output$W[i,k],Gamma_ab=Gamma_ab,p=output$p,i=i)}) 

                        ## Ksi_mat
                        Ksi_mat <- lapply( 1:output$n, function(i){calculate_regression_matrix(vects[[i]]$x,p=output$p+1,a=output$a_hat[i,k],b=output$b_hat[i,k],method=output$regression_method)})

                        ## Calculating Beta: Beta[,k] = (sum_{i=1}^n  c_i_k^2 * W_i_k * Ksi_i' * Ksi_i + V_XX_i)^(-1) * (sum_{i=1}^n  W_i_k *c_i_k * Ksi_i' * (y_i - d_i_k) + V_X_i' * y_i - V_X_cd )
                        Beta_vec <- Reduce('+',lapply(1:output$n, function(i){output$W[i,k] *  t(Ksi_mat[[i]])%*%Ksi_mat[[i]] + V_XX[[i]]}))
                        output$Beta[,k] <- solve(Beta_vec) %*% Reduce('+',lapply(1:output$n, function(i){output$W[i,k]* t(Ksi_mat[[i]])%*%  vects[[i]]$y  + t(V_X[[i]]) %*% vects[[i]]$y } ) )


                        ## Calculating Sigma: Sigma[k] = sqrt( sum_{i=1}^n W_i_k* (||y_i - c_i_k * Ksi_i * Beta_k - d_i_k||^2 - 2* y_i' * V_X_i * Beta_k + Beta_k' * V_XX_i *Beta_k + 2* Beta_k' * V_X_cd + n_i * V_d_i_k) / sum(W[i,k]*n_i) )
                        Sigma_test <- sum(sapply(1:output$n, function(i){ output$W[i,k]* ( norm(vects[[i]]$y  * Ksi_mat[[i]] %*% output$Beta[,k],"2")^2 - as.numeric(2* t(vects[[i]]$y) %*% V_X[[i]] %*% output$Beta[,k]) + as.numeric(t(output$Beta[,k]) %*% V_XX[[i]] %*% output$Beta[,k]) )})) / sum(output$W[,k]*output$n_i)
                        if (Sigma_test<=0)
                        {
                                print("Sigma was negative, replaced with opposite value?")
                                print(paste0('Sigma =',Sigma_test))
                                output$Sigma[k] <- abs(Sigma_test)
                        } else {
                                output$Sigma[k] <- sqrt(Sigma_test) 
                        }

                }
                return(output)
}

Initialize_MStep <- function(output,vects) ## Initial parameters {{{1
{
        output$Beta <- matrix(0,nrow=p+1,ncol=output$nclusts)
        output <- MStep(output,vects)

        ## Initialize Beta
        # Beta : Careful when initializing Beta if its too far the Lhood
        # Let's initialize Beta with the solution of the regression problems for i=1,11,21 (corresponding to the 3 modes)
        for (k in 1:output$nclusts)
        {
                Ksi_i <-  calculate_regression_matrix(vects[[(k-1)*output$n/output$nclusts+1]]$x,p=output$p+1,a=output$a_hat[i,k],b=output$b_hat[i,k],method=output$regression_method)
                output$Beta[,k] <- solve(t(Ksi_i)%*%(Ksi_i))%*%t(Ksi_i)%*% vects[[(k-1)*output$n/output$nclusts+1]]$y
        }



        return(output)
}



StoppingCondition <- function(Lhood,numIter,max_iter,Thresh) ## Stopping Condition {{{1
{
        Stop <- F
        if (numIter==max_iter)
        {
                Stop <- T
        }

        if (is.nan(Lhood[numIter])) {
                print('Likelihood was NA')
                Stop <- T
        } else if (abs(Lhood[numIter] - Lhood[numIter-1])<Thresh) {
                Stop <- T
        }

        return(Stop)
}

calcLike <- function(output,N) ## calcLike {{{1 ### TO DO
{
        sumW <- apply(output$W,1,sum)
        output$Lhood <- sum(log(sumW)) 
        #output$Lhood <- sum(log(s)) +  N %*% log(output$scale)
        return(output)
}

curvclust_time_align <- function(vects, p, nclusts, regression_method="polynomial", MC_runs=150, Thresh=1e-5,max_iter=15) ### MAIN FUNCTION {{{1
{
        require(MASS)
        # vects is a list of n n_ix2 matrices. vects[[i]]$x is the vector of covariates (i.e time or position) and vects[[i]]$y is the vector of output (can be in D-dimension but here we have D=1).
        # p  is the dimension of the regression
        # nclusts is the number of clusters
        # Thresh is the threshold for the EM-algorithm
        output <- NULL
        output$p <- p
        output$n_i <- vapply(vects,nrow,1)
        output$n <- length(vects)
        output$nclusts <- nclusts
        output$regression_method <- regression_method
        output$max_iter <- max_iter
        output$MC_runs <- MC_runs

        output <- Initialize_EStep(output, vects)
        output <- Initialize_MStep(output, vects)

        numIter <- 1
        Lhood <- rep(-Inf,max_iter+1)

        ## EM Algorithm
        while (1)
        {
                numIter <- numIter+1
                print(paste0('Iteration N°',numIter))

                # E-step
                output <- EStep(output,vects)
                output$Z <- apply(output$W,1,which.max)

                ## Verify conditions and break out of loop if satisfied
                #output <- calcLike(output,vects);
                Lhood[numIter] <- output$Lhood
                Stop <- StoppingCondition(Lhood,numIter,max_iter=max_iter,Thresh=Thresh)
                if (Stop) 
                {
                        print('ending EM algorithm')
                        break
                }


                # M-step : maximization of the Q-function
                output <- MStep(output,vects)
        }


        return(output)
}
