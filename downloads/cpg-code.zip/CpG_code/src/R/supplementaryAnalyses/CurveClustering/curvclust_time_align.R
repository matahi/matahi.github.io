calculate_regression_matrix <- function(x, method="polynomial", a=1,b=0, p )
{
        ## PRM
        if (method=="polynomial")
        {
                require(matrixcalc)
                Ksi <- vandermonde.matrix( a*x - b , p)
                ## SRM
        } else if (method=="spline") {
                ## BSRM
        } else if (method=="Bspline") {
                ## NULL
        } else {
                print('not a valid method')
        }
        return(Ksi)
}

## Small_gamma  (6.13)
calculate_gamma_m_z <- function(mu, Variance, m)
{
        if (m==0)
        {
                gamma_m_z <- rep(0,length(mu))
        } else if (m==1) {
                gamma_m_z <- rep(0,length(mu))
        } else {

                G_q <- sapply(1:floor(m/2),function(q){out <- 1;for(j in 1:q){out <- out*(2*j-1)};return(out)})
                C_m_2q <- choose(m,2*(1:floor(m/2)))
                Sigma_2q <- sapply((1:floor(m/2)),function(k){Variance^(k)}) ## Variance = Sigma^2
                mu_m_2q <- sapply(1:floor(m/2),function(k){mu^(m-2*k)})

                gamma_m_z <-sapply(1:length(mu),function(n_i){sum(G_q*C_m_2q*Sigma_2q[n_i,]*mu_m_2q[n_i,])})
        }
        return(gamma_m_z)
}

## V_X_i (6.38)
calculate_V_X_i <- function(x,W,Gamma_ab,p,i)
{
        C_m_p <- lapply(0:p,function(j){choose(j,0:j)})
        minus_m <- lapply(0:p,function(j){(-1)^(0:j)})
        x_p_m <- lapply(0:p,function(j){sapply(j:0,function(k){x^k})})
        V_X_i <- matrix(0,length(x),p+1)
        for (j in 0:p)
        {
                if (j==0)
                {
                        V_X_i[,j+1] <- 0
                } else if (j==1) {
                        V_X_i[,j+1] <- 0
                } else {
                        V_X_i[,j+1] <- W* apply(minus_m[[j+1]]*Gamma_ab[[j+1]][i,]*x_p_m[[j+1]]*C_m_p[[j+1]],1,sum)
                }
        }
        return(V_X_i)
}

## V_XX_i
calculate_V_XX_i <- function(x,W,Gamma_ab,p,i)
{
        V_XX_i <- matrix(0,nrow=p+1,ncol=p+1)
        vxx <- calculate_V_X_i(x,W,Gamma_ab,2*p,i) 
        vxx <- apply(vxx,2,sum) 
        for (j in 0:(2*p))
        {
                vxx_j <- vxx[j+1]
                                        
                for (n_row in 1:min(j+1,p+1))
                {
                        #print(paste0("n_row=",n_row))
                        n_col <- j+2-n_row
                        #print(paste0("n_col=",n_col))
                        if (n_col<=(p+1))
                                V_XX_i[n_row,n_col] <- vxx_j
                }
        }

        return(V_XX_i)
}



## Log posterior
log_posterior_y_i <- function(a,b,y_i,x_i,Beta,sigma,r,s,p)
{
        Ksi <- calculate_regression_matrix(x_i, a=a,b=b,p=p+1)
        return( norm(y_i - Ksi*Beta,"2")/(sigma^2) + (a-1)^2/(r^2) + b^2/(s^2) )
}

proj_PDC_gaffney <- function(V,max_counter = 5) # Transform V into PSD matrix using gaffney method
{
        tmp <- eigen(V)
        counter <- 0
        if (any(tmp$values<0)|(counter<=max_counter))
        { 
                counter <- counter + 1
                tmp <- eigen(V)
                diag(V) <- 1.25*diag(V)
        }

        output <- NULL
        if (any(tmp$values<0)) {
                output$keep <- F
        } else {
                output$keep <- T
        }
                
        output$V <- V
        return(output)
}

#############################################################################################################################################################################################################
curvclust_time_align <- function(vects, p, nclusts, regression_method="polynomial", MC_runs=150, Thresh=1e-5)
{
        require(MASS)
        # vects is a list of n n_ix2 matrices. vects[[i]]$x is the vector of covariates (i.e time or position) and vects[[i]]$y is the vector of output (can be in D-dimension but here we have D=1).
        # p  is the dimension of the regression
        # nclusts is the number of clusters
        # Thresh is the threshold for the EM-algorithm
        n <- length(vects)
        n_i <- vapply(vects,nrow,1) # length of i-th sample

        # Likelihood
        Lhood <- -Inf

        #### Hidden parameters
        # cluster membership
        W <- matrix(1/nclusts,nrow=n,ncol=nclusts)

        # alpha_k
        alpha <- rep(1/nclusts,nclusts)
        
        # Noise
        Sigma <- rep(1,nclusts)

        # Transformation priors
        r <- rep(1,nclusts)
        s <- rep(1,nclusts)

        ## Observed parameters
        # Time Transformation
        a_hat <- matrix(1,nrow=n,ncol=nclusts)
        b_hat <- matrix(0,nrow=n,ncol=nclusts)

        V_a <- matrix(1,nrow=n,ncol=nclusts)
        V_b <- matrix(1,nrow=n,ncol=nclusts)
        V_a_b <- matrix(1,nrow=n,ncol=nclusts)

        # Beta : Careful when initializing Beta if its too far the Lhood
        # Let's initialize Beta with the solution of the regression problems for i=1,11,21,31 (corresponding to the 4 modes)
        Beta <- matrix(0,nrow=p+1,ncol=nclusts)
        for (k in 1:nclusts)
        {
                Ksi_i <-  calculate_regression_matrix(vects[[(k-1)*n/nclusts+1]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)
                Beta[,k] <- solve(t(Ksi_i)%*%(Ksi_i))%*%t(Ksi_i)%*% vects[[(k-1)*n/nclusts+1]]$y
        }

        # Calculate Likelihood for initial condition : 

        SumLhood <- matrix(0,n,nclusts)
        for (i in 1:n)
        {
                for (k in 1:nclusts)
                {
                        a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2)))
                        Xhat <- lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})

                        p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt(det(Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})


                        p_k <- sum(p_k_sum)/MC_runs

                        SumLhood[i,k] <- alpha[k] * p_k 
                }
        }
        NewLhood <- sum(log(apply(SumLhood,1,sum)))

        ## EM Algorithm
        while (abs(Lhood-NewLhood)>Thresh) {#||(is.na(abs(Lhood-NewLhood)))
                Lhood <- NewLhood
                print(paste0('NewLhood=',Lhood))

                # E-step
                print("E-step.....")
                for (i in 1:n){
                        for (k in 1:nclusts)
                        {
                                ## 1) Estimate a and b 
                                # a) mean with Nelder-Mead
                                res <- optim(c(1,0),function(a_b){ log_posterior_y_i(a_b[1],a_b[2],vects[[i]]$y,vects[[i]]$x,Beta[,k],Sigma[k],r[k],s[k],p)})
                                a_hat[i,k] <- res$par[1]
                                b_hat[i,k] <- res$par[2]

                                ## 2) Variance with inverse information
                                Ksi_i <- calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)
                                Dx <- rep(1,n_i[i]) %*% t(0:p); # n_i x p+1
                                Dx[,3:(p+1)] <- Dx[,3:(p+1)] * Ksi_i[ , 2:p]  # n_i x p+1
                                D2x <- rep(1,n_i[i]) %*% t(c(0,0,2:p)) # n_i x p+1
                                D2x[,3:(p+1)] <- D2x[,3:(p+1)] * Dx[,2:p] # n_i x p+1

                                Dx_Beta <- Dx %*% Beta[,k]; # nix1
                                Dx_Beta_x <- Dx_Beta * vects[[i]]$x # nix1
                                D2x_Beta <- D2x %*% Beta[,k] # nix1
                                D2x_Beta_x <- D2x_Beta * vects[[i]]$x
                                Y_x_Beta <- vects[[i]]$y - Ksi_i %*% Beta[,k]

                                # a) Inverse information
                                Ia <- sum(Y_x_Beta * (D2x_Beta_x * vects[[i]]$x)) / Sigma[k]^2 - sum(Dx_Beta_x^2)/Sigma[k]^2 - 1/r[k]^2;
                                Ib <- sum(Y_x_Beta * D2x_Beta) /Sigma[k]^2 - sum( Dx_Beta^2 )/Sigma[k]^2 - 1/s[k]^2;
                                Iab <- - sum(Y_x_Beta * D2x_Beta_x)/ Sigma[k]^2 + sum(Dx_Beta *Dx_Beta_x)/Sigma[k]^2 ;

                                V <- diag(c(Ia,Ib))
                                V[1,2] <- Iab; V[2,1] <- Iab

                                V_inv <- solve(-V) #

                                V_a[i,k] <- V_inv[1,1];
                                V_b[i,k] <- V_inv[2,2];

                                ## Verify that no value is negative
                                if (V_a[i,k]<0)
                                {
                                        print(paste0('V_a is negative for i=',i,' and for k=',k))
                                        V_a[i,k] <- abs(V_inv[1,1]);
                                }
                                if (V_b[i,k]<0)
                                {
                                        print(paste0('V_b is negative for i=',i,' and for k=',k))
                                        V_b[i,k] <- abs(V_inv[2,2]);
                                }

                                V_a_b[i,k] <- V_inv[1,2];


                                ## 3) Calculate probas 
                                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2))) ## should we take mu = c(a_hat,b_hat)?
                                Xhat <-  lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})
                                p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt(det(Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})
                                p_k <- sum(p_k_sum)/MC_runs

                                ## 4) Cluster Membership : only proportional ! normalization comes after
                                W[i,k] <- alpha[k] * p_k

                        }
                }

                ## Then normalize W
                W <- W/apply(W,1,sum)

                # M-step : maximization of the Q-function
                print("M-step.....")
                for (k in 1:nclusts)
                {
                        print(paste0('      k=',k))
                        ## Calculating alpha 
                        alpha[k] <- 1/n*sum(W[,k])

                        ## Calculating r, s, u and v
                        r[k] <- sqrt(sum(W[,k] * ((a_hat[,k]-1)^2 + V_a[,k]))/sum(W[,k]))
                        s[k] <- sqrt(sum(W[,k] * (b_hat[,k]^2 + V_b[,k]))/sum(W[,k]))

                        ## Calculate runs
                        a_runs <- matrix(0,n, MC_runs)
                        b_runs <- matrix(0,n, MC_runs)

                        ## Initialization

                        ## run a,b,c,d to calculate the moments
                        for (i in 1:n)
                        {
                                ## Cov Matrix
                                V <- matrix ( c( V_a[i,k]       , V_a_b[i,k]    , 
                                                 V_a_b[i,k]     , V_b[i,k]      ),
                                             nrow=2,ncol=2,byrow=T)
                                
                                # Make sure V is PD
                                output <- proj_PDC_gaffney(V) ## proj on the SDP cone

                                V_est <- output$V
                                keep <- output$keep

                                output$keep <- F

                                if (output$keep)
                                {
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k]) , Sigma=V_est) ##
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                } else {
                                        print('used diagonal matrix')
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k]) , Sigma=diag(diag(V_est))) 
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                }

                        }

                        ## Estimating the covariances
                        Cov_a_b <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m),b_runs[i,]^m)})})}) # Cov_a_b[[j+1]] is the matrix of size nx(j+1) that contains all the cov(a_i^(j-r),b_i^r) for r in 0:j

                        ## Estimating the gammas with the covariances
                        gamma_m_b <- sapply(0:(2*p), function(j){calculate_gamma_m_z(b_hat[,k],V_b[,k],j)}) # gamma_m_b[i,j+1] is gamma_j_(b_i) 
                        gamma_m_a <- sapply(0:(2*p), function(j){calculate_gamma_m_z(a_hat[,k],V_a[,k],j)})
                        ## dim(Gamma_ab[[j+1]])= nx(j+1) and  contains all the Gamma_i_m_j for m in 0:j  
                        Gamma_ab <- lapply(0:(2*p), function(j){sapply(j:0,function(k_i){a_hat[,k]^k_i}) * gamma_m_b[,1:(j+1)] + sapply(0:j,function(k_i){b_hat[,k]^k_i}) * gamma_m_a[,(j+1):1] + gamma_m_a[,(j+1):1] * gamma_m_b[,1:(j+1)] + Cov_a_b[[j+1]]})

                        ## Estimating V_XX_i, V_X_i 
                        V_X <- lapply(1:n, function(i){calculate_V_X_i(x=vects[[i]]$x,W=W[i,k],Gamma_ab=Gamma_ab,p=p,i=i)})
                        V_XX <- lapply(1:n, function(i){calculate_V_XX_i(x=vects[[i]]$x,W=W[i,k],Gamma_ab=Gamma_ab,p=p,i=i)}) 

                        ## Ksi_mat
                        Ksi_mat <- lapply( 1:n, function(i){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)})

                        ## Calculating Beta: Beta[,k] = (sum_{i=1}^n  c_i_k^2 * W_i_k * Ksi_i' * Ksi_i + V_XX_i)^(-1) * (sum_{i=1}^n  W_i_k *c_i_k * Ksi_i' * (y_i - d_i_k) + V_X_i' * y_i - V_X_cd )
                        Beta_vec <- Reduce('+',lapply(1:n, function(i){W[i,k] *  t(Ksi_mat[[i]])%*%Ksi_mat[[i]] + V_XX[[i]]}))
                        Beta[,k] <- solve(Beta_vec) %*% Reduce('+',lapply(1:n, function(i){W[i,k]* t(Ksi_mat[[i]])%*%  vects[[i]]$y  + t(V_X[[i]]) %*% vects[[i]]$y } ) )


                        ## Calculating Sigma: Sigma[k] = sqrt( sum_{i=1}^n W_i_k* (||y_i - c_i_k * Ksi_i * Beta_k - d_i_k||^2 - 2* y_i' * V_X_i * Beta_k + Beta_k' * V_XX_i *Beta_k + 2* Beta_k' * V_X_cd + n_i * V_d_i_k) / sum(W[i,k]*n_i) )
                        Sigma_test <- sum(sapply(1:n, function(i){ W[i,k]* ( norm(vects[[i]]$y  * Ksi_mat[[i]] %*% Beta [,k],"2")^2 - as.numeric(2* t(vects[[i]]$y) %*% V_X[[i]] %*% Beta[,k]) + as.numeric(t(Beta[,k]) %*% V_XX[[i]] %*% Beta[,k]) )})) / sum(W[,k]*n_i)
                        if (Sigma_test<=0)
                        {
                                print("Sigma was negative, replaced with opposite value?")
                                print(paste0('Sigma =',Sigma_test))
                                Sigma[k] <- abs(Sigma_test)
                        } else {
                                Sigma[k] <- sqrt(Sigma_test) 
                        }

                }

                ## 3) Calculate the New Likelihood
                print('Calculating New Likelihood...')
                SumLhood <- matrix(0,n,nclusts)
                for (i in 1:n)
                {
                        for (k in 1:nclusts)
                        {
                                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2)))
                                Xhat <-  lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})

                                ## Make a test if (U_k_i_k+V_k_i_k - Sigma[k]^2) is non invertible
                                p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt(det(Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})

                                p_k <- sum(p_k_sum)/MC_runs
                                SumLhood[i,k] <- alpha[k] * p_k 

                        }

                }
                NewLhood <- sum(log(apply(SumLhood,1,sum)))

        }

        output <- NULL
        output$Beta <- Beta
        output$Sigma <- Sigma
        output$Lhood <- NewLhood
        output$alpha <- alpha
        output$W <- W
        output$Z <- apply(W,1,which.max)
        output$a <- a_hat
        output$b <- b_hat

        return(output)
}



