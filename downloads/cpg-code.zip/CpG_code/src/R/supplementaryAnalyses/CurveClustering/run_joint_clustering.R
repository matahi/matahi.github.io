###############################################################################################
setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R')
library(ggplot2)

nclusts <- 3 ## number of clusters
p <- 4

## Functions 
Func <- vector('list',nclusts)

# Function 1 : a_k*exp(c_k*x + d_k) + b_k
Func[[1]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){-a*(c*x+d)^2/20+b+sigma}
# Function 2 : a_k_1*(c_k*x + d_k)^2 + b_k
Func[[2]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){(a*abs(c*x+d)^3+b+sigma)/100}
# Function 3 : a_k*sin(c_k*x + d_k) + b_k
Func[[3]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*sin(c*x+d)+b+sigma}
# Function 4 : a_k*1/(abs(c_k*x + d_k)+1) + b_k
Func[[4]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*(c*x+d)^2/20+b+sigma}

## Signals
#n <- 30 ## number of signals
#max_points <- 100
#min_points <- 50
#limits <- c(0,2*pi)
#Dat <- vector('list',n) 

#########################################################
## If there was no deformation : {{{1

## Transformation priors
r <- 1:nclusts/10
s <- 1:nclusts/10
u <- 1:nclusts/10
v <- 1:nclusts/10
sigma <- 1:nclusts/40

for (i in 1:n)
{
        k <- ceiling(i*nclusts/n)
        sample_size <- sample(min_points:max_points,1)
        sample_x <- sort(runif(sample_size,min=limits[1],max=limits[2]))
        a <- 1
        b <- 0
        c <- 1
        d <- 0
        Sigma <- rnorm(sample_size,mean=0,sd=sigma[k])
        sample_x <- a*sample_x - b 
        sample_y <- c*Func[[k]](x=sample_x) + d + Sigma
        Dat[[i]] <- data.frame(x=sample_x,y=sample_y,nsample=i,nclust=k)
}


## plot
n_i <- vapply(Dat,nrow,1)

## data.frame
Dat.df <- Reduce(rbind,Dat)

pdf('../../results/Curve_Clustering/Simulated_Data/curves.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample))
gg_p
dev.off()

source('fun/curvclust.R')
output <- curvclust(vects=Dat, p=p, nclusts=nclusts, regression_method="polynomial", Thresh=1e-6)
NewGrid <- seq(limits[1],limits[2],length.out=100)
Cluster.df <- data.frame(x=rep(NewGrid,nclusts),y= matrix(calculate_regression_matrix(NewGrid,p=p) %*% output$Beta,ncol=1), nclust=rep(1:4,each=length(NewGrid)))

pdf('../../results/Curve_Clustering/Simulated_Data/curve_clustering.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
dev.off()

#########################################################
## With space Deformation : {{{1
input <- NULL
input$u <- 1:nclusts/20
input$v <- 1:nclusts/20
input$sigma <- 1:nclusts/30

input$c <- rep(0,n)
input$d <- rep(0,n)
input$nclusts <- 3

for (i in 1:n)
{
        k <- ceiling(i*nclusts/n)
        sample_size <- sample(min_points:max_points,1)
        sample_x <- sort(runif(sample_size,min=limits[1],max=limits[2]))
        input$c[i] <- rnorm(1,mean=1,sd=input$u[k])
        input$d[i] <- rnorm(1,mean=0,sd=input$v[k])
        Sigma <- rnorm(sample_size,mean=0,sd=input$sigma[k])
        sample_x <- sample_x
        sample_y <- input$c[i]*Func[[k]](x=sample_x) + input$d[i] + Sigma 
        Dat[[i]] <- data.frame(x=sample_x,y=sample_y,nsample=i,nclust=k)
}

## data.frame
Dat.df <- Reduce(rbind,Dat)

# pdf('../../results/Curve_Clustering/Simulated_Data/curves_space_deformation.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p
# dev.off()

# Solution

source('fun/curvclust_space_align.R')
output <- curvclust_space_align(vects=Dat, p=p, nclusts=nclusts, regression_method="polynomial", Thresh=0.05,n_iter=20)
NewGrid <- seq(limits[1],limits[2],length.out=100)
Cluster.df <- data.frame(x=rep(NewGrid,nclusts),y= matrix(calculate_regression_matrix(NewGrid,p=p) %*% output$Beta,ncol=1), nclust=rep(1:nclusts,each=length(NewGrid)))
Dat.realigned <- Dat.df

for (i in 1:nrow(output$d))
{
        current_clust <- output$Z[i]
        #Dat.realigned[Dat.realigned$nsample==i,"y"] <- output$c[i,current_clust] * Dat.realigned[Dat.realigned$nsample==i,"y"] - output$d[i,current_clust]
        Dat.realigned[Dat.realigned$nsample==i,"y"] <-  (Dat.realigned[Dat.realigned$nsample==i,"y"] - output$d[i,current_clust] ) /output$c[i,current_clust] 
}

#c_align <- rep(0,n)
#d_align <- rep(0,n)
#for (i in 1:n)
#{
#        current_clust <- output$Z[i]
#        c_align[i] <- output$c[i,current_clust]
#        d_align[i] <- output$d[i,current_clust]
#}

# pdf('../../results/Curve_Clustering/Simulated_Data/joint_space_clustering.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
# dev.off()

# pdf('../../results/Curve_Clustering/Simulated_Data/joint_space_clustering_realigned.pdf')
gg_p <- ggplot(Dat.realigned,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
# dev.off()

#########################################################
## With time Deformation : {{{1
n <- 30 ## number of signals
max_points <- 40
min_points <- 30
limits <- c(0,2*pi)
Dat <- vector('list',n) 


## Test :
input <- NULL
input$r <- 1:nclusts/10
input$s <- 1:nclusts/5
#u <- 1:nclusts/10
#v <- 1:nclusts/10
input$sigma <- 1:nclusts/30
input$a <- rep(0,n)
input$b <- rep(0,n)

for (i in 1:n)
{
        k <- ceiling(i*nclusts/n)
        sample_size <- sample(min_points:max_points,1)
        sample_x <- sort(runif(sample_size,min=limits[1],max=limits[2]))
        input$a[i] <- rnorm(1,mean=1,sd=input$r[k])
        input$b[i] <- rnorm(1,mean=0,sd=input$s[k])
        pos_x <- sample_x
        sample_x <- input$a[i]*sample_x - input$b[i]
        #sample_bis <- a[i]*sample_x - b[i]
        sample_y <- Func[[k]](x=pos_x) + rnorm(sample_size,mean=0,sd=input$sigma[k])
        Dat[[i]] <- data.frame(x=sample_x,y=sample_y,nsample=i,nclust=k)
}


## plot
n_i <- vapply(Dat,nrow,1)
## data.frame
Dat.df <- Reduce(rbind,Dat)

# pdf('../../results/Curve_Clustering/Simulated_Data/curves_time_deformation.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p
# dev.off()

# Solution
vects <- Dat
p <- p
nclusts <- nclusts
MC_runs <- 150
regression_method <- "polynomial"
Thresh <- 0.01
max_iter <- 15

# source('fun/curvclust_time_align.R')
source('fun/curvclust_time_align_bis.R')
output <- curvclust_time_align(vects=Dat, p=p, nclusts=nclusts, regression_method="polynomial", Thresh=0.01)
NewGrid <- seq(limits[1],limits[2],length.out=100)
Cluster.df <- data.frame(x=rep(NewGrid,nclusts),y= matrix(calculate_regression_matrix(NewGrid,p=p+1) %*% output$Beta,ncol=1), nclust=rep(1:nclusts,each=length(NewGrid)))

##
Dat.realigned <- Dat.df
for (i in 1:length(output$Z))
{
        current_clust <- output$Z[i]
        Dat.realigned[Dat.realigned$nsample==i,"x"] <-  (Dat.realigned[Dat.realigned$nsample==i,"x"] + output$b_hat[i,current_clust]) *output$a_hat[i,current_clust]
}

# pdf('../../results/Curve_Clustering/Simulated_Data/joint_time_clustering.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
# dev.off()

# pdf('../../results/Curve_Clustering/Simulated_Data/joint_time_clustering_realigned.pdf')
gg_p <- ggplot(Dat.realigned,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2) 
# gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2) + xlim(c(0,2)) + ylim(c(-2,2))
# dev.off()

## Real Solution
Dat.sol <- Dat.df
for (i in 1:max(Dat.sol$nsample))
{
        current_clust <- Dat.sol[which(Dat.sol$nsample==i)[1],'nclust']
        Dat.sol[Dat.sol$nsample==i,"x"] <-  (Dat.sol[Dat.sol$nsample==i,"x"] + input$b[i]) /input$a[i]
}
quartz()
gg_p <- ggplot(Dat.sol,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p

#########################################################
## With space and time Deformation : {{{1
## Signals
n <- 30 ## number of signals
max_points <- 100
min_points <- 50
limits <- c(0,2*pi)
Dat <- vector('list',n) 


input <- NULL
input$r <- 1:nclusts/20
input$s <- 1:nclusts/20
input$u <- 1:nclusts/20
input$v <- 1:nclusts/20
input$sigma <- 1:nclusts/30

input$a <- rep(0,n)
input$b <- rep(0,n)
input$c <- rep(0,n)
input$d <- rep(0,n)

for (i in 1:n)
{
        k <- ceiling(i*nclusts/n)
        sample_size <- sample(min_points:max_points,1)
        sample_x <- sort(runif(sample_size,min=limits[1],max=limits[2]))
        input$a[i] <- rnorm(1,mean=1,sd=input$r[k])
        input$b[i] <- rnorm(1,mean=0,sd=input$s[k])
        input$c[i] <- rnorm(1,mean=1,sd=input$u[k])
        input$d[i] <- rnorm(1,mean=0,sd=input$v[k])
        pos_x <- sample_x
        sample_x <- input$a[i]*sample_x - input$b[i] 
        sample_y <- input$c[i]*Func[[k]](x=pos_x) + input$d[i] + rnorm(sample_size,mean=0,sd=input$sigma[k])
        Dat[[i]] <- data.frame(x=sample_x,y=sample_y,nsample=i,nclust=k)
}

n_i <- vapply(Dat,nrow,1)
## data.frame
Dat.df <- Reduce(rbind,Dat)

## plot
pdf('../../results/Curve_Clustering/Simulated_Data/curves_space_time_deformation.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p
dev.off()

## debugging
vects <- Dat
p <- p
nclusts <- nclusts
MC_runs <- 150
regression_method <- "polynomial"
Tresh <- 0.01


# Solution
source('fun/joint_prob_curvclust_align.R')
output <- joint_prob_curvclust_align(vects=Dat, p=p, nclusts=nclusts, regression_method="polynomial", Thresh=0.01)
NewGrid <- seq(limits[1],limits[2],length.out=100)
Cluster.df <- data.frame(x=rep(NewGrid,nclusts),y= matrix(calculate_regression_matrix(NewGrid,p=p+1) %*% output$Beta,ncol=1), nclust=rep(1:4,each=length(NewGrid)))

##
Dat.realigned <- Dat.df
for (i in 1:nrow(output$d))
{
        current_clust <- output$Z[i]
        Dat.realigned[Dat.realigned$nsample==i,"x"] <-  (Dat.realigned[Dat.realigned$nsample==i,"x"] + output$b[i,current_clust]) /output$a[i,current_clust]
        Dat.realigned[Dat.realigned$nsample==i,"y"] <-  (Dat.realigned[Dat.realigned$nsample==i,"y"] - output$d[i,current_clust]) / output$c[i,current_clust]
}

pdf('../../results/Curve_Clustering/Simulated_Data/joint_space_time_clustering.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
dev.off()

pdf('../../results/Curve_Clustering/Simulated_Data/joint_space_time_clustering_realigned.pdf')
gg_p <- ggplot(Dat.realigned,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
dev.off()

## Real Solution
Dat.RealSol <- Dat.df
for (i in 1:length(input$d))
{
        Dat.RealSol[Dat.RealSol$nsample==i,"x"] <-  (Dat.RealSol[Dat.RealSol$nsample==i,"x"] + input$b[i]) / input$a[i]
        Dat.RealSol[Dat.RealSol$nsample==i,"y"] <-  (Dat.RealSol[Dat.RealSol$nsample==i,"y"] - input$d[i]) / input$c[i]
}
quartz()
gg_p <- ggplot(Dat.RealSol,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p

## lrm_d_ab Deformation : {{{1
## Signals
n <- 30 ## number of signals
max_points <- 100
min_points <- 50
limits <- c(0,2*pi)
Dat <- vector('list',n) 

input <- NULL
input$r <- 1:nclusts/20
input$s <- 1:nclusts/20
input$v <- 1:nclusts/20
input$sigma <- 1:nclusts/30

input$a <- rep(0,n)
input$b <- rep(0,n)
input$d <- rep(0,n)

for (i in 1:n)
{
        k <- ceiling(i*nclusts/n)
        sample_size <- sample(min_points:max_points,1)
        sample_x <- sort(runif(sample_size,min=limits[1],max=limits[2]))
        input$a[i] <- rnorm(1,mean=1,sd=input$r[k])
        input$b[i] <- rnorm(1,mean=0,sd=input$s[k])
        input$d[i] <- rnorm(1,mean=0,sd=input$v[k])
        pos_x <- sample_x
        sample_x <- input$a[i]*sample_x - input$b[i] 
        sample_y <- Func[[k]](x=pos_x) + input$d[i] + rnorm(sample_size,mean=0,sd=input$sigma[k])
        Dat[[i]] <- data.frame(x=sample_x,y=sample_y,nsample=i,nclust=k)
}

## data.frame
Dat.df <- Reduce(rbind,Dat)

## plot
# pdf('../../results/Curve_Clustering/Simulated_Data/curves_space_time_deformation.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p
# dev.off()

## debugging
vects <- Dat
p <- p
nclusts <- nclusts
MC_runs <- 150
regression_method <- "polynomial"
Tresh <- 0.01


# Solution
source('fun/lrm_d_ab.R')
output <- lrm_d_ab(vects=Dat, p=p, nclusts=nclusts, regression_method="polynomial", Thresh=0.01)
NewGrid <- seq(limits[1],limits[2],length.out=100)
Cluster.df <- data.frame(x=rep(NewGrid,nclusts),y= matrix(calculate_regression_matrix(NewGrid,p=p+1) %*% output$Beta,ncol=1), nclust=rep(1:nclusts,each=length(NewGrid)))

##
Dat.realigned <- Dat.df
for (i in 1:nrow(output$d))
{
        current_clust <- output$Z[i]
        Dat.realigned[Dat.realigned$nsample==i,"x"] <-  (Dat.realigned[Dat.realigned$nsample==i,"x"] + output$b[i,current_clust]) /output$a[i,current_clust]
        Dat.realigned[Dat.realigned$nsample==i,"y"] <-  (Dat.realigned[Dat.realigned$nsample==i,"y"] - output$d[i,current_clust])
        Dat.realigned[Dat.realigned$nsample==i,"nclust"] <- output$Z[i]
}

# pdf('../../results/Curve_Clustering/Simulated_Data/joint_space_time_clustering.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
# dev.off()

# pdf('../../results/Curve_Clustering/Simulated_Data/joint_space_time_clustering_realigned.pdf')
gg_p <- ggplot(Dat.realigned,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p + geom_line(data=Cluster.df,aes(colour=factor(nclust)),size=2)
# dev.off()

## Real Solution
Dat.RealSol <- Dat.df
for (i in 1:length(input$d))
{
        Dat.RealSol[Dat.RealSol$nsample==i,"x"] <-  (Dat.RealSol[Dat.RealSol$nsample==i,"x"] + input$b[i]) / input$a[i]
        Dat.RealSol[Dat.RealSol$nsample==i,"y"] <-  (Dat.RealSol[Dat.RealSol$nsample==i,"y"] - input$d[i]) 
}
quartz()
gg_p <- ggplot(Dat.RealSol,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p


