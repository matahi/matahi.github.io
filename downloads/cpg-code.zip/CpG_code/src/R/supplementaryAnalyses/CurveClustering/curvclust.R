calculate_regression_matrix <- function(x, method="polynomial", a=1,b=0, p )
{
        ## PRM
        if (method=="polynomial")
        {
                require(matrixcalc)
                ksi <- vandermonde.matrix( a*x - b , p)
                ## SRM
        } else if (method=="spline") {
                ## BSRM
        } else if (method=="Bspline") {
                ## NULL
        } else {
                print('not a valid method')
        }
        return(ksi)
}


curvclust <- function(vects, p, nclusts, regression_method="polynomial", Thresh=1e-5)
{
        # vects is a list of n n_ix2 matrices. vects[[i]]$x is the vector of covariates (i.e time or position) and vects[[i]]$y is the vector of output (can be in D-dimension but here we have D=1).
        # p  is the dimension of the regression
        # nclusts is the number of clusters
        # Thresh is the threshold for the EM-algorithm
        n <- length(vects)
        n_i <- vapply(vects,nrow,1) # length of i-th sample

        # Likelihood
        Lhood <- -Inf

        # Set of Parameters
        # cluster membership
        W <- matrix(1/nclusts,nrow=n,ncol=nclusts)

        # alpha_k
        alpha <- rep(1/nclusts,nclusts)
        
        # Noise
        Sigma <- rep(1,nclusts)

        # Beta : Careful when initializing Beta if its too far the Lhood
        # Let's initialize Beta with the solution of the regression problems for i=1,11,21,31 (corresponding to the 4 modes)
        Beta <- matrix(0,nrow=p,ncol=nclusts)
        for (k in 1:nclusts)
        {
                X_i <-  calculate_regression_matrix(vects[[(k-1)*n/nclusts+1]]$x,p=p,method=regression_method)
                Beta[,k] <- solve(t(X_i)%*%(X_i))%*%t(X_i)%*% vects[[(k-1)*n/nclusts+1]]$y
        }

        # Calculate Likelihood for initial condition : 
        SumLhood <- rep(0,n)
        for (i in 1:n)
        {
                X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,method=regression_method)
                SumLhood[i] <- sum( W[i,] * log( alpha * exp(-(1/2)* norm( vects[[i]]$y - X_i%*% Beta ,"2" ))/(2*pi*Sigma)   ) )
        }

        NewLhood <- sum(SumLhood)

        ## EM Algorithm
        while (abs(Lhood-NewLhood)>Thresh) {#||(is.na(abs(Lhood-NewLhood)))
                Lhood <- NewLhood
                print(Lhood)

                # E-step
                for (i in 1:n){
                        for (k in 1:nclusts)
                        {
                                X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,method=regression_method)
                                W[i,k] <- alpha[k] *exp(-(1/2)* norm( vects[[i]]$y - X_i%*% Beta[,k] ,"2" ))/(2*pi*Sigma[k]) 
                        }
                }

                ## Then normalize W
                W <- W/apply(W,1,sum)

                # M-step : maximization of the Q-function
                for (k in 1:nclusts)
                {
                        ## Calculating Beta
                        Beta_Mat1 <- 0
                        Beta_Vect <- 0

                        for (i in 1:n)
                        {
                                X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,method=regression_method)
                                Beta_Mat1 <- Beta_Mat1 + W[i,k]* t(X_i)%*%X_i
                                Beta_Vect <- Beta_Vect + W[i,k]* t(X_i)%*% vects[[i]]$y
                        }

                        Beta[,k] <- solve(Beta_Mat1) %*% Beta_Vect

                        ## Calculating Sigma
                        Sigma_Norm <- 0

                        for (i in 1:n)
                        {
                                X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,method=regression_method)
                                Sigma_Norm <- Sigma_Norm + W[i,k] * norm(vects[[i]]$y - X_i %*% Beta[,k],"2")
                        }

                        Sigma[k] <- sqrt( Sigma_Norm/sum(W[,k]))


                        ## Calculating alpha 
                        alpha[k] <- 1/n*sum(W[,k])
                }

                ## Calculate the New Likelihood
                SumLhood <- rep(0,n)
                for (i in 1:n)
                {
                        X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,method=regression_method)
                        SumLhood[i] <- sum( W[i,] * log( alpha * exp(-(1/2)* norm( vects[[i]]$y - X_i%*% Beta ,"2" ))/(2*pi*Sigma)   ) )

                }

                NewLhood <- sum(SumLhood)

        }

        output <- NULL
        output$Beta <- Beta
        output$Sigma <- Sigma
        output$Lhood <- NewLhood
        output$alpha <- alpha
        output$W <- W
        output$Z <- apply(W,1,which.max)

        return(output)
}



