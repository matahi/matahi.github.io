calculate_regression_matrix <- function(x, method="polynomial", a=1,b=0, p )
{
        ## PRM
        if (method=="polynomial")
        {
                require(matrixcalc)
                Ksi <- vandermonde.matrix( a*x - b , p)
                ## SRM
        } else if (method=="spline") {
                ## BSRM
        } else if (method=="Bspline") {
                ## NULL
        } else {
                print('not a valid method')
        }
        return(Ksi)
}


## Small_gamma  (6.13)
calculate_gamma_m_z <- function(mu, Variance, m)
{
        if (m==0)
        {
                gamma_m_z <- rep(0,length(mu))
        } else if (m==1) {
                gamma_m_z <- rep(0,length(mu))
        } else {

                G_q <- sapply(1:floor(m/2),function(q){out <- 1;for(j in 1:q){out <- out*(2*j-1)};return(out)})
                C_m_2q <- choose(m,2*(1:floor(m/2)))
                Sigma_2q <- sapply((1:floor(m/2)),function(k){Variance^(k)}) ## Variance = Sigma^2
                mu_m_2q <- sapply(1:floor(m/2),function(k){mu^(m-2*k)})

                gamma_m_z <-sapply(1:length(mu),function(n_i){sum(G_q*C_m_2q*Sigma_2q[n_i,]*mu_m_2q[n_i,])})
        }
        return(gamma_m_z)
}

#                         V_XX <- lapply(1:n, function(i){calculate_V_XX_i(x=vects[[i]]$x,W=W[i,k],Gamma_abc2=Gamma_abc2,p=p,i=i)}) 
#                         V_X <- lapply(1:n, function(i){calculate_V_X_i(x=vects[[i]]$x,W=W[i,k],Gamma_abc=Gamma_abc,p=p,i=i)})
#                         V_X_cd <- lapply(1:n, function(i){calculate_V_X_cd(x=vects[[i]]$x,W=W[i,k],Gamma_abcd=Gamma_abcd,p=p,i=i) })
# 

## V_X_i (6.38)
calculate_V_X_i <- function(x,W,Gamma_abc,p,i)
{
        C_m_p <- choose(p,0:p)
        minus_m <- (-1)^(0:p)
        x_p_m <- sapply(p:0,function(k){x^k})
        V_X_i <- matrix(0,length(x),p+1)
        for (j in 0:p)
        {
                if (j==0)
                {
                        V_X_i[,j+1] <- 0
                } else if (j==1) {
                        V_X_i[,j+1] <- 0
                } else {
                        V_X_i[,j+1] <- W* sum(minus_m[1:(j+1)]*Gamma_abc[[j+1]][i,]*x_p_m[,1:(j+1)]*C_m_p[1:(j+1)])
                }
        }
        return(V_X_i)
}

## V_X_cd
calculate_V_X_cd <- function(x,W,Gamma_abcd, p,i)
{
        C_m_p <- choose(p,0:p)
        minus_m <- (-1)^(0:p)
        x_p_m <- sapply(p:0,function(k){x^(k)})
        V_X_cd <- sapply(0:p,function(j){W*sum(minus_m[1:(j+1)]*C_m_p[1:(j+1)]*Gamma_abcd[[j+1]][i,]*x_p_m[,1:(j+1)])})

        return(V_X_cd)
}

## V_XX_i
calculate_V_XX_i <- function(x,W,Gamma_abc2,p,i)
{
        C_m <- lapply(0:(2*p),function(j){choose(j,0:j)})
        minus_m <- lapply(0:(2*p),function(j){(-1)^(0:j)})
        #x_p_m <- lapply(0:(2*p),function(j){sapply(j:0,function(k){x^k})})
        x_p_m <- sapply(0:(2*p),function(j){x^j})

        V_XX_i <- matrix(0,nrow=p+1,ncol=p+1)
        for (j in 0:(2*p))
        {
                if (j==0)
                {
                        V_XX_i[1,1] <- 0
                } else if (j==1) {
                        V_XX_i[1,2] <- 0
                        V_XX_i[2,1] <- 0
                } else {
                        vxx <- W*sum(minus_m[[j+1]]*C_m[[j+1]][1:(j+1)]*Gamma_abc2[[j+1]][i,]*x_p_m[,(j+1):1]) ## To complete
                        
                                     for (n_row in 1:min(j+1,p+1))
                                     {
                                             #print(paste0("n_row=",n_row))
                                             n_col <- j+2-n_row
                                             #print(paste0("n_col=",n_col))
                                             if (n_col<=(p+1))
                                                     V_XX_i[n_row,n_col] <- vxx
                                     }
                }
        }

        return(V_XX_i)
}



## Log posterior
log_posterior_y_i <- function(a,b,y_i,x_i,Beta,sigma,r,s,u,v,p)
{
        n_i <- length(x_i)
        Ksi <- calculate_regression_matrix(x_i, a=a,b=b,p=p+1)
        U_k_i_k <- u^2 * Ksi %*% Beta %*% t(Beta) %*% t(Ksi) + sigma^2 * diag(n_i)
        V_k_i_k <- v^2 * matrix(1,n_i,n_i) + sigma^2 * diag(n_i)
        Vect <- t(y_i - Ksi%*% Beta )%*%solve(U_k_i_k + V_k_i_k - sigma^2 * diag(n_i))%*% (y_i - Ksi%*% Beta) 
        return( Vect + (a-1)^2/(r^2) + b^2/(s^2) )
}

proj_PDC <- function(V) # proj on the PSD cone when V is symmetric
{
        tmp <- eigen(V)
        if (any(tmp$values<0))
        { 
                print('V was not PSD replacing with closest PSD matrix')
        }
        New_eigen <- (abs(tmp$values) + (tmp$values)) /2 +0.001 # max(eigen+0.001,0.001) ## little bias to have strictly positive matrix

        init <- 0
        for (k in 1:nrow(V))
        {
                init <- init + New_eigen[k] * tmp$vectors[,k] %*% t(tmp$vectors[,k])
        }

        return(init)
}

proj_PDC_gaffney <- function(V,max_counter = 5) # Transform V into PSD matrix using gaffney method
{
        tmp <- eigen(V)
        counter <- 0
        if (any(tmp$values<0)|(counter<=max_counter))
        { 
                counter <- counter + 1
                tmp <- eigen(V)
                diag(V) <- 1.25*diag(V)
        }

        output <- NULL
        if (any(tmp$values<0)) {
                output$keep <- F
        } else {
                output$keep <- T
        }
                
        output$V <- V
        return(output)
}





#############################################################################################################################################################################################################
joint_prob_curvclust_align <- function(vects, p, nclusts, regression_method="polynomial", MC_runs=150, Thresh=1e-5)
{
        require(MASS)
        # vects is a list of n n_ix2 matrices. vects[[i]]$x is the vector of covariates (i.e time or position) and vects[[i]]$y is the vector of output (can be in D-dimension but here we have D=1).
        # p  is the dimension of the regression
        # nclusts is the number of clusters
        # Thresh is the threshold for the EM-algorithm
        n <- length(vects)
        n_i <- vapply(vects,nrow,1) # length of i-th sample

        # Likelihood
        Lhood <- -Inf

        #### Hidden parameters
        # cluster membership
        W <- matrix(1/nclusts,nrow=n,ncol=nclusts)

        # alpha_k
        alpha <- rep(1/nclusts,nclusts)
        
        # Noise
        Sigma <- rep(1,nclusts)

        # Transformation priors
        r <- rep(1,nclusts)
        s <- rep(1,nclusts)
        u <- rep(1,nclusts)
        v <- rep(1,nclusts)

        ## Observed parameters
        # Time Transformation
        a_hat <- matrix(1,nrow=n,ncol=nclusts)
        b_hat <- matrix(0,nrow=n,ncol=nclusts)

        V_a <- matrix(1,nrow=n,ncol=nclusts)
        V_b <- matrix(1,nrow=n,ncol=nclusts)
        V_a_b <- matrix(0,nrow=n,ncol=nclusts)

        # Space Transformation
        c_hat <- matrix(1,nrow=n,ncol=nclusts)
        d_hat <- matrix(0,nrow=n,ncol=nclusts)

        V_c <- matrix(1,nrow=n,ncol=nclusts)
        V_d <- matrix(1,nrow=n,ncol=nclusts)
        V_c_d <- matrix(0,nrow=n,ncol=nclusts)

        # Crossed variances
        V_a_c <- matrix(0,nrow=n,ncol=nclusts)
        V_a_d <- matrix(0,nrow=n,ncol=nclusts)
        V_b_c <- matrix(0,nrow=n,ncol=nclusts)
        V_b_d <- matrix(0,nrow=n,ncol=nclusts)

        # Beta : Careful when initializing Beta if its too far the Lhood
        # Let's initialize Beta with the solution of the regression problems for i=1,11,21,31 (corresponding to the 4 modes)
        Beta <- matrix(0,nrow=p+1,ncol=nclusts)
        for (k in 1:nclusts)
        {
                sample_model <-(k-1)*n/nclusts+1 ## i = 1 11 21 31
                Ksi_i <-  calculate_regression_matrix(vects[[sample_model]]$x,p=p+1,a=a_hat[sample_model,k],b=b_hat[sample_model,k],method=regression_method)
                Beta[,k] <- solve(t(Ksi_i)%*%(Ksi_i))%*%t(Ksi_i)%*% vects[[sample_model]]$y
        }

        # Calculate Likelihood for initial condition : 
        SumLhood <- matrix(0,n,nclusts)
        for (i in 1:n)
        {
                for (k in 1:nclusts)
                {
                        a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2)))
                        Xhat <- lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})
                        U_k_i_k <- lapply(1:MC_runs,function(m){u[k]^2 * Xhat[[m]] %*% Beta[,k] %*% t(Beta[,k]) %*% t(Xhat[[m]]) + Sigma[k]^2 * diag(n_i[i])})
                        V_k_i_k <- lapply(1:MC_runs,function(m){v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])})

                        p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^(n_i[i]) *det(U_k_i_k[[m]] + V_k_i_k[[m]] - Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(U_k_i_k[[m]] + V_k_i_k[[m]] - Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})


                        p_k <- sum(p_k_sum)/MC_runs

                        SumLhood[i,k] <- alpha[k] * p_k 
                }
        }
        NewLhood <- sum(log(apply(SumLhood,1,sum)))

        ## EM Algorithm
        while (abs(Lhood-NewLhood)>Thresh) {#||(is.na(abs(Lhood-NewLhood)))
                Lhood <- NewLhood
                print(paste0('NewLhood=',Lhood))

                # E-step
                print("E-step.....")
                for (i in 1:n){
                        for (k in 1:nclusts)
                        {
                                ## 1) Estimate a and b 
                                # a) mean with Nelder-Mead
                                res <- optim(c(1,0),function(a_b){ log_posterior_y_i(a_b[1],a_b[2],vects[[i]]$y,vects[[i]]$x,Beta[,k],Sigma[k],r[k],s[k],u[k],v[k],p)})
                                a_hat[i,k] <- res$par[1]
                                b_hat[i,k] <- res$par[2]

                                ## 2) Estimate c and d
                                Ksi_i <- calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)

                                U_k_i_k <- u[k]^2 * Ksi_i %*% Beta[,k] %*% t(Beta[,k]) %*% t(Ksi_i) + Sigma[k]^2 * diag(n_i[i])
                                V_k_i_k <- v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])

                                V_c_i_k <- as.numeric(1/( t(Beta[,k]) %*% t(Ksi_i) %*% solve(V_k_i_k) %*% Ksi_i %*% Beta[,k] + 1/u[k]^2))
                                V_d_i_k <- as.numeric(1/( t(rep(1,n_i[i])) %*% solve(U_k_i_k) %*% rep(1,n_i[i]) + 1/v[k]^2))
                                lambda <- solve(u[k]^2 *t(Beta[,k]) %*% t(Ksi_i) %*%Ksi_i %*% Beta[,k] + Sigma[k]^2) /(n_i[i]*v[k]^2 + Sigma[k]^2)
                                V_c_d_i_k <- as.numeric(- u[k] * v[k] * sqrt(lambda* V_c_i_k * V_d_i_k) * t(rep(1,n_i[i])) %*% Ksi_i %*% Beta[,k])

                                c_hat[i,k] <-V_c_i_k * as.numeric(( t(Beta[,k]) %*% t(Ksi_i) %*% solve(V_k_i_k) %*% vects[[i]]$y +1/u[k]^2))
                                d_hat[i,k] <- V_d_i_k * as.numeric(t(vects[[i]]$y - Ksi_i %*% Beta[,k]) %*% solve(U_k_i_k) %*% rep(1,n_i[i]))

                                ## 2.bis) Estimate c and d using gaffney
                                #Ksi_i <- calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)
                                #Ksi_Beta <- Ksi_i %*% Beta[,k]
                                #BetaKsiKsiBeta <- as.numeric(t(Ksi_Beta) %*% Ksi_Beta)

                                #siR <- apply(diag(n_i[i]) / Sigma[k]^2 - Ksi_Beta %*% t(Ksi_Beta) / (Sigma[k]^4/u[k]^2 + Sigma[k]^2 * BetaKsiKsiBeta),1,sum)
                                #iS <- diag(n_i[i])/ Sigma[k]^2 - 1/(n_i[i] * Sigma[k]^2 + Sigma[k]^4/v[k]^2)
                                #MuXiS <- t(Ksi_Beta) %*% iS
                                #Ve <- as.numeric(u[k]^2/( u[k]^2 * MuXiS %*% Ksi_Beta + 1))
                                #Vf <- as.numeric(v[k]^2/( v[k]^2 *sum(siR) +1))
                                #Ee <- as.numeric(Ve*(MuXiS %*% vects[[i]]$y + 1/u[k]^2))
                                #Ef <- as.numeric(Vf*siR %*%(vects[[i]]$y - Ksi_Beta))


                                # 3) Variance with Inverse information
                                Dx <- rep(1,n_i[i]) %*% t(0:p); # n_i x p+1
                                Dx[,3:(p+1)] <- Dx[,3:(p+1)] * Ksi_i[ , 2:p]  # n_i x p+1
                                D2x <- rep(1,n_i[i]) %*% t(c(0,0,2:p)) # n_i x p+1
                                D2x[,3:(p+1)] <- D2x[,3:(p+1)] * Dx[,2:p] # n_i x p+1

                                ####
                                Beta_c <- Beta[,k] * c_hat[i,k] # p+1 x 1
                                d_est <- rep(1,n_i[i]) * d_hat[i,k] # n_i x 1

                                ####
                                Ksi_beta <- Ksi_i %*% Beta[,k] # nix1
                                Dx_beta <- Dx %*% Beta[,k]; # nix1
                                Dx_beta_x <- Dx_beta * vects[[i]]$x # nix1
                                Dx_Beta <- Dx %*% Beta_c # nix1
                                Dx_Beta_x <- Dx_Beta * vects[[i]]$x # nix1
                                D2x_Beta <- D2x %*% Beta_c # nix1
                                D2x_Beta_x <- D2x_Beta * vects[[i]]$x
                                D2x_Beta_x2 <- D2x_Beta_x * vects[[i]]$x
                                Y_x_Beta <- vects[[i]]$y - Ksi_i %*% Beta_c - d_est

                                # a) Inverse information
                                Ia <- sum(Y_x_Beta * D2x_Beta_x2) / Sigma[k]^2 - sum(Dx_Beta_x^2)/Sigma[k]^2 - 1/r[k]^2;
                                Ib <- sum(Y_x_Beta * D2x_Beta) /Sigma[k]^2 - sum( Dx_Beta^2 )/Sigma[k]^2 - 1/s[k]^2;
                                Iab <- - sum(Y_x_Beta * D2x_Beta_x)/ Sigma[k]^2 + sum(Dx_Beta *Dx_Beta_x)/Sigma[k]^2 ;
                                Iac <- (sum(as.vector(Y_x_Beta) * Dx_beta_x) - sum(Ksi_beta * Dx_Beta_x))/Sigma[k]^2 ;
                                Ibc <- - (sum(as.vector(Y_x_Beta) * Dx_beta) -sum(as.vector(Ksi_beta) * Dx_beta))/Sigma[k]^2;
                                Iad <- - sum(Dx_Beta_x)/Sigma[k]^2 ;
                                Ibd <- sum(Dx_Beta)/Sigma[k]^2;
                                Ic <- - sum(Ksi_beta^2)/Sigma[k]^2 - 1/u[k]^2;
                                Id <- - n_i[i]/Sigma[k]^2 - 1/v[k]^2;
                                Icd <- - sum(Ksi_beta)/Sigma[k]^2;

                                # b) Variance is the inverse of the negative information
                                V <- diag(c(Ia,Ib,Ic,Id))
                                V[1,2] <- Iab; V[2,1] <- Iab
                                V[1,3] <- Iac; V[3,1] <- Iac
                                V[1,4] <- Iad; V[4,1] <- Iad
                                V[2,3] <- Ibc; V[3,2] <- Ibc
                                V[2,4] <- Ibd; V[4,2] <- Ibd
                                V[3,4] <- Icd; V[4,3] <- Icd

                                V_inv <- solve(-V) #

                                V_a[i,k] <- V_inv[1,1];
                                V_b[i,k] <- V_inv[2,2];
                                V_c[i,k] <- V_inv[3,3];
                                V_d[i,k] <- V_inv[4,4];

                                ## Verify that no value is negative
                                if (V_a[i,k]<0)
                                {
                                        print(paste0('V_a is negative for i=',i,' and for k=',k))
                                        V_a[i,k] <- abs(V_inv[1,1]);
                                }
                                if (V_b[i,k]<0)
                                {
                                        print(paste0('V_b is negative for i=',i,' and for k=',k))
                                        V_b[i,k] <- abs(V_inv[2,2]);
                                }
                                if (V_c[i,k]<0)
                                {
                                        print(paste0('V_c is negative for i=',i,' and for k=',k))
                                        V_c[i,k] <- abs(V_inv[3,3]);
                                }
                                if (V_d[i,k]<0)
                                {
                                        print(paste0('V_d is negative for i=',i,' and for k=',k))
                                        V_d[i,k] <- abs(V_inv[4,4]);
                                }
                                
                                V_a_b[i,k] <- V_inv[1,2];
                                V_a_c[i,k] <- V_inv[1,3];
                                V_a_d[i,k] <- V_inv[1,4];
                                V_b_c[i,k] <- V_inv[2,3];
                                V_b_d[i,k] <- V_inv[2,4];
                                V_c_d[i,k] <- V_inv[3,4];

                                # Need to calculate the joint probability

                                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2))) ## should we take mu = c(a_hat,b_hat)?
                                Xhat <-  lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})
                                U_k_i_k <- lapply(1:MC_runs,function(m){u[k]^2 * Xhat[[m]] %*% Beta[,k] %*% t(Beta[,k]) %*% t(Xhat[[m]]) + Sigma[k]^2 * diag(n_i[i])})
                                V_k_i_k <- lapply(1:MC_runs,function(m){v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])})
                                p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^n_i[i] * det(U_k_i_k[[m]] + V_k_i_k[[m]] - Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(U_k_i_k[[m]] + V_k_i_k[[m]] - Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})
                                p_k <- sum(p_k_sum)/MC_runs

                                ## Using Gaffney
                                #XMu <- lapply(1:MC_runs,function(m){Xhat[[m]] %*% Beta[,k]})
                                #iR <- lapply(1:MC_runs,function(m){ diag(n_i[i])/Sigma[k]^2 - XMu[[m]] %*% t(XMu[[m]]) / ( Sigma[k]^4/u[k]^2 + Sigma[k]^2 *as.numeric( t(XMu[[m]]) %*% XMu[[m]]) ) })
                                #siR <- lapply(1:MC_runs,function(m){apply(iR[[m]],1,sum)})
                                #siR2 <- lapply(1:MC_runs,function(m){apply(iR[[m]],2,sum)})
                                #sum_siR <- lapply(1:MC_runs,function(m){sum(siR[[m]])})
                                #iV <- lapply(1:MC_runs, function(m){ iR[[m]] - siR2[[m]] %*% t(siR[[m]]) /(1/v[k]^2 + sum_siR[[m]])})
                                #p_k_sum_gaffney <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^n_i[i] * 1/det(iV[[m]]) ) * exp(-1/2 * t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%iV[[m]]%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]))})
                                #p_k_gaffney <- sum(p_k_sum_gaffney)/MC_runs
                                             
                                ## 5) Cluster Membership : only proportional ! normalization comes after
                                W[i,k] <- alpha[k] * p_k

                        }
                }

                ## Then normalize W
                if (any(apply(W,1,sum)==0)) {
                        print("one of the cluster is empty")
                } else {
                        W <- W/apply(W,1,sum)
                }

                # M-step : maximization of the Q-function
                print("M-step.....")
                for (k in 1:nclusts)
                {
                        print(paste0('      k=',k))
                        ## Calculating alpha 
                        alpha[k] <- 1/n*sum(W[,k])

                        ## Calculating r, s, u and v
                        r[k] <- sqrt(sum(W[,k] * ((a_hat[,k]-1)^2 + V_a[,k]))/sum(W[,k]))
                        s[k] <- sqrt(sum(W[,k] * (b_hat[,k]^2 + V_b[,k]))/sum(W[,k]))
                        u[k] <- sqrt(sum(W[,k] * ((c_hat[,k]-1)^2 + V_c[,k]))/sum(W[,k]))
                        v[k] <- sqrt(sum(W[,k] * (d_hat[,k]^2 + V_d[,k]))/sum(W[,k]))

                        ## Calculate runs
                        a_runs <- matrix(0,n, MC_runs)
                        b_runs <- matrix(0,n, MC_runs)
                        c_runs <- matrix(0,n, MC_runs)
                        d_runs <- matrix(0,n, MC_runs)

                        ## Initialization

                        ## run a,b,c,d to calculate the moments
                        for (i in 1:n)
                        {
                                print(i)
                                ## Cov Matrix
                                V <- matrix ( c( V_a[i,k]       , V_a_b[i,k]    , V_a_c[i,k]    , V_a_d[i,k],
                                                 V_a_b[i,k]     , V_b[i,k]      , V_b_c[i,k]    , V_b_d[i,k],
                                                 V_a_c[i,k]     , V_b_c[i,k]    , V_c[i,k]      , V_c_d[i,k],
                                                 V_a_d[i,k]     , V_b_d[i,k]    , V_c_d[i,k]    , V_d[i,k]  ) , 
                                             nrow=4,ncol=4,byrow=T)
                                
                                # Make sure V is PD
                                output <- proj_PDC_gaffney(V) ## proj on the SDP cone

                                ## Set up sampling to estimate cov(a^(p-i),b^i) cov(a^(p-i)*b^i,e^{1|2}) and cov(a^(p-i)*b^i*e,f)
                                V_est <- output$V
                                keep <- output$keep

                                if (output$keep)
                                {
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k],c_hat[i,k],d_hat[i,k]) , Sigma=V_est) ## Careful with tolerance????
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                        c_runs[i,] <- matrix_runs[,3]
                                        d_runs[i,] <- matrix_runs[,4]
                                } else {
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k],c_hat[i,k],d_hat[i,k]) , Sigma=diag(diag(V_est))) ## Careful with tolerance????
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                        c_runs[i,] <- matrix_runs[,3]
                                        d_runs[i,] <- matrix_runs[,4]
                                }
                        }

                        ## Estimating the covariances
                        Cov_a_b <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m),b_runs[i,]^m)})})}) # Cov_a_b[[j+1]] is the matrix of size nx(j+1) that contains all the cov(a_i^(j-r),b_i^r) for r in 0:j
                        Cov_ab_c <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m)*b_runs[i,]^m,c_runs[i,])})})})
                        Cov_ab_c2 <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m)*b_runs[i,]^m,c_runs[i,]^2)})})})
                        Cov_abc_d <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m)*b_runs[i,]^m*c_runs[i,],d_runs[i,])})})})

                        ## Estimating the gammas with the covariances
                        gamma_m_b <- sapply(0:(2*p), function(j){calculate_gamma_m_z(b_hat[,k],V_b[,k],j)}) # gamma_m_b[i,j+1] is gamma_j_(b_i) 
                        gamma_m_a <- sapply(0:(2*p), function(j){calculate_gamma_m_z(a_hat[,k],V_a[,k],j)})
                        ## dim(Gamma_ab[[j+1]])= nx(j+1) and  contains all the Gamma_i_m_j for m in 0:j  
                        Gamma_ab <- lapply(0:(2*p), function(j){sapply(j:0,function(k_i){a_hat[,k]^k_i}) * gamma_m_b[,1:(j+1)] + sapply(0:j,function(k_i){b_hat[,k]^k_i}) * gamma_m_a[,(j+1):1] + gamma_m_a[,(j+1):1] * gamma_m_b[,1:(j+1)] + Cov_a_b[[j+1]]})
                        Gamma_abc <- lapply(0:(2*p), function(j){Gamma_ab[[j+1]] * c_hat[,k] + Cov_ab_c[[j+1]]})
                        Gamma_abcd <- lapply(0:(2*p), function(j){Gamma_abc[[j+1]] * d_hat[,k] + Cov_abc_d[[j+1]]})
                        Gamma_abc2 <- lapply(0:(2*p), function(j){Gamma_ab[[j+1]] * (V_c[,k] + c_hat[,k]^2) + sapply(j:0,function(k_i){a_hat[,k]^k_i}) * sapply(0:j,function(k_i){b_hat[,k]^k_i}) * V_c[,k] + Cov_ab_c2[[j+1]] })

                        ## Estimating V_XX_i, V_X_i, V_X_cd
                        V_XX <- lapply(1:n, function(i){calculate_V_XX_i(x=vects[[i]]$x,W=W[i,k],Gamma_abc2=Gamma_abc2,p=p,i=i)}) 
                        V_X <- lapply(1:n, function(i){calculate_V_X_i(x=vects[[i]]$x,W=W[i,k],Gamma_abc=Gamma_abc,p=p,i=i)})
                        V_X_cd <- lapply(1:n, function(i){calculate_V_X_cd(x=vects[[i]]$x,W=W[i,k],Gamma_abcd=Gamma_abcd,p=p,i=i) })

                        ## Ksi_mat
                        Ksi_mat <- lapply( 1:n, function(i){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)})

                        ## Calculating Beta: Beta[,k] = (sum_{i=1}^n  c_i_k^2 * W_i_k * Ksi_i' * Ksi_i + V_XX_i)^(-1) * (sum_{i=1}^n  W_i_k *c_i_k * Ksi_i' * (y_i - d_i_k) + V_X_i' * y_i - V_X_cd )
                        Beta_vec <- Reduce('+',lapply(1:n, function(i){W[i,k]*c_hat[i,k]^2 *  t(Ksi_mat[[i]])%*%Ksi_mat[[i]] + V_XX[[i]]}))
                        Beta[,k] <- solve(Beta_vec) %*% Reduce('+',lapply(1:n, function(i){W[i,k]* c_hat[i,k] * t(Ksi_mat[[i]])%*%  (vects[[i]]$y - d_hat[i,k]) + t(V_X[[i]]) %*% vects[[i]]$y - V_X_cd[[i]]} ) )


                        ## Calculating Sigma: Sigma[k] = sqrt( sum_{i=1}^n W_i_k* (||y_i - c_i_k * Ksi_i * Beta_k - d_i_k||^2 - 2* y_i' * V_X_i * Beta_k + Beta_k' * V_XX_i *Beta_k + 2* Beta_k' * V_X_cd + n_i * V_d_i_k) / sum(W[i,k]*n_i) )
                        Sigma_test <- sum(sapply(1:n, function(i){ W[i,k]* ( norm(vects[[i]]$y - c_hat[i,k] * Ksi_mat[[i]] %*% Beta [,k] - d_hat[i,k],"2")^2 - as.numeric(2* t(vects[[i]]$y) %*% V_X[[i]] %*% Beta[,k]) + as.numeric(t(Beta[,k]) %*% V_XX[[i]] %*% Beta[,k]) + as.numeric(2 * t(Beta[,k]) %*% V_X_cd[[i]] ) + n_i[i] * V_d[i,k] )})) / sum(W[,k]*n_i)
                        if (Sigma_test<=0)
                        {
                                print("Sigma was negative, replaced with small value?")
                                print(paste0('Sigma =',Sigma_test))
                                #                                 Sigma[k] <- sqrt(abs(Sigma_test))
                                Sigma[k] <- 10^-5
                        } else {
                                Sigma[k] <- sqrt(Sigma_test) 
                        }

                }

                ## 3) Calculate the New Likelihood
                print('Calculating New Likelihood...')
                SumLhood <- matrix(0,n,nclusts)
                for (i in 1:n)
                {
                        for (k in 1:nclusts)
                        {
                                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2)))
                                #a_b_run <- mvrnorm(MC_runs,mu=c(a_hat[i,k],b_hat[i,k]),Sigma=diag(c(r[k]^2,s[k]^2)))
                                Xhat <-  lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})
                                U_k_i_k <- lapply(1:MC_runs,function(m){u[k]^2 * Xhat[[m]] %*% Beta[,k] %*% t(Beta[,k]) %*% t(Xhat[[m]]) + Sigma[k]^2 * diag(n_i[i])})
                                V_k_i_k <- lapply(1:MC_runs,function(m){v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])})

                                ## Make a test if (U_k_i_k+V_k_i_k - Sigma[k]^2) is non invertible
                                p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^(n_i[i])*det(U_k_i_k[[m]] + V_k_i_k[[m]] - Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(U_k_i_k[[m]] + V_k_i_k[[m]] - Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})

                                p_k <- sum(p_k_sum)/MC_runs
                                SumLhood[i,k] <- alpha[k] * p_k 

                        }

                }
                NewLhood <- sum(log(apply(SumLhood,1,sum)))

        }

        output <- NULL
        output$Beta <- Beta
        output$Sigma <- Sigma
        output$Lhood <- NewLhood
        output$alpha <- alpha
        output$W <- W
        output$Z <- apply(W,1,which.max)
        output$a <- a_hat
        output$b <- b_hat
        output$c <- c_hat
        output$d <- d_hat

        return(output)
}


initialize_Mstep <- function(W,V)
{
        print("Initialize M-step.....")
        output <- NULL
                for (k in 1:nclusts)
                {
                        
                        print(paste0('      k=',k))
                        ## Calculating alpha 
                        output$alpha[k] <- 1/n*sum(W[,k])

                        ## Calculating r, s, u and v
                        output$r[k] <- sqrt(sum(W[,k] * ((a_hat[,k]-1)^2 + V_a[,k]))/sum(W[,k]))
                        output$s[k] <- sqrt(sum(W[,k] * (b_hat[,k]^2 + V_b[,k]))/sum(W[,k]))
                        output$u[k] <- sqrt(sum(W[,k] * ((c_hat[,k]-1)^2 + V_c[,k]))/sum(W[,k]))
                        output$v[k] <- sqrt(sum(W[,k] * (d_hat[,k]^2 + V_d[,k]))/sum(W[,k]))

                        ## Calculate runs
                        a_runs <- matrix(0,n, MC_runs)
                        b_runs <- matrix(0,n, MC_runs)
                        c_runs <- matrix(0,n, MC_runs)
                        d_runs <- matrix(0,n, MC_runs)

                        ## Initialization

                        ## run a,b,c,d to calculate the moments
                        for (i in 1:n)
                        {
                                print(i)
                                ## Cov Matrix
                                V <- matrix ( c( V_a[i,k]       , V_a_b[i,k]    , V_a_c[i,k]    , V_a_d[i,k],
                                                 V_a_b[i,k]     , V_b[i,k]      , V_b_c[i,k]    , V_b_d[i,k],
                                                 V_a_c[i,k]     , V_b_c[i,k]    , V_c[i,k]      , V_c_d[i,k],
                                                 V_a_d[i,k]     , V_b_d[i,k]    , V_c_d[i,k]    , V_d[i,k]  ) , 
                                             nrow=4,ncol=4,byrow=T)
                                
                                # Make sure V is PD
                                output <- proj_PDC_gaffney(V) ## proj on the SDP cone

                                ## Set up sampling to estimate cov(a^(p-i),b^i) cov(a^(p-i)*b^i,e^{1|2}) and cov(a^(p-i)*b^i*e,f)
                                V_est <- output$V
                                keep <- output$keep

                                if (output$keep)
                                {
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k],c_hat[i,k],d_hat[i,k]) , Sigma=V_est) ## Careful with tolerance????
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                        c_runs[i,] <- matrix_runs[,3]
                                        d_runs[i,] <- matrix_runs[,4]
                                } else {
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k],c_hat[i,k],d_hat[i,k]) , Sigma=diag(diag(V_est))) ## Careful with tolerance????
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                        c_runs[i,] <- matrix_runs[,3]
                                        d_runs[i,] <- matrix_runs[,4]
                                }
                        }

                        ## Estimating the covariances
                        Cov_a_b <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m),b_runs[i,]^m)})})}) # Cov_a_b[[j+1]] is the matrix of size nx(j+1) that contains all the cov(a_i^(j-r),b_i^r) for r in 0:j
                        Cov_ab_c <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m)*b_runs[i,]^m,c_runs[i,])})})})
                        Cov_ab_c2 <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m)*b_runs[i,]^m,c_runs[i,]^2)})})})
                        Cov_abc_d <- lapply(0:(2*p),function(j){sapply(0:j, function(m){sapply(1:n,function(i){cov(a_runs[i,]^(j-m)*b_runs[i,]^m*c_runs[i,],d_runs[i,])})})})

                        ## Estimating the gammas with the covariances
                        gamma_m_b <- sapply(0:(2*p), function(j){calculate_gamma_m_z(b_hat[,k],V_b[,k],j)}) # gamma_m_b[i,j+1] is gamma_j_(b_i) 
                        gamma_m_a <- sapply(0:(2*p), function(j){calculate_gamma_m_z(a_hat[,k],V_a[,k],j)})
                        ## dim(Gamma_ab[[j+1]])= nx(j+1) and  contains all the Gamma_i_m_j for m in 0:j  
                        Gamma_ab <- lapply(0:(2*p), function(j){sapply(j:0,function(k_i){a_hat[,k]^k_i}) * gamma_m_b[,1:(j+1)] + sapply(0:j,function(k_i){b_hat[,k]^k_i}) * gamma_m_a[,(j+1):1] + gamma_m_a[,(j+1):1] * gamma_m_b[,1:(j+1)] + Cov_a_b[[j+1]]})
                        Gamma_abc <- lapply(0:(2*p), function(j){Gamma_ab[[j+1]] * c_hat[,k] + Cov_ab_c[[j+1]]})
                        Gamma_abcd <- lapply(0:(2*p), function(j){Gamma_abc[[j+1]] * d_hat[,k] + Cov_abc_d[[j+1]]})
                        Gamma_abc2 <- lapply(0:(2*p), function(j){Gamma_ab[[j+1]] * (V_c[,k] + c_hat[,k]^2) + sapply(j:0,function(k_i){a_hat[,k]^k_i}) * sapply(0:j,function(k_i){b_hat[,k]^k_i}) * V_c[,k] + Cov_ab_c2[[j+1]] })

                        ## Estimating V_XX_i, V_X_i, V_X_cd
                        V_XX <- lapply(1:n, function(i){calculate_V_XX_i(x=vects[[i]]$x,W=W[i,k],Gamma_abc2=Gamma_abc2,p=p,i=i)}) 
                        V_X <- lapply(1:n, function(i){calculate_V_X_i(x=vects[[i]]$x,W=W[i,k],Gamma_abc=Gamma_abc,p=p,i=i)})
                        V_X_cd <- lapply(1:n, function(i){calculate_V_X_cd(x=vects[[i]]$x,W=W[i,k],Gamma_abcd=Gamma_abcd,p=p,i=i) })

                        ## Ksi_mat
                        Ksi_mat <- lapply( 1:n, function(i){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)})

                        ## Calculating Beta: Beta[,k] = (sum_{i=1}^n  c_i_k^2 * W_i_k * Ksi_i' * Ksi_i + V_XX_i)^(-1) * (sum_{i=1}^n  W_i_k *c_i_k * Ksi_i' * (y_i - d_i_k) + V_X_i' * y_i - V_X_cd )
                        Beta_vec <- Reduce('+',lapply(1:n, function(i){W[i,k]*c_hat[i,k]^2 *  t(Ksi_mat[[i]])%*%Ksi_mat[[i]] + V_XX[[i]]}))
                        Beta[,k] <- solve(Beta_vec) %*% Reduce('+',lapply(1:n, function(i){W[i,k]* c_hat[i,k] * t(Ksi_mat[[i]])%*%  (vects[[i]]$y - d_hat[i,k]) + t(V_X[[i]]) %*% vects[[i]]$y - V_X_cd[[i]]} ) )


                        ## Calculating Sigma: Sigma[k] = sqrt( sum_{i=1}^n W_i_k* (||y_i - c_i_k * Ksi_i * Beta_k - d_i_k||^2 - 2* y_i' * V_X_i * Beta_k + Beta_k' * V_XX_i *Beta_k + 2* Beta_k' * V_X_cd + n_i * V_d_i_k) / sum(W[i,k]*n_i) )
                        Sigma_test <- sum(sapply(1:n, function(i){ W[i,k]* ( norm(vects[[i]]$y - c_hat[i,k] * Ksi_mat[[i]] %*% Beta [,k] - d_hat[i,k],"2")^2 - as.numeric(2* t(vects[[i]]$y) %*% V_X[[i]] %*% Beta[,k]) + as.numeric(t(Beta[,k]) %*% V_XX[[i]] %*% Beta[,k]) + as.numeric(2 * t(Beta[,k]) %*% V_X_cd[[i]] ) + n_i[i] * V_d[i,k] )})) / sum(W[,k]*n_i)
                        if (Sigma_test<=0)
                        {
                                print("Sigma was negative, replaced with small value?")
                                print(paste0('Sigma =',Sigma_test))
                                #                                 Sigma[k] <- sqrt(abs(Sigma_test))
                                Sigma[k] <- 10^-5
                        } else {
                                Sigma[k] <- sqrt(Sigma_test) 
                        }

                }

}
