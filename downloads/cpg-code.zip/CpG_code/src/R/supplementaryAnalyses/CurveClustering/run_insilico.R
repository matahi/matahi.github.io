######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
PATH <- "~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R" # for own laptop
# PATH <- "~/Desktop/CpG/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

# Package loading
require('ggplot2')
require('gplots') # heatmap.2
require('dtw')

## Creating Insilico data
nclusts <- 4
n <- 100
min_points <- 10
max_points <- 20
#limits <- c(0,2*pi)
limits <- c(-100,100)
Dat <- vector('list',n)
## Functions 
Func <- vector('list',nclusts)

## Function 1 : a_k*exp(c_k*x + d_k) + b_k
#Func[[1]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){-a*(c*x+d)^2/20+b+sigma}
## Function 2 : a_k_1*(c_k*x + d_k)^2 + b_k
#Func[[2]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){(a*abs(c*x+d)^3+b+sigma)/100}
## Function 3 : a_k*sin(c_k*x + d_k) + b_k
#Func[[3]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*sin(c*x+d)+b+sigma}
## Function 4 : a_k*1/(abs(c_k*x + d_k)+1) + b_k
#Func[[4]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*(c*x+d)^2/20+b+sigma}

# Function 1 : a_k*exp(c_k*x + d_k) + b_k
Func[[1]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){log(1+abs(x))/4+sigma}
# Function 2 : a_k_1*(c_k*x + d_k)^2 + b_k
Func[[2]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*atan(c*x+d)/2+b+sigma}
# Function 3 : a_k*sin(c_k*x + d_k) + b_k
Func[[3]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*sin(x/50+d)+b+sigma}
# Function 4 : a_k*1/(abs(c_k*x + d_k)+1) + b_k
Func[[4]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){(exp(abs(x/50)))/(exp(x/50)+exp(-x/50))+b+sigma}


input <- NULL
input$r <- 1:nclusts/20
input$s <- 1:nclusts/20
input$u <- 1:nclusts/20
input$v <- 1:nclusts/20
input$sigma <- 1:nclusts/100

#input$r <- rep(1,nclusts)/20
#input$s <- rep(1,nclusts)/20
#input$u <- rep(1,nclusts)/20
#input$v <- rep(1,nclusts)/20
#input$sigma <- rep(1,nclusts)/30


input$a <- rep(0,n)
input$b <- rep(0,n)
input$c <- rep(0,n)
input$d <- rep(0,n)

for (i in 1:n)
{
        k <- ceiling(i*nclusts/n)
        sample_size <- sample(min_points:max_points,1)
        sample_x <- sort(runif(sample_size,min=limits[1],max=limits[2]))
        input$a[i] <- rnorm(1,mean=1,sd=input$r[k])
        input$b[i] <- rnorm(1,mean=0,sd=input$s[k])
        input$c[i] <- rnorm(1,mean=1,sd=input$u[k])
        input$d[i] <- rnorm(1,mean=0,sd=input$v[k])
        pos_x <- sample_x
        sample_x <- input$a[i]*sample_x - input$b[i] 
        sample_y <- input$c[i]*Func[[k]](x=pos_x) + input$d[i] + rnorm(sample_size,mean=0,sd=input$sigma[k])
        #sample_y <- input$c[i]*Func[[1]](x=pos_x) + input$d[i] + rnorm(sample_size,mean=0,sd=input$sigma[k])
        Dat[[i]] <- data.frame(x=sample_x,y=sample_y,nsample=i,nclust=k)
}

n_i <- vapply(Dat,nrow,1)
## data.frame
Dat.df <- Reduce(rbind,Dat)

## plot
#pdf('../../results/Curve_Clustering/Simulated_Data/curves_space_time_deformation.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p
#dev.off()


## Time Warping
#Loc <- lapply(1:length(list_big_island), function(x){fData450K[rownames(BRCA.CancerousCGIs.Mean[list_big_island[x]]), "MAPINFO" ]})
distanceMat <- matrix(0,nrow=length(Dat),ncol=length(Dat))
distanceMat.Normalized <- matrix(0,nrow=length(Dat),ncol=length(Dat))

for (k in 1:length(Dat))
{
        #print(k)
        for (l in k:length(Dat))
        {
                #tmp <- dtw(BRCA.CancerousCGIs.Mean[[Dat[k]]],BRCA.CancerousCGIs.Mean[[Dat[l]]])
                tmp <- dtw(Dat[[k]]$y,Dat[[l]]$y, open.end=T , open.begin=T, step=asymmetric,distance.only=T)
                distanceMat[k,l] <- tmp$distance
                distanceMat[l,k] <- tmp$distance
                distanceMat.Normalized[l,k] <- tmp$normalizedDistance 
                distanceMat.Normalized[k,l] <- tmp$normalizedDistance
        }
}

#k <- 1
#l <- 5
#tmp <- dtw(Dat[[k]]$y,Dat[[l]]$y, keep=T, open.end=T , open.begin=T, step=asymmetric)
#
#plot(tmp, type="two", off=1)

## Clustering
dist.Mat <- dist(distanceMat)
clust.res <- hclust(dist.Mat, method="ward")
#pdf('~/Desktop/ClustOpenEnd.pdf')
plot(clust.res)
#dev.off()

distNorm.Mat <- dist(distanceMat.Normalized)
clustNorm.res <- hclust(distNorm.Mat, method="ward")
#pdf('~/Desktop/ClustNormOpenEnd.pdf')
plot(clustNorm.res)
#dev.off()


A <- cutree(clustNorm.res,k=4)

library(ConsensusClusterPlus)

### TO REDO
B <- ConsensusClusterPlus(Dat, maxK=8, innerLinkage= "ward", finalLinkage="ward", distance=DTW,title="~/Desktop/tata",plot="pdf")

#write.table(which(A==1),file="~/Desktop/class1.txt")
#write.table(which(A==2),file="~/Desktop/class2_ClustOpenEnd.txt")
write.table(which(A==2),file="~/Desktop/class2_ClustOpenEnd.txt")


##### Sparse CCA
## Suppose we also have a quantitative outcome, y, and we want to find
## features in x and z that are correlated with each other and with the
## outcome:
#y <- rnorm(nrow(x))
#perm.out <- CCA.permute(x,z,typex="standard",typez="standard",outcome="quantitative",y=y, nperms=6)
#print(perm.out)
#out<-CCA(x,z,typex="standard",typez="standard",outcome="quantitative",y=y,penaltyx=perm.out$bestpenaltyx,penaltyz=perm.out$bestpenaltyz)
#print(out)
#
## now, do CCA with type="ordered"
## Example involving the breast cancer data: gene expression + CGH
#set.seed(22)
#data(breastdata)
#attach(breastdata)
#dna <- t(dna)
#rna <- t(rna)
#perm.out <- CCA.permute(x=rna,z=dna[,chrom==1],typex="standard", typez="ordered",nperms=5,penaltyxs=seq(.02,.7,len=10))
## We run CCA using all gene exp. data, but CGH data on chrom 1 only.
#print(perm.out)
#plot(perm.out)
#out <- CCA(x=rna,z=dna[,chrom==1], typex="standard", typez="ordered",penaltyx=perm.out$bestpenaltyx,
#v=perm.out$v.init, penaltyz=perm.out$bestpenaltyz, xnames=substr(genedesc,1,20),
#znames=paste("Pos", sep="", nuc[chrom==1])) # Save time by inputting  lambda and v
#print(out) # could do print(out,verbose=TRUE)
#print(genechr[out$u!=0]) # Cool! The genes associated w/ gain or loss
## on chrom 1 are located on chrom 1!!
#par(mfrow=c(1,1))
#PlotCGH(out$v, nuc=nuc[chrom==1], chrom=chrom[chrom==1],
#main="Regions of gain/loss on Chrom 1 assoc'd with gene expression")
#
#detach(breastdata)
