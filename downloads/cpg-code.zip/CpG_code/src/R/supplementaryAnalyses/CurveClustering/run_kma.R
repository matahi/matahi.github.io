###############################################################################################
setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R')
library(ggplot2)
library(fdakma)

nclusts <- 3 ## number of clusters
p <- 4

## Functions 
Func <- vector('list',nclusts)

# Function 1 : a_k*exp(c_k*x + d_k) + b_k
Func[[1]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){-a*(c*x+d)^2/20+b+sigma}
# Function 2 : a_k_1*(c_k*x + d_k)^2 + b_k
Func[[2]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){(a*abs(c*x+d)^3+b+sigma)/100}
# Function 3 : a_k*sin(c_k*x + d_k) + b_k
Func[[3]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*sin(c*x+d)+b+sigma}
# Function 4 : a_k*1/(abs(c_k*x + d_k)+1) + b_k
Func[[4]] <- function(x,a=1,b=0,c=1,d=0,sigma=0){a*(c*x+d)^2/20+b+sigma}

## Signals
n <- 30 ## number of signals
max_points <- 100
min_points <- 50
limits <- c(0,2*pi)
Dat <- vector('list',n) 

input <- NULL
input$r <- 1:nclusts/20
input$s <- 1:nclusts/20
input$v <- 1:nclusts/20
input$sigma <- 1:nclusts/30

input$a <- rep(0,n)
input$b <- rep(0,n)
input$d <- rep(0,n)

for (i in 1:n)
{
        k <- ceiling(i*nclusts/n)
        #         sample_size <- sample(min_points:max_points,1)
        sample_size <- min_points
        sample_x <- sort(runif(sample_size,min=limits[1],max=limits[2]))
        input$a[i] <- rnorm(1,mean=1,sd=input$r[k])
        input$b[i] <- rnorm(1,mean=0,sd=input$s[k])
        input$d[i] <- rnorm(1,mean=0,sd=input$v[k])
        pos_x <- sample_x
        sample_x <- input$a[i]*sample_x - input$b[i] 
        sample_y <- Func[[k]](x=pos_x) + input$d[i] + rnorm(sample_size,mean=0,sd=input$sigma[k])
        Dat[[i]] <- data.frame(x=sample_x,y=sample_y,nsample=i,nclust=k)
}

n_i <- vapply(Dat,nrow,1)
## data.frame
Dat.df <- Reduce(rbind,Dat)

## plot
# pdf('../../results/Curve_Clustering/Simulated_Data/curves_space_time_deformation.pdf')
gg_p <- ggplot(Dat.df,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p
# dev.off()

## Real Solution
Dat.RealSol <- Dat.df
for (i in 1:length(input$d))
{
        Dat.RealSol[Dat.RealSol$nsample==i,"x"] <-  (Dat.RealSol[Dat.RealSol$nsample==i,"x"] + input$b[i]) / input$a[i]
        Dat.RealSol[Dat.RealSol$nsample==i,"y"] <-  (Dat.RealSol[Dat.RealSol$nsample==i,"y"] - input$d[i]) 
}
quartz()
gg_p <- ggplot(Dat.RealSol,aes(x=x,y=y))+ geom_line(aes(group=nsample,colour=factor(nclust)))
gg_p



##

Dat_x <- lapply(1:length(Dat),function(i){Dat[[i]]$x})
Dat_y <- lapply(1:length(Dat),function(i){Dat[[i]]$y})

x <- Reduce('rbind',Dat_x)
y0 <- Reduce('rbind',Dat_y)
y1 <- t(apply(y0,1,diff))
x1 <- t(apply(x,1,diff))
y1 <- y1/x1
x <- x[,-ncol(x)]
y0 <- y0[,-ncol(y0)]


matplot(t(x),t(y0) , type='l')
matplot(t(x),t(y1) , type='l')

## On functions
kma_example <- kma (
                    x=x, y0=y0, y1=y1,n.clust = 3, 
                    warping.method = 'affine', 
                    similarity.method = 'd0.pearson',
                    center.method = 'k-means', 
                    )

kma.show.results(kma_example)


## On discrete derivatives
kma_example <- kma (
                    x=x, y0=y0, y1=y1,n.clust = 3, 
                    warping.method = 'affine', 
                    similarity.method = 'd1.pearson',
                    center.method = 'k-means', 
                    )

kma.show.results(kma_example)

