calculate_regression_matrix <- function(x, method="polynomial", a=1,b=0, p )
{
        ## PRM
        if (method=="polynomial")
        {
                require(matrixcalc)
                Ksi <- vandermonde.matrix( a*x - b , p)
                ## SRM
        } else if (method=="spline") {
                ## BSRM
        } else if (method=="Bspline") {
                ## NULL
        } else {
                print('not a valid method')
        }
        return(Ksi)
}


curvclust_space_align <- function(vects, p, nclusts, regression_method="polynomial", Thresh=1e-5,n_iter=20)
{
        # vects is a list of n n_ix2 matrices. vects[[i]]$x is the vector of covariates (i.e time or position) and vects[[i]]$y is the vector of output (can be in D-dimension but here we have D=1).
        # p  is the dimension of the regression
        # nclusts is the number of clusters
        # Thresh is the threshold for the EM-algorithm
        n <- length(vects)
        n_i <- vapply(vects,nrow,1) # length of i-th sample

        # Likelihood
        Lhood <- -Inf

        # Hidden parameters
        # cluster membership
        W <- matrix(1/nclusts,nrow=n,ncol=nclusts)

        # alpha_k
        alpha <- rep(1/nclusts,nclusts)
        
        # Noise
        Sigma <- rep(1,nclusts)

        # Transformation priors
        u <- rep(1,nclusts)
        v <- rep(1,nclusts)

        # Observed parameters
        # Transformation
        c_hat <- matrix(1,nrow=n,ncol=nclusts)
        d_hat <- matrix(0,nrow=n,ncol=nclusts)

        V_c <- matrix(1,nrow=n,ncol=nclusts)
        V_d <- matrix(1,nrow=n,ncol=nclusts)
        V_c_d <- matrix(0,nrow=n,ncol=nclusts)

        U_k <- vector('list',n)
        V_k <- vector('list',n)

        for (i in 1:n)
        {
                U_k[[i]] <- vector('list',nclusts)
                V_k[[i]] <- vector('list',nclusts)
        }

        # Noise
        Epsilon <- vector('list',n)
        V_Epsilon <- vector('list',n)

        for (i in 1:n)
        {
                Epsilon[[i]] <- matrix(0,n_i[i],nclusts)
                V_Epsilon[[i]] <- vector('list',nclusts)
                for (k in 1:nclusts)
                {
                        V_Epsilon[[i]][[k]] <- matrix(0,n_i[i],n_i[i])
                }
        }

        # Beta : Careful when initializing Beta
        # Let's initialize Beta with the solution of the regression problems for i=1,11,21,31 (corresponding to the 4 modes)
        Beta <- matrix(0,nrow=p,ncol=nclusts)
        for (k in 1:nclusts)
        {
                X_i <-  calculate_regression_matrix(vects[[(k-1)*n/nclusts+1]]$x,p=p,a=1,b=0,method=regression_method)
                Beta[,k] <- solve(t(X_i)%*%(X_i))%*%t(X_i)%*% vects[[(k-1)*n/nclusts+1]]$y
        }

        # Calculate Likelihood for initial condition : 
        SumLhood <- matrix(0,n,nclusts)
        for (i in 1:n)
        {
                for (k in 1:nclusts)
                {
                        X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,a=1,b=0,method=regression_method)
                        U_k[[i]][[k]] <- u[k]^2 * X_i %*% Beta[,k] %*% t(Beta[,k]) %*% t(X_i) + Sigma[k]^2 * diag(n_i[i])
                        V_k[[i]][[k]] <- v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])
                        SumLhood[i,k] <- alpha[k] *1/sqrt(det(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2) *t( vects[[i]]$y - X_i%*% Beta[,k] )%*%solve(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - X_i%*% Beta[,k]))  
                }
        }
        NewLhood <- sum(log(apply(SumLhood,1,sum)))

        ## EM Algorithm
        while (abs(Lhood-NewLhood)>Thresh) {#||(is.na(abs(Lhood-NewLhood)))
                Lhood <- NewLhood
                print(Lhood)

                # E-step
                for (i in 1:n){
                        for (k in 1:nclusts)
                        {
                                X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,a=1,b=0,method=regression_method)
                                
                                ## 1) Estimate c and d
                                U_k[[i]][[k]] <- u[k]^2 * X_i %*% Beta[,k] %*% t(Beta[,k]) %*% t(X_i) + Sigma[k]^2 * diag(n_i[i])
                                V_k[[i]][[k]] <- v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])

                                V_c[i,k] <- as.numeric(1/ ( t(Beta[,k]) %*% t(X_i) %*% solve(V_k[[i]][[k]]) %*% X_i %*% Beta[,k] + 1/u[k]^2) )
                                V_d[i,k] <- as.numeric(1/ ( t(rep(1,n_i[i])) %*% solve(U_k[[i]][[k]]) %*% rep(1,n_i[i]) + 1/v[k]^2) )

                                lambda <- 1/(as.numeric(u[k]^2 *t(Beta[,k]) %*% t(X_i) %*%X_i %*% Beta[,k] + Sigma[k]^2) *(n_i[i]*v[k]^2 + Sigma[k]^2))

                                V_c_d[i,k] <- as.numeric(- u[k] * v[k] * sqrt(lambda* V_c[i,k] * V_d[i,k]) * t(rep(1,n_i[i])) %*% X_i %*% Beta[,k])

                                c_hat[i,k] <- V_c[i,k] *( t(Beta[,k]) %*% t(X_i) %*% solve(V_k[[i]][[k]]) %*% vects[[i]]$y +1/u[k]^2)
                                d_hat[i,k] <- V_d[i,k] *t(vects[[i]]$y - X_i %*% Beta[,k]) %*% solve(U_k[[i]][[k]]) %*% rep(1,n_i[i])

                                # Noise vector estimation
                                Epsilon[[i]][,k]  <- vects[[i]]$y - c_hat[i,k] * X_i %*% Beta[,k] - d_hat[i,k]
                                V_Epsilon[[i]][[k]] <- V_c[i,k] * X_i %*% Beta[,k] %*% t(Beta[,k]) %*% t(X_i) + V_d[i,k] * matrix(1,n_i[i],n_i[i]) + 2* V_c_d[i,k] * X_i %*% Beta[,k] %*% t(rep(1,n_i[i]))

                                ## 2) Cluster Membership : only proportional ! normalization comes after
                                if (sqrt(det(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i])))==0){
                                        W[i,k] <- 0
                                        print("assignin probability to 0 because of singularity")
                                } else {
                                        W[i,k] <- alpha[k] *1/sqrt(det(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2)* t( vects[[i]]$y - X_i%*% Beta[,k] )%*%solve(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - X_i%*% Beta[,k]) ) 
                                }
                        }
                }

                ## Then normalize W
                W <- W/apply(W,1,sum)

                # M-step : maximization of the Q-function
                for (k in 1:nclusts)
                {
                        ## Calculating alpha 
                        alpha[k] <- 1/n*sum(W[,k])

                        ## Calculating u and v
                        u_Norm <- 0
                        v_Norm <- 0
                        for (i in 1:n)
                        {
                                u_Norm <- u_Norm + W[i,k] * ((c_hat[i,k]-1)^2 + V_c[i,k])
                                v_Norm <- v_Norm + W[i,k] * (d_hat[i,k]^2 + V_d[i,k])
                        }

                        u[k] <- sqrt( u_Norm/sum(W[,k]))
                        v[k] <- sqrt( v_Norm/sum(W[,k]))

                        ## Calculating Sigma
                        Sigma_Norm <- 0

                        for (i in 1:n)
                        {
                                Sigma_Norm <- Sigma_Norm + W[i,k] * ( t(Epsilon[[i]][,k]) %*% (Epsilon[[i]][,k]) + sum(diag((V_Epsilon[[i]][[k]]))))
                        }

                        Sigma[k] <- sqrt( Sigma_Norm/sum(W[,k] * n_i))


                        ## Calculating Beta
                        Beta_Mat1 <- 0
                        Beta_Vect <- 0

                        for (i in 1:n)
                        {
                                X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,a=1,b=0,method=regression_method)
                                Beta_Mat1 <- Beta_Mat1 + W[i,k]* t(X_i)%*%X_i * (c_hat[i,k]^2 + V_c[i,k])
                                Beta_Vect <- Beta_Vect + W[i,k]* t(X_i)%*% ( c_hat[i,k] * (vects[[i]]$y - d_hat[i,k]) - V_c_d[i,k])
                        }

                        Beta[,k] <- solve(Beta_Mat1) %*% Beta_Vect
                }

                ## Calculate the New Likelihood
                SumLhood <- matrix(0,n,nclusts)
                for (i in 1:n)
                {
                        for (k in 1:nclusts)
                        {
                                X_i <- calculate_regression_matrix(vects[[i]]$x,p=p,a=1,b=0,method=regression_method)
                                U_k[[i]][[k]] <- u[k]^2 * X_i %*% Beta[,k] %*% t(Beta[,k]) %*% t(X_i) + Sigma[k]^2 * diag(n_i[i])
                                V_k[[i]][[k]] <- v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])
                                if (sqrt(det(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i])))==0){ ## cheating when Non invertible matrix
                                        print(paste("i=",i))
                                        print(paste("   k=",k))
                                        print('careful putting likelihood to 0 because non-invertible matrix')
                                        SumLhood[i,k] <- 0
                                } else {
                                SumLhood[i,k] <- alpha[k] *1/sqrt(det(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i]))) * exp(-(1/2) *t( vects[[i]]$y - X_i%*% Beta[,k] )%*%solve(U_k[[i]][[k]] + V_k[[i]][[k]] - Sigma[k]^2 * diag(n_i[i]))%*%(vects[[i]]$y - X_i%*% Beta[,k]))  
                                }
                        }
                }
                NewLhood <- sum(log(apply(SumLhood,1,sum)))

        }

        output <- NULL
        output$Beta <- Beta
        output$Sigma <- Sigma
        output$Lhood <- NewLhood
        output$alpha <- alpha
        output$W <- W
        output$Z <- apply(W,1,which.max)
        output$c <- c_hat
        output$d <- d_hat

        return(output)
}



