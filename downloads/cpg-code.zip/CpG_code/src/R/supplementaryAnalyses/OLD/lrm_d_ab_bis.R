calculate_regression_matrix <- function(x, method="polynomial", a=0,b=0, p )
{
        ## PRM
        if (method=="polynomial")
        {
                require(matrixcalc)
                Ksi <- vandermonde.matrix( a*x - b , p)
                ## SRM
        } else if (method=="spline") {
                ## BSRM
        } else if (method=="Bspline") {
                ## NULL
        } else {
                print('not a valid method')
        }
        return(Ksi)
}


## Small_gamma  (6.13)
calculate_gamma_m_z <- function(mu, Variance, m)
{
        if (m==0)
        {
                gamma_m_z <- rep(0,length(mu))
        } else if (m==1) {
                gamma_m_z <- rep(0,length(mu))
        } else {

                G_q <- sapply(1:floor(m/2),function(q){out <- 1;for(j in 1:q){out <- out*(2*j-1)};return(out)})
                C_m_2q <- choose(m,2*(1:floor(m/2)))
                Sigma_2q <- sapply((1:floor(m/2)),function(k){Variance^(k)}) ## Variance = Sigma^2
                mu_m_2q <- sapply(1:floor(m/2),function(k){mu^(m-2*k)})

                gamma_m_z <-sapply(1:length(mu),function(n_i){sum(G_q*C_m_2q*Sigma_2q[n_i,]*mu_m_2q[n_i,])})
        }
        return(gamma_m_z)
}

## V_X_i (6.38)
calculate_V_X_i <- function(x,W,Gamma_ab,p,i)
{
        C_m_p <- lapply(0:p,function(j){choose(j,0:j)})
        minus_m <- lapply(0:p,function(j){(-1)^(0:j)})
        x_p_m <- lapply(0:p,function(j){sapply(j:0,function(k){x^k})})
        V_X_i <- matrix(0,length(x),p+1)
        for (j in 0:p)
        {
                if (j==0)
                {
                        V_X_i[,j+1] <- 0
                } else if (j==1) {
                        V_X_i[,j+1] <- 0
                } else {
                        V_X_i[,j+1] <- W* apply(minus_m[[j+1]]*C_m_p[[j+1]]*Gamma_ab[[j+1]][i,]*x_p_m[[j+1]],1,sum)
                }
        }
        return(V_X_i)
}

## V_X_d
calculate_V_X_d <- function(x,W,Gamma_abd, p,i)
{
        C_m_p <- lapply(0:p,function(j){choose(j,0:j)})
        minus_m <- lapply(0:p,function(j){(-1)^(0:j)})
        x_p_m <- lapply(0:p,function(j){sapply(j:0,function(k){x^(k)})})
        V_X_d <- sapply(0:p,function(j){W*sum(minus_m[[j+1]]*C_m_p[[j+1]]*Gamma_abd[[j+1]][i,]*x_p_m[[j+1]])})
        #         V_X_d <- sapply(0:p,function(j){W*apply(minus_m[[j+1]]*C_m_p[[j+1]]*Gamma_abd[[j+1]][i,]*x_p_m[[j+1]],1,sum)})
        return(V_X_d)
}

## V_XX_i
calculate_V_XX_i <- function(x,W,Gamma_ab,p,i)
{
        V_XX_i <- matrix(0,nrow=p+1,ncol=p+1)
        vxx <- calculate_V_X_i(x,W,Gamma_ab,2*p,i) 
        vxx <- apply(vxx,2,sum) 
        for (j in 0:(2*p))
        {
                vxx_j <- vxx[j+1]
                                        
                for (n_row in 1:min(j+1,p+1))
                {
                        #print(paste0("n_row=",n_row))
                        n_col <- j+2-n_row
                        #print(paste0("n_col=",n_col))
                        if (n_col<=(p+1))
                                V_XX_i[n_row,n_col] <- vxx_j
                }
        }

        return(V_XX_i)
}

## Log posterior
log_posterior_y_i <- function(a,b,y_i,x_i,Beta,sigma,r,s,v,p)
{
        n_i <- length(x_i)
        Ksi <- calculate_regression_matrix(x_i, a=a,b=b,p=p+1)
        V_k_i_k <- v^2 * matrix(1,n_i,n_i) + sigma^2 * diag(n_i)
        Vect <- t(y_i - Ksi%*% Beta )%*%solve(V_k_i_k)%*% (y_i - Ksi%*% Beta) 
        return( as.numeric(Vect + (a-1)^2/(r^2) + b^2/(s^2)) )
}

proj_PDC_gaffney <- function(V,max_counter = 5) # Transform V into PSD matrix using gaffney method
{
        tmp <- eigen(V)
        counter <- 0
        if (any(tmp$values<0)|(counter<=max_counter))
        { 
                counter <- counter + 1
                tmp <- eigen(V)
                diag(V) <- 1.25*diag(V)
        }

        output <- NULL
        if (any(tmp$values<0)) {
                output$keep <- F
        } else {
                output$keep <- T
        }
                
        output$V <- V
        return(output)
}

#############################################################################################################################################################################################################
lrm_d_ab <- function(vects, p, nclusts, regression_method="polynomial", MC_runs=150, Thresh=1e-5)
{
        require(MASS)
        # vects is a list of n n_ix2 matrices. vects[[i]]$x is the vector of covariates (i.e time or position) and vects[[i]]$y is the vector of output (can be in D-dimension but here we have D=1).
        # p  is the dimension of the regression
        # nclusts is the number of clusters
        # Thresh is the threshold for the EM-algorithm
        n <- length(vects)
        n_i <- vapply(vects,nrow,1) # length of i-th sample

        # Likelihood
        Lhood <- -Inf

        #### Hidden parameters
        # cluster membership
        W <- matrix(1/nclusts,nrow=n,ncol=nclusts)

        # alpha_k
        alpha <- rep(1/nclusts,nclusts)
        
        # Noise
        Sigma <- rep(1,nclusts)

        # Transformation priors
        r <- rep(1,nclusts)
        s <- rep(1,nclusts)
        v <- rep(1,nclusts)

        ## Observed parameters
        # Time Transformation
        a_hat <- matrix(1,nrow=n,ncol=nclusts)
        b_hat <- matrix(0,nrow=n,ncol=nclusts)

        V_a <- matrix(1,nrow=n,ncol=nclusts)
        V_b <- matrix(1,nrow=n,ncol=nclusts)
        V_a_b <- matrix(0,nrow=n,ncol=nclusts)

        # Space Transformation
        d_hat <- matrix(0,nrow=n,ncol=nclusts)

        V_d <- matrix(1,nrow=n,ncol=nclusts)

        # Crossed variances
        V_a_d <- matrix(0,nrow=n,ncol=nclusts)
        V_b_d <- matrix(0,nrow=n,ncol=nclusts)

        # Beta : Careful when initializing Beta if its too far the Lhood
        # Let's initialize Beta with the solution of the regression problems for i=1,11,21,31 (corresponding to the 4 modes)
        Beta <- matrix(0,nrow=p+1,ncol=nclusts)
        for (k in 1:nclusts)
        {
                sample_model <-(k-1)*n/nclusts+1 ## i = 1 11 21 31
                Ksi_i <-  calculate_regression_matrix(vects[[sample_model]]$x,p=p+1,a=a_hat[sample_model,k],b=b_hat[sample_model,k],method=regression_method)
                Beta[,k] <- solve(t(Ksi_i)%*%(Ksi_i))%*%t(Ksi_i)%*% vects[[sample_model]]$y
        }

        # Calculate Likelihood for initial condition : 
        SumLhood <- matrix(0,n,nclusts)
        for (i in 1:n)
        {
                for (k in 1:nclusts)
                {
                        a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2)))
                        Xhat <- lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})
                        V_k_i_k <- lapply(1:MC_runs,function(m){v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])})

                        p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^(n_i[i]) *det(V_k_i_k[[m]])) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(V_k_i_k[[m]])%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})


                        p_k <- sum(p_k_sum)/MC_runs

                        SumLhood[i,k] <- alpha[k] * p_k 
                }
        }
        NewLhood <- sum(log(apply(SumLhood,1,sum)))

        ## EM Algorithm
        while (abs(Lhood-NewLhood)>Thresh) {#||(is.na(abs(Lhood-NewLhood)))
                Lhood <- NewLhood
                print(paste0('NewLhood=',Lhood))

                # E-step
                print("E-step.....")
                for (i in 1:n){
                        for (k in 1:nclusts)
                        {
                                ## 1) Estimate a and b 
                                # a) mean with Nelder-Mead
                                res <- optim(c(1,0),function(a_b){ log_posterior_y_i(a_b[1],a_b[2],vects[[i]]$y,vects[[i]]$x,Beta[,k],Sigma[k],r[k],s[k],v[k],p)})
                                a_hat[i,k] <- res$par[1]
                                b_hat[i,k] <- res$par[2]

                                ## 2) Estimate d
                                Ksi_i <- calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_hat[i,k],b=b_hat[i,k],method=regression_method)
                                #V_k_i_k <- v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])
                                V_d_i_k <- 1/( n_i[i]/Sigma[k]^2 + 1/v[k]^2)
                                d_hat[i,k] <- V_d_i_k/Sigma[k]^2 * as.numeric(t(vects[[i]]$y - Ksi_i %*% Beta[,k]) %*% rep(1,n_i[i])) 

                                # 3) Variance with Inverse information
                                Dx <- rep(1,n_i[i]) %*% t(0:p); # n_i x p+1
                                Dx[,3:(p+1)] <- Dx[,3:(p+1)] * Ksi_i[ , 2:p]  # n_i x p+1
                                D2x <- rep(1,n_i[i]) %*% t(c(0,0,2:p)) # n_i x p+1
                                D2x[,3:(p+1)] <- D2x[,3:(p+1)] * Dx[,2:p] # n_i x p+1

                                ####
                                d_est <- rep(1,n_i[i]) * d_hat[i,k] # n_i x 1

                                ####
                                Ksi_beta <- Ksi_i %*% Beta[,k] # nix1
                                Dx_Beta <- Dx %*% Beta[,k]; # nix1
                                Dx_Beta_x <- Dx_Beta * vects[[i]]$x # nix1
                                D2x_Beta <- D2x %*% Beta[,k] # nix1
                                D2x_Beta_x <- D2x_Beta * vects[[i]]$x
                                D2x_Beta_x2 <- D2x_Beta_x * vects[[i]]$x
                                Y_x_Beta <- vects[[i]]$y - Ksi_i %*% Beta[,k] - d_est

                                # a) Inverse information
                                Ia <- sum(Y_x_Beta * D2x_Beta_x) / Sigma[k]^2 - sum(Dx_Beta_x^2)/Sigma[k]^2 - 1/r[k]^2;
                                Ib <- sum(Y_x_Beta * D2x_Beta) /Sigma[k]^2 - sum( Dx_Beta^2 )/Sigma[k]^2 - 1/s[k]^2;
                                Iab <- - sum(Y_x_Beta * D2x_Beta_x)/ Sigma[k]^2 + sum(Dx_Beta *Dx_Beta_x)/Sigma[k]^2 ;
                                Iad <- - sum(Dx_Beta_x)/Sigma[k]^2 ;
                                Ibd <- sum(Dx_Beta)/Sigma[k]^2;
                                Id <- - n_i[i]/Sigma[k]^2 - 1/v[k]^2;

                                # b) Variance is the inverse of the negative information
                                V <- diag(c(Ia,Ib,Id))
                                V[1,2] <- Iab; V[2,1] <- Iab
                                V[1,3] <- Iad; V[3,1] <- Iad
                                V[2,3] <- Ibd; V[3,2] <- Ibd

                                V_inv <- solve(-V) #

                                V_a[i,k] <- V_inv[1,1];
                                V_b[i,k] <- V_inv[2,2];
                                V_d[i,k] <- V_inv[3,3];

                                ## Verify that no value is negative
                                if (V_a[i,k]<0)
                                {
                                        print(paste0('V_a is negative for i=',i,' and for k=',k))
                                        V_a[i,k] <- abs(V_inv[1,1]);
                                }
                                if (V_b[i,k]<0)
                                {
                                        print(paste0('V_b is negative for i=',i,' and for k=',k))
                                        V_b[i,k] <- abs(V_inv[2,2]);
                                }
                                if (V_d[i,k]<0)
                                {
                                        print(paste0('V_d is negative for i=',i,' and for k=',k))
                                        V_d[i,k] <- abs(V_inv[3,3]);
                                }
                                
                                V_a_b[i,k] <- V_inv[1,2];
                                V_a_d[i,k] <- V_inv[1,3];
                                V_b_d[i,k] <- V_inv[2,3];

                                # Need to calculate the joint probability

                                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2))) ## should we take mu = c(a_hat,b_hat)?
                                Xhat <-  lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})
                                V_k_i_k <- lapply(1:MC_runs,function(m){v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])})
                                p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^n_i[i] * det(V_k_i_k[[m]])) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(V_k_i_k[[m]])%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})
                                p_k <- sum(p_k_sum)/MC_runs
                                            
                                ## 5) Cluster Membership : only proportional ! normalization comes after
                                W[i,k] <- alpha[k] * p_k

                        }
                }

                # Then normalize W
                if (any(apply(W,1,sum)==0)) {
                        print("one of the cluster is empty")
                        print("one of the sample is in no cluster")
                } else {
                        W <- W/apply(W,1,sum)
                }

                # M-step : maximization of the Q-function
                print("M-step.....")
                for (k in 1:nclusts)
                {
                        print(paste0('      k=',k))
                        ## Calculating alpha 
                        alpha[k] <- 1/n*sum(W[,k])

                        ## Calculating r, s, u and v
                        r[k] <- sqrt(sum(W[,k] * ((a_hat[,k]-1)^2 + V_a[,k]))/sum(W[,k]))
                        s[k] <- sqrt(sum(W[,k] * (b_hat[,k]^2 + V_b[,k]))/sum(W[,k]))
                        v[k] <- sqrt(sum(W[,k] * (d_hat[,k]^2 + V_d[,k]))/sum(W[,k]))

                        ## Calculate runs
                        a_runs <- matrix(0,n, MC_runs)
                        b_runs <- matrix(0,n, MC_runs)
                        d_runs <- matrix(0,n, MC_runs)

                        ## Initialization

                        ## run a,b,d to calculate the moments
                        for (i in 1:n)
                        {
                                ## Cov Matrix
                                V <- matrix ( c( V_a[i,k]       , V_a_b[i,k]    , V_a_d[i,k],
                                                 V_a_b[i,k]     , V_b[i,k]      , V_b_d[i,k],
                                                 V_a_d[i,k]     , V_b_d[i,k]    , V_d[i,k]  ) , 
                                             nrow=3,ncol=3,byrow=T)
                                
                                # Make sure V is PD
                                output <- proj_PDC_gaffney(V) ## proj on the SDP cone

                                V_est <- output$V
                                keep <- output$keep

                                if (output$keep)
                                {
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k],d_hat[i,k]) , Sigma=V_est) ##
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                        d_runs[i,] <- matrix_runs[,3]
                                } else {
                                        print('used diagonal matrix')
                                        matrix_runs <- mvrnorm(n = MC_runs, mu=c(a_hat[i,k],b_hat[i,k],d_hat[i,k]) , Sigma=diag(diag(V_est))) 
                                        a_runs[i,] <- matrix_runs[,1]
                                        b_runs[i,] <- matrix_runs[,2]
                                        d_runs[i,] <- matrix_runs[,3]
                                }
                        }


                        ## Initialization
                        X <- NULL
                        Y <- NULL
                        Seq <- NULL
                        for (j in 1:length(vects))
                        {
                                X <- c(X,t(vects[[j]]$x))
                                Y <- c(Y,t(vects[[j]]$x))
                                Seq <- c(Seq,length(vects[[j]]$x))
                        }

                        N <- length(X)
                        X <- matrix(X,nrow=N,ncol=1)

                        Xp <- t(apply(cbind(rep(1,N),X[,rep(1,2*p)]),1,cumprod))
                        YVx <- matrix(0,nrow=p+1,ncol=1)
                        Vxf <- matrix(0,nrow=p+1,ncol=1)
                        Vxx <- matrix(0,nrow=p+1,ncol=p+1)
                        ga <- matrix(0,nrow=n,ncol=2*p+1)
                        gb <- matrix(0,nrow=n,ncol=2*p+1)
                        neg <- -cumprod(-rep(1,2*p+1))
                        zz <- matrix(0,nrow=n,ncol=1);

                        Piik <- rep(W[,k],Seq)
                        a_hatp <- t(apply(cbind(rep(1,n),a_hat[,rep(k,2*p)]),1,cumprod))
                        b_hatp <- t(apply(cbind(rep(1,n),b_hat[,rep(k,2*p)]),1,cumprod))
                        Vap <- t(apply(V_a[,rep(k,p)],1,cumprod))
                        Vbp <- t(apply(V_b[,rep(k,p)],1,cumprod))

                        a_p_runs <- array(0,dim=c(n,MC_runs,2*p)) # n x MC_runs x 2*p ## a_runs[i,]
                        b_p_runs <- array(0,dim=c(n,MC_runs,2*p)) # n x MC_runs x 2*p ## b_runs[i,]
                        for (i in 1:n)
                        {
                                a_p_runs[i,,] <- t(apply(matrix(a_runs[i,],nrow=MC_runs,1) %*% matrix(1,nrow=1,ncol=2*p),1,cumprod))
                                b_p_runs[i,,] <- t(apply(matrix(b_runs[i,],nrow=MC_runs,1) %*% matrix(1,nrow=1,ncol=2*p),1,cumprod))
                        }
                        d_runs <- d_runs #  n x MC_runs

                        ## mj and mCombo
                        maxp = 2*p
                        M.Combo = matrix(1,nrow=maxp+1,ncol = maxp+1)
                        for (n_row in 1:maxp)
                        {
                                for (n_col in 1:(n_row-1))
                                {

                                        if (n_col>floor(n_row/2))
                                        {
                                                M.Combo[n_row+1,n_col+1] = M.Combo[n_row+1,n_row-n_col+1]
                                        } else {
                                                M.Combo[n_row+1,n_col+1] = prod((n_row-n_col+1) :n_row) / prod(1:n_col)
                                        }
                                }
                        }
                        M.Combo[2,1] <- 1 ## small error
                        M.mj = cumprod(seq(from = 1, to = maxp ,by=2))
                                        

                        for (j in 0:(2*p))
                        {
                                fj = floor(j/2)
                                MjCombo = matrix(1,nrow=n,ncol=1) %*% (M.mj[1:fj] * M.Combo[j+1,2*(1:fj)+1])
                                NegCombo = matrix(1,nrow=N,ncol=1) %*% (neg[1:(j+1)] * M.Combo[j+1,1:(j+1)])

                                # gamma_ma gamma_mb
                                if (j==0)
                                {
                                        ga[,j+1] <- 0
                                        gb[,j+1] <- 0
                                } else if (j==1){
                                        ga[,j+1] <- 0
                                        gb[,j+1] <- 0

                                } else {
                                        ga[,j+1] <- apply( MjCombo * Vap[,1:fj] * a_hatp[,seq(from = (j-1),to =1, by =-2)],1,sum)
                                        gb[,j+1] <- apply( MjCombo * Vbp[,1:fj] * b_hatp[,seq(from = (j-1),to =1, by =-2)],1,sum)
                                }

                                # cov(a^(j-r),b^r)
                                if (j==0)
                                {
                                        Vapbp = zz
                                } else if (j==1) {
                                        Vapbp = cbind(zz,zz)
                                } else if (j==2) {
                                        Vapbp = cbind(zz,V_a_b[,k],zz)
                                } else {
                                        covv = sapply(1:(j-1),function(m){sapply(1:n,function(i){cov(a_p_runs[i,,(j-1-m+1)],b_p_runs[i,,m])})})
                                        Vapbp = cbind(zz,covv,zz)
                                }

                                # Gamma_ab
                                G_ab = a_hatp[,(j+1):1] * gb[,1:(j+1)] + b_hatp[,1:(j+1)] * ga[,(j+1):1] + ga[,(j+1):1] * gb[,1:(j+1)] + Vapbp

                                if (j<=p)
                                {
                                        if (j>1)
                                        {
                                                ab <- array(0,dim=c(n,MC_runs,j+1))
                                                ab[,,1] = a_p_runs[,,j]
                                                ab[,,j+1] = b_p_runs[,,j+1]
                                                ab[,,2:j] = a_p_runs[,,(j-1):1] * b_p_runs[,,1:(j-1)]
                                        }

                                        if (j==0)
                                        {
                                                Vabpf = zz
                                        } else if (j==1) {
                                                Vabpf = cbind(V_a_d[,k], V_b_d[,k])
                                        } else {
                                                covv2 = sapply(1:(j+1),function(m){sapply(1:n,function(i){cov(ab[i,,m],d_runs[i,])})})
                                                Vabpf = covv2
                                        }

                                        # Gammas and Deltas
                                        G_abf = G_ab * d_hat[,k] + Vabpf
                                        Vxf[j+1,1] = t(Piik) %*% apply(NegCombo*apply(G_abf,2,function(x){rep(x, Seq)}) * Xp[,(j+1):1],1,sum)
 
                               }



                                # Calculate non-D-based Deltas
                                Vx <- Piik * apply(NegCombo*apply(G_ab,2,function(x){rep(x,Seq)})*Xp[,(j+1):1],1,sum)
                                if (j<=p)
                                {
                                        YVx[j+1,1] <- t(Vx) %*% Y;
                                }

                                p1=1; p2=j+1;
                                dj = p2-(p+1);
                                if (dj>0)
                                {
                                        p1=p1+dj
                                        p2=p2-dj
                                }
                                Vxx[(p+1) * (p2:p1 - 1) + p1:p2] = sum(Vx)
                        }

                        # Now Make Xhat and finish up the M-step
                        Xhat <- calculate_regression_matrix(as.vector(rep(a_hat[,k],Seq)*X - rep(b_hat[,k],Seq)),a=1,b=0,p=p+1)

                        PikXhat <- Piik %*% matrix(1,nrow=1,ncol=p+1) * Xhat
                        Ed <- rep(d_hat[,k],Seq)

                        ## Beta
                        Beta[,k] <- solve(t(PikXhat) %*% Xhat +Vxx) %*% ( t(PikXhat) %*% (Y-Ed) + YVx - Vxf)

                        ## Sigma
                        Sigma_test <- (t(Piik) %*% ( (Y -Xhat%*%Beta[,k] - Ed)^2) - 2* t(YVx) %*% Beta[,k] + t(Beta[,k])%*% Vxx %*% Beta[,k] + 2* t(Beta[,k]) %*% Vxf + t(W[,k] * n_i) %*% V_d[,k]) / sum(W[,k] * n_i)
                        if (Sigma_test<0) {
                                print('Sigma is negative, replacing by small value!')
                                Sigma[k] <- 10e-5
                        } else {
                                Sigma[k] <- sqrt(Sigma_test)
                        }



                }

                ## 3) Calculate the New Likelihood
                print('Calculating New Likelihood...')
                SumLhood <- matrix(0,n,nclusts)
                for (i in 1:n)
                {
                        for (k in 1:nclusts)
                        {
                                a_b_run <- mvrnorm(MC_runs,mu=c(1,0),Sigma=diag(c(r[k]^2,s[k]^2)))
                                Xhat <-  lapply(1:MC_runs,function(m){calculate_regression_matrix(vects[[i]]$x,p=p+1,a=a_b_run[m,1],b=a_b_run[m,2],method=regression_method)})
                                V_k_i_k <- lapply(1:MC_runs,function(m){v[k]^2 * matrix(1,n_i[i],n_i[i]) + Sigma[k]^2 * diag(n_i[i])})

                                p_k_sum <- sapply(1:MC_runs,function(m){1/sqrt((2*pi)^(n_i[i])*det(V_k_i_k[[m]] )) * exp(-(1/2)* t( vects[[i]]$y - Xhat[[m]]%*% Beta[,k] )%*%solve(V_k_i_k[[m]])%*%(vects[[i]]$y - Xhat[[m]]%*% Beta[,k]) )})

                                p_k <- sum(p_k_sum)/MC_runs
                                SumLhood[i,k] <- alpha[k] * p_k 

                        }

                }
                NewLhood <- sum(log(apply(SumLhood,1,sum)))

                print(paste0('NewLhood=',NewLhood))

        }

        output <- NULL
        output$Beta <- Beta
        output$Sigma <- Sigma
        output$Lhood <- NewLhood
        output$alpha <- alpha
        output$W <- W
        output$Z <- apply(W,1,which.max)
        output$a <- a_hat
        output$b <- b_hat
        output$d <- d_hat

        return(output)
}



