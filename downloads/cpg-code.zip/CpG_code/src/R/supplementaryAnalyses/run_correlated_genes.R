######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading 
## Path Setting 
setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
#args <- commandArgs(TRUE); PATH = args[1]
#setwd(PATH)

# Gene processed Methylation
###   load("../../data/processed/Methylation/TCGA/BRCA/CancerousGenes_processed.RData")
###   load("../../data/processed/Methylation/TCGA/BRCA/NormalGenes_processed.RData")
###   
###   # Gene Expression
###   load("../../data/processed/GeneExpression/TCGA/BRCA/CancerousLevel3GE_processed.RData")
###   load("../../data/processed/GeneExpression/TCGA/BRCA/NormalLevel3GE_processed.RData")
###   
###   # load clinicalinfo
###   load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
###   load("../../data/processed/fData/fData450K_Gene.RData") 
###   load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox 
## load the used packages 
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos
source("fun/predict_GE.R")

## Analysis 
list_big_island <- which(CpGIslands.probesize >=20)

DiseaseName <- "BRCA"
type <- "Cancerous"

GE.dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData')))
CommonGenes <- get(load('../../big_data/CommonGenes.RData'))


Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 

GE.New <- GE.dat[match(CommonGenes,Genes.GE),]

library(GenomicRanges)
gene.gr <- get(load('../../big_data/GenePosition.RData'))
chrOrder <- c(paste0('chr',1:22),'chrX')
OrderGenes <- Reduce('c',lapply(1:length(chrOrder), function(k) {
                                                        Index <- which(seqnames(gene.gr)==chrOrder[k])
                                                        GenomePosition <- start(gene.gr[Index])
                                                        NewOrder <- Index[order(GenomePosition)]
                                                       }))

gene.gr.bis <- gene.gr[OrderGenes]


## Careful gene.gr names are different from CommonGenes (recover some gene.gr from the genome)

###### Distance Matrix between genes
#  CorDistMat <- matrix(0,nrow=nrow(GE.New),ncol=nrow(GE.New))
#  
#  for (k in 1:nrow(CorDistMat))
#  {
#          print(paste0(k,"/",nrow(CorDistMat)))
#          for (l in k:ncol(CorDistMat))
#          {
#                  CorDistMat[k,l] <- cor(GE.New[k,],GE.New[l,])
#                  CorDistMat[l,k] <- CorDistMat[k,l]
#          }
#  }
#  
#  save(CorDistMat, file="../../big_data/BRCA_CorDistMat.RData")

CorDistMat <- get(load('../../big_data/BRCA_CorDistMat.RData'))

CorDistMat.reordered <- CorDistMat[OrderGenes,OrderGenes]

CorDistMat.chr6 <- CorDistMat.reordered[as.character(seqnames(gene.gr.bis))=="chr6",as.character(seqnames(gene.gr.bis))=="chr6"]
Abs.CorDistMat.chr6 <- abs(CorDistMat.reordered[as.character(seqnames(gene.gr.bis))=="chr6",as.character(seqnames(gene.gr.bis))=="chr6"])

library(reshape2)
ggplot(melt(CorDistMat.chr6)) + geom_tile(aes(x=Var1, y=Var2, fill=value)) + scale_fill_gradient(low='green', high='red') + ggtitle('chr6') + theme_bw()+theme(axis.title=element_blank())

ggplot(melt(Abs.CorDistMat.chr6)) + geom_tile(aes(x=Var1, y=Var2, fill=value)) + scale_fill_gradient(low='green', high='red') + ggtitle('chr6') + 
                                     theme_bw()+theme(axis.title=element_blank())



# png('../../results/GE_prediction/CorDistMatGenes.png')
# image(CorDistMat.reordered)
# dev.off()







## Dist = 1-abs(cor)
## or Dist = (1-cor)/2
DistCorMat <- 1-abs(CorDistMat)
library(ggdendro)

Clusters.GE <- get(load('../../big_data/GE_prediction/BRCA_Cancerous_ClustersGE_updown.RData'))
colnames(DistCorMat) <- names(Clusters.GE)
rownames(DistCorMat) <- names(Clusters.GE)
colour_scale <- c('1'='red',
                  '2'='green',
                  '3up'='blue',
                  '3down'='yellow',
                  '4'='black')



hc <- hclust(as.dist(DistCorMat), "ward.D")
p1 <- ggdendrogram(hc, rotate=FALSE,labels=F, leaf_labels=F)

df1<-data.frame(cluster=Clusters.GE, Gene= factor(hc$labels,levels=hc$labels[hc$order]))
p1.colors<-ggplot(df1,aes(Gene,y=1,fill=factor(cluster)))+geom_tile()+
                scale_y_continuous(expand=c(0,0))+ scale_fill_manual(values=colour_scale)+
                theme(axis.title=element_blank(),
                      axis.ticks=element_blank(),
                      axis.text=element_blank(),
                      legend.position="bottom")

gp1<-ggplotGrob(p1)
gp2<-ggplotGrob(p1.colors)  

maxWidth <- grid::unit.pmax(gp1$widths[2:5], gp2$widths[2:5])
gp1$widths[2:5] <- as.list(maxWidth)
gp2$widths[2:5] <- as.list(maxWidth)

pdf(paste0('../../results/GE_prediction/Infos/Gene_correlation.pdf'))
grid.arrange(gp1, gp2, ncol=1,heights=c(4/5,1/5))
dev.off()

### Get GE position on the genome
# CommonGenes
library(GenomicRanges)
data(genesymbol, package="biovizBase")

# MissingGenes <- CommonGenes[!(CommonGenes %in% names(genesymbol))]
# Association <- rep('0',length(MissingGenes))
# 
# names(Association) <- MissingGenes
# Association["C14orf181"] <- "C14orf181"
# Association["MICA"] <- "MICA"
# Association["PPP1R2P1"] <- "PPP1R2P1"
# Association["SPATA1"] <- "SPATA1"
# 
# save(Association,file="../../big_data/Association.RData")
load("../../big_data/Association.RData")

## ## Adding missing gene infos
## gr.bis <- GRanges(seqnames=c('chr14','chr6','chr6','chr1','chr14'), 
##                   ranges=IRanges(start=c(69261464,31399784,32876478,84971974,69767095), end= c(69263190,31415315,32880074,85031877,69772005)),
##                   strand= c('+','+','-','+','+'),
##                   symbol=c('C14orf181','MICA','PPP1R2P1','SPATA1','SFRS5'),
##                   ensembl_id=c(NA,NA,NA,NA,NA)
##                   )
## names(gr.bis) <-c('C14orf181','MICA','PPP1R2P1','SPATA1','SFRS5')
## genesymbol.bis <- c(genesymbol,gr.bis)
## 
## New.CommonGenes <- CommonGenes
## for (n in 1:length(Association))
## {
## New.CommonGenes[CommonGenes==names(Association)[n]] <- Association[n]
## }
## 
## gene.gr <- genesymbol.bis[New.CommonGenes]
# save(gene.gr, file="../../big_data/GenePosition.RData")

#### Do CGI.gr
load('../../big_data/CommonGenes.RData')
load("../../big_data/AssocIslandGenes.RData")
CGIs <- lapply(1:length(CommonGenes), function(n) { return( Reduce('rbind',list_big_island[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]] ])  ) }) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better.
CGIs <- unique(Reduce('c',CGIs))

fData.CGIs <- get(load('../../data/processed/fData/fData_CGI.RData'))[CGIs]

Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean_updown.RData'))

## from CGIs + list_big_island create Clusters.CGIs :
library(GenomicRanges)
Clusters.CGIs <- Clusters[ match(CGIs,list_big_island)]

CGIs.gr <- GRanges(seqnames= sapply(1:length(fData.CGIs),function(n){paste0('chr',fData.CGIs[[n]][1,"CHR"])}),
                   ranges=IRanges(start= sapply(1:length(fData.CGIs), function(n){fData.CGIs[[n]][1,"IslandBegin"]})   ,
                                  end= sapply(1:length(fData.CGIs), function(n){fData.CGIs[[n]][1,"IslandEnd"]})))

save(CGIs.gr, file="../../big_data/CGIs.RData")

CGIs.gr$clusters <- Clusters.CGIs

colour_scale <- c('1'='red',
                  '2'='green',
                  '3up'='blue',
                  '3down'='yellow',
                  '4'='black')


load('../../big_data/GenePosition.RData')

Ideo <- get(load('../../data/processed/fData/hg19.RData'))


library(ggbio)

pdf('../../results/GE_prediction/Infos/karyogram.pdf')
p <- ggplot(Ideo) + layout_karyogram(cytoband=TRUE) + layout_karyogram(gene.gr,aes(x=start), geom="rect", ylim=c(11,21)) + 
                                                      layout_karyogram(CGIs.gr,aes(x=start,colour=clusters), geom="rect", ylim=-c(0,10)) + scale_colour_manual(values=colour_scale) + theme(legend.position="none")
print(p)
dev.off()


## zoom on some regions : Add Cluster CGI infos
CHRs <- c('chr6','chr11')

Pos <- rbind(c(30e6, 34e6),
             c(94.8e6, 102e6))

Regions.df <- data.frame(chr=CHRs, position=Pos)
Regions.df$chr <- as.character(Regions.df$chr)
colnames(Regions.df) <- c('chr','begin','end')


for (k in 1:nrow(Regions.df))
{
        chr <- Regions.df$chr[k]
        Region <- c(Regions.df$begin[k], Regions.df$end[k])
        p.chr <- plotIdeogram(Ideo, chr)
        p.gene <- autoplot(gene.gr[seqnames(gene.gr)== chr]) + xlim(Region)
        p.CGIs <- autoplot(CGIs.gr[seqnames(CGIs.gr)==chr],aes(colour=clusters)) +xlim(Region) + scale_colour_manual(values=colour_scale)

        pdf(paste0('../../results/GE_prediction/Infos/Region_',k,'.pdf')) 
        print(tracks(chr = p.chr, genes = p.gene, CGIs=p.CGIs, heights = c(1,1,3)))
        dev.off()
}

