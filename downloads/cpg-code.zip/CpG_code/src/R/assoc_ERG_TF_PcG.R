# Set Path
#setwd("~/Desktop/CpG/src/R") # for Curie Machines
setwd('~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R')

# load featureData
###   load("../../data/processed/fData/fData450K_Gene.RData") 
###   load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
load("../../data/processed/fData/GeneList.RData")
#load("../../data/processed/fData/GeneProbesList.RData")


# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

list_big_island <-which(CpGIslands.probesize>=20)

### Toolbox 
## load the used packages 
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos
source("fun/predict_GE.R")
source("fun/linear_model.R")

source('fun/reduce_tools.R')
source("fun/plot_tools.R")



CommonGenes <- get(load('../../big_data/CommonGenes.RData'))


TopList <- 50

### PcG
PcG <- get(load('../../data/processed/TSS/PcGTargets.RData'))
PcG <- PcG[PcG$V2==1,]

### TF
TF.Zhang <- read.table('../../data/raw/TF/TFZhang.txt',header=T,sep="\t")
TF.Zhang <- read.table('../../data/raw/TF/TFVaq.txt',header=T,sep="\t")

###
CommonGenes.PcG <- sum(CommonGenes %in% PcG$name2)
CommonGenes.TF.Zhang <- sum(CommonGenes %in% TF.Zhang$Symbol)
CommonGenes.TF.Vaq <- sum(CommonGenes %in% TF.Vaq$HGNC.symbol)
###

### BRCA
ERG.BRCA <- get(load('../../big_data/GE_prediction/BRCA_ERG.RData'))
ERG.BRCA <- ERG.BRCA[seq(TopList),]
ERG.BRCA.TF.Zhang <- sum(ERG.BRCA$Gene %in% TF.Zhang$Symbol)
ERG.BRCA.TF.Zhang.Genes <- ERG.BRCA$Gene[ERG.BRCA$Gene %in% TF.Zhang$Symbol]

ERG.BRCA.TF.Vaq <- sum(ERG.BRCA$Gene %in% TF.Vaq$HGNC.symbol)

# ERG.df <- data.frame(Genes=rep(1,2374), PcG= as.numeric(ERG.BRCA$Gene %in% PcG$name2), TF=as.numeric(ERG.BRCA$Gene %in% TF.Zhang$Symbol) )
# ERG.df$Genes <- ERG.df$Genes * 1:2374
# ERG.df$PcG <- ERG.df$PcG * 1:2374
# ERG.df$TF <- ERG.df$TF * 1:2374
# library(reshape2)
# library(ggplot2)
# 
# ERG.m <- melt(ERG.df)
# ERG.m <- ERG.m[ERG.m$value != 0, ]
# 
# ggplot(ERG.m) + geom_boxplot(aes(x=variable, y=value))


# ERG.BRCA.TF.Vaq <- sum(ERG.BRCA$Gene %in% TF.Vaq$HGNC.symbol)
# ERG.BRCA.TF.Vaq.Genes <- ERG.BRCA$Gene[ERG.BRCA$Gene %in% TF.Vaq$HGNC.symbol]

ERG.BRCA.PcG <- sum(ERG.BRCA$Gene %in% PcG$name2)
ERG.BRCA.PcG.Genes <- ERG.BRCA$Gene[ERG.BRCA$Gene %in% PcG$name2]

# TF.Vaq[TF.Vaq$HGNC.symbol %in% ERG.BRCA.TF.Vaq.Genes , ]

phyper(ERG.BRCA.TF.Zhang-1,CommonGenes.TF.Zhang, length(CommonGenes) - CommonGenes.TF.Zhang,nrow(ERG.BRCA),lower.tail=F)
# phyper(ERG.BRCA.TF.Vaq-1,CommonGenes.TF.Vaq, length(CommonGenes) - CommonGenes.TF.Vaq,nrow(ERG.BRCA),lower.tail=F)
phyper(ERG.BRCA.PcG-1,CommonGenes.PcG, length(CommonGenes) - CommonGenes.PcG,nrow(ERG.BRCA),lower.tail=F)

### LUAD
ERG.LUAD <- get(load('../../big_data/GE_prediction/LUAD_ERG.RData'))
ERG.LUAD <- ERG.LUAD[seq(TopList),]
ERG.LUAD.TF.Zhang <- sum(ERG.LUAD$Gene %in% TF.Zhang$Symbol)
ERG.LUAD.TF.Zhang.Genes <- ERG.LUAD$Gene[ERG.LUAD$Gene %in% TF.Zhang$Symbol]

# ERG.LUAD.TF.Vaq <- sum(ERG.LUAD$Gene %in% TF.Vaq$HGNC.symbol)
# ERG.LUAD.TF.Vaq.Genes <- ERG.LUAD$Gene[ERG.LUAD$Gene %in% TF.Vaq$HGNC.symbol]

ERG.LUAD.PcG <- sum(ERG.LUAD$Gene %in% PcG$name2)
ERG.LUAD.PcG.Genes <- ERG.LUAD$Gene[ERG.LUAD$Gene %in% PcG$name2]

# TF.Vaq[TF.Vaq$HGNC.symbol %in% ERG.LUAD.TF.Vaq.Genes , ]

phyper(ERG.LUAD.TF.Zhang-1,CommonGenes.TF.Zhang, length(CommonGenes) - CommonGenes.TF.Zhang,nrow(ERG.LUAD),lower.tail=F)
# phyper(ERG.LUAD.TF.Vaq-1,CommonGenes.TF.Vaq, length(CommonGenes) - CommonGenes.TF.Vaq,nrow(ERG.LUAD),lower.tail=F)
phyper(ERG.LUAD.PcG-1,CommonGenes.PcG, length(CommonGenes) - CommonGenes.PcG,nrow(ERG.LUAD),lower.tail=F)

### Colon
ERG.Colon <- get(load('../../big_data/GE_prediction/Colon_ERG.RData'))
ERG.Colon <- ERG.Colon[seq(TopList),]
ERG.Colon.TF.Zhang <- sum(ERG.Colon$Gene %in% TF.Zhang$Symbol)
ERG.Colon.TF.Zhang.Genes <- ERG.Colon$Gene[ERG.Colon$Gene %in% TF.Zhang$Symbol]

# ERG.Colon.TF.Vaq <- sum(ERG.Colon$Gene %in% TF.Vaq$HGNC.symbol)
# ERG.Colon.TF.Vaq.Genes <- ERG.Colon$Gene[ERG.Colon$Gene %in% TF.Vaq$HGNC.symbol]

ERG.Colon.PcG <- sum(ERG.Colon$Gene %in% PcG$name2)
ERG.Colon.PcG.Genes <- ERG.Colon$Gene[ERG.Colon$Gene %in% PcG$name2]

phyper(ERG.Colon.TF.Zhang-1,CommonGenes.TF.Zhang, length(CommonGenes) - CommonGenes.TF.Zhang,nrow(ERG.Colon),lower.tail=F)
# phyper(ERG.Colon.TF.Vaq-1,CommonGenes.TF.Vaq, length(CommonGenes) - CommonGenes.TF.Vaq,nrow(ERG.Colon),lower.tail=F)
phyper(ERG.Colon.PcG-1,CommonGenes.PcG, length(CommonGenes) - CommonGenes.PcG,nrow(ERG.Colon),lower.tail=F)

####### In normal tissues
### BRCA
ERG.BRCA.Normal <- get(load('../../big_data/GE_prediction/BRCA_ERG_Normal.RData'))
ERG.BRCA.Normal <- ERG.BRCA.Normal[seq(TopList),]
ERG.BRCA.Normal.TF.Zhang <- sum(ERG.BRCA.Normal$Gene %in% TF.Zhang$Symbol)
ERG.BRCA.Normal.TF.Zhang.Genes <- ERG.BRCA.Normal$Gene[ERG.BRCA.Normal$Gene %in% TF.Zhang$Symbol]

ERG.BRCA.Normal.PcG <- sum(ERG.BRCA.Normal$Gene %in% PcG$name2)
ERG.BRCA.Normal.PcG.Genes <- ERG.BRCA.Normal$Gene[ERG.BRCA.Normal$Gene %in% PcG$name2]

# TF.Vaq[TF.Vaq$HGNC.symbol %in% ERG.BRCA.TF.Vaq.Genes , ]

phyper(ERG.BRCA.Normal.TF.Zhang-1,CommonGenes.TF.Zhang, length(CommonGenes) - CommonGenes.TF.Zhang,nrow(ERG.BRCA.Normal),lower.tail=F)
phyper(ERG.BRCA.Normal.PcG-1,CommonGenes.PcG, length(CommonGenes) - CommonGenes.PcG,nrow(ERG.BRCA.Normal),lower.tail=F)

### LUAD
ERG.LUAD.Normal <- get(load('../../big_data/GE_prediction/LUAD_ERG_Normal.RData'))

ERG.LUAD.Normal <- ERG.LUAD.Normal[seq(TopList),]
ERG.LUAD.Normal.TF.Zhang <- sum(ERG.LUAD.Normal$Gene %in% TF.Zhang$Symbol)
ERG.LUAD.Normal.TF.Zhang.Genes <- ERG.LUAD.Normal$Gene[ERG.LUAD.Normal$Gene %in% TF.Zhang$Symbol]

# ERG.LUAD.TF.Vaq <- sum(ERG.LUAD$Gene %in% TF.Vaq$HGNC.symbol)
# ERG.LUAD.TF.Vaq.Genes <- ERG.LUAD$Gene[ERG.LUAD$Gene %in% TF.Vaq$HGNC.symbol]

ERG.LUAD.Normal.PcG <- sum(ERG.LUAD.Normal$Gene %in% PcG$name2)
ERG.LUAD.Normal.PcG.Genes <- ERG.LUAD.Normal$Gene[ERG.LUAD.Normal$Gene %in% PcG$name2]

# TF.Vaq[TF.Vaq$HGNC.symbol %in% ERG.LUAD.TF.Vaq.Genes , ]

phyper(ERG.LUAD.Normal.TF.Zhang-1,CommonGenes.TF.Zhang, length(CommonGenes) - CommonGenes.TF.Zhang,nrow(ERG.LUAD.Normal),lower.tail=F)
# phyper(ERG.LUAD.TF.Vaq-1,CommonGenes.TF.Vaq, length(CommonGenes) - CommonGenes.TF.Vaq,nrow(ERG.LUAD),lower.tail=F)
phyper(ERG.LUAD.Normal.PcG-1,CommonGenes.PcG, length(CommonGenes) - CommonGenes.PcG,nrow(ERG.LUAD.Normal),lower.tail=F)

# ERG.df <- data.frame(Genes=rep(1,2374), PcG= as.numeric(ERG.LUAD.Normal$Gene %in% PcG$name2), TF=as.numeric(ERG.LUAD.Normal$Gene %in% TF.Zhang$Symbol) )
# ERG.df$Genes <- ERG.df$Genes * 1:2374
# ERG.df$PcG <- ERG.df$PcG * 1:2374
# ERG.df$TF <- ERG.df$TF * 1:2374
# library(reshape2)
# library(ggplot2)
# 
# ERG.m <- melt(ERG.df)
# ERG.m <- ERG.m[ERG.m$value != 0, ]
# 
# ggplot(ERG.m) + geom_boxplot(aes(x=variable, y=value))


