compare_clusters <- function(Disease1,type1,Disease2=NULL,type2=NULL,analysis=c('Mean','Var'))
{
        if (is.null(Disease2))
        {
                Disease2 <- Disease1
                type2 <- ifelse(type1=="Normal","Cancerous","Normal")
        }

        if (is.null(type2))
        {
                type2 <- type1
        }

        for (method in analysis)
        {
                cluster1 <- get(load(paste0('../../big_data/CGIs/',Disease1,'_',type1,'_Clusters',method,'.RData')))
                cluster2 <- get(load(paste0('../../big_data/CGIs/',Disease2,'_',type2,'_Clusters',method,'.RData')))

                # write.table(table(cluster1, cluster2), file=paste0("../../results/clustering/",Disease1,"/",method,"/concordance_cancerous_normal.txt"))
                # write.table(table(cluster1, cluster2), file=paste0("../../results/clustering/",Disease1,"/",method,"/concordance_cancerous_normal.txt"))
                write.table(table(cluster1,cluster2),file=paste0('~/Desktop/',Disease1,'_',Disease2,'_concordance_normal.txt'))

                ## assign(paste0(Disease,".",type,".clusters",method),tmp)
                ## save(list=eval(paste0(Disease,".",type,".clusters",method)), file=paste0('../../big_data/CGIs/',Disease,'_',type,'_Clusters',method,'_updown.RData'))

                ## library(knitr)
                ## kable(table(cluster1,cluster2),format="html", row.names=T)

                clusters.df <- data.frame( CGIs = paste0("CGI",1:length(list_big_island)), cluster1 = cluster1, cluster2 = cluster2 )
                colnames(clusters.df)[2] <- paste0(Disease1,'_',type1)
                colnames(clusters.df)[3] <- paste0(Disease2,'_',type2)

                clusters.df.m <- melt(clusters.df)

                ## Concordance of clusters
                # Visualization
                pdf(paste0('../../results/clustering/',Disease1,'/',method,'/concordance_cancerous_normal_two_classes.pdf'))
                p <- ggplot(clusters.df.m,aes(CGIs,factor(variable))) + geom_tile(aes(fill=factor(value))) 
                print(p + ylab('Component') + labs(x="",y="") + theme(axis.text.x=element_blank(), axis.ticks=element_blank(), panel.background=element_blank()) + theme(legend.position="none"))
                dev.off()

        }


}


