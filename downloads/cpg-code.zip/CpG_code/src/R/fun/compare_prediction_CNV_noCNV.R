compare_prediction_CNV_noCNV <- function(DiseaseName)
{

        ###########################
        #### 0) Preprocessing {{{1

        typeList <- "Cancerous" ## We only look at Cancerous because of CNVs

        # AnalysisList <- c('Mean','Promoter','AllCGIs')
        AnalysisList <- c('Mean','Promoter')

        # Stock the p-values of tests
        out <- NULL

        # GeneNames
        CommonGenes <- get(load('../../big_data/CommonGenes.RData'))

        # GenesBigIsland
        list_big_island <- which(CpGIslands.probesize >=20)

        # CGIs Info
        AllCGIs.Assoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
        Assoc.Length <- sapply(AllCGIs.Assoc,length)
        MultipleCGIs <- (Assoc.Length != 1)

        ##### Create the dataframes
        Gene.score <- Reduce('rbind',lapply(1:length(typeList), function(k)
                                            {
                                                    NoCNV.index <- lapply(1:length(AnalysisList),function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_CNV_index.RData')))})

                                                    tmp.noCNV <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_table.RData')))})

                                                    if (DiseaseName == "Colon")
                                                    {
                                                            tmp.CNV <- lapply(1:length(AnalysisList), function(n)
                                                                              {
                                                                                      get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_table_CNV_new.RData')))
                                                                              })
                                                    } else {
                                                            #tmp.CNV <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_table_CNV.RData')))
                                                            tmp.CNV <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_table_CNV_new.RData')))
                                                                              })
                                                    }

                                                    ### Process NoCNV
                                                    tmp.noCNV.processed <- NULL
                                                    tmp.noCNV.processed[[1]] <- as.numeric(apply(tmp.noCNV[[1]],1,function(x){mean(x,na.rm=T)}))
                                                    tmp.noCNV.processed[[2]] <- data.frame(Reduce('cbind',lapply(1:length(tmp.noCNV[[2]]), function(n){apply(tmp.noCNV[[2]][[n]],1,function(s){mean(s,na.rm=T)})})))

                                                    ### Process CNV
                                                    tmp.CNV.processed <- NULL
                                                    tmp.CNV.processed[[1]] <- data.frame(Reduce('cbind',lapply(1:length(tmp.CNV[[1]]),function(n){apply(tmp.CNV[[1]][[n]],1,function(s){mean(s,na.rm=T)})})))
                                                    colnames(tmp.CNV.processed[[1]]) <- names(tmp.CNV[[1]])
                                                    tmp.CNV.processed[[2]] <- data.frame(Reduce('cbind',lapply(1:length(tmp.CNV[[2]]),function(n){apply(tmp.CNV[[2]][[n]],1,function(s){mean(s,na.rm=T)})})))
                                                    colnames(tmp.CNV.processed[[2]]) <- names(tmp.CNV[[2]])

                                                    ###
                                                    tmp.df.noCNV <- Reduce('cbind',tmp.noCNV.processed)
                                                    tmp.df.CNV <- Reduce('cbind',tmp.CNV.processed)
                                                    NoCNV.index.df <- Reduce('cbind',NoCNV.index)
                                                    colnames(NoCNV.index.df) <- AnalysisList

                                                    ######
                                                    tmp.df <- cbind(tmp.df.noCNV, tmp.df.CNV)

                                                    colnames(tmp.df) <- c('LS.Meth_Only','Promoter.Lasso','Promoter.Ridge','LS.Meth_CNV','LS.CNV_Only','Promoter.Lasso.CNV','Promoter.Ridge.CNV')
                                                    rownames(tmp.df) <- CommonGenes
                                                    tmp.df <- tmp.df[,c(2,5,6)]
                                                    # tmp.df <- tmp.df[,c(3,5,7)] ## Use Ridge instead of Lasso for Colon
                                                    tmp.m <- melt(tmp.df)
                                                    tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Lasso','LS','Lasso'),each=2374), analysis=rep(c('Methylation','CNV','Methylation + CNV'),each=2374))
                                                    # tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Lasso','LS', 'LS','Lasso'),each=2374), analysis=rep(c('Methylation','LS Meth + CNV', 'CNV','Methylation + CNV'),each=2374))
                                                    ## Reorder the factors
                                                    tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('CNV', 'Methylation', 'Methylation + CNV'))
                                                    #tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('CNV', 'Methylation', 'LS Meth + CNV', 'Methylation + CNV'))
                                                    tmp.melted$method <- factor(tmp.melted$method, levels=c('LS','Lasso'))

                                                    out <- NULL
                                                    out$df <- tmp.df
                                                    out$melted <- tmp.melted
                                                    out$NoCNV.index <- NoCNV.index.df
                                                    return(out)
                                            }))

        #######
        # Verify Ridge vs Lasso !!
        tmp.CNV <- get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_Cancerous_Promoter_table_CNV_new.RData')))
        tmp.CNV.lasso <- apply(tmp.CNV[[1]],1,function(s){mean(s,na.rm=T)})
        tmp.CNV.ridge <- apply(tmp.CNV[[2]],1,function(s){mean(s,na.rm=T)})

        Dat.df <- data.frame(score=c(tmp.CNV.lasso,tmp.CNV.ridge), method=rep(c("lasso","ridge"),each=2374))

        ggplot(Dat.df) + geom_boxplot(aes(x=method,y=score))

        # wilcox.test(tmp.CNV.lasso,tmp.CNV.ridge, paired=T,alternative="less")
        qplot( tmp.CNV.lasso, tmp.CNV.ridge) + geom_abline(a=0,b=1,col="red")

        ######
        qplot( Gene.score$df$LS.CNV_Only, tmp.CNV.ridge) + geom_abline(a=0,b=1,col="red")
        qplot( tmp.CNV.lasso, tmp.CNV.ridge) + geom_abline(a=0,b=1,col="red")
        # qplot( Gene.score$df$LS.CNV_Only, tmp.CNV.ridge) + geom_abline(a=0,b=1,col="red")

        # wilcox.test(Gene.score$df$LS.CNV_Only, tmp.CNV.ridge)$p.value


        ###### Except for COLON, ridge and lasso are almost identical.

        ### Increase of predictive power from Methylation or CNV only to combined
        wilcox.test(Gene.score$df$Promoter.Lasso, Gene.score$df$Promoter.Lasso.CNV)$p.value
        wilcox.test(Gene.score$df$LS.CNV_Only, Gene.score$df$Promoter.Lasso.CNV)$p.value
        # wilcox.test(Gene.score$df$LS.CNV_Only, Gene.score$df$Promoter.Lasso.CNV, alternative="less")$p.value

        qplot(Gene.score$df$LS.CNV_Only,Gene.score$df$Promoter.Lasso.CNV) + geom_abline(a=0,b=1, col="red")

        qplot(Gene.score$df$LS.Meth_CNV,Gene.score$df$LS.CNV_Only) + geom_abline(a=0,b=1, col="red")

        ## Clusters Info
        Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown.RData')))
        Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
        Clusters.GE <- sapply(1:length(CommonGenes), function(n) { return(Clusters.Meth[Promoter.Assoc[n]])})
        names(Clusters.GE) <- CommonGenes

        ###########################
        #### 1) Plots {{{1
        ## a) Boxplot of the Scores given CNV/ noCNV 
        colour_data <- c('Methylation'='#d95f02',
                         'CNV' = '#1b9e77',
                         'Methylation + CNV'='#7570b3')
                         # 'LS Meth + CNV'='blue')

        p.GeneScore_CNV <- ggplot(Gene.score$melted) + geom_boxplot(aes(y=r2.predict,x=analysis,fill=analysis)) + scale_fill_manual(values= colour_data) +  ylab('R2 predict') + xlab('') +
                           coord_cartesian(ylim=c(-0.05, 1)) +
                           scale_y_continuous(breaks=c(0,0.5,1), labels=c('0','0.5','1')) +
                           theme(panel.grid=element_blank(),
                                 legend.position="none",
                                 text = element_text(size=20),
                                 panel.background=element_rect(fill="white"),
                                 axis.text=element_text(colour="black",size=rel(0.8)),
                                 axis.ticks=element_line(colour="black"),
                                 panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                 axis.title.y = element_text(vjust=0.35),
                                 strip.background = element_rect(colour="black",fill="white",size=0.7),
                                 axis.line = element_line(colour = "black",size=0.3))


        ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/GeneScore_CNV.pdf'),p.GeneScore_CNV,dpi=300)

        ## DiseaseName <- "Colon" ### Weird Things !!!!
        # qplot(Gene.score$df$Promoter.Lasso.CNV, Gene.score$df$LS.CNV_Only) + geom_abline(a=0,b=1, col="red")

        pdf(paste0('../../results/lasso_ls/',DiseaseName,'.pdf'))
        print(qplot(Gene.score$df$LS.CNV_Only, Gene.score$df$Promoter.Lasso.CNV) + geom_abline(a=0,b=1, col="red"))
        dev.off()

        # ## b) Scatterplot  
        #p.Scatter <- ggplot(Gene.score$df) + geom_point(aes(x=LS.Meth_Only, y=LS.CNV_Only)) + xlim(0,1) + ylim(0,1) + xlab('Average Methylation') + ylab('CNV') +
        p.Scatter <- ggplot(Gene.score$df) + geom_point(aes(x=Promoter.Lasso, y=LS.CNV_Only),alpha=0.5) + xlim(0,1) + ylim(0,1) + xlab('Methylation') + ylab('CNV') +
                     coord_cartesian(ylim=c(-0.01,1),xlim=c(-0.01,1)) +
                     scale_x_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) + scale_y_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) +
                     theme(panel.grid=element_blank(),
                           panel.background=element_rect(fill="white", colour=NA),
                           legend.position="none",
                           text = element_text(size=20),
                           axis.text=element_text(colour="black",size=rel(0.8)),
                           panel.border=element_rect(fill=NA, colour="black",size=0.7),
                           axis.ticks=element_line(colour="black"),
                           strip.background = element_rect(colour="black") ,
                           axis.line = element_line(colour = "black",size=0.3))

        # ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatterplot_LS_Meth_CNV.pdf'), p.Scatter, dpi=300)
        ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatterplot_Meth_CNV.pdf'), p.Scatter, dpi=300)

        toto <- lm(LS.CNV_Only ~ Promoter.Lasso , Gene.score$df)
        summary(toto)$r.squared

        ###########################
        #### 3) List of epigenetically regulated Genes
        ## Look at clusters associated

        #a) Analyze the intersection
        ###########################
        # intersect(out$ERG$AllCGIs.Lasso.Cancerous$Genes,out$ERG$AllCGIs.Ridge.Cancerous$Genes)
        #### Intersection is ~ stable

        #b) Do gene ontology
        ###################
        ### -> InterCancer
        
        #c) Verify Gene expression
        ##########################
        ## For all genes
        # GE.Full <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed_bis.RData')))
        # GE.Names <- sapply(strsplit(rownames(GE.Full),"\\|"),"[",1)
        # GE.Dat <- GE.Full[match(CommonGenes, GE.Names),]
        # GE.Mean <- apply(GE.Dat,1,mean)
        # GE.Mean <- GE.Mean + 1e-5

        # GE.clusters.full <- data.frame(GE=GE.Mean, Score=Gene.score$df[,"AllCGIs.Lasso.CNV"], clusters=Clusters.GE)

        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_GE_Clusters_CNV.pdf'))
        # print(ggplot(GE.clusters.full) + geom_point(aes(x=GE,y=Score)) + facet_grid(~clusters) + geom_hline(yintercept=0.5, colour='blue', linetype="longdash") + geom_vline(xintercept=1, colour='red') + scale_x_log10() + ylim(0,1)    )
        # dev.off()

        # median(na.omit(GE.Mean[Clusters.GE=="4up"]))

        # median(na.omit(GE.Mean[Clusters.GE=="1"]))

        ## For Interesting genes
        # Interesting.Genes <-out$ERG$AllCGIs.Lasso.CNV$Genes ## out$ERG[[9]] = AllCGIs Lasso Cancerous
        # GE.Interesting <- GE.Full[match(Interesting.Genes, GE.Names),] 
        # rownames(GE.Interesting) <- Interesting.Genes 

        # GE.Interesting.melted <- melt(GE.Interesting)
        # GE.Interesting.melted <- data.frame(Gene= GE.Interesting.melted$Var1, GE= GE.Interesting.melted$value, cluster= Clusters.GE[as.character(GE.Interesting.melted$Var1)])

        # colour_scale <- c('1'='red',
        #                   '2'='green',
        #                   '3'='black',
        #                   '4down'='yellow',
        #                   '4up'='blue')

        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/GE_CNV.pdf'))
        # print(ggplot(GE.Interesting.melted) + geom_boxplot(aes(x=Gene,y=GE,fill=cluster)) + theme(axis.text.x = element_text(angle = 90, hjust = 1)) + geom_hline(yintercept=1, colour='red') + scale_y_log10() + scale_fill_manual(values=colour_scale)      )
        # dev.off()

        # d) Verify CNV
        ###################
        CNV.Dat <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/CancerousCNV_Genes.RData')))
        CNV.Mean <- apply(CNV.Dat,1,mean)
        CNV.Mean_loss_gain <- sapply(1:length(CNV.Mean), function(n)
                                     {
                                             if (is.na(CNV.Mean[n]))
                                             {
                                                     return(NA)
                                             } else if (CNV.Mean[n] < -0.2)
                                             {
                                                     return("Loss")
                                             } else if (CNV.Mean[n] > 0.2)
                                             {
                                                     return("Gain")
                                             } else 
                                             {
                                                     return("Normal")
                                             }
                                     })
        CNV.Mean_loss_gain <- factor(CNV.Mean_loss_gain, levels=c('Loss','Normal','Gain'))

        # CNV.clusters.full.noCNV <- data.frame(CNV=CNV.Mean_loss_gain, Score=Gene.score$df[,"Promoter.Lasso"], clusters=Clusters.GE, type="No CNV")
        # CNV.clusters.full.CNV <- data.frame(CNV=CNV.Mean_loss_gain, Score=Gene.score$df[,"Promoter.Lasso.CNV"], clusters=Clusters.GE, type="CNV")

        # CNV.clusters.full <- rbind(CNV.clusters.full.noCNV, CNV.clusters.full.CNV)
        # CNV.clusters.full.noNA <- CNV.clusters.full[!(is.na(CNV.clusters.full$CNV)),]

        CNV.clusters.full.MethOnly <- data.frame(CNV=CNV.Mean_loss_gain, Score=Gene.score$df[,"Promoter.Lasso"], clusters=Clusters.GE, type="Methylation Only")
        CNV.clusters.full.CNVOnly <- data.frame(CNV=CNV.Mean_loss_gain, Score=Gene.score$df[,"LS.CNV_Only"], clusters=Clusters.GE, type="CNV Only")
        CNV.clusters.full.MethCNV <- data.frame(CNV=CNV.Mean_loss_gain, Score=Gene.score$df[,"Promoter.Lasso.CNV"], clusters=Clusters.GE, type="Methylation + CNV")

        CNV.clusters.full <- rbind(CNV.clusters.full.MethOnly, CNV.clusters.full.CNVOnly, CNV.clusters.full.MethCNV)
        CNV.clusters.full.noNA <- CNV.clusters.full[!(is.na(CNV.clusters.full$CNV)),]


        colour_CNV <- c('Loss' = '#d6604d',
                        'Normal' = '#ffffbf',
                        'Gain' = '#4393c3')


        #p.Scores_CNV <- ggplot(CNV.clusters.full.noNA) + geom_boxplot(aes(x=CNV,y=Score,fill=CNV)) + scale_fill_manual(values = colour_CNV) + facet_grid(~type) +
        p.Scores_Method <- ggplot(CNV.clusters.full.noNA) + geom_boxplot(aes(x=type,y=Score,fill=CNV)) + scale_fill_manual(values = colour_CNV) + 
                        ylab("R2 predict")+ 
                        xlab('') +
                        #xlab('Gene Copy Number Information') +
                        coord_cartesian(ylim=c(-0.01, 1)) +
                        scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
                        theme(panel.grid=element_blank(),
                              legend.position="none",
                              text = element_text(size=20),
                              panel.border=element_rect(fill=NA, colour="black",size=0.7),
                              panel.background=element_rect(fill="white"),
                              axis.text=element_text(colour="black",size=rel(0.8)),
                              axis.title.x = element_text(vjust=0.35),
                              axis.ticks=element_line(colour="black"),
                              strip.background = element_rect(colour="black",fill="white",size=0.7),
                              axis.line = element_line(colour = "black",size=0.3))

        ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_Method.pdf'),p.Scores_Method, dpi=300)

        colour_data <- c('Methylation Only'='#d95f02',
                         'CNV Only' = '#1b9e77',
                         'Methylation + CNV'='#7570b3')

        p.Scores_CNV <- ggplot(CNV.clusters.full.noNA) + geom_boxplot(aes(x=CNV,y=Score,fill=type)) + scale_fill_manual(values = colour_data) + # facet_grid(~CNV) +
        ylab("R2 predict")+ xlab('Gene Copy Number Information') +
        coord_cartesian(ylim=c(-0.01, 1)) +
        scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
        theme(panel.grid=element_blank(),
              legend.position="none",
              text = element_text(size=20),
              panel.border=element_rect(fill=NA, colour="black",size=0.7),
              panel.background=element_rect(fill="white"),
              axis.text=element_text(colour="black",size=rel(0.8)),
              axis.title.x = element_text(vjust=0.35),
              axis.ticks=element_line(colour="black"),
              strip.background = element_rect(colour="black",fill="white",size=0.7),
              axis.line = element_line(colour = "black",size=0.3))

        ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_CNV.pdf'),p.Scores_CNV, dpi=300)


        CNV.df <- data.frame(CNV=CNV.Mean_loss_gain, Meth=Gene.score$df[,"Promoter.Lasso"], CNV.dat= Gene.score$df[,"LS.CNV_Only"])
        CNV.df <- CNV.df[!(is.na(CNV.df$CNV)),]

        ggplot(CNV.df[CNV.df$CNV=="Gain",]) + geom_point(aes(x=Meth,y=CNV.dat)) + xlim(0,1) + ylim(0,1)
        ggplot(CNV.df[CNV.df$CNV=="Normal",]) + geom_point(aes(x=Meth,y=CNV.dat)) + xlim(0,1) + ylim(0,1)
        ggplot(CNV.df[CNV.df$CNV=="Loss",]) + geom_point(aes(x=Meth,y=CNV.dat)) + xlim(0,1) + ylim(0,1)

        cor(CNV.df[CNV.df$CNV=="Gain","Meth"], CNV.df[CNV.df$CNV=="Gain","CNV.dat"],method="pearson")
        cor(CNV.df[CNV.df$CNV=="Loss","Meth"], CNV.df[CNV.df$CNV=="Loss","CNV.dat"],method="pearson",use="pairwise.complete.obs")
        cor(CNV.df[CNV.df$CNV=="Normal","Meth"], CNV.df[CNV.df$CNV=="Normal","CNV.dat"],method="pearson")


        Dat <- CNV.df[CNV.df$CNV=="Gain",]


        toto <- lm(CNV.dat ~ Meth , Dat)
        summary(toto)$r.squared


        aa





        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_CNV_noCNV.pdf'))
        # # print(ggplot(CNV.clusters.full) + geom_point(aes(x=CNV,y=Score)) + facet_grid(~type) + geom_hline(yintercept=0.5, colour='blue', linetype="longdash") + geom_vline(xintercept=0, colour='red') + ylim(0,1)    )
        # dev.off()

        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/CNV_Value_Clusters.pdf'))
        # print(ggplot(CNV.clusters.full.CNV) + geom_boxplot(aes(y=CNV,x=clusters,fill=clusters)) + scale_fill_manual(values=colour_scale) )
        # dev.off()

        #e) Look at Lasso predictor for interesting genes
        #################################################
        ### Interesting.Genes <-out$ERG$AllCGIs.Lasso.CNV$Genes ## out$ERG[[9]] = AllCGIs Lasso Cancerous
        ### GE.Interesting <- GE.Full[match(Interesting.Genes, GE.Names),] 
        ### rownames(GE.Interesting) <- Interesting.Genes 

        ### Meth.dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed_bis.RData')))[list_big_island]
        ### CNV.dat <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/CancerousCNV_Genes.RData')))
        ### fData.big_island <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))

        ### library(glmnet)
        ### set.seed(1234)
        ### n.folds <- 3
        ### folds <- split( sample( seq(ncol(GE.Interesting)) ), seq(n.folds) )

        ### Predictions.CV <- lapply(1:length(Interesting.Genes), function(n){ 
        ###                          print(n)
        ###                          Index <- which(CommonGenes==Interesting.Genes[n])
        ###                          Y <- t(GE.Interesting[n,,drop=F])
        ###                          X <- t(Meth.dat[[ Promoter.Assoc[Index] ]])

        ###                          ## Verify
        ###                          if (any( is.na(CNV.dat[Index,])))
        ###                          {
        ###                                  print("NA")
        ###                          } else {
        ###                                  X <- cbind(X , CNV.dat[Index,])
        ###                          }

        ###                          prediction.fold <- lapply(seq(n.folds), function(n_fold)
        ###                                                             {
        ###                                                                     Y_train <- Y[-folds[[n_fold]],,drop=F ]
        ###                                                                     X_train <- X[-folds[[n_fold]],]

        ###                                                                     Y_test <- Y[folds[[n_fold]],,drop=F ]
        ###                                                                     X_test <- X[folds[[n_fold]],]

        ###                                                                     ###### Verify if any(Y_train != Y_train[1])
        ###                                                                     if (any(Y_train != Y_train[1]))
        ###                                                                     {
        ###                                                                             ## 1) do Crossval on (X_train,Y_train) to tune lambda
        ###                                                                             lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1)$lambda.min

        ###                                                                             ## 2) do prediction of Y_test and look at correlation with real Y_test
        ###                                                                             predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)

        ###                                                                             Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)

        ###                                                                             r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
        ###                                                                     } else {
        ###                                                                             r2.pearson.lasso <- NA
        ###                                                                             r2.pearson.ridge <- NA
        ###                                                                     }

        ###                                                                     return(data.frame(Real=as.vector(Y_test),Predict=as.vector(Y_predict.lasso)))
        ###                                                             })

        ###                          return(Reduce('rbind',prediction.fold))

        ###                   } )

        ### Predictions.df <- data.frame(Real=Reduce('rbind',Predictions.CV)$Real,
        ###                              Predict=Reduce('rbind',Predictions.CV)$Predict,
        ###                              Gene=rep(Interesting.Genes, each=ncol(GE.Interesting)))

        ### GeneList <-  split( Interesting.Genes, seq(floor(length(Interesting.Genes)/12 )))

        ### for (k in 1:length(GeneList))
        ### {
        ###         pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Plot_Predict_Real_',k,'_CNV.pdf'))
        ###         print(ggplot(Predictions.df[Predictions.df$Gene %in%  GeneList[[k]] , ]) + geom_point(aes(x=Real,y=Predict)) + facet_wrap( ~ Gene, scales="free", ncol=4)  )
        ###         dev.off()
        ### }

        #### TO FINISH INCLUDING CNV INFO IN THE PLOT
        ## Predictors.New <- lapply(1:length(Interesting.Genes), function(n){ 
        ##                          print(n)
        ##                          Index <- which(CommonGenes==Interesting.Genes[n])
        ##                          Y <- t(GE.Interesting[n,,drop=F])
        ##                          X <- t(Meth.dat[[ Promoter.Assoc[Index] ]])
        ##                          NA.CNV <- F
        ##                          if (any( is.na(CNV.dat[Index,])))
        ##                          {
        ##                                  print("NA")
        ##                                  NA.CNV <- T
        ##                          } else {
        ##                                  X <- cbind(X,CNV.dat[Index,])
        ##                          }

        ##                          cv.lasso <- cv.glmnet(X,Y,alpha=1)      
        ##                          best.fit <- glmnet(X,Y,lambda=cv.lasso$lambda.min,alpha=1)

        ##                          ## TO DO
        ##                          out <- NULL
        ##                          if (NA.CNV)
        ##                          {
        ##                                  out$Meth <- as.vector(coef(best.fit))[-1]/norm(as.vector(coef(best.fit))[-1],"2")
        ##                                  out$CNV <- NA
        ##                          } else {
        ##                                  Predictor <-as.vector(coef(best.fit))[-1]/norm(as.vector(coef(best.fit))[-1],"2")
        ##                                  out$Meth <- Predictor[-length(Predictor)]
        ##                                  out$CNV <- Predictor[length(Predictor)]
        ##                          }

        ##                          return(out)
        ##                   } )

        ## Predictors.Meth <- Reduce('c',lapply(1:length(Predictors.New), function(n){Predictors.New[[n]]$Meth}))
        ## Predictors.CNV <- Reduce('c',lapply(1:length(Predictors.New), function(n){Predictors.New[[n]]$CNV}))

        ## Dat <- data.frame(Predictors= Predictors.Meth,
        ##                   position= Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ; fData.big_island[[ Promoter.Assoc[Index] ]][ ,"MAPINFO"    ]  })),
        ##                   IslandDist= Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandDist"    ]  })),
        ##                   CGI = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index]  ]][ ,"UCSC_CpG_Islands_Name"    ]  })),
        ##                   Gene = rep(Interesting.Genes, sapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]);nrow(fData.big_island[[Promoter.Assoc[Index] ]])})),
        ##                   IslandBegin = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandBegin"    ]  })),
        ##                   IslandEnd = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandEnd"    ]  })),
        ##                   Relation_to_UCSC_CpG_Island = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"Relation_to_UCSC_CpG_Island"    ]  })))

        ## Dat$Relation_to_UCSC_CpG_Island <- factor(Dat$Relation_to_UCSC_CpG_Island, levels= c('N_Shelf','N_Shore','Island','S_Shore','S_Shelf'))

        ## pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_CNV.pdf'))
        ## print(ggplot(Dat,aes(x=position,y=Predictors))+geom_point() 
        ##       + geom_line()
        ##       + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")
        ##       + geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")
        ##       + geom_hline(yintercept=0, colour="red")
        ##       #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
        ##       + facet_wrap( ~ Gene, scales="free", ncol=4)  
        ##       + theme(legend.position="none", axis.text.x=element_blank()))
        ## dev.off()

        ## pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_boxplot_CNV.pdf'))
        ## print(ggplot(Dat,aes(x=Relation_to_UCSC_CpG_Island,y=abs(Predictors))) 
        ##       + geom_boxplot()
        ##       + theme(legend.position="none"))
        ## dev.off()

        ## Dat.CGI <- Dat[(Dat$IslandDist>=0)&(Dat$IslandDist<=1),]
        ## Dat.Shore_Shelves <- Dat[(Dat$IslandDist<=0)|(Dat$IslandDist>=1),]

        ## pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_Resume_CGI_CNV.pdf'))
        ## print(ggplot(Dat.CGI,aes(x=IslandDist,y=abs(Predictors)))+geom_point() 
        ##       + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
        ##       + geom_vline(aes(xintercept=1),colour="black", linetype= "longdash")
        ##       + geom_hline(yintercept=0, colour="red")
        ##       #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
        ##       + theme(legend.position="none", axis.text.x=element_blank()))
        ## dev.off()

        ## pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_Resume_Shore_Shelves_CNV.pdf'))
        ## print(ggplot(Dat.Shore_Shelves,aes(x=IslandDist,y=abs(Predictors)))+geom_point() 
        ##       + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
        ##       + geom_hline(yintercept=0, colour="red")
        ##       #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
        ##       + theme(legend.position="none", axis.text.x=element_blank()))
        ## dev.off()

        # Promoter Ridge vs AllCGIs Ridge
        out$CNV_NoCNV <- wilcox.test(Gene.score$df[MultipleCGIs,"Promoter.Ridge.Cancerous"], Gene.score$df[MultipleCGIs,"Promoter.Ridge.CNV"])$p.value


        return(out)
}

compare_prediction_Normal_Cancerous <- function(DiseaseName)
{

        ###########################
        #### 0) Preprocessing {{{1
        if (DiseaseName=="Colon")
        {
                typeList <- "Cancerous"
        } else {
                typeList <- c('Normal',"Cancerous")
        }

        AnalysisList <- c('Mean','Promoter','AllCGIs')
        AnalysisList_Final <- c('Mean','Promoter')

        # Stock the p-values of tests
        out <- NULL

        # GeneNames
        CommonGenes <- get(load('../../big_data/CommonGenes.RData'))

        # GenesBigIsland
        list_big_island <- which(CpGIslands.probesize >=20)

        # CGIs Info
        AllCGIs.Assoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
        Assoc.Length <- sapply(AllCGIs.Assoc,length)
        MultipleCGIs <- (Assoc.Length != 1)

        ##### Create the dataframes
        Gene.score <- lapply(1:length(typeList), function(k)
                             {
                                     tmp.noCNV <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'.RData')))})
                                     tmp.noCNV[[1]] <- t(tmp.noCNV[[1]])
                                     tmp.df.noCNV <- Reduce('cbind',tmp.noCNV)

                                     if (typeList[k]=="Cancerous")
                                     {
                                             tmp.CNV <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_CNV.RData')))})
                                             NoCNV.index <- lapply(1:length(AnalysisList),function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_CNV_index.RData')))})
                                             tmp.df.CNV <- Reduce('cbind',tmp.CNV)
                                             NoCNV.index.df <- Reduce('cbind',NoCNV.index)
                                             tmp.df <- cbind(tmp.df.noCNV, tmp.df.CNV)
                                             colnames(NoCNV.index.df) <- c('Mean','Promoter','AllCGIs')
                                             colnames(tmp.df) <- c('LS.Meth_Only','Promoter.Lasso','Promoter.Ridge','AllCGIs.Lasso','AllCGIs.Ridge','LS.Meth_CNV','LS.CNV_Only','Promoter.Lasso.CNV','Promoter.Ridge.CNV','AllCGIs.Lasso.CNV','AllCGIs.Ridge.CNV')
                                     } else 
                                     {
                                             tmp.df <- tmp.df.noCNV
                                             colnames(tmp.df) <- c('LS','Promoter.Lasso','Promoter.Ridge','AllCGIs.Lasso','AllCGIs.Ridge')
                                     }

                                     ######
                                     rownames(tmp.df) <- CommonGenes
                                     tmp.m <- melt(tmp.df)

                                     if (typeList[k]=="Cancerous")
                                     {
                                             tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('LS','Lasso','Ridge','Lasso','Ridge','LS','LS','Lasso','Ridge','Lasso','Ridge'),each=2374), analysis=rep(c('Mean','Promoter','Promoter','AllCGIs','AllCGIs','Mean','Mean','Promoter','Promoter','AllCGIs','AllCGIs'),each=2374), type=typeList[k],CNV=rep(c('noCNV','both','CNV','both'),c(2374*5, 2374, 2374, 2374*4)))
                                     } else {
                                             tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('LS','Lasso','Ridge','Lasso','Ridge'),each=2374), analysis=rep(c('Mean','Promoter','Promoter','AllCGIs','AllCGIs'),each=2374), type=typeList[k],CNV='noCNV')
                                     }

                                     ## Reorder the factors
                                     tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('Mean','Promoter','AllCGIs'))
                                     tmp.melted$CNV <- factor(tmp.melted$CNV, levels=c('noCNV','CNV','both'))
                                     tmp.melted$method <- factor(tmp.melted$method, levels=c('LS','Ridge','Lasso'))


                                     out <- NULL
                                     out$df <- tmp.df
                                     out$melted <- tmp.melted
                                     if (typeList[k]=="Cancerous")
                                     {
                                             out$NoCNV.index <- NoCNV.index.df
                                     }
                                     return(out)
                             })
        names(Gene.score) <- typeList

        Gene.score.df <- Reduce('cbind', lapply(1:length(typeList), function(k)
                                                {
                                                        tmp.df <- Gene.score[[k]]$df
                                                        colnames(tmp.df) <- paste0(colnames(tmp.df),'.',typeList[k])

                                                        return(tmp.df)

                                                }))

        if (DiseaseName != Colon)
        {
                pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatterplot_LS_Normal_Cancerous.pdf'))
                print(ggplot(Gene.score.df) + geom_point(aes(x=LS.Normal, y=LS.Meth_CNV.Cancerous)) + geom_abline(a=0,b=1,col="red") + xlim(0,1) + ylim(0,1) + xlab('LS Normal') + ylab('LS Cancerous (Meth+CNV)'))
                dev.off()
        }

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatterplot_Lasso_Ridge_Cancerous.pdf'))
        print(ggplot(Gene.score.df) + geom_point(aes(x=AllCGIs.Lasso.Cancerous, y=AllCGIs.Ridge.Cancerous)) + geom_abline(a=0,b=1,col="red") + xlim(0,1) + ylim(0,1) )
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatterplot_LS_Ridge_Cancerous.pdf'))
        print(ggplot(Gene.score.df) + geom_point(aes(x=LS.Meth_Only.Cancerous, y=AllCGIs.Ridge.Cancerous)) + geom_abline(a=0,b=1,col="red") + xlim(0,1) + ylim(0,1) )
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatterplot_Lasso_Normal_Cancerous.pdf'))
        print(ggplot(Gene.score.df) + geom_point(aes(x=AllCGIs.Lasso.Normal, y=AllCGIs.Lasso.Cancerous)) + geom_abline(a=0,b=1,col="red") + xlim(0,1) + ylim(0,1) )
        dev.off()


        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatterplot_Lasso_Normal_Cancerous_CNV.pdf'))
        print(ggplot(Gene.score.df) + geom_point(aes(x=AllCGIs.Lasso.Normal, y=AllCGIs.Lasso.CNV.Cancerous)) + geom_abline(a=0,b=1,col="red") + xlim(0,1) + ylim(0,1) )
        #         print(ggplot(Gene.score.df) + geom_point(aes(x=AllCGIs.Lasso.Normal, y=AllCGIs.Lasso.Cancerous)) + geom_abline(a=0,b=1,col="red") + xlim(0,1) + ylim(0,1) )
        dev.off()

        # toto <- lm(LS.Meth_Only.Cancerous ~ AllCGIs.Ridge.Cancerous , Gene.score.df)
        # summary(toto)$r.squared

}


