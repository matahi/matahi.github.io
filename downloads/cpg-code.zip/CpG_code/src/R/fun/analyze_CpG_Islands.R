analyze_CpG_Islands <- function(Disease,Chrom,type="BOTH")
{
        Dat <- eval(parse(text=paste0(Disease,".",type)))

        # Filtering
        ChrFilter <- rownames(fData450K[fData450K[,"CHR"]==Chrom,])
        BigIslands <- CpGIslands[CpGIslands.probesize>10]
        BigIslandsFilter <- rownames(fData450K[fData450K[,"UCSC_CpG_Islands_Name"] %in% BigIslands,])
        Chr_BigIslandsFilter <- intersect(ChrFilter,BigIslandsFilter)

        # Subsampling
        subsample <- Dat[Chr_BigIslandsFilter,]
        subsample.fData <- fData450K[Chr_BigIslandsFilter,c("MAPINFO","UCSC_CpG_Islands_Name","IslandBegin","IslandEnd")]
        df.betas <- melt(subsample)

        subsample.dataframe <- data.frame(Patient = df.betas$variable, betas=df.betas$value,cg=Chr_BigIslandsFilter,position=subsample.fData$MAPINFO,CpGIsland=subsample.fData$UCSC_CpG_Islands_Name,IslandBegin= subsample.fData$IslandBegin,IslandEnd = subsample.fData$IslandEnd)
        subsample_subset.dataframe <- subsample.dataframe[subsample.dataframe[,"CpGIsland"] %in% levels(subsample.dataframe$CpGIsland)[2:40],]

        # Plotting
        pdf(paste("../../results/Relation_to_CpG_Island/CpGIslandsChr",Chrom,".pdf",sep=""), width=10, height=10, pointsize=10)
        print(ggplot(subsample_subset.dataframe,aes(x=position,y=betas))+geom_point(aes(colour=Patient)) + geom_line(aes(colour=Patient))+ geom_vline(aes(xintercept=IslandBegin),colour="blue")+geom_vline(aes(xintercept=IslandEnd),colour="blue")+facet_wrap( ~ CpGIsland, scales="free", ncol=4) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

}

analyze_CGI_patterns = function (CGI,Disease="BRCA",type="BOTH",nclusts=2,method="kmeans") {
        Id <- which(CpGIslands==CGI)

        if (type!="BOTH"){
                Betas.Island <- eval(parse(text=paste0(Disease,'.',type,'CGIs')))[[Id]]
        } else {
                Betas.Island <- cbind(eval(parse(text=paste0(Disease,'.CancerousCGIs')))[[Id]],eval(parse(text=paste0(Disease,'.NormalCGIs')))[[Id]])
        }

        Betas.Infos <- melt(Betas.Island)

        # fData
        ## !! Careful doesn't work if Matrix has only one probe
        fData.Infos <- fData450K[rownames(Betas.Island),c("MAPINFO","IslandBegin","IslandEnd")]

        ### Clustering Analysis
        output <- NULL

        if (method=="kmeans"){
                out.kmeans <-kmeans(t(Betas.Island),nclusts)
                output$cl <- out.kmeans$cluster
                output$modes <- out.kmeans$centers
        } else if (method=="GPMM"){
                # Initialize the clusters
                output$cl <- rep(1,ncol(Betas.Island))
                Epsilon <- 0.5
                output$cl <- cl
                # EM Algorithm
                while (Step >= Epsilon){
                        # Estimation Step
                        # Minimisation Step
                }
        }

        ### plot
        # clusters
        data_to_plot <- data.frame(Patient=Betas.Infos$Var2,cluster=rep(output$cl,each=nrow(Betas.Island)), betas=Betas.Infos$value, Location= fData.Infos$MAPINFO, IslandBegin=fData.Infos$IslandBegin, IslandEnd=fData.Infos$IslandEnd)

        output$p <-ggplot(data=data_to_plot,aes(x=Location,y=betas)) +
        geom_line(aes(colour=cluster,group=Patient)) +
        geom_point(aes(colour=cluster)) +
        theme(legend.position="none") +
        geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))

        # modes
        if (nclusts==2){
        output$modes <- rbind(output$modes, output$modes[2,]- output$modes[1,])
        rownames(output$modes)[3] <- "Diff"
        }

        Modes.Infos <- melt(output$modes)

        if (nclusts==2){
        modes_to_plot <- data.frame(Modes = Modes.Infos$Var1, betas= Modes.Infos$value, Location = rep(fData.Infos$MAPINFO,each=nclusts+1))
        } else {
        modes_to_plot <- data.frame(Modes = Modes.Infos$Var1, betas= Modes.Infos$value, Location = rep(fData.Infos$MAPINFO,each=nclusts))
        }

        output$p_modes <-ggplot(data=modes_to_plot,aes(x=Location,y=betas)) +
        geom_line(aes(colour=Modes)) +
        geom_point(aes(colour=Modes)) +
        geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))


        ### output
        return(output)
}
