analyze_CGI_clusters <- function(Disease,type,analysis=c('Mean'), cutoff=3, doGO=F,info="updown")
{
        doGO <- T

        for (method in analysis)
        {
                distanceMat.Normalized <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type,'_DistanceMat',method,'Norm.RData')) )

                ## colour_scale
                if (type=="Cancerous")
                {
                        colour_scale <- c('1' = '#225ea8',
                                          '2' = 'gold1',
                                          '3down' = '#66c2a4',
                                          '3up' = '#238b45')

                } else if (type=="Normal") {
                        colour_scale <- c('1' = '#225ea8',
                                          '2' = 'gold1')
                                          

                }

                if (method=="Var")
                {
                        colour_scale <- c('1'='#225ea8',
                                          '2'='gold1',
                                          '3'='#238b45')
                }

                #######
                library(ggdendro)
                library(ggplot2)
                hc <- hclust(as.dist(distanceMat.Normalized), "ward")

                                
                #################################
                ## Cluster Stability
                #################################

                #source('lib/clusterComp_bis.R')
                #tata <- clusterComp_bis(distanceMat.Normalized,4,method="ward", B=100)

                ## ConsensusClusterPlus
                # library(ConsensusClusterPlus)
                # index <- 1:1500
                index <- 1:ncol(distanceMat.Normalized)
                dt <- as.dist(distanceMat.Normalized[index,index])

                #dt <- as.dist(distanceMat.Normalized)
                #source('lib/ConsensusClusterPlus_bis.R')
                # rcc2 = ConsensusClusterPlus(d=dt,maxK=10,reps=100,pItem=0.8,pFeature=1,plot="pdf",innerLinkage="ward", finalLinkage="ward", title="example2",distance="euclidean",clusterAlg="hc")

                #clust2 <- get(load(paste0('../../big_data/CGIs/',Disease,'_Cancerous_ClustersMean_updown.RData')))
                # table(rcc2[[4]]$consensusClass,clust2[index])
                

                #### ClusterStab
                # library(ClusterStab)

                # install.packages('NbClust')
                # library(NbClust)

                ####################################
                source('fun/rearrange_clusters.R')
                clusters <- cutree(hc,cutoff)

                ### We rearranged the clusters so that clust 1= hypo, clust2= hyper, clust3= hemi.
                clusters <- rearrange_clusters(clusters)

                ## We added the info for clust3 of whether the CGI is assigned to clust1 or clust2 in normal
                clusters <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type,'_Clusters',method,'_updown_bis.RData')))


                save(clusters, file= paste0('../../big_data/CGIs/',Disease,'_',type,'_Clusters',method,'_updown_bis.RData'))

                # Heatmap 
                Cols <- as.character(clusters)
                Cols[Cols=="1"] <- colour_scale[1]
                Cols[Cols=="2"] <- colour_scale[2]

                if (type=="Cancerous")
                {
                        Cols[Cols=="3down"] <- colour_scale["3down"]
                        Cols[Cols=="3up"] <- colour_scale["3up"]
                } else if (type=="Normal")
                {
                }

                library(gplots)

                df1<-data.frame(cluster=clusters, CGI= factor(hc$labels,levels=hc$labels[hc$order]))

                ## Clustering Mean adding mean colors 
                #####################################################
                p1 <- ggdendrogram(hc, rotate=FALSE,labels=F, leaf_labels=F) + 
                     theme(axis.text.x=element_blank(),
                           text = element_text(size=20),
                           axis.text=element_text(colour="black",size=rel(0.8)),
                           plot.margin=unit(c(0,0.5,-0.5,0),"cm"))

                library(gridExtra)
                p1.colors<-ggplot(df1,aes(CGI,y=1,fill=factor(cluster)))+geom_tile()+
                scale_y_continuous(expand=c(0,0))+ scale_fill_manual(values=colour_scale)+
                theme(axis.title=element_blank(),
                      axis.ticks=element_blank(),
                      axis.text=element_blank(),
                      legend.position="none",
                      plot.margin=unit(c(-0.5,0.5,0,0),"cm"))

                gp1<-ggplotGrob(p1)
                gp2<-ggplotGrob(p1.colors)  

                maxWidth <- grid::unit.pmax(gp1$widths[2:5], gp2$widths[2:5])
                gp1$widths[2:5] <- as.list(maxWidth)
                gp2$widths[2:5] <- as.list(maxWidth)

                p.final <- arrangeGrob(gp1,gp2,ncol=1, heights=c(19/20,1/20))

                class(p.final) <- c(class(p.final), "ggplot")

                ggsave(paste0('../../results/clustering/',Disease,'/',method,'/Clust_Cols_',type,'_clusters_',method,'_',cutoff,'.pdf'), p.final, dpi=300)

                ##################################################################
                ## CGI clustering analysis 
                library(reshape2)
                load('../../data/processed/fData/fData_CGI_big_island.RData')

                CGI.analysis <- data.frame( CGIs = paste0("CGI",1:length(list_big_island)), Mean = clusters )
                # CGI.analysis.m <- melt(CGI.analysis)

                ## Position of the clusters on the genome
                library(GenomicRanges)
                library(ggbio)
                source('fun/plot_gr.R')
                load('../../data/processed/fData/hg19.RData')
                CGIs.names <- names(fData_CGI_big_island)

                ###   output <- plot_gr(CGIs.names,clusters = clusters, colour_scale=colour_scale)

                ###   pdf(paste0('../../results/clustering/',Disease,'/',method,'/position_clusters_',type,'_clusters_',cutoff,'.pdf'))
                ###   print(output$p)
                ###   dev.off()

                ###   CGI.info.df <- data.frame(clusters=clusters, CHR=sapply(1:length(fData_CGI_big_island),function(n){fData_CGI_big_island[[n]]$CHR[1]}), size= sapply(1:length(fData_CGI_big_island),
                ###                                                                                                                                                       function(n){fData_CGI_big_island[[n]]$IslandEnd[1] - fData_CGI_big_island[[n]]$IslandBegin[1]}))

                ###   pdf(paste0('../../results/clustering/',Disease,'/',method,'/clusters_repartition',type,'_clusters_',cutoff,'.pdf'))
                ###   print(ggplot(CGI.info.df,aes(x=factor(CHR, levels=c(1:22,'X')), fill=factor(clusters))) + geom_bar(position="fill") + theme(legend.position="none") + scale_fill_manual(values=colour_scale))
                ###   dev.off()

                ###   pdf(paste0('../../results/clustering/',Disease,'/',method,'/clusters_size',type,'_clusters_',cutoff,'.pdf'))
                ###   print(ggplot(CGI.info.df,aes(x=clusters,y=size)) + geom_boxplot() + theme(legend.position="none")) 
                ###   dev.off()

                ## Type of CGIs

                ##### Genes associated clusters
                CGI.Genes <- sapply(1:length(fData_CGI_big_island),function(n){ unique(Reduce('c',strsplit(fData_CGI_big_island[[n]][,"UCSC_RefGene_Name"], ";")))   })

                ### Gene Ontology between clusters
                ## First transform symbols into entrezgene
                
                if (doGO)
                {
                        if (info=="updown")
                        {
                                unique_clusters <- c('1','2','3down','3up')
                                # CGI.Genes.clusters <- lapply(1:length(unique(clusters)), function(n){ unique(Reduce('c', CGI.Genes[clusters==unique_clusters[n]]))})
                                CGI.Genes.clusters <- lapply(1:length(unique(clusters)), function(n){ Reduce('c', CGI.Genes[clusters==unique_clusters[n]])})

                                library(biomaRt)
                                mart <- useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")
                                CGI.entrezGenes.clusters <- lapply(1:length(unique(clusters)),function(n){getBM(attributes = c("entrezgene"),
                                                                                                                filters = "hgnc_symbol", values = CGI.Genes.clusters[[n]],
                                                                                                                mart = mart)[,1]})
                                names(CGI.entrezGenes.clusters) <- unique_clusters


                        } else
                        {
                                CGI.Genes.clusters <- lapply(1:length(unique(clusters)), function(n){ unique(Reduce('c', CGI.Genes[clusters==n]))})

                                library(biomaRt)
                                mart <- useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")
                                CGI.entrezGenes.clusters <- lapply(1:length(unique(clusters)),function(n){getBM(attributes = c("entrezgene"),
                                                                                                                filters = "hgnc_symbol", values = CGI.Genes.clusters[[n]],
                                                                                                                mart = mart)[,1]})
                                names(CGI.entrezGenes.clusters) <- paste0("clusters",1:length(unique(clusters)))

                        }


                        library('clusterProfiler')
                        source('lib/fct.plotCompClusterProfiler.R')

                        ## Reference gene set
                        # universe <- unique(Reduce("c",CGI.entrezGenes.clusters))
                        background_genes <- Reduce("c",CGI.entrezGenes.clusters)


                        ##
                        length(background_genes)
                        sum(sapply(CGI.entrezGenes.clusters,length))

                        ## See if enrichment in any biological process with respect to the reference universe
                        # xx_bp <- compareCluster(CGI.entrezGenes.clusters, fun="enrichGO", ont="BP")
                        xx_bp <- compareCluster(CGI.entrezGenes.clusters, fun="enrichGO", ont="BP", universe=background_genes,qvalueCutoff=0.05,minGSSize=20)

                        write.table(summary(xx_bp),file = paste0("../../results/clustering/",Disease,"/",type,"_GO_Clusters.txt"),row.names=F, sep="\t", quote=F) 

                        sum_xx_bp <- summary(xx_bp)

                        xx_mf <- compareCluster(CGI.entrezGenes.clusters, fun="enrichGO", ont="MF", universe=background_genes)

                        pdf(paste0('../../results/clustering/',Disease,'/',method,'/Gene_Ontology_BP_',type,'_clusters_',cutoff,'.pdf'),width=10, height=10, pointsize=10, bg="white")
                        print(plotCompGO(xx_bp,grps=names(CGI.entrezGenes.clusters), sortBy="Count", showCategory=20 ))
                        # print(plotCompGO(xx_bp,grps=names(CGI.entrezGenes.clusters), sortBy="pvalue", showCategory=20 ))
                        dev.off()

                        pdf(paste0('../../results/clustering/',Disease,'/',method,'/Gene_Ontology_MF_',type,'_clusters_',cutoff,'.pdf'),width=10, height=10, pointsize=10, bg="white")
                        # print(plotCompGO(xx_mf,grps=names(CGI.entrezGenes.clusters), sortBy="Count", showCategory=20 ))
                        print(plotCompGO(xx_mf,grps=names(CGI.entrezGenes.clusters), sortBy="Count", showCategory=10 ))
                        dev.off()


                        #####
                        ## ClusterSizes
                        sig <- 0.05
                        entrezGenes.clusters.size <- sapply(CGI.entrezGenes.clusters,length)
                        universe.size <- sum(entrezGenes.clusters.size)
                        GO_term_all <- unique(summary(xx_bp)$Description)
                        tmp <- summary(xx_bp)

                        GO.Counts <- sapply(1:length(GO_term_all), function(n)
                                            {
                                                    print(n)
                                                    GO_term <- GO_term_all[n]
                                                    return(sum(tmp[tmp$Description==GO_term,"Count"]))
                                            })
                        names(GO.Counts) <- GO_term_all

                        Clust.enrich.GO <- lapply(1:length(GO_term_all), function(n)
                                                  {
                                                          print(n)
                                                          GO_term <- GO_term_all[n]
                                                          GO.clusters.count <- sapply(names(entrezGenes.clusters.size),function(clust)
                                                                                      {
                                                                                              if (sum((tmp$Cluster==clust)&(tmp$Description==GO_term))>0)
                                                                                              {
                                                                                                      Count <- tmp[(tmp$Cluster==clust)&(tmp$Description==GO_term),"Count"]
                                                                                              } else
                                                                                              {
                                                                                                      Count <- 0
                                                                                              }
                                                                                              return(Count)
                                                                                      })
                                                          names(GO.clusters.count) <- names(entrezGenes.clusters.size)

                                                          GO.Matrix <- matrix(c(GO.clusters.count, entrezGenes.clusters.size- GO.clusters.count),byrow=T,ncol=length(GO.clusters.count),
                                                                              dimnames=list(hit=c('Gene count in GO','Gene count not in GO'),
                                                                                            clusters=names(GO.clusters.count)))

                                                          Clust.enrich <- lapply(1:ncol(GO.Matrix), function(k)
                                                                                 {
                                                                                         Clust.Mat <- matrix(c(GO.Matrix[1,k], GO.Matrix[2,k], sum(GO.Matrix[1,-k]) , sum(GO.Matrix[2,-k])), ncol=2,
                                                                                                             dimnames=list(hit=c('Gene count in GO','Gene count not in GO'),
                                                                                                                           clusters=c('clust','not in clust')))

                                                                                         out <- NULL
                                                                                         out$Significant <- (fisher.test(Clust.Mat, alternative="greater")$p.val < sig)
                                                                                         out$pvalue <- fisher.test(Clust.Mat, alternative="greater")$p.val
                                                                                         #return(fisher.test(Clust.Mat, alternative="greater")$p.val < sig)
                                                                                         #return(fisher.test(Clust.Mat, alternative="greater")$p.val)
                                                                                         return(out)

                                                                                 })

                                                          out <- NULL
                                                          out$Significant <- sapply(1:ncol(GO.Matrix), function(k){ Clust.enrich[[k]]$Significant})
                                                          out$pvalue <- sapply(1:ncol(GO.Matrix), function(k){ Clust.enrich[[k]]$pvalue})

                                                          # names(Clust.enrich) <- unique_clusters

                                                          return(out)
                                                  })

                        Clust.enrich.GO.sig <- t(sapply(1:length(Clust.enrich.GO), function(k){ Clust.enrich.GO[[k]]$Significant }))
                        Clust.enrich.GO.pval <- t(sapply(1:length(Clust.enrich.GO), function(k){ Clust.enrich.GO[[k]]$pvalue }))

                        rownames(Clust.enrich.GO.sig) <- GO_term_all
                        colnames(Clust.enrich.GO.sig) <- unique_clusters
                        rownames(Clust.enrich.GO.pval) <- GO_term_all
                        colnames(Clust.enrich.GO.pval) <- unique_clusters

                        Clust.enrich.resume <- cbind(Clust.enrich.GO.sig, GO.Counts)

                        TopGO <- 10
                        GO.Clusters <- lapply(1:length(unique_clusters), function(n_clust)
                                              {
                                                      # Dat.Clust <- Clust.enrich.resume[Clust.enrich.resume[ ,n_clust]==1,"GO.Counts"]
                                                      # Dat.Clust.Counts <- sort(Dat.Clust,decreasing=T)
                                                      # GO.Clusters <- names(Dat.Clust.Counts)[1:TopGO]


                                                      ##### Take only index when cluster is the only significant
                                                      Clust.enrich.resume.only <- Clust.enrich.resume[,1:length(unique_clusters)]
                                                      Clust.enrich.resume.only[,-n_clust] <- !Clust.enrich.resume.only[,-n_clust]
                                                      Index_only <- apply(Clust.enrich.resume.only,1,all)
                                                      Dat.Clust.only <- Clust.enrich.resume[Index_only,"GO.Counts"]
                                                      Pval <- Clust.enrich.GO.pval[Index_only, n_clust]

                                                      Dat.Clust.only <- Dat.Clust.only[order(Pval)]
                                                      Pval <- Pval[order(Pval)]

                                                      # GO.Clusters <- names(Dat.Clust.only)[1:TopGO]
                                                      if (length(names(Dat.Clust.only)) < TopGO)
                                                      {
                                                              GO.out <-data.frame(Pvalue = Pval, Counts= Dat.Clust.only)
                                                      } else 
                                                      {
                                                              GO.out <-data.frame(Pvalue = Pval[1:TopGO], Counts= Dat.Clust.only[1:TopGO])
                                                      }

                                                      return(GO.out)
                                              })


                        save(GO.Clusters, file=paste0('~/Desktop/',Disease,"_GO.RData"))

                }

                

        } # End Method
}

### Supplementary Data Analysis
##   ## Promoter associated clusters
##         CGI.Regulatory_Feature_Group <- sapply(1:length(fData_CGI_big_island),function(n){ any(grepl("Promoter_Associated",fData_CGI_big_island[[n]][,"Regulatory_Feature_Group"]))})
##         write.table(table(CGI.Regulatory_Feature_Group, clusters.Mean), file=paste0("../../results/clustering/",Disease,"/table_RFG_clusterMean_",type,".txt"))
##
##         ###         clusters.Mean
##         ### CGI.RFG   1   2   3
##         ###    FALSE 394 192 240
##         ###    TRUE  915  40  46
##
##         ###          70%  17%  16%
##
##         ##### Enhancer associated clusters
##         CGI.Enhancer <- sapply(1:length(fData_CGI_big_island),function(n){ any(as.logical(fData_CGI_big_island[[n]][,"Enhancer"]))})
##         CGI.Enhancer[is.na(CGI.Enhancer)] <- F
##
##         write.table(table(CGI.Enhancer, clusters.Mean), file=paste0("../../results/clustering/",Disease,"/table_RFG_clusterMean_",type,".txt"))
##
##
##         ###             clusters.Mean
##         ### CGI.Enhancer   1   2   3
##         ###        FALSE 884 121 110
##         ###        TRUE  425 111 176
##
##         ###              32% 48% 61%
##
##         ##### DMR associated clusters
##         CGI.DMR <- sapply(1:length(fData_CGI_big_island),function(n){ any(grepl( c("CDMR|DMR|RDMR"),fData_CGI_big_island[[n]][,"DMR"]))})
##
##         write.table(table(CGI.DMR, clusters.Mean), file=paste0("../../results/clustering/",Disease,"/table_RFG_clusterMean_",type,".txt"))
##
##         ###       clusters.Mean
##         ###CGI.DMR   1   2   3
##         ###  FALSE 706 167  32
##         ###  TRUE  603  65 254
##
##         ###        46% 28% 89%
##
##         ##### DHS associated clusters
##         CGI.DHS <- sapply(1:length(fData_CGI_big_island),function(n){ any(as.logical( fData_CGI_big_island[[n]][,"DHS"]))})
##         CGI.DHS[is.na(CGI.DHS)] <- F
##
##         write.table(table(CGI.DHS, clusters.Mean), file=paste0("../../results/clustering/",Disease,"/table_RFG_clusterMean_",type,".txt"))
##
##         ####       clusters.Mean
##         ####CGI.DHS   1   2   3
##         ####  FALSE 814 128 113
##         ####  TRUE  495 104 173
##
##         ###        38% 45% 60%
##
##         ##### Fantom Regions
##         CGI.Phantom <- sapply(1:length(fData_CGI_big_island),function(n){ tmp <- strsplit(fData_CGI_big_island[[n]][,"Phantom"],":"); 
##                               tmp2<- Reduce('c',sapply(1:length(tmp),function(k){ tmp[[k]][1]}))
##
##                               if (any(grepl("high-CpG",tmp2)) & any(grepl("low-CpG",tmp2)))
##                               { 
##                                       return("both")
##                               } else if (any(grepl("high-CpG",tmp2))){
##                                       return("high-CpG")
##                               } else if (any(grepl("low-CpG",tmp2))){
##                                       return("low-CpG")
##                               } else {
##                                       return("none")
##                               }
##               })
##
##
##         write.table(table(CGI.Phantom, clusters.Mean), file=paste0("../../results/clustering/",Disease,"/table_RFG_clusterMean_",type,".txt"))
##
##         ###            clusters.Mean
##         ### CGI.Phantom   1   2   3
##         ###    both      76   2   4
##         ###    high-CpG 870  26 111
##         ###    low-CpG   22  11  10
##         ###    none     341 193 161
##
##         knownFeatures.df <- data.frame(clusters=clusters.Mean, RFG=CGI.Regulatory_Feature_Group, Enhancer=CGI.Enhancer, DMR=CGI.DMR, DHS=CGI.DHS, Phantom=CGI.Phantom)
##         knownFeatures.df$clusters <- factor(knownFeatures.df$clusters)
##         knownFeatures.df$RFG <- factor(knownFeatures.df$RFG)
##         knownFeatures.df$Enhancer <- factor(knownFeatures.df$Enhancer)
##         knownFeatures.df$DMR <- factor(knownFeatures.df$DMR)
##         knownFeatures.df$DHS <- factor(knownFeatures.df$DHS)
##         #  require('FactoMineR')
##         res.c <- catdes(knownFeatures.df, num.var=1)
##
##         ## TO FINISH

# num_char <- 10
#                 #### Plot Characteristic profiles
#                 unique_clusters <- unique(clusters)
#                 index_characteristics <- lapply(1:length(unique_clusters), function(n){
#                                                 tmp.dist <- distanceMat.Normalized[clusters==unique_clusters[n],clusters==unique_clusters[n]]
#                                                 dist.cluster <- sapply(1:nrow(tmp.dist),function(k){sum(tmp.dist[k,-k]^2)})
#                                                 #dist.cluster <- sapply(1:nrow(tmp.dist),function(k){sum(tmp.dist[k,-k])}) ## sum of dist or square dist?
#                                                 return(which(clusters==unique_clusters[n])[order(dist.cluster)[1:num_char]])
#                                                 })
# 
#                 names(index_characteristics) <- unique_clusters
#                 #save(index_characteristics, file=paste0('../../big_data/CGIs/',Disease,'_',type,'CGIs_characteristics.RData'))
#                 save(index_characteristics, file=paste0('../../big_data/CGIs/',Disease,'_',type,'_',method,'CGIs_characteristics.RData'))
# 
#                 CGI <- load(paste0('../../big_data/CGIs/',Disease,'_',type,'CGIs_',method,'.RData'))
#                 CGI.dat <- get(CGI)
# 
#                 CGI.dat_big_island <- CGI.dat[list_big_island]
# 
#                 load('../../data/processed/fData/fData_CGI_big_island.RData')
# 
#                 Dat.char <- vector('list')
#                 unique_clusters_char <- as.character(unique_clusters) 
# 
#                 for (k in 1:length(unique_clusters))
#                 {
#                         Dat.char[[k]] <- data.frame(methylation=Reduce('c', CGI.dat_big_island[ index_characteristics[[unique_clusters_char[k]]]]) , 
#                                                     position = Reduce('c',lapply(1:length(index_characteristics[[unique_clusters_char[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[unique_clusters_char[k]]][n]]][ ,"MAPINFO"    ]})) , 
#                                                     CGI =  Reduce('c',lapply(1:length(index_characteristics[[unique_clusters_char[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[unique_clusters_char[k]]][n]]][ ,"UCSC_CpG_Islands_Name"]})), 
#                                                     IslandBegin= Reduce('c',lapply(1:length(index_characteristics[[unique_clusters_char[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[unique_clusters_char[k]]][n]]][ ,"IslandBegin"]})), 
#                                                     IslandEnd=Reduce('c',lapply(1:length(index_characteristics[[unique_clusters_char[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[unique_clusters_char[k]]][n]]][ ,"IslandEnd"]})),
#                                                     IslandDist=Reduce('c',lapply(1:length(index_characteristics[[unique_clusters_char[k]]]), function(n){fData_CGI_big_island[[index_characteristics[[unique_clusters_char[k]]][n]]][ ,"IslandDist"]})),
#                                                     cluster=paste0('Cluster ',unique_clusters[k]) )
# 
# 
#                         Dat.char[[k]]$IslandDist[Dat.char[[k]]$IslandDist >1] <- Dat.char[[k]]$IslandDist[Dat.char[[k]]$IslandDist >1]+1000
#                         Dat.char[[k]]$IslandDist[(Dat.char[[k]]$IslandDist <=1) & (Dat.char[[k]]$IslandDist >0)] <-  Dat.char[[k]]$IslandDist[(Dat.char[[k]]$IslandDist <=1) & (Dat.char[[k]]$IslandDist >0)] * 1000
# 
#                         # pdf(paste0("../../results/clustering/",Disease,"/",method,"/cluster_",unique(clusters)[k],"_characteristic_profiles_",type,"_updown.pdf"), width=10, height=10, pointsize=10)
#                         # if (method== "Mean")
#                         # {
#                         # print(ggplot(Dat.char[[k]],aes(x=position,y=methylation))+ geom_point() + geom_line()+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1))
#                         # } else if (method=="Var")
#                         # {
#                         # print(ggplot(Dat.char[[k]],aes(x=position,y=methylation))+ geom_point() + geom_line()+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,0.1))
#                         # }
#                         # dev.off()
#                 }
# 
#                 Dat.char.tot <- Reduce('rbind',Dat.char)
#                 Dat.char.tot$cluster <- factor(Dat.char.tot$cluster, levels= c('Cluster 1','Cluster 2', 'Cluster 3'))
# 
#                 if (method=="Mean")
#                 {
#                         breaks_val <- seq(0,1,0.5)
#                         labels_val <- c(0,0.5,1)
#                 } else 
#                 {
#                         breaks_val <- seq(0,0.1,0.05)
#                         labels_val <- c(0,0.05,0.1)
#                 }
# 
#                 p <- ggplot(Dat.char.tot,aes(x=IslandDist,y=methylation))+ 
#                 geom_point(aes(colour=CGI)) + geom_line(aes(colour=CGI,group=CGI),alpha=0.5)+ 
#                 geom_vline(aes(xintercept=0),colour="#fc8d59",linetype="dashed",size=1) +
#                 geom_vline(aes(xintercept=+1000),colour="#fc8d59",linetype="dashed",size=1)+ 
#                 geom_vline(aes(xintercept=-2000),colour="#91bfdb",linetype="dashed",size=1)+
#                 geom_vline(aes(xintercept=+3000),colour="#91bfdb",linetype="dashed",size=1)+ 
#                 facet_wrap( ~ cluster ,ncol=2) + 
#                 ylab("Methylation") +
#                 xlab('') +
#                 coord_cartesian(ylim=c(0, 0.1)) +
#                 scale_y_continuous(breaks=breaks_val,label=labels_val) +
#                 scale_x_continuous(breaks=c(-4000,-2000,0,1000,3000,5000),label=c('-4kb','-2kb','','','2kb','4kb')) +
#                 theme(panel.grid=element_blank(),
#                       panel.margin = unit(1, "lines"),
#                       # axis.ticks.margin = unit(1, "lines"),
#                       legend.position="none",
#                       text = element_text(size=20),
#                       panel.background=element_rect(fill="white"),
#                       axis.text=element_text(colour="black",size=rel(0.8)),
#                       axis.ticks=element_line(colour="black"),
#                       panel.border=element_rect(fill=NA, colour="black",size=0.7),
#                       axis.title.y = element_text(vjust=0.35),
#                       strip.background = element_rect(colour="black",fill="white"),
#                       axis.line = element_line(colour = "black",size=0.3))
# 
#                 ggsave(paste0("../../results/clustering/",Disease,"/",method,"/clusters_profiles_",type,".pdf"),p, dpi=300)
# 
#                 # clusters_Mean <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type,'_ClustersMean_updown.RData')))
#                 # clusters <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type,'_ClustersMean_updown.RData')))
# 
#                 table(clusters, clusters_Mean)
# 

