compare_prediction_interCancer <- function()
{
        ###### InterCancer prediction comparison
        DiseaseList <- c('BRCA','LUAD','Colon')
        DiseaseList_Normal <- c('BRCA','LUAD')
        # Gene.score.intercancer.melted <- Reduce('rbind', lapply(1:length(DiseaseList), function(k)
        #                                                         {
        #                                                                 tmp <- get(load(paste0('../../big_data/GE_prediction/',DiseaseList[k],'_Cancerous_AllCGIs_CNV.RData')))
        #                                                                 tmp.lasso <- tmp[,"lasso",drop=F]
        #                                                                 tmp.melted <- data.frame(r2.predict=tmp.lasso,disease=DiseaseList[k])
        #                                                                 return(tmp.melted)
        #                                                         }))
        # 

        Gene.score.intercancer.df <- data.frame(Reduce('cbind', lapply(1:length(DiseaseList), function(k)
                                                                       {
                                                                               tmp <- get(load(paste0('../../big_data/GE_prediction/',DiseaseList[k],'_Cancerous_Promoter_table.RData')))
                                                                               Score <- apply(tmp$lasso,1,function(x){mean(x,na.rm=T)})
                                                                               return(Score)
                                                                       })))
        colnames(Gene.score.intercancer.df) <- DiseaseList

        Gene.score.Normal.df <- data.frame(Reduce('cbind', lapply(1:length(DiseaseList_Normal), function(k)
                                                                       {
                                                                               tmp <- get(load(paste0('../../big_data/GE_prediction/',DiseaseList_Normal[k],'_Normal_Promoter_table.RData')))
                                                                               Score <- apply(tmp$lasso,1,function(x){mean(x,na.rm=T)})
                                                                               return(Score)
                                                                       })))
        colnames(Gene.score.Normal.df) <- DiseaseList_Normal

        # Gene.score.intercancer.m <- melt(Gene.score.intercancer.df)

        ####### Do plots
        p.BRCA_LUAD <- ggplot(Gene.score.intercancer.df) + geom_point(aes(x=BRCA,y=LUAD),alpha=0.5) + xlab('R2 breast cancerous') + ylab('R2 lung cancerous') +
                       coord_cartesian(xlim=c(-0.01,1), ylim=c(-0.01, 1)) +
                       scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
                       scale_x_continuous(breaks=seq(0, 1.5, 0.5)) +
                       theme(panel.grid=element_blank(),
                             legend.position="none",
                             text = element_text(size=20),
                             panel.background=element_rect(fill="white"),
                             axis.text=element_text(colour="black",size=rel(0.8)),
                             axis.ticks=element_line(colour="black"),
                             panel.border=element_rect(fill=NA, colour="black",size=0.7),
                             axis.title.y = element_text(vjust=0.35),
                             axis.title.x = element_text(vjust=-1),
                             strip.background = element_rect(colour="black",fill="white",size=0.7),
                             axis.line = element_line(colour = "black",size=0.3),
                             plot.margin = unit(c(1, 1, 2, 0.5), "lines"))

        ggsave('../../results/GE_prediction/InterCancer/BRCA_LUAD_Cancerous.pdf',p.BRCA_LUAD,dpi=300)

        p.BRCA_Colon <- ggplot(Gene.score.intercancer.df) + geom_point(aes(x=BRCA,y=Colon),alpha=0.5) + xlab('R2 breast cancerous') + ylab('R2 colon cancerous') +
                        coord_cartesian(xlim=c(-0.01,1), ylim=c(-0.01, 1)) +
                        scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
                        scale_x_continuous(breaks=seq(0, 1.5, 0.5)) +
                        theme(panel.grid=element_blank(),
                              legend.position="none",
                              text = element_text(size=20),
                              panel.background=element_rect(fill="white"),
                              axis.text=element_text(colour="black",size=rel(0.8)),
                              axis.ticks=element_line(colour="black"),
                              panel.border=element_rect(fill=NA, colour="black",size=0.7),
                              axis.title.y = element_text(vjust=0.35),
                              axis.title.x = element_text(vjust=-1),
                              strip.background = element_rect(colour="black",fill="white",size=0.7),
                              axis.line = element_line(colour = "black",size=0.3),
                              plot.margin = unit(c(1, 1, 2, 0.5), "lines"))

        ggsave('../../results/GE_prediction/InterCancer/BRCA_Colon_Cancerous.pdf',p.BRCA_Colon,dpi=300)

        p.Colon_LUAD <- ggplot(Gene.score.intercancer.df) + geom_point(aes(x=Colon,y=LUAD),alpha=0.5) + xlab('R2 colon cancerous') + ylab('R2 lung cancerous') +
                        coord_cartesian(xlim=c(-0.01,1), ylim=c(-0.01, 1)) +
                        scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
                        scale_x_continuous(breaks=seq(0, 1.5, 0.5)) +
                        theme(panel.grid=element_blank(),
                              legend.position="none",
                              text = element_text(size=20),
                              panel.background=element_rect(fill="white"),
                              axis.text=element_text(colour="black",size=rel(0.8)),
                              axis.ticks=element_line(colour="black"),
                              panel.border=element_rect(fill=NA, colour="black",size=0.7),
                              axis.title.y = element_text(vjust=0.35),
                              axis.title.x = element_text(vjust=-1),
                              strip.background = element_rect(colour="black",fill="white",size=0.7),
                              axis.line = element_line(colour = "black",size=0.3),
                              plot.margin = unit(c(1, 1, 2, 0.5), "lines"))


        ggsave('../../results/GE_prediction/InterCancer/Colon_LUAD_Cancerous.pdf',p.Colon_LUAD,dpi=300)

        p.BRCA_LUAD_Normal <- ggplot(Gene.score.Normal.df) + geom_point(aes(x=BRCA,y=LUAD),alpha=0.5) + xlab('R2 breast normal') + ylab('R2 lung normal') +
                              coord_cartesian(xlim=c(-0.01,1), ylim=c(-0.01, 1)) +
                              scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
                              scale_x_continuous(breaks=seq(0, 1.5, 0.5)) +
                              theme(panel.grid=element_blank(),
                                    legend.position="none",
                                    text = element_text(size=20),
                                    panel.background=element_rect(fill="white"),
                                    axis.text=element_text(colour="black",size=rel(0.8)),
                                    axis.ticks=element_line(colour="black"),
                                    panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                    axis.title.y = element_text(vjust=0.35),
                                    axis.title.x = element_text(vjust=-1),
                                    strip.background = element_rect(colour="black",fill="white",size=0.7),
                                    axis.line = element_line(colour = "black",size=0.3),
                                    plot.margin = unit(c(1, 1, 2, 0.5), "lines"))

        ggsave('../../results/GE_prediction/InterCancer/BRCA_LUAD_Normal.pdf',p.BRCA_LUAD_Normal,dpi=300)

        #qplot(Gene.score.intercancer.df$BRCA, Gene.score.intercancer.df$LUAD)

        summary(lm(BRCA ~ LUAD, Gene.score.intercancer.df))$r.squared
        summary(lm(LUAD ~ Colon, Gene.score.intercancer.df))$r.squared
        summary(lm(Colon ~ BRCA, Gene.score.intercancer.df))$r.squared

        summary(lm(BRCA ~ LUAD, Gene.score.Normal.df))$r.squared


        ### Look at intersection
        ERG <- lapply(1:length(DiseaseList), function(n)
                      { 
                              tmp <- get(load(paste0('../../big_data/GE_prediction', DiseaseList[n],'_ERG.RData')))
                              Genes <- as.character(tmp$Gene)
                              return(Genes)
                      })
        names(ERG) <- DiseaseList

        library(VennDiagram)

        p.Correlation <- venn.diagram(ERG, filename=NULL)

        pdf('../../results/GE_prediction/InterCancer/Venn_Correlation.pdf')
        grid.draw(p.Correlation)
        dev.off()

        #### DO GENE ONTOLOGY 
        # universe <- get(load("../../big_data/GeneList.RData"))

}
##################################
##################################
##################################
# sample.size.list <- c(478,82, 34)
# n.folds <- 3
# Corr.Thresh <- 0.5
# 
# GeneList <- lapply(1:ncol(Gene.score.intercancer.df), function(n)
#                  {
#                          n.size <- ceiling(sample.size.list[n]/n.folds)
#                          tmp <- sapply(1:nrow(Gene.score.intercancer.df), function(k)
#                                        {
#                                                r <- sqrt(Gene.score.intercancer.df[k,n])
#                                                return(r * sqrt( (n.size-2)/ (1-r^2)))
#                                        })
# 
#                          Pvalues <- sapply(1:nrow(Gene.score.intercancer.df), function(k){ 2*pt(-abs(tmp[k]), df=n.size-2)})
#                          Adj.Pvalues <-  p.adjust(Pvalues, method = "BH", n = length(Pvalues)-sum(is.na(Pvalues)))
# 
# 
#                          Genes <- NULL
# 
#                          Genes$Correlation <- na.omit(CommonGenes[which(Gene.score.intercancer.df[,n] > Corr.Thresh)])
#                          Genes$Significance <- na.omit(CommonGenes[which(Adj.Pvalues<0.05)])
#                          return(Genes)
#                  })
# 
# GeneList.Correlation <- lapply(1:length(DiseaseList),function(n)
#                                {
#                                        GeneList[[n]]$Correlation
#                                })
# names(GeneList.Correlation) <- DiseaseList
# 
# GeneList.Significance <- lapply(1:length(DiseaseList),function(n)
#                                {
#                                        GeneList[[n]]$Significance
#                                })
# names(GeneList.Significance) <- DiseaseList
# 
# 
# library(VennDiagram)
# 
# p.Significance <- venn.diagram(GeneList.Significance, filename=NULL)
# 
# pdf('../../results/GE_prediction/InterCancer/Venn_Significance.pdf')
# grid.draw(p.Significance)
# dev.off()


