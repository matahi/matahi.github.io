find_BRCAtype = function (ClinicalInfo) {
        type <- rep("", nrow(ClinicalInfo))
        for (k in 1:nrow(ClinicalInfo)){
                print(paste0(k,"/",nrow(ClinicalInfo)))
                if (is.na(ClinicalInfo$ER[k])&is.na(ClinicalInfo$HER2[k])){
                        type[k] <- "NA"
                } else if (ClinicalInfo$ER[k]&is.na(ClinicalInfo$HER2[k])){
                        type[k] <- "ER+/HER2?"
                } else if (!(ClinicalInfo$ER[k])&is.na(ClinicalInfo$HER2[k])){
                        type[k] <- "ER-/HER2?"
                } else if (ClinicalInfo$ER[k]&ClinicalInfo$HER2[k]){
                        type[k] <- "ER+/HER2+"
                } else if (ClinicalInfo$ER[k]&!(ClinicalInfo$HER2[k])){
                        type[k] <- "ER+/HER2-"
                } else if (!(ClinicalInfo$ER[k])&ClinicalInfo$HER2[k]){
                        type[k] <- "ER-/HER2+"
                } else if ((ClinicalInfo$ER[k]==0)&(ClinicalInfo$HER2[k]==0)){
                        type[k] <- "Triple Negative"
                } else {
                        type[k] <- "?"
                }
        }
        return(type)
}
