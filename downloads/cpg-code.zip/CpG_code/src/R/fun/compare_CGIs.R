compare_CGIs <- function(Disease,type1="Cancerous",type2="Normal", method="L2")
{
        analysis <- "Mean"

        CGI1 <- load(paste0('../../big_data/CGIs/',Disease,'_',type1,'CGIs_',analysis,'.RData'))
        CGI2 <- load(paste0('../../big_data/CGIs/',Disease,'_',type2,'CGIs_',analysis,'.RData'))
        Dat1 <- get(CGI1)
        Dat2 <- get(CGI2)

        if (method=="dtw")
        {
                #distanceMat <- matrix(0,nrow=length(list_big_island),ncol=length(list_big_island))
                distanceMat.Normalized <- matrix(0,nrow=length(list_big_island),ncol=length(list_big_island))

                library(dtw)
                for (k in 1:length(list_big_island))
                {
                        for (l in k:length(list_big_island))
                        {
                                tmp1 <- dtw(na.omit(Dat1[[list_big_island[k]]]),na.omit(Dat2[[list_big_island[l]]]), open.end=T , open.begin=T, step=asymmetric, distance.only=T)
                                distanceMat.Normalized[l,k] <- tmp1$normalizedDistance 
                                distanceMat.Normalized[k,l] <- tmp1$normalizedDistance
                        }
                }

                rownames(distanceMat.Normalized) <- paste0("CGI",1:nrow(distanceMat.Normalized))
                colnames(distanceMat.Normalized) <- paste0("CGI",1:nrow(distanceMat.Normalized))

                assign(paste0(Disease,".",type1,"_",type2,".distanceMat",analysis,".Norm"), distanceMat.Normalized)

                save(list=eval(paste0(Disease,".",type1,"_",type2,".distanceMat",analysis,".Norm")), file=paste0("../../big_data/CGIs/",Disease,"_",type1,"_",type2,"_DistanceMat",analysis,"Norm.RData"))

        } else if (method=="L2")
        {
                distanceCGI.Normalized <- rep(0,length(list_big_island)) 
                for (k in 1:length(list_big_island))
                {
                        distanceCGI.Normalized[k] <- norm(Dat1[[list_big_island[k]]] - Dat2[[list_big_island[k]]],"2")/length(Dat1[[list_big_island[k]]])
                }

                names(distanceCGI.Normalized) <- paste0("CGI",1:length(distanceCGI.Normalized))

                assign(paste0(Disease,".",type1,"_",type2,".distanceCGI",analysis,".Norm"), distanceCGI.Normalized)

                save(list=eval(paste0(Disease,".",type1,"_",type2,".distanceCGI",analysis,".Norm")), file=paste0("../../big_data/CGIs/",Disease,"_",type1,"_",type2,"_DistanceCGI",analysis,"Norm.RData"))
        }



}
