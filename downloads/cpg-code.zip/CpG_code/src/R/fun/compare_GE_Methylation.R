compare_GE_Methylation <- function(DiseaseName,type,preprocessing="CGIs",MethylationAnalysis='mean',Clinical=F)
{
        ## Preprocessing {{{1
        Meth <- load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,preprocessing,'_processed.RData'))
        GE <- load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData'))

        Meth.dat <- get(Meth)
        GE.dat <- get(GE)

        # load clinicalinfo
        if (Clinical) {
                #ClinicalInfo <- load(paste0("../../data/processed/ClinicalAnnotations/TCGA/",DiseaseName,".Clinical.",type,".RData"))
                #Clinical.dat <- get(ClinicalInfo)
                Clinical.dat <- eval(parse(text=paste0(DiseaseName,'.Clinical')))
        }

        # required packages
        require('ggplot2')
        require('reshape2') #for Melt for data.frame
        require('gridExtra') # for plotting several ggplots -> grid.arrange
        require('ggbio')

        ### Statistical Analysis {{{1
        ## Preprocessing of Methylation {{{2
        if (MethylationAnalysis=="mean") { # {{{3 mean
                print('preprocessing Methylation data : using mean...')
                adaptativeMean <- function(x)
                {
                        if (is.null(dim(x))){
                                output <- x
                        } else {
                                output <- apply(x,2,mean)
                        }
                }

                Meth.Value <- lapply(Meth.dat,adaptativeMean)
                Meth.df <- Reduce('rbind',Meth.Value)
                rownames(Meth.df) <- names(Meth.dat)

        } else if (MethylationAnalysis=="") {
                print('preprocessing Methylation data : using method...')
        }


        ## Comparison of Gene Expression and Methylation {{{2
        CommonGenes <- intersect(rownames(Meth.df),rownames(GE.dat)) ## Genes in CommonBetween GE and Meth dataframes
        Meth.df.Names <- sapply(colnames(Meth.df), function(S){substring(S,1,12)})
        GE.dat.Names <- sapply(colnames(GE.dat), function(S){substring(S,1,12)})

        ## There is one duplicated Meth.Info
        test.double <- which(duplicated(Meth.df.Names))[2]
        Meth.df.unique <- Meth.df[,-test.double]
        
        Meth.df.unique.Names <- sapply(colnames(Meth.df.unique), function(S){substring(S,1,12)})
        Reordering <- match(Meth.df.unique.Names,GE.dat.Names)
        # all(Meth.df.unique.Names == GE.dat.Names[Reordering]) -> TRUE 

        #i <- 2
        #Gene <- CommonGenes[i]
        #pdf(paste0('~/Desktop/Test',i,'.pdf'))
        ##scatterplot(Meth.df.unique[Gene,],GE.dat[Gene,Reordering]) ## Using ggplot
        #plot(Meth.df.unique[Gene,],GE.dat[Gene,Reordering]) ## Using ggplot
        #dev.off()

}
