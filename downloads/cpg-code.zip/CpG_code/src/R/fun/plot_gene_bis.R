plot_gene = function (Gene, Disease, type='BOTH') {
        # Betas
        # Id <- which(names(eval(parse(text=paste0(Disease,'.CancerousCGIs'))))==CGI)

        if (type!="BOTH"){
                Betas.Gene <- eval(parse(text=paste0(Disease,'.',type,'Genes')))[[Gene]]
        } else {
                Betas.Cancerous <-eval(parse(text=paste0(Disease,'.CancerousGenes')))[[Gene]]
                Betas.Normal <-eval(parse(text=paste0(Disease,'.NormalGenes')))[[Gene]]
                Betas.Gene <- cbind(Betas.Cancerous,Betas.Normal)
        }
        Betas.Infos <- melt(Betas.Gene)

        # Isoforms
        require(TxDb.Hsapiens.UCSC.hg19.knownGene)
        txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene

        data(genesymbol, package="biovizBase")
        gene.gr <- genesymbol[Gene]

        # fData
        ## !! Careful doesn't work if Matrix has only one probe
        #fData.Infos <- fData450K[rownames(Betas.Island),c("MAPINFO","IslandBegin","IslandEnd")]
        fData.Infos <- fData450K_Gene[[Gene]]

        if (type!="BOTH"){
                data_to_plot <- data.frame(Patient=Betas.Infos$Var2, betas=Betas.Infos$value, Location= fData.Infos$MAPINFO)

                # plot {{{3
                p <- ggplot(data = data_to_plot,aes(x=Location,y=betas))
                p1 <- autoplot(txdb, which=gene.gr)
                p2 <- p + geom_line(aes(colour = Patient)) + geom_point(aes(colour= Patient)) + theme(legend.position="none")
                p2 <- p2 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
                #p2 <- p + geom_smooth() 
                #p2 <- p2 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
                #         multiplot(p1,p2, cols=1)
                grid.arrange(p1,p2,ncol=1)
        } else {
                type <-c(rep('Cancerous',nrow(Betas.Cancerous)*ncol(Betas.Cancerous)),rep('Normal',nrow(Betas.Normal)*ncol(Betas.Normal)))
                data_to_plot <- data.frame(Patient=Betas.Infos$Var2,type=type, betas=Betas.Infos$value, Location= fData.Infos$MAPINFO) 
                # plot {{{3
                p <- ggplot(data = data_to_plot,aes(x=Location,y=betas))

                p2 <- p + geom_line(aes(colour = type, group=Patient)) + geom_point(aes(colour=type)) + theme(legend.position="none")
                #p2 <- p + geom_smooth(aes(colour=type)) 
                #         multiplot(p1,p2, cols=1)
                grid.arrange(p1,p2,ncol=1)
        }


}
