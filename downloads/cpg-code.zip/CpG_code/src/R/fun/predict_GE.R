predict_GE <- function(DiseaseName,type,preprocessing="CGIs",MethylationAnalysis='Promoter')
{
        ## Preprocessing 
        Meth.dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,preprocessing,'_processed.RData')))
        GE.dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData')))

        ## Load fData Infos
        load("../../data/processed/fData/CpGIslands.RData")
        load("../../data/processed/fData/CpGIslands_size.RData")
        load("../../data/processed/fData/CpGIslands_probe_size.RData")
        list_big_island <- which(CpGIslands.probesize >=20)

        # required packages
        require('ggplot2')
        require('reshape2') #for Melt for data.frame
        require('gridExtra') # for plotting several ggplots -> grid.arrange
        require('ggbio')

        ## preprocessing
        Meth.dat <- Meth.dat[list_big_island]

        load('../../big_data/GE_prediction/Tools/CommonGenes.RData')
        Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
        GE.df <- GE.dat[match(CommonGenes,Genes.GE),]

        # n.folds <- 3
        # set.seed(1234)
        # folds <- split( sample( seq(ncol(GE.df)) ), seq(n.folds) )

        ### Statistical Analysis 
        ## Preprocessing of Methylation 
        if (MethylationAnalysis=="Mean") { #  mean
                # print('predicting GE with Methylation MEAN...')
                print('Method : Mean')

                ### Tool Function
                adaptativeMean <- function(x)
                {
                        if (is.null(dim(x))){
                                output <- x
                        } else {
                                output <- apply(x,2,mean)
                        }
                }

                ### Process Methylation Data
                Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
                Meth.dat <- lapply(1:length(Promoter.Assoc),function(n){ Meth.dat[[Promoter.Assoc[n]]]})

                ### Processing Methylation Mean
                Meth.df <- t(sapply(Meth.dat,adaptativeMean))
                rownames(Meth.df) <- CommonGenes

                n.repeats <- 100
                n.folds <- 3
                set.seed(1234)
                folds <- lapply(seq(n.repeats), function(n){split( sample( seq(ncol(GE.df)) ), seq(n.folds) )})

### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                Regression.List <- lapply(seq(n.repeats), function(n.rep)
                                          {
                                                  print(n.rep)
                                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                                       {
                                                                               ###
                                                                               Y <- t(GE.df[n,,drop=F])
                                                                               X <- t(Meth.df[n,,drop=F])

                                                                               Dat <- data.frame(Methylation=X[,1], Expression=Y[,1])

                                                                               ###
                                                                               pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                                      {
                                                                                                              ## 1) do Least Squares 
                                                                                                              Fit.lm <- lm(Expression ~ Methylation, Dat, subset=-folds[[n.rep]][[n_fold]])

                                                                                                              ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                              Y_test <- Y[folds[[n.rep]][[n_fold]],,drop=F ]
                                                                                                              X_test <- X[folds[[n.rep]][[n_fold]],,drop=F]

                                                                                                              Y_predict.LS <- Fit.lm$coefficients[[2]]*X_test + Fit.lm$coefficients[[1]]

                                                                                                              r2.pearson.LS <- cor(Y_test,Y_predict.LS)^2

                                                                                                              return(c('LS'=r2.pearson.LS))
                                                                                                      })

                                                                               pearson.df <- data.frame(t(pearson.fold))

                                                                               return(c('LS'=mean(pearson.df$LS)))
                                                                       })

                                                  Regression.df <- data.frame(t(Regression))

                                                  return(Regression.df)
                                          })

                Regression.table <- Reduce('cbind',lapply(Regression.List,as.numeric))
                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table.RData"))

                # Regression.Final <- as.numeric(Reduce('+',Regression.List)/n.repeats)
                # save(Regression.Final,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,n.repeats,".RData"))

        } else if (MethylationAnalysis=="Promoter") {
                # print('predicting GE with 1 to 1 CGI/GE association')
                print('Method : Promoter')

                ### Process Methylation Data
                Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
                Meth.df <- lapply(1:length(Promoter.Assoc),function(n){ Meth.dat[[Promoter.Assoc[n]]]})

                n.repeats <- 100
                n.folds <- 3
                set.seed(1234)
                folds <- lapply(seq(n.repeats), function(n){split( sample( seq(ncol(GE.df)) ), seq(n.folds) )})

                ### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                Regression.List <- lapply(seq(n.repeats), function(n.rep)
                                          {
                                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                                       {
                                                                               # progress <- n*100/nrow(GE.df)
                                                                               # if (progress %/% GE.df==0)
                                                                               
                                                                               ###
                                                                               Y <- t(GE.df[n,,drop=F])
                                                                               X <- t(Meth.df[[n]])

                                                                               ###
                                                                               pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                                      {
                                                                                                              Y_train <- Y[-folds[[n.rep]][[n_fold]],,drop=F ]
                                                                                                              X_train <- X[-folds[[n.rep]][[n_fold]],]

                                                                                                              Y_test <- Y[folds[[n.rep]][[n_fold]],,drop=F ]
                                                                                                              X_test <- X[folds[[n.rep]][[n_fold]],]

                                                                                                              if (any(Y_train != Y_train[1]))
                                                                                                              {
                                                                                                                      ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                                                      lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min
                                                                                                                      lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0,nfolds=3)$lambda.min

                                                                                                                      ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                                      predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)
                                                                                                                      predictor.ridge <- glmnet(X_train,Y_train,alpha=0,lambda=lambda.ridge)

                                                                                                                      Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)
                                                                                                                      Y_predict.ridge <- predict(predictor.ridge,newx=X_test, s= lambda.ridge)

                                                                                                                      r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                                                                      r2.pearson.ridge <- cor(Y_test,Y_predict.ridge)^2
                                                                                                              } else {
                                                                                                                      r2.pearson.lasso <- NA
                                                                                                                      r2.pearson.ridge <- NA
                                                                                                              }

                                                                                                              return(c('lasso'=r2.pearson.lasso,'ridge'=r2.pearson.ridge))
                                                                                                              # return(c('lasso'=r2.pearson.lasso))
                                                                                                      })

                                                                               pearson.df <- data.frame(t(pearson.fold))

                                                                               #return(c('lasso'=mean(pearson.df$lasso),'ridge'=mean(pearson.df$ridge) ))
                                                                               return(c('lasso'=mean(na.omit(pearson.df$lasso)),'ridge'=mean(na.omit(pearson.df$ridge) )))
                                                                               # return(c('lasso'=mean(na.omit(pearson.df$lasso))))
                                                                       })

                                                  Regression.df <- data.frame(t(Regression))

                                                  return(Regression.df)
                                          })

                Regression.table <- NULL
                Regression.table$lasso <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$lasso}) )
                Regression.table$ridge <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$ridge}) )
                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table.RData"))

                Regression.Final <- data.frame(sapply(Regression.table, function(x){apply(x,1,function(s){mean(s,na.rm=T)})}))
                save(Regression.Final,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_",n.repeats,".RData"))

                
        } else if (MethylationAnalysis=="AllCGIs") {
                # print('predicting GE with all associated CGIs')
                print('Method : Promoter')

                ### Process Methylation Data
                AllCGIs.Assoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
                Meth.df <- lapply(1:length(AllCGIs.Assoc),function(n){ Reduce('rbind',Meth.dat[AllCGIs.Assoc[[n]]])})

                n.repeats <- 100
                n.folds <- 3
                set.seed(1234)
                folds <- lapply(seq(n.repeats), function(n){split( sample( seq(ncol(GE.df)) ), seq(n.folds) )})


                ### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                Regression.List <- lapply(seq(n.repeats), function(n.rep)
                                          {
                                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                                       {
                                                                               ###
                                                                               Y <- t(GE.df[n,,drop=F])
                                                                               X <- t(Meth.df[[n]])

                                                                               ###
                                                                               pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                                      {
                                                                                                              Y_train <- Y[-folds[[n.rep]][[n_fold]],,drop=F ]
                                                                                                              X_train <- X[-folds[[n.rep]][[n_fold]],]

                                                                                                              Y_test <- Y[folds[[n.rep]][[n_fold]],,drop=F ]
                                                                                                              X_test <- X[folds[[n.rep]][[n_fold]],]

                                                                                                              if (any(Y_train != Y_train[1]))
                                                                                                              {
                                                                                                                      ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                                                      lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min
                                                                                                                      lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0,nfolds=3)$lambda.min

                                                                                                                      ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                                      predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)
                                                                                                                      predictor.ridge <- glmnet(X_train,Y_train,alpha=0,lambda=lambda.ridge)

                                                                                                                      Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)
                                                                                                                      Y_predict.ridge <- predict(predictor.ridge,newx=X_test, s= lambda.ridge)

                                                                                                                      r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                                                                      r2.pearson.ridge <- cor(Y_test,Y_predict.ridge)^2
                                                                                                              } else {
                                                                                                                      r2.pearson.lasso <- NA
                                                                                                                      r2.pearson.ridge <- NA
                                                                                                              }

                                                                                                              return(c('lasso'=r2.pearson.lasso,'ridge'=r2.pearson.ridge))
                                                                                                              # return(c('lasso'=r2.pearson.lasso))
                                                                                                      })

                                                                               pearson.df <- data.frame(t(pearson.fold))

                                                                               #return(c('lasso'=mean(pearson.df$lasso),'ridge'=mean(pearson.df$ridge) ))
                                                                               return(c('lasso'=mean(na.omit(pearson.df$lasso)),'ridge'=mean(na.omit(pearson.df$ridge) )))
                                                                               # return(c('lasso'=mean(na.omit(pearson.df$lasso))))
                                                                       })

                                                  Regression.df <- data.frame(t(Regression))

                                                  return(Regression.df)
                                          })

                Regression.table <- NULL
                Regression.table$lasso <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$lasso}) )
                Regression.table$ridge <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$ridge}) )
                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table.RData"))

                Regression.Final <- data.frame(sapply(Regression.table, function(x){apply(x,1,function(s){mean(s,na.rm=T)})}))
                save(Regression.Final,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_",n.repeats,".RData"))


        }  

}
