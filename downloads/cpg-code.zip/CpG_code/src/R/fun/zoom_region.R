zoom_region = function (df) {
        low_pos <- min(na.omit(df$IslandBegin))
        max_pos <- max(na.omit(df$IslandEnd))

        size_region <- max_pos - low_pos

        return(c(low_pos - size_region/10, max_pos + size_region/10))
}
