calculate_Mean_PC <- function(Disease,type,analysis=c('Mean','Var') , proc=T)
{
        ## Analysis will include PC1 and PC2 soon

        if (proc)
        {
                proc <- "_processed"
        } else {
                proc <- ""
        }

        load(paste0('../../data/processed/Methylation/TCGA/',Disease,'/',type,'CGIs',proc,'.RData'))
        Dat.CGIs <- eval(parse(text=paste0(Disease,'.',type,'CGIs')))

        source('lib/toolkit/adaptiveStats.R')
        for (method in analysis)
        {
                AdaptativeMethod <- eval(parse(text=paste0("adaptative", method)))
                Dat <- lapply(Dat.CGIs, AdaptativeMethod)

                assign(paste0(Disease,".",type,"CGIs.",method), Dat)

                save(list=eval(paste0(Disease,".",type,"CGIs.",method)), file=paste0("../../big_data/CGIs/",Disease,"_",type,"CGIs_",method,".RData"))
        }

}
