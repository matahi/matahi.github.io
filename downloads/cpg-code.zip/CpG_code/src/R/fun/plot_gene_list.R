plot_gene <- function(Gene,Disease,type="Cancerous",ClinicalInfo=NULL, features=NULL,fData=fData450K_Gene)
{
        ## Library Loading 
        require(ggbio)
        require(GenomicRanges)
        source("fun/zoom_region.R")

        ### Processing 
        require(TxDb.Hsapiens.UCSC.hg19.knownGene)
        txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene

        data(genesymbol, package="biovizBase")
        gene.gr <- genesymbol[Gene]

        ## Find Gene probes -> Is there a faster way????
        ## Data Processing 
        Dat <- eval(parse(text=paste0(Disease,".",type,"Genes")))

        Dat.Gene <- Dat[[Gene]]
        fData.Gene <- fData450K_Gene[[Gene]]
        #         Pos <- grep(Gene,fData450K[,"UCSC_RefGene_Name"])
        #         fData.Gene <- fData450K[Pos,]

        #Probes <- fData[Pos,"Name"]
        #Betas <- Dat[Probes,]
        #missingSample <- which(is.na(Betas),arr.ind=TRUE)
        #if (nrow(missingSample)!=0){
        #        Betas <- Betas[,-unique(missingSample[,2])]
        #}

        Dat.df <- melt(Dat.Gene)
        if (is.null(ClinicalInfo))
        {
                df <- data.frame(x = fData.Gene[,"MAPINFO"], methylation = Dat.df$value, sample = Dat.df$Var2)
                p2 <- ggplot(df) + geom_line(aes(x= x, y= methylation, colour=sample)) + geom_point(aes(x= x, y= methylation, colour=sample)) +
                geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + 
                geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"]))) +
                theme(legend.position="none")  

                p1 <- autoplot(txdb, which=gene.gr)

                #                 pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,'.pdf'), width=10, height=10, pointsize=1)
                pdf('~/Desktop/GeneTest.pdf', width=10, height=10, pointsize=1)
                print(tracks(p1, p2))
                dev.off()

                promoterRegion <- zoom_region(fData.Gene) # Find a way to automatize the zoom on the promoter regions

                pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,'promoter.pdf'), width=10, height=10, pointsize=1)
                print(tracks(p1, p2) + xlim(promoterRegion))
                dev.off()
        } else {
                df <- data.frame(x = fData[Pos,"MAPINFO"], betas = Betas.df$value, sample = Betas.df$Var2 )
                NewInfo <- ClinicalInfo[as.character(df$sample),features] 
                df <- cbind(df,NewInfo)

                for (feature in features){
                        if (length(unique(na.omit(fData.Gene[,"IslandBegin"])))!=0){
                                p2 <- ggplot(df, aes_string(x="x",y="betas",colour=paste0("as.factor(",feature,")"))) + geom_line(aes(group=sample)) + geom_point(aes(group=sample)) +
                                geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + 
                                geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"])))# +
                                #                         theme(legend.position="none")  

                                p1 <- autoplot(txdb, which=gene.gr)

                                pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,"_",feature,'.pdf'), width=10, height=10, pointsize=1)
                                print(tracks(p1, p2))
                                dev.off()


                                promoterRegion <- zoom_region(fData.Gene) # Find a way to automatize the zoom on the promoter regions

                                pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,"_",feature,'promoter.pdf'), width=10, height=10, pointsize=1)
                                print(tracks(p1, p2) + xlim(promoterRegion))
                                dev.off()
                        }else{
                                p2 <- ggplot(df, aes_string(x="x",y="betas",colour=paste0("as.factor(",feature,")"))) + geom_line(aes(group=sample)) + geom_point(aes(group=sample)) 

                                p1 <- autoplot(txdb, which=gene.gr)

                                pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,"_",feature,'.pdf'), width=10, height=10, pointsize=1)
                                print(tracks(p1, p2))
                                dev.off()
                        }
                }

                # multiplot(p1,p2, cols=1)
                # grid.arrange(p1,p2,ncol=1)

                #return(Betas)
        }
}
