reduce_LS <- function(LS.out)
{
  out <- Reduce('rbind',lapply(1:length(LS.out), function(k){data.frame(r.squared=LS.out[[k]]$r.squared,
                                                                        adj.r.squared=LS.out[[k]]$adj.r.squared,
                                                                        p.value=pf(LS.out[[k]]$fstatistic[1], LS.out[[k]]$fstatistic[2], LS.out[[k]]$fstatistic[3], lower.tail=F))
                                                            }))
  out$adj.p.value <- p.adjust(out$p.value, method="BH", n= nrow(out))

  return(out)
     
}

reduce_regression <- function(regression.out)
{
  out <- Reduce('rbind',lapply(1:length(regression.out), function(k){data.frame(r.squared=regression.out[[k]]$r.squared,
                                                                                r2.pearson=as.numeric(regression.out[[k]]$r2.pearson))
                                                                        
                                                            }))
  return(out)
}

# BRCA.Cancerous.Pattern.Ridge.reduced <- Reduce('rbind',lapply(1:length(BRCA.Cancerous.Pattern.Ridge), function(n){data.frame(min.cvm=min(BRCA.Cancerous.Pattern.Ridge[[n]]$cvm),
#                                                                                                                              r.squared=BRCA.Cancerous.Pattern.Ridge[[n]]$r.squared,
#                                                                                                                              adj.r.squared=BRCA.Cancerous.Pattern.Ridge[[n]]$adj.r.squared,
#                                                                                                                              pearson=as.numeric(BRCA.Cancerous.Pattern.Ridge[[n]]$pearson)
#                                                                                                                              )}))
# 
