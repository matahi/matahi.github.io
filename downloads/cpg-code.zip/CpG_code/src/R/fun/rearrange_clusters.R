rearrange_clusters <- function(clusters)
{
        out <- clusters
        tmp.table <- table(clusters)
        tmp.table_reordered <- tmp.table[order(tmp.table, decreasing=T)]

        for (i in 1:length(tmp.table))
        {
                out[clusters==names(tmp.table_reordered)[i]] <- i
        }


        return(out)

}
