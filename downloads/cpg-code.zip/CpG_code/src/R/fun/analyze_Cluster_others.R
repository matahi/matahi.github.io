analyze_Cluster_Others  = function (DiseaseName,clust) {

        DiseaseName <- "BRCA"
        DiseaseName <- "Colon"
        DiseaseName <- "LUAD"
        # clust <- "1"
        # clust <- "2"
        # clust <- "3"
        clust <- "3up"
        # clust <- "4down"

        list_big_island <-which(CpGIslands.probesize>=20)

        ##### Methylation Behaviour
        Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown_bis.RData')))
        Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs.RData')))[list_big_island]

        Meth.clust <- Meth.Dat[Clusters.Meth==clust]
        CGI.Sum.Methylation <- sapply(1:length(Meth.clust), function(n)
                                  {
                                          return(apply(Meth.clust[[n]],2,function(x){mean(x,na.rm=T)}))
                                  })

        ##### 
        Clinical <- get(load(paste0('../../data/processed/ClinicalAnnotations/TCGA/',DiseaseName,'.Clinical.RData'))) #### NEW SURVIVAL DATA
        FollowUp <- get(load(paste0('../../data/processed/ClinicalAnnotations/TCGA/',DiseaseName,'.FollowUp.RData'))) #### NEW SURVIVAL DATA

        Clinical.processed <- Clinical[match(substring(rownames(CGI.Sum.Methylation),1,12), Clinical$bcr_patient_barcode),]  # for LUAD and Colon.Clinical.Cancerous
        FollowUp.processed <- FollowUp[match(substring(rownames(CGI.Sum.Methylation),1,12), FollowUp$bcr_patient_barcode),]  # for LUAD and Colon.Clinical.Cancerous

        FollowUp.processed[ which(FollowUp.processed[,"vital_status"] == "[Not Available]"), "vital_status"] <- NA

        #####
        Clinical.cbioportal <- get(load(paste0('../../data/processed/ClinicalAnnotations/TCGA/',DiseaseName,'_Clinical_cBioPortal.RData')))
        Clinical.cbioportal.processed <- Clinical.cbioportal[match(substring(rownames(CGI.Sum.Methylation),1,12), substring(rownames(Clinical.cbioportal),1,12)),]


        ColSideColors.Survival <- as.character(FollowUp.processed[,"vital_status"])
        ColSideColors.Survival[is.na(ColSideColors.Survival)] <- "grey"
        ColSideColors.Survival[ColSideColors.Survival=="Alive"] <- "green"
        ColSideColors.Survival[ColSideColors.Survival=="Dead"] <- "red"
        ColSideColors.Survival <- as.matrix(ColSideColors.Survival)

        ColSideColors.total <- ColSideColors.Survival

        source('lib/heatmap.3.R')
        require('RColorBrewer')
        colmap <- colorRampPalette(c('blue','black','yellow'))(100)

        ### Do Heatmap Methylation
        pdf(paste0('~/Desktop/',DiseaseName,'_heatmap_Cluster',clust,'.pdf'))
        p <- heatmap.3(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="both", trace="none",col=colmap, ColSideColors=ColSideColors.total,  Key="Methylation",labRow=NA,labCol=NA)
        dev.off()

        if (DiseaseName=="Colon")
        {
                CIMP.high <- labels(p$colDendrogram[[1]])
                CIMP.low <- labels(p$colDendrogram[[2]][[1]]) 
                CIMP.intermediate <- labels(p$colDendrogram[[2]][[2]]) 
        } else if (DiseaseName == "LUAD") {
                CIMP.low <- labels(p$colDendrogram[[1]])
                CIMP.high <- labels(p$colDendrogram[[2]][[1]]) 
                CIMP.intermediate <- labels(p$colDendrogram[[2]][[2]]) 
        } else if (DiseaseName == "BRCA") {
                CIMP.low <- labels(p$colDendrogram[[1]])
                CIMP.high <- labels(p$colDendrogram[[2]][[1]]) 
                CIMP.intermediate <- labels(p$colDendrogram[[2]][[2]]) 
        }


        ##
        # Dat <- FollowUp.processed 
        Dat <- Clinical.processed 
        Dat$death_days_to <- as.numeric(as.character(Dat$death_days_to))
        FollowUp.processed$death_days_to <- as.numeric(as.character(FollowUp.processed$death_days_to))
        Clinical.processed$death_days_to <- as.numeric(as.character(Clinical.processed$death_days_to))

        for (k in 1:nrow(Dat))
        {
                if (is.na(FollowUp.processed$vital_status[k])|(is.na(Clinical.processed$vital_status[k])))
                {
                } else if ((FollowUp.processed$vital_status[k]=="Dead")&(Clinical.processed$vital_status[k]=="Alive"))
                {
                        print("using Follow Up Data")
                        print(k)

                        Dat$vital_status[k] <- "Dead"
                        Dat$death_days_to[k] <- FollowUp.processed$death_days_to[k]
                }
        }

        ###
        Dat$last_contact_days_to[Dat$last_contact_days_to == "[Not Available]"] <- NA
        Dat$death_days_to[Dat$death_days_to == "[Not Available]"] <- NA

        ###
        Dat$CIMP <- rep("low",nrow(Clinical.processed))
        Dat$CIMP[ rownames(CGI.Sum.Methylation) %in% CIMP.high] <- "high" 
        Dat$CIMP[ rownames(CGI.Sum.Methylation) %in% CIMP.intermediate] <- "intermediate" 

        ##
        # tmp1.survival <- as.numeric(as.character(Clinical.processed$last_contact_days_to))
        # tmp1.death <- as.numeric(as.character(Clinical.processed$death_days_to))
        # tmp2.survival <- as.numeric(as.character(FollowUp.processed$last_contact_days_to))
        # tmp2.death <- as.numeric(as.character(FollowUp.processed$death_days_to))
        # tmp3 <- Clinical.cbioportal.processed$OS_MONTHS

        # qplot(tmp1.survival,tmp2.survival) + geom_abline(a=0,b=1, col="red")
        # qplot(tmp1.death,tmp2.death) + geom_abline(a=0,b=1, col="red")

        # qplot(tmp2.survival,tmp3) 
        # qplot(tmp2.death,tmp3) 

        # qplot(tmp1.survival,tmp3) 
        # qplot(tmp1.death,tmp3) 

        if (DiseaseName == "Colon")
        {
                Dat$Time <- sapply(1:nrow(Dat), function(k)
                                   {
                                           
                                           if (is.na(Dat$vital_status[k]))
                                           {
                                                   return(NA)
                                           } else if ( (Dat$vital_status[k])=="Alive")
                                           {
                                                   return(as.numeric(as.character(Dat$last_contact_days_to[k])))
                                           } else if (Dat$vital_status[k]=="Dead")
                                           {
                                                   return(as.numeric(as.character(Dat$death_days_to[k])))
                                           } else {
                                                   print('error')
                                           }
                                   })
        } else if (DiseaseName == "LUAD") 
        {
                Dat$Time <- sapply(1:nrow(Dat), function(k)
                                   {
                                           if (is.na(Dat$vital_status[k]))
                                           {
                                                   return(NA)
                                           } else if ( (Dat$vital_status[k])=="Alive")
                                           {
                                                   return(as.numeric(as.character(Dat$last_contact_days_to[k])))
                                           } else if (Dat$vital_status[k]=="Dead")
                                           {
                                                   return(as.numeric(as.character(Dat$death_days_to[k])))
                                           } 
                                   })
        } else if (DiseaseName == "BRCA")
        {
                Dat$Time <- sapply(1:nrow(Dat), function(k)
                                   {
                                           if (k==478)
                                           {
                                                   return(Clinical.processed[k,"last_contact_days_to"])
                                           } else if (is.na(Dat$vital_status[k]))
                                           {
                                                   return(NA)
                                           } else if ( (Dat$vital_status[k])=="Alive")
                                           {
                                                   return(as.numeric(as.character(Dat$last_contact_days_to[k])))
                                           } else if (Dat$vital_status[k]=="Dead")
                                           {
                                                   return(as.numeric(as.character(Dat$death_days_to[k])))
                                           } 
                                   })
        }

        # table(is.na(Dat$Time), is.na(tmp3))

        Censor <- 365*5 ## 5 years
        Dat$Time_cens <- Dat$Time
        Dat$Time_cens[Dat$Time>=Censor] <- Censor

        Dat$vital_status_cens <- Dat$vital_status
        Dat$vital_status_cens[Dat$Time>=Censor] <- "Alive"

        ##
        library(survival)
        source('lib/ggsurv.R')
        Dat.surv.CIMP <- survfit(Surv(Time,vital_status!="Alive") ~ CIMP, data = Dat)
        cox.CIMP <- coxph(Surv(Time,vital_status!="Alive") ~ factor(CIMP), data = Dat)

        Dat.surv.CIMP.cens <- survfit(Surv(Time_cens,vital_status_cens!="Alive") ~ CIMP, data = Dat)
        cox.CIMP.cens <- coxph(Surv(Time_cens,vital_status_cens!="Alive") ~ factor(CIMP), data = Dat)


        # print(ggsurv(Dat.surv.CIMP)+ylim(0,1) )
        # dev.off()

        pdf(paste0('~/Desktop/',DiseaseName,'_Survival_cluster3up.pdf'))
        print(ggsurv(Dat.surv.CIMP.cens)+ylim(0,1) )
        dev.off()

        ########################################################################################################################################################################################################

        ### ### Do Heatmap
        ### # pdf(paste0('../../results/clustering/',DiseaseName,'/heatmap_Cluster',clust,'.pdf'))
        ### pdf(paste0('~/Desktop/heatmap_GE_Cluster',clust,'.pdf'))
        ### #heatmap.3(GE.Clust,hclustfun= function(x){hclust(x,method="ward")},  scale="row", dendrogram="both", trace="none",col=greenred(100), ColSideColors=ColSideColors.total,Key="Gene Expression",
        ### heatmap.3(GE.Clust,hclustfun= function(x){hclust(x,method="ward")},  scale="row", dendrogram="both", trace="none",col=greenred(100), breaks=seq(-5,5,length.out=101), ColSideColors=ColSideColors.total,Key="Gene Expression",
        ###           labRow=NA,labCol=NA)
        ### dev.off()

        ### ### Do Full Plot
        ### fData.clust <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))[Clusters.Meth==clust]

        ### num_char <- 4
        ### n <- length(Meth.clust)
        ### n.folds <- ceiling(length(Meth.clust)/num_char)
        ### idx <- split( seq( n ), seq(n.folds) )

        ### Clinical.Info <- rep(NA, nrow(BRCA.Clinical.processed))

        ### for (k in 1:length(Clinical.Info))
        ### {
        ###         if (is.na(BRCA.Clinical.processed$ER[k]))
        ###         {
        ###         } else if (BRCA.Clinical.processed$ER[k]==1)
        ###         {
        ###                 Clinical.Info[k] <- "ER+"
        ###         } else if (is.na(BRCA.Clinical.processed$HER2[k]))
        ###         {
        ###                 Clinical.Info[k] <- "ER-"
        ###         } else if ((BRCA.Clinical.processed$ER[k]==0) & (BRCA.Clinical.processed$HER2[k]==0))
        ###         {
        ###                 Clinical.Info[k] <- "Triple Neg"
        ###         } else if ((BRCA.Clinical.processed$ER[k]==0) & (BRCA.Clinical.processed$HER2[k]==1))
        ###         {
        ###                 Clinical.Info[k] <- "ER-/HER2+"
        ###         }
        ### }

        ### ### 
        ### # k <- 1
        ### # index_characteristics <- get(load(paste0('../../big_data/CGIs/',Disease,'_CancerousCGIs_characteristics.RData')))
        ### # Clusters.clust <- which(Clusters.Meth==clust)
        ### # Index <- match(index_characteristics[[clust]][1:4],Clusters.clust)

        ### ### ADD NORMAL as control !


        ### for (k in 1:length(idx))
        ### {
        ###         ##
        ###         k <- 1

        ###         Index <- idx[[k]]

        ###         Dat.clust <- data.frame(methylation=Reduce('c',Reduce('rbind', Meth.clust[ Index  ])) , 
        ###                               patient = rep(1:nrow(CGI.Sum.Methylation), each= sum(sapply(fData.clust[Index],nrow))),
        ###                               position = Reduce('c',lapply(1:length(Index), function(n){fData.clust[[ Index[n]]][ ,"MAPINFO"    ]})) , 
        ###                               CGI =  Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
        ###                               IslandBegin= Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandBegin"]})), 
        ###                               IslandEnd=Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandEnd"]})),
        ###                               Clinical.Info= rep(Clinical.Info, each=sum(sapply(fData.clust[Index],nrow))))

        ###         pdf(paste0("../../results/clustering/",Disease,"/Mean/Cluster",clust,"_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
        ###         print(ggplot(Dat.clust,aes(x=position,y=methylation))+geom_point(aes(group=patient,colour=Clinical.Info)) + geom_line(aes(group=patient,colour=Clinical.Info)) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( Clinical.Info ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(axis.text.x=element_blank()))
        ###         dev.off()
        ### }

        ### ####################################################################################################
        ### ####################################################################################################
        ### ### Use Normal as Control
        ### ####################################################################################################
        ### ####################################################################################################

        ### Meth.Control <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/NormalCGIs_processed.RData')))[list_big_island]
        ### Meth.clust.Control <- Meth.Control[Clusters.Meth==clust]

        ### Meth.tot <- lapply(1:length(Meth.clust), function(n){cbind(Meth.clust[[n]], Meth.clust.Control[[n]])})

        ### CGI.Sum.Methylation <- sapply(1:length(Meth.tot), function(n)
        ###                           {
        ###                                   return(apply(Meth.tot[[n]],2,sum))
        ###                           })


        ### BRCA.Clinical <- get(load('../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData'))
        ### BRCA.Clinical.processed <- BRCA.Clinical[match(colnames(Meth.clust[[1]]), rownames(BRCA.Clinical)),]
        ### for (k in 1:ncol(BRCA.Clinical.processed))
        ### {
        ###         if (is.factor(BRCA.Clinical.processed[1,k]))
        ###         {
        ###                 BRCA.Clinical.processed[,k] <- as.character(BRCA.Clinical.processed[,k])
        ###         }
        ### }

        ### BRCA.Clinical.normal <- data.frame(matrix(-1,nrow=ncol(Meth.clust.Control[[1]]),ncol=ncol(BRCA.Clinical.processed)))
        ### colnames(BRCA.Clinical.normal) <- colnames(BRCA.Clinical.processed)
        ### 
        ### BRCA.Clinical.tot <- rbind(BRCA.Clinical.processed,BRCA.Clinical.normal)


        ### #####
        ### ColSideColors <- BRCA.Clinical.tot[,c('ER','PR','HER2')]
        ### ColSideColors[is.na(ColSideColors)] <- "grey"
        ### ColSideColors[ColSideColors=="0"] <- "black"
        ### ColSideColors[ColSideColors=="1"] <- "white"
        ### ColSideColors[ColSideColors=="-1"] <- "green"
        ### ColSideColors <- as.matrix(ColSideColors)

        ### source('lib/heatmap.3.R')
        ### ### Do Heatmap
        ### pdf(paste0('../../results/clustering/',DiseaseName,'/heatmap_Cluster',clust,'.pdf'))
        ### heatmap.3(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},distfun=function(x){as.dist((1-cor(t(x)))/2)},  scale="row", dendrogram="both", trace="none",col=redgreen, ColSideColors=ColSideColors)
        ### dev.off()

        ### ### Do Full Plot
        ### fData.clust <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))[Clusters.Meth==clust]

        ### num_char <- 4
        ### n <- length(Meth.clust)
        ### n.folds <- ceiling(length(Meth.clust)/num_char)
        ### idx <- split( seq( n ), seq(n.folds) )

        ### Clinical.Info <- rep(NA, nrow(BRCA.Clinical.tot))

        ### for (k in 1:length(Clinical.Info))
        ### {
        ###         if (is.na(BRCA.Clinical.tot$ER[k]))
        ###         {
        ###         } else if (BRCA.Clinical.tot$ER[k]==1)
        ###         {
        ###                 Clinical.Info[k] <- "ER+"
        ###         } else if (BRCA.Clinical.tot$ER[k]==-1)
        ###         {
        ###                 Clinical.Info[k] <- "Normal"
        ###         } else if (is.na(BRCA.Clinical.tot$HER2[k]))
        ###         {
        ###                 Clinical.Info[k] <- "ER-"
        ###         } else if ((BRCA.Clinical.tot$ER[k]==0) & (BRCA.Clinical.tot$HER2[k]==0))
        ###         {
        ###                 Clinical.Info[k] <- "Triple Neg"
        ###         } else if ((BRCA.Clinical.tot$ER[k]==0) & (BRCA.Clinical.tot$HER2[k]==1))
        ###         {
        ###                 Clinical.Info[k] <- "ER-/HER2+"
        ###         }
        ### }

        ### ### 
        ### # k <- 1
        ### # index_characteristics <- get(load(paste0('../../big_data/CGIs/',Disease,'_CancerousCGIs_characteristics.RData')))
        ### # Clusters.clust <- which(Clusters.Meth==clust)
        ### # Index <- match(index_characteristics[[clust]][1:4],Clusters.clust)

        ### ### ADD NORMAL as control !


        ### for (k in 1:length(idx))
        ### {
        ###         ##
        ###         k <- 1

        ###         Index <- idx[[k]]

        ###         Dat.clust <- data.frame(methylation=Reduce('c',Reduce('rbind', Meth.tot[ Index  ])) , 
        ###                               patient = rep(1:nrow(CGI.Sum.Methylation), each= sum(sapply(fData.clust[Index],nrow))),
        ###                               position = Reduce('c',lapply(1:length(Index), function(n){fData.clust[[ Index[n]]][ ,"MAPINFO"    ]})) , 
        ###                               CGI =  Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
        ###                               IslandBegin= Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandBegin"]})), 
        ###                               IslandEnd=Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandEnd"]})),
        ###                               Clinical.Info= rep(Clinical.Info, each=sum(sapply(fData.clust[Index],nrow))))

        ###         pdf(paste0("../../results/clustering/",Disease,"/Mean/Cluster",clust,"_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
        ###         print(ggplot(Dat.clust,aes(x=position,y=methylation))+geom_point(aes(group=patient,colour=Clinical.Info)) + geom_line(aes(group=patient,colour=Clinical.Info)) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( Clinical.Info ~ CGI, scales="free", ncol=5) + ylim(0,1) + theme(axis.text.x=element_blank()))
        ###         dev.off()

        ### }





}
