linear_model <- function(DiseaseName,type,preprocessing="CGIs",MethylationAnalysis='pattern',n.folds=3)
{
        ## Preprocessing {{{1
        Meth <- load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,preprocessing,'_processed.RData'))
        GE <- load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData'))

        Meth.dat <- get(Meth)
        GE.dat <- get(GE)

        # required packages
        require('ggplot2')
        require('reshape2') #for Melt for data.frame
        require('gridExtra') # for plotting several ggplots -> grid.arrange
        require('ggbio')

        ### Statistical Analysis {{{1
        ## Preprocessing of Methylation {{{2
        if (MethylationAnalysis=="mean") { # {{{3 mean
                print('predicting GE with Methylation MEAN...')
                adaptativeMean <- function(x)
                {
                        if (is.null(dim(x))){
                                output <- x
                        } else {
                                output <- apply(x,2,mean)
                        }
                }

                Meth.dat.big_island <- Meth.dat[list_big_island]

                Meth.Value <- lapply(Meth.dat.big_island,adaptativeMean)
                Meth.df <- Reduce('rbind',Meth.Value)
                rownames(Meth.df) <- names(Meth.dat.big_island)

                load("../../data/processed/fData/fData_CGI.RData") 
                fData.big_island <- fData_CGI[list_big_island]
                Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

                # Find common genes between methylation and expression
                Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
                CommonGenes <- intersect(Genes.GE, Genes.big_island)
                ######
                GE.New <- GE.dat[match(CommonGenes,Genes.GE),]
                load("../../big_data/AssocIslandGenes.RData")
                Meth.New <- t(sapply(1:length(CommonGenes), function(n) { return( Meth.df[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1] , ]  ) })) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better. !!!!! Careful !!!!!!!

                ### For GE = f(Mean_Methylation) we only look at least.squares
                least.squares <- lapply(1:nrow(GE.New), function(k){ 
                                                                    Y <- t(GE.New[k,,drop=F    ])
                                                                    X <- t(Meth.New[k,,drop=F]) # in our case n >= p although verify
                                                                    Dat <- cbind(Y,X)
                                                                    colnames(Dat)[1] <- "gene"
                                                                    Dat <- data.frame(Dat)
                                                                    lm.predict <- lm( gene ~ ., data=Dat)
                                                                    lm.infos <- list(r.squared=summary(lm.predict)$r.squared, adj.r.squared=summary(lm.predict)$adj.r.squared, fstatistic=summary(lm.predict)$fstatistic)
                                                                    return(lm.infos)})
                names(least.squares) <- CommonGenes

                save(least.squares,file=paste0("../../big_data/GE_prediction/",DiseaseName,"_",type,"_least_squares_",MethylationAnalysis,".RData"))

        } else if (MethylationAnalysis=="pattern") {
                print('predicting GE with 1 to 1 CGI/GE association')

                # First take only big islands
                Meth.df <- Meth.dat[list_big_island]

                load("../../data/processed/fData/fData_CGI.RData") 
                fData.big_island <- fData_CGI[list_big_island]
                Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

                # Find common genes between methylation and expression
                Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
                CommonGenes <- intersect(Genes.GE, Genes.big_island)
                ######
                GE.New <- GE.dat[match(CommonGenes,Genes.GE),]
                load("../../big_data/AssocIslandGenes.RData")

                Meth.New <- lapply(1:length(CommonGenes), function(n) { return( Meth.df[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]] ]  ) }) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better.

                ### Train a least square model of GE = f(Methylation) for each gene and calculate the performance
                least.squares <- lapply(1:nrow(GE.New), function(k){ 
                                                                    print(k)
                                                                    Y <- t(GE.New[k,,drop=F    ])
                                                                    X <- t(Meth.New[[k]][[1]]) 
                                                                    Dat <- cbind(Y,X)
                                                                    colnames(Dat)[1] <- "gene"
                                                                    Dat <- data.frame(Dat)
                                                                    lm.predict <- lm( gene ~ ., data=Dat)
                                                                    lm.infos <- list(r.squared=summary(lm.predict)$r.squared, adj.r.squared=summary(lm.predict)$adj.r.squared, fstatistic=summary(lm.predict)$fstatistic)
                                                                    return(lm.infos)})
                names(least.squares) <- CommonGenes

                save(least.squares,file=paste0("../../big_data/GE_prediction/",DiseaseName,"_",type,"_least_squares_",MethylationAnalysis,".RData"))

                ### Train a linear ridge regression of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                # library(SPAMS)
                # n.folds <- 10
                n <- ncol(GE.New)
                idx <- split(sample(seq(n)),seq(n.folds)) 
                #library(doMC)
                #registerDoMC(cores=4)

                ridge.regression <- lapply(1:nrow(GE.New), function(k){ 
                                                                    print(k)
                                                                    Y <- t(GE.New[k,,drop=F])
                                                                    X <- t(Meth.New[[k]][[1]])
                                                                    R2.fold <- rep(0,n.folds)
                                                                    R2.pearson <- rep(0,n.folds)

                                                                    for (p in 1:length(idx))
                                                                    {
                                                                            print(p)
                                                                            Y_train <- Y[-idx[[p]],,drop=F]
                                                                            X_train <- X[-idx[[p]],,drop=F]
                                                                            Y_test <- Y[idx[[p]],,drop=F]
                                                                            X_test <- X[idx[[p]],,drop=F]

                                                                            if (any(Y_train!=Y_train[1])) ## Verify if response is not constant (can happen if Y==0)
                                                                            {
                                                                                    #cv.ridge <- cv.glmnet(X_train,Y_train,alpha=0,parallel=T)
                                                                                    cv.ridge <- cv.glmnet(X_train,Y_train,alpha=0)
                                                                                    best.fit <- glmnet(X_train,Y_train,lambda=cv.ridge$lambda.min,alpha=0)
                                                                                    y_predict <- predict(best.fit,newx=X_test)
                                                                                    y_mean <- mean(Y_train)
                                                                                    R2.fold[p] <- 1- norm(Y_test - y_predict ,'F')/ norm(Y_test - y_mean,'F')
                                                                                    R2.pearson[p] <- cor(y_predict,Y_test)^2
                                                                                    #n <- length(Y)
                                                                                    #p <- ncol(X) ##### Look at degree of freedom !! 
                                                                                    #adj.R2 <- 1 - (1-R2) * (n-1)/(n-p-1)

                                                                            } else {
                                                                                    R2.fold[p] <- 0
                                                                                    R2.pearson[p] <- 0
                                                                            }
                                                                    }

                                                                    lm.infos <- list(#cvm=cv.ridge$cvm, 
                                                                                     #lambda=cv.ridge$lambda, 
                                                                                     #lambda.min=cv.ridge$lambda.min, 
                                                                                     r.squared=mean(R2.fold), 
                                                                                     # adj.r.squared=adj.R2,
                                                                                     r2.pearson=mean(R2.pearson))

                                                                    return(lm.infos)
                                                                    })

                names(ridge.regression) <- CommonGenes

                save(ridge.regression,file=paste0("../../big_data/GE_prediction/",DiseaseName,"_",type,"_ridge_regression_",MethylationAnalysis,".RData"))

                ### Train a lasso regression of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)

                lasso.regression <- lapply(1:nrow(GE.New), function(k){ 
                                                                    print(k)
                                                                    Y <- t(GE.New[k,,drop=F])
                                                                    X <- t(Meth.New[[k]][[1]])
                                                                    R2.fold <- rep(0,n.folds)
                                                                    R2.pearson <- rep(0,n.folds)

                                                                    for (p in 1:length(idx))
                                                                    {
                                                                            Y_train <- Y[-idx[[p]],,drop=F]
                                                                            X_train <- X[-idx[[p]],,drop=F]
                                                                            Y_test <- Y[idx[[p]],,drop=F]
                                                                            X_test <- X[idx[[p]],,drop=F]

                                                                            if (any(Y_train!=Y_train[1])) ## Verify if response is not constant (can happen if Y==0)
                                                                            {
                                                                                    #cv.lasso <- cv.glmnet(X_train,Y_train,alpha=1,parallel=T)
                                                                                    cv.lasso <- cv.glmnet(X_train,Y_train,alpha=1)
                                                                                    best.fit <- glmnet(X_train,Y_train,lambda=cv.lasso$lambda.min,alpha=1)
                                                                                    y_predict <- predict(best.fit,newx=X_test)
                                                                                    y_mean <- mean(Y_train)
                                                                                    R2.fold[p] <- 1- norm(Y_test - y_predict ,'F')/ norm(Y_test - y_mean,'F')
                                                                                    R2.pearson[p] <- cor(y_predict,Y_test)^2
                                                                                    #n <- length(Y)
                                                                                    #p <- ncol(X) ##### Look at degree of freedom !! 
                                                                                    #adj.R2 <- 1 - (1-R2) * (n-1)/(n-p-1)

                                                                            } else {
                                                                                    R2.fold[p] <- 0
                                                                                    R2.pearson[p] <- 0
                                                                            }
                                                                    }

                                                                    lm.infos <- list(#cvm=cv.lasso$cvm, 
                                                                                     #lambda=cv.lasso$lambda, 
                                                                                     #lambda.min=cv.lasso$lambda.min, 
                                                                                     r.squared=mean(R2.fold), 
                                                                                     # adj.r.squared=adj.R2,
                                                                                     r2.pearson=mean(R2.pearson))

                                                                    return(lm.infos)
                                                                    })

                names(lasso.regression) <- CommonGenes

                save(lasso.regression,file=paste0("../../big_data/GE_prediction/",DiseaseName,"_",type,"_lasso_regression_",MethylationAnalysis,".RData"))
                
        } else if (MethylationAnalysis=="All_CGIs") {
                print('predicting GE with all associated CGIs')

                # First take only big islands
                Meth.df <- Meth.dat[list_big_island]

                load("../../data/processed/fData/fData_CGI.RData") 
                fData.big_island <- fData_CGI[list_big_island]
                Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

                # Find common genes between methylation and expression
                Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
                CommonGenes <- intersect(Genes.GE, Genes.big_island)
                ######
                GE.New <- GE.dat[match(CommonGenes,Genes.GE),]

                save(CommonGenes,file="../../big_data/CommonGenes.RData")

                load("../../big_data/AssocIslandGenes.RData")

                Meth.New <- lapply(1:length(CommonGenes), function(n) { return( Reduce('rbind',Meth.df[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]] ])  ) }) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better.
                # assoc <- sapply(Meth.New,length)

                ### Train a least square model of GE = f(Methylation) for each gene and calculate the performance
                least.squares <- lapply(1:nrow(GE.New), function(k){ 
                                                                    Y <- t(GE.New[k,,drop=F    ])
                                                                    X <- t(Meth.New[[k]]) 
                                                                    Dat <- cbind(Y,X)
                                                                    colnames(Dat)[1] <- "gene"
                                                                    Dat <- data.frame(Dat)
                                                                    lm.predict <- lm( gene ~ ., data=Dat)
                                                                    lm.infos <- list(r.squared=summary(lm.predict)$r.squared, adj.r.squared=summary(lm.predict)$adj.r.squared, fstatistic=summary(lm.predict)$fstatistic)
                                                                    return(lm.infos)})
                names(least.squares) <- CommonGenes

                save(least.squares,file=paste0("../../big_data/GE_prediction/",DiseaseName,"_",type,"_least_squares_",MethylationAnalysis,".RData"))

                ### Train a linear ridge regression of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                # n.folds <- 10
                n <- ncol(GE.New)
                idx <- split(sample(seq(n)),seq(n.folds)) 
                # library(doMC)
                # registerDoMC(cores=4)

                ridge.regression <- lapply(1:nrow(GE.New), function(k){ 
                                                                    print(k)
                                                                    Y <- t(GE.New[k,,drop=F])
                                                                    X <- t(Meth.New[[k]])
                                                                    R2.fold <- rep(0,n.folds)
                                                                    R2.pearson <- rep(0,n.folds)

                                                                    for (p in 1:length(idx))
                                                                    {
                                                                            Y_train <- Y[-idx[[p]],,drop=F]
                                                                            X_train <- X[-idx[[p]],,drop=F]
                                                                            Y_test <- Y[idx[[p]],,drop=F]
                                                                            X_test <- X[idx[[p]],,drop=F]

                                                                            if (any(Y_train!=Y_train[1])) ## Verify if response is not constant (can happen if Y==0)
                                                                            {
                                                                                    #cv.ridge <- cv.glmnet(X_train,Y_train,alpha=0,parallel=T)
                                                                                    cv.ridge <- cv.glmnet(X_train,Y_train,alpha=0)
                                                                                    best.fit <- glmnet(X_train,Y_train,lambda=cv.ridge$lambda.min,alpha=0)
                                                                                    y_predict <- predict(best.fit,newx=X_test)
                                                                                    y_mean <- mean(Y_train)
                                                                                    R2.fold[p] <- 1- norm(Y_test - y_predict ,'F')/ norm(Y_test - y_mean,'F')
                                                                                    R2.pearson[p] <- cor(y_predict,Y_test)^2
                                                                                    #n <- length(Y)
                                                                                    #p <- ncol(X) ##### Look at degree of freedom !! 
                                                                                    #adj.R2 <- 1 - (1-R2) * (n-1)/(n-p-1)

                                                                            } else {
                                                                                    R2.fold[p] <- 0
                                                                                    R2.pearson[p] <- 0
                                                                            }
                                                                    }

                                                                    lm.infos <- list(#cvm=cv.ridge$cvm, 
                                                                                     #lambda=cv.ridge$lambda, 
                                                                                     #lambda.min=cv.ridge$lambda.min, 
                                                                                     r.squared=mean(R2.fold), 
                                                                                     # adj.r.squared=adj.R2,
                                                                                     r2.pearson=mean(R2.pearson))

                                                                    return(lm.infos)
                                                                    })

                names(ridge.regression) <- CommonGenes

                save(ridge.regression,file=paste0("../../big_data/GE_prediction/",DiseaseName,"_",type,"_ridge_regression_",MethylationAnalysis,".RData"))

                ### Train a lasso regression of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)

                lasso.regression <- lapply(1:nrow(GE.New), function(k){ 
                                                                    print(k)
                                                                    Y <- t(GE.New[k,,drop=F])
                                                                    X <- t(Meth.New[[k]])
                                                                    R2.fold <- rep(0,n.folds)
                                                                    R2.pearson <- rep(0,n.folds)

                                                                    for (p in 1:length(idx))
                                                                    {
                                                                            Y_train <- Y[-idx[[p]],,drop=F]
                                                                            X_train <- X[-idx[[p]],,drop=F]
                                                                            Y_test <- Y[idx[[p]],,drop=F]
                                                                            X_test <- X[idx[[p]],,drop=F]

                                                                            if (any(Y_train!=Y_train[1])) ## Verify if response is not constant (can happen if Y==0)
                                                                            {
                                                                                    #cv.lasso <- cv.glmnet(X_train,Y_train,alpha=1,parallel=T)
                                                                                    cv.lasso <- cv.glmnet(X_train,Y_train,alpha=1)
                                                                                    best.fit <- glmnet(X_train,Y_train,lambda=cv.lasso$lambda.min,alpha=1)
                                                                                    y_predict <- predict(best.fit,newx=X_test)
                                                                                    y_mean <- mean(Y_train)
                                                                                    R2.fold[p] <- 1- norm(Y_test - y_predict ,'F')/ norm(Y_test - y_mean,'F')
                                                                                    R2.pearson[p] <- cor(y_predict,Y_test)^2
                                                                                    #n <- length(Y)
                                                                                    #p <- ncol(X) ##### Look at degree of freedom !! 
                                                                                    #adj.R2 <- 1 - (1-R2) * (n-1)/(n-p-1)
                                                                            } else {
                                                                                    R2.fold[p] <- 0
                                                                                    R2.pearson[p] <- 0

                                                                            }
                                                                    }

                                                                    lm.infos <- list(#cvm=cv.lasso$cvm, 
                                                                                     #lambda=cv.lasso$lambda, 
                                                                                     #lambda.min=cv.lasso$lambda.min, 
                                                                                     r.squared=mean(R2.fold), 
                                                                                     # adj.r.squared=adj.R2,
                                                                                     r2.pearson=mean(R2.pearson))

                                                                    return(lm.infos)
                                                                    })

                names(lasso.regression) <- CommonGenes

                save(lasso.regression,file=paste0("../../big_data/GE_prediction/",DiseaseName,"_",type,"_lasso_regression_",MethylationAnalysis,".RData"))

        } else if (MethylationAnalysis=="Regional_CGIs") {
                print('predicting groups of genes with regional CGIs')

                # First take only big islands
                Meth.df <- Meth.dat[list_big_island]

                load("../../data/processed/fData/fData_CGI.RData") 
                fData.big_island <- fData_CGI[list_big_island]
                Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

                # Find common genes between methylation and expression
                Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
                CommonGenes <- intersect(Genes.GE, Genes.big_island)
                ######
                GE.New <- GE.dat[match(CommonGenes,Genes.GE),]
                load("../../big_data/AssocIslandGenes.RData")

                # Meth.New <- lapply(1:length(CommonGenes), function(n) { return( Meth.df[[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1] ]]  ) }) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better.

                Meth.New <- lapply(1:length(CommonGenes), function(n) { return( Reduce('rbind',Meth.df[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]] ])  ) }) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better.
                # assoc <- sapply(Meth.New,length)

                clusters.CGI <-  get(load(paste0('../../big_data/CGIs/',DiseaseName,'_',type,'_ClustersMean_updown.RData')))
                # clusters.GE <- sapply(1:length(CommonGenes), function(n) { index <- Assoc.islandGenes[[match(CommonGenes[n],names(Assoc.islandGenes))]][1] ; return(clusters.CGI[index])  } ) 
                # names(clusters.GE) <- CommonGenes

        } else if (MethylationAnalysis=="full_sparse") {
                print('Predicting full GE by methylation using sparse methods and see spatial association')

                # First take only big islands
                Meth.df <- Meth.dat[list_big_island]

                load("../../data/processed/fData/fData_CGI.RData") 
                fData.big_island <- fData_CGI[list_big_island]
                Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

                # Find common genes between methylation and expression
                Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
                CommonGenes <- intersect(Genes.GE, Genes.big_island)
                ######
                GE.New <- GE.dat[match(CommonGenes,Genes.GE),]
                #Meth.New <- Reduce('rbind',Meth.df)
                #save(Meth.New,file='../../big_data/MethNew.RData')
                load('../../big_data/MethNew.RData')

                #### Maybe needed later
                #load("../../big_data/AssocIslandGenes.RData")
                #Meth.New <- lapply(1:length(CommonGenes), function(n) { return( Meth.df[[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1] ]]  ) }) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better.
                # clusters.CGI <-  get(load(paste0('../../big_data/CGIs/',DiseaseName,'_',type,'_ClustersMean_updown.RData')))
                # clusters.GE <- sapply(1:length(CommonGenes), function(n) { index <- Assoc.islandGenes[[match(CommonGenes[n],names(Assoc.islandGenes))]][1] ; return(clusters.CGI[index])  } ) 
                # names(clusters.GE) <- CommonGenes
                # save(clusters.GE, file="../../big_data/GE_prediction/BRCA_Cancerous_ClustersGE_updown.RData")

        }  ### Do Lasso_Matrix ??

}


