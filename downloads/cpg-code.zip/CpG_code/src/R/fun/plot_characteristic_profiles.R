plot_characteristic_profiles <- function(Disease,type,num_char=12, analysis=c('Mean','Var'))
{

        for (method in analysis)
        {

                distMat.Normalized <- load(paste0('../../big_data/CGIs/',Disease,'_',type,'_DistanceMat',method,'Norm.RData')) 
                cluster.info <- load(paste0('../../big_data/CGIs/',Disease,'_',type,'_Clusters',method,'.RData'))

                distanceMat.Normalized <- get(distMat.Normalized)
                cluster <- get(cluster.info)

                index_characteristics <- lapply(1:length(unique(cluster)), function(n){
                                                tmp.dist <- distanceMat.Normalized[cluster==n,cluster==n]
                                                dist.cluster <- sapply(1:nrow(tmp.dist),function(k){sum(tmp.dist[k,-k]^2)})
                                                #dist.cluster <- sapply(1:nrow(tmp.dist),function(k){sum(tmp.dist[k,-k])}) ## sum of dist or square dist?
                                                return(which(cluster==n)[order(dist.cluster)[1:num_char]])
                                                })

                CGI <- load(paste0('../../big_data/CGIs/',Disease,'_',type,'CGIs_',method,'.RData'))
                CGI.dat <- get(CGI)

                CGI.dat_big_island <- CGI.dat[list_big_island]

                load('../../data/processed/fData/fData_CGI_big_island.RData')

                Dat.char <- vector('list')

                for (k in 1:length(unique(cluster)))
                {
                        Dat.char[[k]] <- data.frame(methylation=Reduce('c', CGI.dat_big_island[ index_characteristics[[k]]]) , 
                                                    position = Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"MAPINFO"    ]})) , 
                                                    CGI =  Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                                    IslandBegin= Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandBegin"]})), 
                                                    IslandEnd=Reduce('c',lapply(1:length(index_characteristics[[k]]), function(n){fData_CGI_big_island[[index_characteristics[[k]][n]]][ ,"IslandEnd"]})))

                        pdf(paste0("../../results/clustering/",Disease,"/",method,"/cluster_",k,"_characteristic_profiles_",type,".pdf"), width=10, height=10, pointsize=10)
                        print(ggplot(Dat.char[[k]],aes(x=position,y=methylation))+ geom_point() + geom_line()+ geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype="longdash")+geom_vline(aes(xintercept=IslandEnd),colour="blue",linetype="longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + theme(legend.position="none", axis.text.x=element_blank()) + ylim(0,1) )
                        dev.off()
                }
        }

}
