analyze_CpG_distance <- function(Disease, type)
{
        Dat <- eval(parse(text=paste0(Disease,".",type)))

        FilterIsland <- fData450K[fData450K[,"Relation_to_UCSC_CpG_Island"]=="Island","Name"]
        FilterNShore <- fData450K[fData450K[,"Relation_to_UCSC_CpG_Island"]=="N_Shore","Name"]
        FilterNShelf <- fData450K[fData450K[,"Relation_to_UCSC_CpG_Island"]=="N_Shelf","Name"]
        FilterSShore <- fData450K[fData450K[,"Relation_to_UCSC_CpG_Island"]=="S_Shore","Name"]
        FilterSShelf <- fData450K[fData450K[,"Relation_to_UCSC_CpG_Island"]=="S_Shelf","Name"]

        Reordering <- match(rownames(Dat), fData450K$Name)
        Relation_to_UCSC_CpG_Island <- factor(fData450K[Reordering,"Relation_to_UCSC_CpG_Island"],levels=c('','N_Shelf','N_Shore','Island','S_Shore','S_Shelf'),ordered=TRUE)

        data_methylation.test <- data.frame(cg= rownames(Dat),
                                            betas= as.vector(Dat[,1]),
                                            Relation_to_UCSC_CpG_Island=Relation_to_UCSC_CpG_Island,
                                            DistanceIsland=fData450K[Reordering,"IslandDist"],
                                            CHR=fData450K[Reordering,"CHR"])			       

        # Plot Methylation in Shores/Shelves/Islands by chromosomes {{{3
        p <- ggplot(data_methylation.test, aes(factor(Relation_to_UCSC_CpG_Island),betas))
        pdf("../../results/Relation_to_CpG_Island/boxplot_betas.pdf", width=10, height=10, pointsize=10)
        p + geom_boxplot(aes(fill= factor(CHR)))
        dev.off()

        # Look at the distribution inside the shores (maybe shores all ill-defined) {{{3
        p1 <- ggplot(data_methylation.test, aes(x=betas,colour=factor(Relation_to_UCSC_CpG_Island)))
        pdf("../../results/Relation_to_CpG_Island/density.pdf", width=10, height=10, pointsize=10)
        p1+ geom_density()
        dev.off()

        # Look at the distribution of the Betas for shores compared to the distance to the Island {{{3
        Shore.dataframe <- data_methylation.test[data_methylation.test[,"Relation_to_UCSC_CpG_Island"] %in% c('N_Shore','S_Shore'),]
        # plot
        p3 <- ggplot(Shore.dataframe, aes(x=DistanceIsland,y=betas))
        pdf("../../results/Relation_to_CpG_Island/Shore.pdf", width=10, height=10, pointsize=10)
        p3 + geom_point()
        dev.off()

        pdf("../../results/Relation_to_CpG_Island/Shore_smooth.pdf", width=10, height=10, pointsize=10)
        p3 + stat_smooth()
        dev.off()

        # plot spline
        library(splines)
        Shore_spline.dataframe <- data.frame(spline(Shore.dataframe[,c('DistanceIsland','betas')]))
        p4 <- ggplot(Shore_spline.dataframe, aes(x,y))
        pdf("../../results/Relation_to_CpG_Island/Shore_spline.pdf", width=10, height=10, pointsize=10)
        p4 + geom_line()
        dev.off()

        # Look at the distribution of the Betas for shelves compared to the distance to the Island {{{3
        Shelf.dataframe <- data_methylation.test[data_methylation.test[,"Relation_to_UCSC_CpG_Island"] %in% c('N_Shelf','S_Shelf'),]
        # plot
        p3 <- ggplot(Shelf.dataframe, aes(x=DistanceIsland,y=betas))
        pdf("../../results/Relation_to_CpG_Island/Shelf.pdf", width=10, height=10, pointsize=10)
        p3 + geom_point()
        dev.off()

        pdf("../../results/Relation_to_CpG_Island/Shelf_smooth.pdf", width=10, height=10, pointsize=10)
        p3 + stat_smooth()
        dev.off()

        # plot spline
        library(splines)
        Shelf_spline.dataframe <- data.frame(spline(Shelf.dataframe[,c('DistanceIsland','betas')]))
        p4 <- ggplot(Shelf_spline.dataframe, aes(x,y))
        pdf("../../results/Relation_to_CpG_Island/Shelf_spline.pdf", width=10, height=10, pointsize=10)
        p4 + geom_line()
        dev.off()

        # Look at the distribution of the Betas for shores+shelves compared to the distance to the Island {{{3
        Shore_Shelf.dataframe <- data_methylation.test[data_methylation.test[,"Relation_to_UCSC_CpG_Island"] %in% c('N_Shore','S_Shore','N_Shelf','S_Shelf'),]
        # plot
        p3 <- ggplot(Shore_Shelf.dataframe, aes(x=DistanceIsland,y=betas))
        pdf("../../results/Relation_to_CpG_Island/Shore_Shelf.pdf", width=10, height=10, pointsize=10)
        p3 + geom_point() + geom_vline(xintercept=-2000, colour="blue") + geom_vline(xintercept=2000, colour="blue")
        dev.off()

        pdf("../../results/Relation_to_CpG_Island/Shore_Shelf_smooth.pdf", width=10, height=10, pointsize=10)
        p3 + stat_smooth()
        dev.off()

        # plot spline
        library(splines)
        Shore_Shelf_spline.dataframe <- data.frame(spline(Shore_Shelf.dataframe[,c('DistanceIsland','betas')]))
        p4 <- ggplot(Shore_Shelf_spline.dataframe, aes(x,y))
        pdf("../../results/Relation_to_CpG_Island/Shore_Shelf_spline.pdf", width=10, height=10, pointsize=10)
        p4 + geom_line()
        dev.off()


        # Look at the distribution of the Betas according to normalized distance inside the island {{{3
        Island.dataframe <- data_methylation.test[data_methylation.test[,"Relation_to_UCSC_CpG_Island"] == "Island",]
        # plot
        p3 <- ggplot(Island.dataframe, aes(x=DistanceIsland,y=betas))
        pdf("../../results/Relation_to_CpG_Island/Island.pdf", width=10, height=10, pointsize=10)
        p3 + geom_point()
        dev.off()

        # plot smoothed version
        pdf("../../results/Relation_to_CpG_Island/Island_smooth.pdf", width=10, height=10, pointsize=10)
        p3 + stat_smooth()
        dev.off()

        # plot spline
        library(splines)
        Island_spline.dataframe <- data.frame(spline(Island.dataframe[,c('DistanceIsland','betas')]))
        p4 <- ggplot(Island_spline.dataframe, aes(x,y))
        pdf("../../results/Relation_to_CpG_Island/Island_spline.pdf", width=10, height=10, pointsize=10)
        p4 + geom_line()
        dev.off()

        # #Plot variance with respect to Relation to CpG_Island {{{3
        # BetasVar <- apply(Dat,1,var) ##
        # save(BetasVar,file="../../data/BetasVar.RData")
        # #plot(BetasVar / Distance to CpG Island)
        # var.noNA <- function(x){var(x,na.rm=TRUE)}
        # BetasVar.noNA <- apply(Dat,1,var.noNA)
        # 
        # data_variance <- data.frame(variance=BetasVar.noNA, Relation_to_UCSC_CpG_Island=Relation_to_UCSC_CpG_Island)
        # p.var <- ggplot(data_variance, aes(factor(Relation_to_UCSC_CpG_Island),variance))+ geom_boxplot()
        # p.var 
}
