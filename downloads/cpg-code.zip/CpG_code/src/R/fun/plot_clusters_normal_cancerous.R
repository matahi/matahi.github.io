plot_clusters_normal_cancerous <- function(Disease,num_char=30)
{
        type1 <- "Normal"
        type2 <- "Cancerous"

        cluster1 <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type1,'_ClustersMean.RData')))
        cluster2 <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type2,'_ClustersMean_updown.RData')))

        load('../../data/processed/fData/fData_CGI_big_island.RData')

        ###
        Dat.Mean1 <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type1,'CGIs_Mean.RData')))[list_big_island]
        Dat.Mean2 <- get(load(paste0('../../big_data/CGIs/',Disease,'_',type2,'CGIs_Mean.RData')))[list_big_island]


        ### colour_scale
        colour_scale <- c('1'='red',
                          '2'='green',
                          '3'='grey40',
                          '4up'='blue',
                          '4down'='yellow3')

        ###### Normal== 1/2 Cancerous == 3
        cluster.hyper <- which((cluster1 %in% c(1,2)) & (cluster2 == "3"))
        n <- length(cluster.hyper)
        n.folds <- ceiling(length(cluster.hyper)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        for (k in 1:length(idx))
        {
                cluster.hyper_sample <- cluster.hyper[idx[[k]]] 

                Dat.X.1_hyper <- data.frame(methylation=Reduce('c', Dat.Mean1[ cluster.hyper_sample  ]) , type=type1,
                                          cluster = rep(cluster1[cluster.hyper_sample], sapply(1:(length(cluster.hyper_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.hyper_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[ cluster.hyper_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandEnd"]})))

                Dat.X.2_hyper <- data.frame(methylation=Reduce('c', Dat.Mean2[ cluster.hyper_sample ]) , type=type2,
                                          cluster = rep(cluster2[cluster.hyper_sample], sapply(1:(length(cluster.hyper_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.hyper_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[ cluster.hyper_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandEnd"]})))

                Dat.X_hyper <- rbind(Dat.X.1_hyper,Dat.X.2_hyper)

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Clusterhyper_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.X_hyper,aes(x=position,y=methylation))+geom_point(aes(group=type)) + geom_line(aes(group=type,colour=factor(cluster),linetype=factor(type)))+ scale_colour_manual(values=colour_scale) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()))
                dev.off()
        }

        ###### Normal== 3 Cancerous == 1/2
        cluster.hypo <- which((cluster2 %in% c(1,2)) & (cluster1 == "3"))
        n <- length(cluster.hypo)
        n.folds <- ceiling(length(cluster.hypo)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        for (k in 1:length(idx))
        {
                cluster.hypo_sample <- cluster.hypo[idx[[k]]] 

                Dat.X.1_hypo <- data.frame(methylation=Reduce('c', Dat.Mean1[ cluster.hypo_sample  ]) , type=type1,
                                          cluster = rep(cluster1[cluster.hypo_sample], sapply(1:(length(cluster.hypo_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.hypo_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[ cluster.hypo_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[cluster.hypo_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[cluster.hypo_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[cluster.hypo_sample[n]]][ ,"IslandEnd"]})))

                Dat.X.2_hypo <- data.frame(methylation=Reduce('c', Dat.Mean2[ cluster.hypo_sample ]) , type=type2,
                                          cluster = rep(cluster2[cluster.hypo_sample], sapply(1:(length(cluster.hypo_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.hypo_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[ cluster.hypo_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[cluster.hypo_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[cluster.hypo_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.hypo_sample), function(n){fData_CGI_big_island[[cluster.hypo_sample[n]]][ ,"IslandEnd"]})))

                Dat.X_hypo <- rbind(Dat.X.1_hypo,Dat.X.2_hypo)

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Clusterhypo_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.X_hypo,aes(x=position,y=methylation))+geom_point(aes(group=type)) + geom_line(aes(group=type,colour=factor(cluster),linetype=factor(type)))+ scale_colour_manual(values=colour_scale) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()))
                dev.off()
        }


        ###### 3up
        cluster.4up <- which(cluster2=="4up")
        n <- length(cluster.4up)
        n.folds <- ceiling(length(cluster.4up)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        for (k in 1:length(idx))
        {
                cluster.4up_sample <- cluster.4up[idx[[k]]] 

                Dat.X.1_4up <- data.frame(methylation=Reduce('c', Dat.Mean1[ cluster.4up_sample  ]) , type=type1,
                                          cluster = rep(cluster1[cluster.4up_sample], sapply(1:(length(cluster.4up_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.4up_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[ cluster.4up_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[cluster.4up_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[cluster.4up_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[cluster.4up_sample[n]]][ ,"IslandEnd"]})))

                Dat.X.2_4up <- data.frame(methylation=Reduce('c', Dat.Mean2[ cluster.4up_sample ]) , type=type2,
                                          cluster = rep(cluster2[cluster.4up_sample], sapply(1:(length(cluster.4up_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.4up_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[ cluster.4up_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[cluster.4up_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[cluster.4up_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.4up_sample), function(n){fData_CGI_big_island[[cluster.4up_sample[n]]][ ,"IslandEnd"]})))

                Dat.X_4up <- rbind(Dat.X.1_4up,Dat.X.2_4up)

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Cluster4up_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.X_4up,aes(x=position,y=methylation))+geom_point(aes(group=type)) + geom_line(aes(group=type,colour=factor(cluster),linetype=factor(type)))+ scale_colour_manual(values=colour_scale) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()))
                dev.off()
        }

        ###### 4down
        cluster.4down <- which(cluster2=="4down")
        n <- length(cluster.4down)
        n.folds <- ceiling(length(cluster.4down)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        for (k in 1:length(idx))
        {
                cluster.4down_sample <- cluster.4down[idx[[k]]] 

                Dat.X.1_4down <- data.frame(methylation=Reduce('c', Dat.Mean1[ cluster.4down_sample  ]) , type=type1,
                                          cluster = rep(cluster1[cluster.4down_sample], sapply(1:(length(cluster.4down_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.4down_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[ cluster.4down_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[cluster.4down_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[cluster.4down_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[cluster.4down_sample[n]]][ ,"IslandEnd"]})))

                Dat.X.2_4down <- data.frame(methylation=Reduce('c', Dat.Mean2[ cluster.4down_sample ]) , type=type2,
                                          cluster = rep(cluster2[cluster.4down_sample], sapply(1:(length(cluster.4down_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.4down_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[ cluster.4down_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[cluster.4down_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[cluster.4down_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.4down_sample), function(n){fData_CGI_big_island[[cluster.4down_sample[n]]][ ,"IslandEnd"]})))

                Dat.X_4down <- rbind(Dat.X.1_4down,Dat.X.2_4down)

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Cluster4down_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.X_4down,aes(x=position,y=methylation))+geom_point(aes(grodown=type)) + geom_line(aes(grodown=type,colour=factor(cluster),linetype=factor(type)))+ scale_colour_manual(values=colour_scale) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()))
                dev.off()
        }



}
