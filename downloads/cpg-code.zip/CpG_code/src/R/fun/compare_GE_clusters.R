compare_GE_clusters <- function(DiseaseName,analysis = c('Mean'), MethylationAnalysis='mean',Clinical=F,big_island=T)
{
        ## Preprocessing {{{1
        DiseaseName <- "BRCA"
        # DiseaseName <- "LUAD"
        # DiseaseName <- "Colon"
        method <- "Mean"
        MethylationAnalysis <- "mean"
        Clinical <- F
        big_island <- T
t
        # Genes_Michel <- c('TET1','TET2','TET3','DNMT1','DNMT3L','DNMT3A','DNMT3B','IDH1','IDH2')




        for (method in analysis)
        {
                GE.dat.Cancerous <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData')))
                if (DiseaseName != "Colon")
                {
                        GE.dat.Normal <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/NormalLevel3GE_processed.RData')))
                }
                if (method=="Mean")
                {
                        # Clusters.cancerous <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_Clusters',method,'_updown.RData')))
                        # Clusters.normal <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Normal_Clusters',method,'_updown.RData')))

                        Clusters.cancerous <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_Clusters',method,'_updown_bis.RData')))
                        Clusters.normal <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Normal_Clusters',method,'_updown_bis.RData')))

                } else if (method=="Var")
                {
                        Clusters.cancerous <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_Clusters',method,'.RData')))
                        Clusters.normal <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Normal_Clusters',method,'.RData')))
                }

                # required packages
                require('ggplot2')
                require('reshape2') #for Melt for data.frame
                # require('gridExtra') # for plotting several ggplots -> grid.arrange
                # require('ggbio')

                ### Statistical Analysis {{{1
                # Process Genes
                CommonGenes <- get(load('../../big_data/GE_prediction/Tools/CommonGenes.RData')) 
                PromoterAssoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
                AllCGIsAssoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
                Genes.GE <- sapply(1:nrow(GE.dat.Cancerous), function(n){ tmp <- strsplit(rownames(GE.dat.Cancerous)[n],"\\|"); return(tmp[[1]][1])     } ) 


                # ###########################
                # #### Question Michel ######
                # ###########################
                # GE.Cancerous.Michel <- GE.dat.Cancerous[match(Genes_Michel, Genes.GE),]
                # GE.Normal.Michel <- GE.dat.Normal[match(Genes_Michel, Genes.GE),]

                # rownames(GE.Cancerous.Michel) <- Genes_Michel
                # rownames(GE.Normal.Michel) <- Genes_Michel

                # #### 
                # GE.Cancerous.m <- melt(GE.Cancerous.Michel)
                # GE.Normal.m <- melt(GE.Normal.Michel)
                # GE.Cancerous.m$type <- "Cancerous"
                # GE.Normal.m$type <- "Normal"

                # GE.m <- rbind(GE.Cancerous.m, GE.Normal.m)

                # ####
                # pdf('~/Desktop/Genes_Normal_Cancerous.pdf')
                # ggplot(GE.m) + geom_boxplot(aes(x=Var1,y=log10(value), fill=type))
                # dev.off()
                # ####

                # Clusters.CIMP <- get(load('../../big_data/Clusters_CIMP.RData'))

                # GE.clusts <- GE.Cancerous.m
                # GE.clusts$clusters <- rep(Clusters.CIMP,each=9)

                # ####
                # pdf('~/Desktop/Genes_Cancerous_Clusters.pdf')
                # ggplot(GE.clusts) +geom_boxplot(aes(x=clusters    ,y=value, fill=clusters)) + facet_wrap( ~ Var1, scales="free_y")
                # dev.off()
                # ####

                ###############################

                ######
                GE.dat.Cancerous.common <- GE.dat.Cancerous[match(CommonGenes,Genes.GE),]
                if (DiseaseName != "Colon")
                        GE.dat.Normal.common <- GE.dat.Normal[match(CommonGenes,Genes.GE),]

                ### Associate Cluster to a gene
                Clusters.New.cancerous <- sapply(1:length(CommonGenes), function(n) { return( Clusters.cancerous[PromoterAssoc[n]]  ) })
                if (DiseaseName != "Colon")
                        Clusters.New.normal <- sapply(1:length(CommonGenes), function(n) { return( Clusters.normal[PromoterAssoc[n]]  ) })

                GE.Mean.Cancerous <- apply(GE.dat.Cancerous.common,1,mean)
                if (DiseaseName != "Colon")
                        GE.Mean.Normal <- apply(GE.dat.Normal.common,1,mean)

                GE.Variance.Cancerous <- apply(GE.dat.Cancerous.common,1,var)
                if (DiseaseName != "Colon")
                {
                        GE.Variance.Normal <- apply(GE.dat.Normal.common,1,var)
                }

                library(reshape2)

                Dat.df.Cancerous <- data.frame(Clusters= Clusters.New.cancerous, Variance= GE.Variance.Cancerous, Mean= GE.Mean.Cancerous,type="Cancerous") 
                rownames(Dat.df.Cancerous) <- CommonGenes
                #save(Dat.df.Cancerous, file="~/Desktop/BRCA_GE_Cancerous.RData")
                Dat.df.Cancerous.tot <- Dat.df.Cancerous
                Dat.df.Cancerous.tot$Clusters <- "Ref"
                Dat.df.Cancerous <- rbind(Dat.df.Cancerous,Dat.df.Cancerous.tot)

                # Dat.df.Cancerous$Clusters <- factor(Dat.df.Cancerous$Clusters, level=c('Ref','1','2','3','4down','4up'))
                Dat.df.Cancerous$Clusters <- factor(Dat.df.Cancerous$Clusters, level=c('Ref','1','2','3down','3up'))
                Dat.df.Cancerous$Mean <- Dat.df.Cancerous$Mean + 1e-5

                # Index.Cancerous <- which(Dat.df.Cancerous$Mean==0)

                # if (length(which(Dat.df.Cancerous$Mean==0)) != 0)
                #         Dat.df.Cancerous <- Dat.df.Cancerous[-which(Dat.df.Cancerous$Mean==0), ]

                colour_type <- c('Cancerous' = '#F8766D',
                                 'Normal' = '#00BFC4')

                # gg_color_hue <- function(n) {
                #           hues = seq(15, 375, length=n+1)
                #   hcl(h=hues, l=65, c=100)[1:n]
                # }

                #pdf(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Cluster_Cancerous_GEMean_updown.pdf'))
                p.Cancerous <- ggplot(Dat.df.Cancerous) + geom_boxplot(aes(x=Clusters,y=log2(Mean),fill=type)) + scale_fill_manual(values=colour_type) +  
                               ylab('log2(Gene Expression)') +
                               theme (panel.grid=element_blank(),                             
                                      panel.background = element_rect(fill="white", colour=NA),
                                      text = element_text(size=20),
                                      axis.text=element_text(colour="black",size=rel(0.8)),
                                      axis.ticks=element_line(colour="black"),
                                      legend.position="none",
                                      panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                      axis.title.y = element_text(vjust=0.35),
                                      strip.background = element_rect(colour="black",fill="white"),
                                      axis.line = element_line(colour = "black",size=0.3))

                ggsave(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Cluster_Cancerous_GEMean_updown.pdf'), p.Cancerous,dpi=300)

                # fml <- kruskal.test(Mean ~ Clusters, Dat.df.Cancerous)
                # TukeyHSD(fml) => Only for aov

                wilcox.test(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=='3up'], Dat.df.Cancerous$Mean[!(Dat.df.Cancerous$Clusters %in% c("3up","Ref"))])
                wilcox.test(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters %in% c('3up','3down')], Dat.df.Cancerous$Mean[!(Dat.df.Cancerous$Clusters %in% c("3up","3down","Ref"))])


                if (DiseaseName != "Colon")
                {
                        #### using the cancerous clusters
                        #Dat.df.Normal <- data.frame(Clusters= Clusters.New.cancerous, Variance= GE.Variance.Normal, Mean= GE.Mean.Normal, type="Normal") 
                        #Dat.df.Normal.tot <- Dat.df.Normal
                        #Dat.df.Normal.tot$Clusters <- "Ref"
                        #Dat.df.Normal <- rbind(Dat.df.Normal,Dat.df.Normal.tot)

                        #### using the normal clusters
                        Dat.df.Normal <- data.frame(Clusters= Clusters.New.normal, Variance= GE.Variance.Normal, Mean= GE.Mean.Normal,type="Normal") 
                        rownames(Dat.df.Normal) <- CommonGenes

                        # save(Dat.df.Normal, file="~/Desktop/BRCA_GE_Normal.RData")
                        ###

                        # kruskal.test(Mean ~ Clusters, Dat.df.Normal)
                        # Dat.df.Normal$Clusters[Dat.df.Normal$Clusters==2] <- 1
                        # wilcox.test(Mean ~ Clusters, Dat.df.Normal)

                        Dat.df.Normal.tot <- Dat.df.Normal
                        Dat.df.Normal.tot$Clusters <- "Ref"
                        Dat.df.Normal <- rbind(Dat.df.Normal,Dat.df.Normal.tot)

                        Dat.df.Normal$Clusters <- factor(Dat.df.Normal$Clusters, level=c('Ref','1','2'))
                        Dat.df.Normal$Variance <- Dat.df.Normal$Variance+1e-5
                        Dat.df.Normal$Mean <- Dat.df.Normal$Mean+1e-5

                        # Index.Normal <- which(Dat.df.Cancerous$Mean==0)

                        # if (length(which(Dat.df.Normal$Mean==0)) != 0)
                        #         Dat.df.Normal <- Dat.df.Normal[-which(Dat.df.Normal$Mean==0), ]

                        
                        # pdf(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Cluster_Normal_GEMean_updown.pdf'))
                        # print(ggplot(Dat.df.Normal) + geom_boxplot(aes(x=Clusters,y=Mean,fill=factor(type))) + scale_y_log10() ) #+ coord_trans(y="log2")
                        # dev.off()

                        ###################
                        # Question Michel 2
                        ###################

                        ### Genes.Hypo.repressed.Normal <- Dat.df.Normal[(Dat.df.Normal$Clusters == 1)&(Dat.df.Normal$Mean < quantile(Dat.df.Normal$Mean,0.05)),c("Mean","type")]
                        ### Genes.Hypo.repressed.Cancerous <- Dat.df.Cancerous[rownames(Genes.Hypo.repressed.Normal), c("Mean","type")]

                        ### Mat <- data.frame( Normal = Genes.Hypo.repressed.Normal$Mean, Cancerous = Genes.Hypo.repressed.Cancerous$Mean)
                        ### rownames(Mat) <- rownames(Genes.Hypo.repressed.Normal)

                        ### write.table(Mat,file="~/Desktop/Genes_Repressed_Hypo_Normal_Cancerous.txt")

                        ### pdf('~/Desktop/Genes_Repressed_Hypo_Normal_Cancerous.pdf')
                        ### qplot(Genes.Hypo.repressed.Normal$Mean, Genes.Hypo.repressed.Cancerous$Mean) + geom_abline(a=0,b=1,col="red")
                        ### dev.off()

                        # rownames(Genes.Hypo.repressed.Cancerous)[which(Genes.Hypo.repressed.Cancerous$Mean >2)]
                        # "CPLX2"

                        #######################

                        p.Normal <- ggplot(Dat.df.Normal) + geom_boxplot(aes(x=Clusters,y=log2(Mean),fill=type)) + scale_fill_manual(values=colour_type) +
                        ylab('log2(Gene Expression)') +
                        theme (panel.grid=element_blank(),                             
                               panel.background = element_rect(fill="white", colour=NA),
                               legend.position="none",
                               axis.text=element_text(colour="black",size=rel(0.8)),
                               axis.ticks=element_line(colour="black"),
                               text = element_text(size=20),
                               panel.border=element_rect(fill=NA, colour="black",size=0.7),
                               axis.title.y = element_text(vjust=0.35),
                               strip.background = element_rect(colour="black",fill="white"),
                               axis.line = element_line(colour = "black",size=0.3))

                        ggsave(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Cluster_Normal_GEMean_updown.pdf'), p.Normal,dpi=300)

                        wilcox.test(Dat.df.Normal$Mean[Dat.df.Normal$Clusters=='1'], Dat.df.Normal$Mean[Dat.df.Normal$Clusters=="2"])

                        # wilcox.test(Dat.df.Normal$Mean[Dat.df.Normal$Clusters=='3'], Dat.df.Normal$Mean[Dat.df.Normal$Clusters=="2"])
                        # wilcox.test(Dat.df.Normal$Mean[Dat.df.Normal$Clusters=='3'], Dat.df.Normal$Mean[Dat.df.Normal$Clusters=="1"])


                }

                if (DiseaseName != "Colon")
                {
                        Dat.df <- rbind(Dat.df.Cancerous,Dat.df.Normal)
                        Dat.df$Clusters <- Dat.df.Cancerous$Clusters
                } else 
                {
                        Dat.df <- Dat.df.Cancerous
                }

                #Dat.df$Clusters <- factor(Dat.df$Clusters, level=c('Ref','1','2','3','4down','4up'))
                Dat.df$Clusters <- factor(Dat.df$Clusters, level=c('Ref','1','2','3down','3up'))

                ###### ANOVA: GE vs Clusters #####
                aov.GE.Clusters <- aov(Mean ~ Clusters, data=Dat.df.Cancerous)
                summary(aov.GE.Clusters)



                # Dat.df$Variance <- Dat.df$Variance+1e-5
                # Dat.df$Mean <- Dat.df$Mean+1e-5


                ####

                # pdf(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Cluster_Normal_Cancerous_GEMean_updown.pdf'))
                # #print(ggplot(Dat.df) + geom_boxplot(aes(x=factor(Clusters),y=Mean,fill=factor(type))) ) #+ coord_trans(y="log2")
                # print(ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=Mean,fill=factor(type))) + scale_y_log10() ) #+ coord_trans(y="log2")
                # dev.off()



                # p.final <- ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=log10(Mean),fill=type)) + scale_fill_manual(values=colour_type) +  scale_y_log10() +
                p.final <- ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=log2(Mean),fill=type)) + scale_fill_manual(values=colour_type) +
                               ylab('log2(Gene Expression)') +
                               theme (panel.grid=element_blank(),                             
                                      panel.background = element_rect(fill="white", colour=NA),
                                      legend.position="none",
                                      axis.text=element_text(colour="black",size=rel(0.8)),
                                      axis.ticks=element_line(colour="black"),
                                      text = element_text(size=20),
                                      panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                      axis.title.y = element_text(vjust=0.35),
                                      strip.background = element_rect(colour="black",fill="white"),
                                      axis.line = element_line(colour = "black",size=0.3))

                ggsave(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Cluster_Normal_Cancerous_GEMean_updown.pdf'), p.final,dpi=300)

                # Dat.df.No.Ref <- bind(Dat.df.Cancerous,Dat.df.Normal)

                Dat.df.NoRef <- data.frame(Clusters=Dat.df.Cancerous$Clusters, Normal= Dat.df.Normal$Mean, Cancerous=Dat.df.Cancerous$Mean)
                Dat.df.NoRef <- Dat.df.NoRef[Dat.df.NoRef$Clusters != "Ref",]

                p.final.Scatter <- ggplot(Dat.df.NoRef) + geom_point(aes(x=log10(Normal),y=log10(Cancerous)))  + facet_wrap(~Clusters)+ 
                                   geom_abline(a=0,b=1,col="red") +
                                   theme (panel.grid=element_blank(),                             
                                      panel.background = element_rect(fill="white", colour=NA),
                                      legend.position="none",
                                      axis.text=element_text(colour="black",size=rel(0.8)),
                                      axis.ticks=element_line(colour="black"),
                                      text = element_text(size=20),
                                      panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                      axis.title.y = element_text(vjust=0.35),
                                      strip.background = element_rect(colour="black",fill="white"),
                                      axis.line = element_line(colour = "black",size=0.3))

                ggsave(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Scatter_Normal_Cancerous_GEMean_updown.pdf'), p.final.Scatter,dpi=300)

                Dat.df.diff <- data.frame(Clusters=Dat.df.Cancerous$Clusters, GE= log2(Dat.df.Cancerous$Mean)-log2(Dat.df.Normal$Mean))
                Dat.df.diff <- Dat.df.diff[Dat.df.diff$Clusters != "Ref",]

                p.final.diff <- ggplot(Dat.df.diff) + geom_boxplot(aes(x=Clusters,y=GE))  +
                                ylab(expression(paste(Delta,'(',GE[Cancerous],' - ',GE[Normal],')'))) +
                               theme (panel.grid=element_blank(),                             
                                      panel.background = element_rect(fill="white", colour=NA),
                                      legend.position="none",
                                      axis.text=element_text(colour="black",size=rel(0.8)),
                                      axis.ticks=element_line(colour="black"),
                                      text = element_text(size=20),
                                      panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                      axis.title.y = element_text(vjust=0.35),
                                      strip.background = element_rect(colour="black",fill="white"),
                                      axis.line = element_line(colour = "black",size=0.3))

                # #######
                # 2^mean(Dat.df.diff[Dat.df.diff$Clusters==1,"GE"])
                # 2^mean(Dat.df.diff[Dat.df.diff$Clusters==2,"GE"])
                # 2^mean(Dat.df.diff[Dat.df.diff$Clusters=="3up","GE"])
                # 2^mean(Dat.df.diff[Dat.df.diff$Clusters=="3down","GE"])

                ##### PAIRED TEST USING THE CLUSTERS FROM CANCEROUS
                ### Significant 1
                t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="1"]), log2(Dat.df.Normal$Mean[Dat.df.Cancerous$Clusters=="1"]) , paired=T ) 

                ### Non Significant 2
                t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="2"]), log2(Dat.df.Normal$Mean[Dat.df.Cancerous$Clusters=="2"]) , paired=T ) 

                ### Significant 3
                t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="3up"]), log2(Dat.df.Normal$Mean[Dat.df.Cancerous$Clusters=="3up"]) , paired=T ) 

                ### Non Significant 4
                t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="3down"]), log2(Dat.df.Normal$Mean[Dat.df.Cancerous$Clusters=="3down"]) , paired=T ) 

                ##### NON-PAIRED TEST USING THE CLUSTERS FROM EACH GROUP 
                ### 
                t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="1"]), log2(Dat.df.Normal$Mean[Dat.df.Normal$Clusters=="1"]) ) 

                ### 
                t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="2"]), log2(Dat.df.Normal$Mean[Dat.df.Normal$Clusters=="2"]) ) 

                ### 
                # t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="3up"]), log2(Dat.df.Normal$Mean[Dat.df.Normal$Clusters=="1"]) ) 

                ### 
                # t.test(log2(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters=="3down"]), log2(Dat.df.Normal$Mean[Dat.df.Normal$Clusters=="2"]) ) 

                ggsave(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Diff_Normal_Cancerous_GEMean_updown.pdf'), p.final.diff,dpi=300)


                if (DiseaseName != "Colon")
                {
                        pdf(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Scatter_Normal_Cancerous.pdf'))
                        print(qplot(Dat.df[ (Dat.df$Clusters=="4up") & (Dat.df$type=="Normal") , "Mean"],Dat.df[ (Dat.df$Clusters=="4up") & (Dat.df$type=="Cancerous") , "Mean"]) + ylab("Cancerous") + xlab('Normal') + scale_y_log10() + scale_x_log10() + geom_abline(a=0,b=1,color="red",linetype="longdash") )
                        dev.off()
                # qplot(Dat.df[ (Dat.df$Clusters=="3") & (Dat.df$type=="Normal") , "Mean"],Dat.df[ (Dat.df$Clusters=="3") & (Dat.df$type=="Cancerous") , "Mean"]) + ylab("Cancerous") + xlab('Normal') + scale_y_log10() + scale_x_log10() + geom_abline(a=0,b=1,color="red",linetype="longdash") 
                }

                pdf(paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/Cluster_GEVariance_updown.pdf'))
                #print(ggplot(Dat.df) + geom_boxplot(aes(x=factor(Clusters),y=Variance,fill=factor(type))) ) 
                print(ggplot(Dat.df) + geom_boxplot(aes(x=Clusters,y=Variance,fill=factor(type))) + scale_y_log10() ) 
                dev.off()

                ########## Calculate P-values
                ## Compare Clusters
                Clusters <- c('1','2','3','4down','4up')

                ## Cancerous vs Cancerous
                P_val_Cancerous <- matrix(1,nrow=length(Clusters),ncol=length(Clusters))
                rownames(P_val_Cancerous) <- Clusters
                colnames(P_val_Cancerous) <- Clusters

                ## Normal vs Normal
                if (DiseaseName != "Colon")
                {
                        P_val_Normal <- matrix(1,nrow=length(Clusters),ncol=length(Clusters))
                        rownames(P_val_Normal) <- Clusters
                        colnames(P_val_Normal) <- Clusters
                }

                ## Normal vs Cancerous 
                if (DiseaseName != "Colon")
                {
                        P_val_Normal_Cancerous <- rep(0,length(Clusters))
                        names(P_val_Normal_Cancerous) <- Clusters
                }

                for (i in 1:length(Clusters))
                {
                        # Cancerous/Cancerous and Normal/Normal
                        for (j in i:length(Clusters))
                        {
                                P_val_Cancerous[i,j] <- P_val_Cancerous[j,i] <- wilcox.test(Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters==Clusters[i]], Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters==Clusters[j]])$p.value
                                if (DiseaseName != "Colon")
                                {
                                        P_val_Normal[i,j] <- P_val_Normal[j,i] <- wilcox.test(Dat.df.Normal$Mean[Dat.df.Normal$Clusters==Clusters[i]], Dat.df.Normal$Mean[Dat.df.Normal$Clusters==Clusters[j]])$p.value
                                }
                        }

                        # Normal/Cancerous
                        if (DiseaseName != "Colon")
                        {
                                P_val_Normal_Cancerous[i] <- wilcox.test(Dat.df.Normal$Mean[Dat.df.Normal$Clusters==Clusters[i]], Dat.df.Cancerous$Mean[Dat.df.Cancerous$Clusters==Clusters[j]])$p.value
                        }
                }

                ##### write.txt with statistics
                ###############################

                ## TO DO !
                # write.table(P_val_Cancerous, file = paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/PvalCancerous.txt'), sep='\t', quote=F)
                # if (DiseaseName != "Colon")
                # {
                #         write.table(P_val_Normal, file = paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/PvalNormal.txt'), sep='\t', quote=F)
                #         write.table(P_val_Normal_Cancerous, file = paste0('../../results/GE_CGIs/',DiseaseName,'/',method,'/PvalNormalCancerous.txt'), sep='\t', quote=F)
                # }

        }

}
