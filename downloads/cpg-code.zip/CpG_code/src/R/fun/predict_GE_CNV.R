predict_GE_CNV <- function(DiseaseName,type,preprocessing="CGIs",MethylationAnalysis='Promoter')
{
        ## Preprocessing {{{1
        Meth.dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,preprocessing,'_processed_bis.RData')))
        GE.dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed_bis.RData')))
        #CNV.dat <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/',type,'Level3_CNV_Hg19_processed_bis.RData')))
        CNV.dat <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/',type,'CNV_Genes.RData')))

        ## Load fData Infos
        load("../../data/processed/fData/CpGIslands.RData")
        load("../../data/processed/fData/CpGIslands_size.RData")
        load("../../data/processed/fData/CpGIslands_probe_size.RData")
        list_big_island <- which(CpGIslands.probesize >=20)

        # required packages
        require('ggplot2')
        require('reshape2') #for Melt for data.frame
        require('gridExtra') # for plotting several ggplots -> grid.arrange
        require('ggbio')

        ## preprocessing
        Meth.dat <- Meth.dat[list_big_island]

        load('../../big_data/GE_prediction/Tools/CommonGenes.RData')
        Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
        GE.df <- GE.dat[match(CommonGenes,Genes.GE),]

        n.folds <- 3
        set.seed(1234)
        folds <- split( sample( seq(ncol(GE.df)) ), seq(n.folds) )


        ### Statistical Analysis {{{1
        ## Preprocessing of Methylation {{{2
        if (MethylationAnalysis=="Mean") { # {{{3 mean
                print(paste(DiseaseName,type,"Mean"))

                ### Tool Function
                adaptativeMean <- function(x)
                {
                        if (is.null(dim(x))){
                                output <- x
                        } else {
                                output <- apply(x,2,mean)
                        }
                }

                ### Process Methylation Data
                Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
                Meth.dat <- lapply(1:length(Promoter.Assoc),function(n){ Meth.dat[[Promoter.Assoc[n]]]})


                ### Processing Methylation Mean
                Meth.df <- t(sapply(Meth.dat,adaptativeMean))
                rownames(Meth.df) <- CommonGenes

                ### Now do linear prediction:  we are interested in the predictive R2
                library(glmnet)
                NoCNV.index <- rep(F,nrow(GE.df))
                for (n in 1:nrow(GE.df))
                {
                        if (all(is.na(CNV.dat[n,])))
                        {
                                NoCNV.index[n] <- T
                        }
                }

                n.repeats <- 300
                n.folds <- 3
                set.seed(1234)
                folds <- lapply(seq(n.repeats), function(n){split( sample( seq(ncol(GE.df)) ), seq(n.folds) )})

                library(doParallel)
                registerDoParallel(cores=10)

                Regression.List <- foreach(n.rep=1:n.repeats) %dopar%
                                          {
                                                  partition <- split(sample(seq(ncol(GE.df))), seq(n.folds))

                                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                                       {
                                                                               ###
                                                                               Y <- t(GE.df[n,,drop=F])
                                                                               X <- t(Meth.df[n,,drop=F])
                                                                               X <- cbind(X,CNV.dat[n,])

                                                                               Dat <- data.frame(Methylation=X[,1],CNV=X[,2], Expression=Y[,1])

                                                                               ###
                                                                               pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                                      {
                                                                                                              if (all(is.na(Dat$CNV)))
                                                                                                              {
                                                                                                                      NoCNV.index[n] <- T
                                                                                                                      #####
                                                                                                                      ## A) Using LM
                                                                                                                      ## 1) do Least Squares 
                                                                                                                      Fit.lm.Meth_CNV <- lm(Expression ~ Methylation, Dat, subset=-partition[[n_fold]])
                                                                                                                      Fit.lm.CNV_Only <- NA 

                                                                                                                      ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                                      Y_test <- Y[partition[[n_fold]],,drop=F ]
                                                                                                                      X_test.df <- Dat[partition[[n_fold]],-3]

                                                                                                                      Y_predict.LS.Meth_CNV <- predict(Fit.lm.Meth_CNV, X_test.df)
                                                                                                                      Y_predict.LS.CNV_Only <- rep(NA,length(Y_test))

                                                                                                                      #######
                                                                                                              } else {
                                                                                                                      ## 1) do Least Squares 
                                                                                                                      Fit.lm.Meth_CNV <- lm(Expression ~ Methylation + CNV, Dat, subset=-partition[[n_fold]])
                                                                                                                      Fit.lm.CNV_Only <- lm(Expression ~ CNV, Dat, subset=-partition[[n_fold]])

                                                                                                                      ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                                      Y_test <- Y[partition[[n_fold]],,drop=F ]
                                                                                                                      X_test.df <- Dat[partition[[n_fold]],-3]

                                                                                                                      Y_predict.LS.Meth_CNV <- predict(Fit.lm.Meth_CNV, X_test.df)
                                                                                                                      Y_predict.LS.CNV_Only <- predict(Fit.lm.CNV_Only, X_test.df)

                                                                                                                      #######
                                                                                                              }


                                                                                                              r2.pearson.LS.CNV_Only <- cor(Y_test,Y_predict.LS.CNV_Only)^2
                                                                                                              r2.pearson.LS.Meth_CNV <- cor(Y_test,Y_predict.LS.Meth_CNV)^2

                                                                                                              # qplot(as.vector(Y_test), as.vector(Y_predict.LS.Meth_CNV))
                                                                                                              qplot(as.vector(Y_test), as.vector(Y_predict.LS.CNV_Only))
                                                                                                              #

                                                                                                              return(c('LS.Meth_CNV'=r2.pearson.LS.Meth_CNV,'LS.CNV_Only'=r2.pearson.LS.CNV_Only))
                                                                                                      })

                                                                               pearson.df <- data.frame(t(pearson.fold))

                                                                               return(c('LS.Meth_CNV'=mean(pearson.df[,"LS.Meth_CNV"]),'LS.CNV_Only'=mean(pearson.df[,"LS.CNV_Only"])))
                                                                       })

                                                  Regression.df <- data.frame(t(Regression))

                                                  return(Regression.df)
                                          }

                # Regression.table <- Reduce('cbind',lapply(Regression.List,as.numeric))
                Regression.table <- NULL
                Regression.table$LS.Meth_CNV <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$LS.Meth_CNV}) )
                Regression.table$LS.CNV_Only <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$LS.CNV_Only}) )
                # save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table_CNV.RData"))
                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table_CNV_new.RData"))

                # Regression.Final <- NULL
                # Regression.Final$LS.Meth_CNV <- apply(Regression.table$LS.Meth_CNV, 1, function(s){mean(s,na.rm=T)})
                # Regression.Final$LS.CNV_Only <- apply(Regression.table$LS.CNV_Only, 1, function(s){mean(s,na.rm=T)})
                # save(Regression.Final,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_",n.repeats,"_CNV.RData"))

                save(NoCNV.index, file=paste0('../../big_data/GE_prediction/',DiseaseName,'_',type,'_',MethylationAnalysis,'_CNV_index.RData'))

        } else if (MethylationAnalysis=="Promoter") {
                print(paste(DiseaseName,type,"Promoter"))

                ### Process Methylation Data
                Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
                Meth.df <- lapply(1:length(Promoter.Assoc),function(n){ Meth.dat[[Promoter.Assoc[n]]]})

                ### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                NoCNV.index <- rep(F,nrow(GE.df))
                for (n in 1:nrow(GE.df))
                {
                        if (any(is.na(CNV.dat[n,])))
                        {
                                NoCNV.index[n] <- T
                        }
                }

                n.repeats <- 300
                n.folds <- 3
                set.seed(1234)
                folds <- lapply(seq(n.repeats), function(n){split( sample( seq(ncol(GE.df)) ), seq(n.folds) )})

                library(doParallel)
                registerDoParallel(cores=10)

                # Regression.List <- foreach(icount(n.repeats)) %dopar%
                Regression.List <- foreach(n.rep=1:n.repeats) %dopar%
                                          {
                                                  partition <- split(sample(seq(ncol(GE.df))), seq(n.folds))

                                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                                       {
                                                                               ###
                                                                               Y <- t(GE.df[n,,drop=F])
                                                                               X <- t(Meth.df[[n]])

                                                                               ###
                                                                               pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                                      {
                                                                                                              #if (all(is.na(CNV.dat[n,-folds[[n_fold]]])))
                                                                                                              if (any(is.na(CNV.dat[n,])))
                                                                                                              {
                                                                                                                      NoCNV.index[n] <- T
                                                                                                              } else {
                                                                                                                      X <- cbind(X,CNV.dat[n,])
                                                                                                              }
                                                                                                              colnames(X)[ncol(X)] <- "CNV"

                                                                                                              Y_train <- Y[-partition[[n_fold]],,drop=F ]
                                                                                                              X_train <- X[-partition[[n_fold]],]

                                                                                                              Y_test <- Y[partition[[n_fold]],,drop=F ]
                                                                                                              X_test <- X[partition[[n_fold]],]

                                                                                                              if (any(Y_train != Y_train[1]))
                                                                                                              {
                                                                                                                      ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                                                      # lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1)$lambda.min
                                                                                                                      # lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0)$lambda.min
                                                                                                                      # cv.err <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)

                                                                                                                      lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min
                                                                                                                      lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0,nfolds=3)$lambda.min


                                                                                                                      ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                                      predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)
                                                                                                                      predictor.ridge <- glmnet(X_train,Y_train,alpha=0,lambda=lambda.ridge)

                                                                                                                      Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)
                                                                                                                      Y_predict.ridge <- predict(predictor.ridge,newx=X_test, s= lambda.ridge)

                                                                                                                      r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                                                                      r2.pearson.ridge <- cor(Y_test,Y_predict.ridge)^2

                                                                                                                      # qplot(as.vector(Y_test), as.vector(Y_predict.lasso))

                                                                                                                      ########
                                                                                                                      # Using lambda.1se instead of lambda.min usually approximates with mean(Y_train)
                                                                                                                      # which is not good to calculate cor !

                                                                                                              } else {
                                                                                                                      r2.pearson.lasso <- NA
                                                                                                                      r2.pearson.ridge <- NA
                                                                                                              }

                                                                                                              return(c('lasso'=r2.pearson.lasso,'ridge'=r2.pearson.ridge))
                                                                                                      })

                                                                               pearson.df <- data.frame(t(pearson.fold))

                                                                               return(c('lasso'=mean(na.omit(pearson.df$lasso)),'ridge'=mean(na.omit(pearson.df$ridge)) ))
                                                                       })

                                                  Regression.df <- data.frame(t(Regression))
                                                  return(Regression.df)
                                          }

                Regression.table <- NULL
                Regression.table$lasso <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$lasso}) )
                Regression.table$ridge <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$ridge}) )
                # save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table_CNV.RData"))
                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table_CNV_new.RData"))

                # Regression.Final <- data.frame(sapply(Regression.table, function(x){apply(x,1,function(s){mean(s,na.rm=T)})}))
                # save(Regression.Final,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_",n.repeats,"_CNV.RData"))
                save(NoCNV.index, file=paste0('../../big_data/GE_prediction/',DiseaseName,'_',type,'_',MethylationAnalysis,'_CNV_index.RData'))



        } else if (MethylationAnalysis=="AllCGIs") {
                print(paste(DiseaseName,type,"AllCGIs"))

                ### Process Methylation Data
                AllCGIs.Assoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))

                Multiple_CGIs <- which(sapply(AllCGIs.Assoc,length) >= 2)

                Meth.df <- lapply(1:length(Multiple_CGIs),function(n){ Reduce('rbind',Meth.dat[AllCGIs.Assoc[[Multiple_CGIs[n] ]]])})
                GE.df <- GE.df[Multiple_CGIs, ]

                ### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                NoCNV.index <- rep(F, nrow(GE.df))
                for (n in 1:nrow(GE.df))
                {
                        if (any(is.na(CNV.dat[n,])))
                        {
                                NoCNV.index[n] <- T
                        }
                }

                n.repeats <- 300
                n.folds <- 3
                set.seed(1234)
                folds <- lapply(seq(n.repeats), function(n){split( sample( seq(ncol(GE.df)) ), seq(n.folds) )})


                library(doParallel)
                registerDoParallel(cores=10)

                Regression.List <- foreach(n.rep=1:n.repeats) %dopar%
                                          {
                                                  partition <- split(sample(seq(ncol(GE.df))), seq(n.folds))

                                                  print(n.rep)

                                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                                       {
                                                                               ###
                                                                               Y <- t(GE.df[n,,drop=F])
                                                                               X <- t(Meth.df[[n]])

                                                                               ###
                                                                               pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                                      {
                                                                                                              #if (all(is.na(CNV.dat[n,-folds[[n_fold]]])))
                                                                                                              if (any(is.na(CNV.dat[n,])))
                                                                                                              {
                                                                                                                      NoCNV.index[n] <- T
                                                                                                              } else {
                                                                                                                      X <- cbind(X,CNV.dat[n,])
                                                                                                              }
                                                                                                              colnames(X)[ncol(X)] <- "CNV"

                                                                                                              Y_train <- Y[-partition[[n_fold]],,drop=F ]
                                                                                                              X_train <- X[-partition[[n_fold]],]

                                                                                                              Y_test <- Y[partition[[n_fold]],,drop=F ]
                                                                                                              X_test <- X[partition[[n_fold]],]

                                                                                                              if (any(Y_train != Y_train[1]))
                                                                                                              {
                                                                                                                      ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                                                      # lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1)$lambda.min
                                                                                                                      # lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0)$lambda.min
                                                                                                                      # cv.err <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)

                                                                                                                      lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min
                                                                                                                      lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0,nfolds=3)$lambda.min


                                                                                                                      ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                                      predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)
                                                                                                                      predictor.ridge <- glmnet(X_train,Y_train,alpha=0,lambda=lambda.ridge)

                                                                                                                      Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)
                                                                                                                      Y_predict.ridge <- predict(predictor.ridge,newx=X_test, s= lambda.ridge)

                                                                                                                      r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                                                                      r2.pearson.ridge <- cor(Y_test,Y_predict.ridge)^2

                                                                                                                      # qplot(as.vector(Y_test), as.vector(Y_predict.lasso))

                                                                                                                      ########
                                                                                                                      # Using lambda.1se instead of lambda.min usually approximates with mean(Y_train)
                                                                                                                      # which is not good to calculate cor !

                                                                                                              } else {
                                                                                                                      r2.pearson.lasso <- NA
                                                                                                                      r2.pearson.ridge <- NA
                                                                                                              }

                                                                                                              return(c('lasso'=r2.pearson.lasso,'ridge'=r2.pearson.ridge))
                                                                                                      })

                                                                               pearson.df <- data.frame(t(pearson.fold))

                                                                               return(c('lasso'=mean(na.omit(pearson.df$lasso)),'ridge'=mean(na.omit(pearson.df$ridge)) ))
                                                                       })

                                                  Regression.df <- data.frame(t(Regression))
                                                  return(Regression.df)
                                          }



                ## We don't need to recompute everything, just the Genes with more than 1 CGI
                Regression.table <- get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',type,'_Promoter_table_CNV.RData')))

                Regression.table.MultipleCGIs <- NULL
                Regression.table.MultipleCGIs$lasso <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$lasso}) )
                Regression.table.MultipleCGIs$ridge <- Reduce('cbind',lapply(1:length(Regression.List), function(n){Regression.List[[n]]$ridge}) )

                Regression.table$lasso[Multiple_CGIs,] <- Regression.table.MultipleCGIs$lasso
                Regression.table$ridge[Multiple_CGIs,] <- Regression.table.MultipleCGIs$ridge

                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table_CNV_new.RData"))

                # Regression.Final <- data.frame(sapply(Regression.table, function(x){apply(x,1,function(s){mean(s,na.rm=T)})}))
                # save(Regression.Final,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_",n.repeats,"_CNV.RData"))
                save(NoCNV.index, file=paste0('../../big_data/GE_prediction/',DiseaseName,'_',type,'_',MethylationAnalysis,'_CNV_index.RData'))

        }  

}

# Regression.List <- lapply(seq(n.repeats), function(n.rep)
#                                           {
#                                                   print(n.rep)
#                                                   Regression <- sapply(1:nrow(GE.df), function(n) 
#                                                                        {
#                                                                                ###
#                                                                                Y <- t(GE.df[n,,drop=F])
#                                                                                X <- t(Meth.df[[n]])
# 
#                                                                                ###
#                                                                                pearson.fold <- sapply(seq(n.folds), function(n_fold)
#                                                                                                       {
#                                                                                                               #if (all(is.na(CNV.dat[n,-folds[[n_fold]]])))
#                                                                                                               if (any(is.na(CNV.dat[n,])))
#                                                                                                               {
#                                                                                                                       NoCNV.index[n] <- T
#                                                                                                               } else {
#                                                                                                                       X <- cbind(X,CNV.dat[n,])
#                                                                                                               }
#                                                                                                               colnames(X)[ncol(X)] <- "CNV"
# 
#                                                                                                               Y_train <- Y[-folds[[n.rep]][[n_fold]],,drop=F ]
#                                                                                                               X_train <- X[-folds[[n.rep]][[n_fold]],]
# 
#                                                                                                               Y_test <- Y[folds[[n.rep]][[n_fold]],,drop=F ]
#                                                                                                               X_test <- X[folds[[n.rep]][[n_fold]],]
# 
#                                                                                                               if (any(Y_train != Y_train[1]))
#                                                                                                               {
#                                                                                                                       ## 1) do Crossval on (X_train,Y_train) to tune lambda
#                                                                                                                       # lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1)$lambda.min
#                                                                                                                       # lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0)$lambda.min
#                                                                                                                       # cv.err <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)
# 
#                                                                                                                       lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min
#                                                                                                                       lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0,nfolds=3)$lambda.min
# 
# 
#                                                                                                                       ## 2) do prediction of Y_test and look at correlation with real Y_test
#                                                                                                                       predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)
#                                                                                                                       predictor.ridge <- glmnet(X_train,Y_train,alpha=0,lambda=lambda.ridge)
# 
#                                                                                                                       Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)
#                                                                                                                       Y_predict.ridge <- predict(predictor.ridge,newx=X_test, s= lambda.ridge)
# 
#                                                                                                                       r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
#                                                                                                                       r2.pearson.ridge <- cor(Y_test,Y_predict.ridge)^2
# 
#                                                                                                                       # qplot(as.vector(Y_test), as.vector(Y_predict.lasso))
# 
#                                                                                                                       ########
#                                                                                                                       # Using lambda.1se instead of lambda.min usually approximates with mean(Y_train)
#                                                                                                                       # which is not good to calculate cor !
# 
#                                                                                                               } else {
#                                                                                                                       r2.pearson.lasso <- NA
#                                                                                                                       r2.pearson.ridge <- NA
#                                                                                                               }
# 
#                                                                                                               return(c('lasso'=r2.pearson.lasso,'ridge'=r2.pearson.ridge))
#                                                                                                       })
# 
#                                                                                pearson.df <- data.frame(t(pearson.fold))
# 
#                                                                                return(c('lasso'=mean(na.omit(pearson.df$lasso)),'ridge'=mean(na.omit(pearson.df$ridge)) ))
#                                                                        })
# 
#                                                   Regression.df <- data.frame(t(Regression))
#                                                   return(Regression.df)
#                                           })
# 
# 


