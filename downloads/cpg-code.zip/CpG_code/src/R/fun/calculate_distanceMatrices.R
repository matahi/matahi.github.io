calculate_distanceMatrices <- function(Disease,type, analysis=c('Mean','Var'))
{
        for (method in analysis)
        {
                load(paste0('../../big_data/CGIs/',Disease,'_',type,'CGIs_',method,'.RData'))
                Dat <- eval(parse(text=paste0(Disease,".",type,"CGIs.",method)))

                distanceMat.Normalized <- matrix(0,nrow=length(list_big_island),ncol=length(list_big_island))

                library(dtw)
                for (k in 1:length(list_big_island))
                {
                        for (l in k:length(list_big_island))
                        {
                                tmp1 <- dtw(na.omit(Dat[[list_big_island[k]]]),na.omit(Dat[[list_big_island[l]]]), open.end=T , open.begin=T, step=asymmetric, distance.only=T)
                                distanceMat.Normalized[l,k] <- tmp1$normalizedDistance 
                                distanceMat.Normalized[k,l] <- tmp1$normalizedDistance
                        }
                }

                rownames(distanceMat.Normalized) <- paste0("CGI",1:nrow(distanceMat.Normalized))
                colnames(distanceMat.Normalized) <- paste0("CGI",1:nrow(distanceMat.Normalized))

                assign(paste0(Disease,".",type,".distanceMat",method,".Norm"), distanceMat.Normalized)

                save(list=eval(paste0(Disease,".",type,".distanceMat",method,".Norm")), file=paste0("../../big_data/CGIs/",Disease,"_",type,"_DistanceMat",method,"Norm.RData"))

        }
}
