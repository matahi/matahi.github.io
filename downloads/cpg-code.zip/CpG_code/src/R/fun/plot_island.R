plot_island <- function(Island,Disease, type="BOTH") #{{{1
{
        Pos <- which(fData450K[,"UCSC_CpG_Islands_Name"]==Island)
        Probes <- fData450K[Pos,"Name"]
        GeneName <- fData450K[Pos,"UCSC_RefGene_Name"]
        Betas.Island <- eval(parse(text=paste0(Disease,".",type)))[Pos,]
        #         Betas.Island <- BRCA.Cancerous[Pos,]
        toto <- melt(Betas.Island)
        data_to_plot <- data.frame(Patient = toto$variable, betas = toto$value, Location = fData450K[Pos, "MAPINFO"], IslandBegin=fData450K[Pos,"IslandBegin"],IslandEnd=fData450K[Pos,"IslandEnd"])

        # plot {{{2
        p <- ggplot(data = data_to_plot,aes(x=Location,y=betas))
        p1 <- p + geom_line(aes(colour = Patient)) + geom_point(aes(colour= Patient)) + theme(legend.position="none")
        p1 <- p1 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
        p2 <- p + geom_smooth() 
        p2 <- p2 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
        multiplot(p1,p2, cols=1)
        grid.arrange(p1,p2,ncol=1)

        # variance plot{{{2
        varBetas.Island <- apply(Betas.Island,1,var.na)
        plot(Location,varBetas.Island)

        # PCA {{{2
        res.pca <- PCA(t(Betas.Island))
        par(mfrow=c(2,1))
        plot(Location,res.pca$var$coord[,1],main ="PC1")
        plot(Location,res.pca$var$coord[,2],main ="PC2")

}

plot_CGI = function (CGI, Disease, type='BOTH') { # {{{1
        # Betas
        Id <- which(names(eval(parse(text=paste0(Disease,'.CancerousCGIs'))))==CGI)

        if (type!="BOTH"){
                Betas.Island <- eval(parse(text=paste0(Disease,'.',type,'CGIs')))[[Id]]
        } else {
                Betas.Cancerous <-eval(parse(text=paste0(Disease,'.CancerousCGIs')))[[Id]]
                Betas.Normal <-eval(parse(text=paste0(Disease,'.NormalCGIs')))[[Id]]
                Betas.Island <- cbind(Betas.Cancerous,Betas.Normal)
        }
        Betas.Infos <- melt(Betas.Island)

        # fData
        ## !! Careful doesn't work if Matrix has only one probe
        fData.Infos <- fData450K[rownames(Betas.Island),c("MAPINFO","IslandBegin","IslandEnd")]

        if (type!="BOTH"){
                data_to_plot <- data.frame(Patient=Betas.Infos$Var2, betas=Betas.Infos$value, Location= fData.Infos$MAPINFO, IslandBegin=fData.Infos$IslandBegin, IslandEnd=fData.Infos$IslandEnd)

                # plot {{{3
                p <- ggplot(data = data_to_plot,aes(x=Location,y=betas))
                p1 <- p + geom_line(aes(colour = Patient)) + geom_point(aes(colour= Patient)) + theme(legend.position="none")
                p1 <- p1 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
                p2 <- p + geom_smooth() 
                p2 <- p2 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
                #         multiplot(p1,p2, cols=1)
                grid.arrange(p1,p2,ncol=1)
        } else {
                type <-c(rep('Cancerous',nrow(Betas.Cancerous)*ncol(Betas.Cancerous)),rep('Normal',nrow(Betas.Normal)*ncol(Betas.Normal)))
                data_to_plot <- data.frame(Patient=Betas.Infos$Var2,type=type, betas=Betas.Infos$value, Location= fData.Infos$MAPINFO, IslandBegin=fData.Infos$IslandBegin, IslandEnd=fData.Infos$IslandEnd)

                # plot {{{3
                p <- ggplot(data = data_to_plot,aes(x=Location,y=betas))
                p1 <- p + geom_line(aes(colour = type, group=Patient)) + geom_point(aes(colour=type)) + theme(legend.position="none")
                p1 <- p1 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
                p2 <- p + geom_smooth(aes(colour=type)) 
                p2 <- p2 + geom_vline(xintercept=unique(c(data_to_plot$IslandBegin,data_to_plot$IslandEnd)))
                #         multiplot(p1,p2, cols=1)
                grid.arrange(p1,p2,ncol=1)
        }


}

plot_CGI_info = function (CGI, Disease,type, pc="normal") { # {{{1
        # Betas
        Id <- which(names(eval(parse(text=paste0(Disease,'.CancerousCGIs'))))==CGI)

        # General Methylation
        Betas.Island <- eval(parse(text=paste0(Disease,'.',type,'CGIs')))[[Id]]
        Betas.Island <- melt(Betas.Island)

        # Mean
        CGI.Mean <-  eval(parse(text=paste0(Disease,'.',type,'CGIs.Mean')))[[Id]]
        if (pc=="normal")
        {
        CGI.PC <- eval(parse(text=paste0(Disease,'.',type,'CGIs.PC')))[[Id]]
        } else if (pc=="robust")
        {
                CGI.PC <- eval(parse(text=paste0(Disease,'.',type,'CGIs.RobustPC')))[[Id]]
        }

        CGI.Infos <- cbind(CGI.Mean,CGI.PC$PC)
        Betas.Infos <- melt(CGI.Infos)
        Betas.Scores <- CGI.PC$Score
        
        # Scores
        #Betas.Scores <- melt(Betas.Scores)

        # fData
        ## !! Careful doesn't work if Matrix has only one probe
        fData.Infos <- fData450K[rownames(CGI.Infos),c("MAPINFO","IslandBegin","IslandEnd")]

        CGI.Betas <- data.frame(Patient=Betas.Island$Var2, betas=Betas.Island$value, Location= fData.Infos$MAPINFO, IslandBegin=fData.Infos$IslandBegin, IslandEnd=fData.Infos$IslandEnd)
        CGI.Resume <- data.frame(Info=Betas.Infos$Var2, betas=Betas.Infos$value, Location= fData.Infos$MAPINFO, IslandBegin=fData.Infos$IslandBegin, IslandEnd=fData.Infos$IslandEnd)
        #CGI.Scores <- data.frame(Info=Betas.Scores$Var2, betas=Betas.Scores$value, Location= fData.Infos$MAPINFO, IslandBegin=fData.Infos$IslandBegin, IslandEnd=fData.Infos$IslandEnd)

        p1 <- ggplot(data= CGI.Betas,aes(x=Location,y=betas))
        p1 <- p1 + geom_line(aes(colour = Patient)) + geom_point(aes(colour= Patient)) + theme(legend.position="none")
        p1 <- p1 + geom_vline(xintercept=unique(c(CGI.Betas$IslandBegin,CGI.Betas$IslandEnd)))
        p2 <- ggplot(data = CGI.Resume,aes(x=Location,y=betas))
        p2 <- p2 + geom_line(aes(colour = Info)) + geom_point(aes(colour= Info)) + theme(legend.position="none")
        p2 <- p2 + geom_vline(xintercept=unique(c(CGI.Resume$IslandBegin,CGI.Resume$IslandEnd)))
        p3 <- qplot(Betas.Scores[,1],Betas.Scores[,2])

        grid.arrange(p1,p2,p3,ncol=1)
}
