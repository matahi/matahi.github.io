plot_clusters_intercancer <- function(Disease1,Disease2,type="Cancerous",num_char=30)
{
        if (type=="Cancerous")
        {
                updown <- "updown"
        } else
        {
                updown <- ""
        }

        cluster1 <- get(load(paste0('../../big_data/CGIs/',Disease1,'_',type,'_ClustersMean_',updown,'.RData')))
        cluster2 <- get(load(paste0('../../big_data/CGIs/',Disease2,'_',type,'_ClustersMean_',updown,'.RData')))

        load('../../data/processed/fData/fData_CGI_big_island.RData')

        ###
        Dat.Mean1 <- get(load(paste0('../../big_data/CGIs/',Disease1,'_',type,'CGIs_Mean.RData')))[list_big_island]
        Dat.Mean2 <- get(load(paste0('../../big_data/CGIs/',Disease2,'_',type,'CGIs_Mean.RData')))[list_big_island]


        ### colour_scale
        #colour_scale <- c('1'='red',
        #                  '2'='green',
        #                  '3'='grey40',
        #                  '4up'='blue',
        #                  '4down'='yellow3')

        colour_scale <- c('BRCA'='red',
                          'LUAD'='green',
                          'Colon'='blue')

        ###### Disease1== 1/2 Disease2 == 3
        cluster.hyper <- which((cluster1 %in% c(1,2)) & (cluster2 == "4up"))
        n <- length(cluster.hyper)
        n.folds <- ceiling(length(cluster.hyper)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        for (k in 1:length(idx))
        {
                cluster.hyper_sample <- cluster.hyper[idx[[k]]] 

                Dat.X.1_hyper <- data.frame(methylation=Reduce('c', Dat.Mean1[ cluster.hyper_sample  ]) , disease=Disease1,
                                          cluster = rep(cluster1[cluster.hyper_sample], sapply(1:(length(cluster.hyper_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.hyper_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[ cluster.hyper_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandEnd"]})))

                Dat.X.2_hyper <- data.frame(methylation=Reduce('c', Dat.Mean2[ cluster.hyper_sample ]) , disease= Disease2,
                                          cluster = rep(cluster2[cluster.hyper_sample], sapply(1:(length(cluster.hyper_sample)), function(n){ nrow(fData_CGI_big_island[[ cluster.hyper_sample[n] ]]) }) ),
                                          position = Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[ cluster.hyper_sample[n]]][ ,"MAPINFO"    ]})) , 
                                          CGI =  Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                          IslandBegin= Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandBegin"]})), 
                                          IslandEnd=Reduce('c',lapply(1:length(cluster.hyper_sample), function(n){fData_CGI_big_island[[cluster.hyper_sample[n]]][ ,"IslandEnd"]})))

                Dat.X_hyper <- rbind(Dat.X.1_hyper,Dat.X.2_hyper)

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Clusterhyper_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.X_hyper,aes(x=position,y=methylation))+geom_point(aes(group=disease)) + geom_line(aes(group=disease,colour=disease,linetype=factor(disease)))+ scale_colour_manual(values=colour_scale) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()))
                dev.off()
        }



}
