# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines


load('../../big_data/CGIs/BRCA_corr_all.RData')
load('../../big_data/CGIs/BRCA_corr_df.RData')
load('../../data/processed/fData/genesGR_Hg19.RData')
load('../../big_data/CGIs/AssocIslandGenes.RData')

library(GenomicRanges)
library(reshape2)
library(ggplot2)

strand.df <- table(as.character(seqnames(genesGR)),as.character(strand(genesGR)))
strand.m <- melt(strand.df)

pdf('~/strand_vs_anti_strand.pdf')
ggplot(strand.m) + geom_bar(aes(x=factor(Var1, levels=c(paste0('chr',1:24))), y=value, fill=factor(Var2)), position="dodge")
dev.off()

##   sum(names(Assoc.islandGenes) %in% genesGR$Symbol)
Genes.CGIs <- unique(corr.df$Gene)

KnownGenesPos <- intersect(Genes.CGIs, genesGR$Symbol)
genesGR.match <- match( KnownGenesPos, genesGR$Symbol )
Assoc.match <- match( KnownGenesPos, Genes.CGIs )

genesGR.pos <- ranges(genesGR)[genesGR.match, ]
genesGR.pos <- data.frame(begin = start(genesGR.pos), end=end(genesGR.pos))
genesGR.strand <- as.character(strand(genesGR)[genesGR.match, ])

Genes.Assoc <- lapply(1:length(Genes.CGIs), function(n){ which(corr.df$Gene==Genes.CGIs[n])})

names(Genes.Assoc) <- Genes.CGIs
CGIs.pos <- data.frame(begin= sapply(1:length(Assoc.match), function(n){ corr.df[ Genes.Assoc[[Assoc.match[n]  ]][1] ,'IslandBegin'   ] } ),
                       end= sapply(1:length(Assoc.match), function(n){ corr.df[ Genes.Assoc[[Assoc.match[n] ]] [1] ,'IslandEnd'   ] } ))

###   ## ChosenCGIs <- sapply(1:length(Assoc.islandGenes), function(n){Assoc.islandGenes[[n]][1]})
###   plot(c(as.numeric(CGIs.pos[1,]), genesGR.pos[1,]), c(0,0,1,1))
###   lines(as.numeric(CGIs.pos[1,]) ,c(0,0), col="red")
###   lines(genesGR.pos[1,] ,c(1,1), col="blue")

strand <- lapply(1:length(Assoc.match), function(n){ rep(genesGR.strand[n], length(Genes.Assoc[[Assoc.match[n]]]) ) })
strand <- Reduce('c',strand)

strandBis <- sapply(1:length(strand), function(n){ifelse(strand[n]=="+",1,-1)})

corr.df <- corr.df[corr.df$Gene %in% KnownGenesPos, ]
corr.df <- cbind(corr.df,strandBis)

Relative <- sapply(1:nrow(corr.df), function(n)
                            {
                                    if (corr.df$position[n] < corr.df$IslandBegin[n])
                                    { 
                                            return(  corr.df$strandBis[n] * (corr.df$position[n] - corr.df$IslandBegin[n]))
                                    } else if ( (corr.df$position[n] > corr.df$IslandBegin[n])& (corr.df$position[n] < corr.df$IslandEnd[n]) )
                                    {
                                            return( 0 )
                                    } else 
                                    {
                                            return( corr.df$strandBis[n] * (corr.df$position[n] - corr.df$IslandEnd[n] ) )
                                    }
                            })


corr.out <- cbind(corr.df, Relative)
corr.out <- corr.out[corr.out$Relative != 0,  ]
corr.out <- data.frame(corr.out, pos=corr.out$Relative <0)

library(ggplot2)
library(splines)
library(MASS)
pdf('corr_out_CGI.pdf')
#ggplot(corr.out) + geom_point(aes(x=Relative,y=correlation)) + geom_vline(xintercept=0, colour="red")
#ggplot(corr.out) + stat_smooth(aes(x=Relative,y=correlation)) + geom_vline(xintercept=0, colour="red")
ggplot(corr.out, aes(x=Relative,y=correlation))  + geom_point() + stat_smooth(method = "lm", formula = y ~ ns(x,3))+  geom_vline(xintercept=0, colour="red")
dev.off()


pdf('corr_out_CGI.pdf')
ggplot(corr.out) + geom_boxplot(aes(x=pos,y=correlation)) 
dev.off()



library(splines)
library(MASS)
pdf('corr_out_CGI_smoothed.pdf')
ggplot(corr.out) + geom_point(aes(x=Relative,y =correlation)) + stat_smooth(aes(x=Relative,y=correlation), method="lm", formula=y~ ns(x,3)) + geom_vline(xintercept=0, colour="red")
dev.off()


RelativeCGI <- sapply(1:nrow(corr.df), function(n)
                      {
                              if (corr.df$position[n] < corr.df$IslandBegin[n])
                              { 
                                      return( 0 )
                              } else if ( (corr.df$position[n] > corr.df$IslandBegin[n])& (corr.df$position[n] < corr.df$IslandEnd[n]) )
                              {
                                      if (corr.df$strandBis[n] == 1)
                                      {
                                              return( (corr.df$position[n] - corr.df$IslandBegin[n]) / ( corr.df$IslandEnd[n] - corr.df$IslandBegin[n] )  )
                                      } else {
                                              return( 1 - (corr.df$position[n] - corr.df$IslandBegin[n]) / ( corr.df$IslandEnd[n] - corr.df$IslandBegin[n] )  )
                                      }

                              } else 
                              {
                                      return( 0 ) 
                              }
                      })


corr.CGI <- cbind(corr.df, RelativeCGI)
corr.CGI <- corr.CGI[corr.CGI$RelativeCGI != 0 , ]


pdf('corr_in_CGI.pdf')
ggplot(corr.CGI) + geom_point(aes(x=RelativeCGI,y=correlation)) + geom_vline(xintercept=0, colour="red") + geom_vline(xintercept=1, colour="red")
dev.off()






