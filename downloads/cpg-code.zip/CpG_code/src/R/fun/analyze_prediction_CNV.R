analyze_prediction_CNV <- function(DiseaseName)
{

        ###########################
        #### 0) Preprocessing {{{1

        if (DiseaseName=="Colon")
        {
                typeList <- "Cancerous"
        } else {
                typeList <- c('Normal',"Cancerous")
        }

        AnalysisList <- c('Mean','Promoter','AllCGIs')
        AnalysisList_Final <- c('Mean','Promoter')

        # Stock the p-values of tests
        out <- NULL

        # GeneNames
        CommonGenes <- get(load('../../big_data/CommonGenes.RData'))

        # GenesBigIsland
        list_big_island <- which(CpGIslands.probesize >=20)

        # CGIs Info
        AllCGIs.Assoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
        Assoc.Length <- sapply(AllCGIs.Assoc,length)
        MultipleCGIs <- (Assoc.Length != 1)

        ##### Create the dataframes
        # Gene.score.melted <- Reduce('rbind',lapply(1:length(typeList), function(k)
        #                                     {
        #                                             tmp <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_CNV.RData')))})
        #                                             tmp[[1]] <- t(tmp[[1]])
        #                                             tmp.df <- Reduce('cbind',tmp)
        #                                             colnames(tmp.df) <- c('LS','Promoter.Lasso','Promoter.Ridge','AllCGIs.Lasso','AllCGIs.Ridge')
        #                                             tmp.m <- melt(tmp.df)
        #                                             tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('LS','Lasso','Ridge','Lasso','Ridge'),each=2374), analysis=rep(c('Mean','Promoter','Promoter','AllCGIs','AllCGIs'),each=2374), type=typeList[k])
        #                                             tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('Mean','Promoter','AllCGIs'))
        #                                             return(tmp.melted)
        #                                     }))
        # Gene.score.df <- Reduce('cbind',lapply(1:length(typeList), function(k)
        #                                     {
        #                                             tmp <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_CNV.RData')))})
        #                                             tmp[[1]] <- t(tmp[[1]]) # Reposition the LS
        #                                             tmp.df <- Reduce('cbind',tmp)
        #                                             colnames(tmp.df) <- paste0(c('Mean.LS.','Promoter.Lasso.','Promoter.Ridge.','AllCGIs.Lasso.','AllCGIs.Ridge.'),typeList[k])
        #                                             rownames(tmp.df) <- CommonGenes
        #                                             return(tmp.df)
        #                                     }))

        Gene.score.melted.Final <- Reduce('rbind',lapply(1:length(typeList), function(k)
                                                         {
                                                                 #tmp <- lapply(1:length(AnalysisList_Final), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList_Final[n],'_100_CNV.RData')))})
                                                                 if (typeList[k] == "Cancerous")
                                                                 {
                                                                         tmp <- lapply(1:length(AnalysisList_Final), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList_Final[n],'_table_CNV.RData')))})
                                                                         tmp.Mean <- data.frame(LS.Meth_CNV=apply(tmp[[1]]$LS.Meth_CNV,1,mean), Promoter.Lasso=apply(tmp[[2]]$lasso,1,mean)  )
                                                                         tmp.m <- melt(tmp.Mean)
                                                                         tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Least Squares','Lasso'),each=2374), analysis=rep(c('Average','Full CGI+SS'),each=2374), type=typeList[k])
                                                                         tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('Average','Full CGI+SS'))
                                                                         tmp.melted$method <- factor(tmp.melted$method, levels=c('Least Squares','Lasso'))
                                                                         return(tmp.melted)

                                                                 } else if (typeList[k] == "Normal")
                                                                 {
                                                                         tmp <- lapply(1:length(AnalysisList_Final), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList_Final[n],'_table.RData')))})
                                                                         tmp.Mean <- data.frame(LS= apply(tmp[[1]],1,mean), Promoter.Lasso= apply(tmp[[2]]$lasso,1,mean))

                                                                         tmp.m <- melt(tmp.Mean)
                                                                         tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Least Squares','Lasso'),each=2374), analysis=rep(c('Average','Full CGI+SS'),each=2374), type=typeList[k])
                                                                         tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('Average','Full CGI+SS'))
                                                                         tmp.melted$method <- factor(tmp.melted$method, levels=c('Least Squares','Lasso'))
                                                                         return(tmp.melted)

                                                                 }

                                                         }))

        ## Clusters Info
        Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown.RData')))
        Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
        Clusters.GE <- sapply(1:length(CommonGenes), function(n) { return(Clusters.Meth[Promoter.Assoc[n]])})
        names(Clusters.GE) <- CommonGenes


        ###########################
        #### 1) Plots {{{1
        ## a) Boxplot of the Scores given the different methods 
        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/GeneScore_CNV.pdf'))
        # print(ggplot(Gene.score.melted) + geom_boxplot(aes(y=r2.predict,x=analysis,fill=method)) + facet_grid(~type))
        # dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/GeneScore_Final_CNV.pdf'))
        print(ggplot(Gene.score.melted.Final) + geom_boxplot(aes(y=r2.predict,x=analysis,fill=method)) + facet_grid(~type))
        dev.off()


        ## b) Plot Karyogram and grandlinear 
        out.karyogram <- plot_karyogram(Gene.score.df[,"Promoter.Ridge.Cancerous"])

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Cancerous_Ridge_Pattern_Karyogram_CNV.pdf'))
        print(out.karyogram$point)
        dev.off()

        # pdf('../../results/GE_prediction/BRCA/Comparison/R2_pearson_Cancerous_Ridge_Pattern_Karyogram_density.pdf')
        # print(out$density)
        # dev.off()

        # ## Zoom on regions
        # chr <- "chr6"
        # Region <- c(30e6, 36e6)

        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/R2_pearson_Cancerous_Promoter_GrandLinear_Zoom.pdf'))
        # out.zoom <- zoom_region(Values= Gene.score.df[,"Promoter.Ridge.Cancerous"], chr=chr, Region=Region)
        # print(out.zoom)
        # dev.off()

        ###########################
        #### 3) List of epigenetically regulated Genes
        out$ERG <- lapply(1:length(colnames(Gene.score.df)), function(n)
                          {
                                  ## Find the genes
                                  tmp <- data.frame(Genes=rownames(Gene.score.df[na.omit(which(Gene.score.df[,n]>0.5)),]),Score=Gene.score.df[na.omit(which(Gene.score.df[,n]>0.5)),n])

                                  ## Then order by decreasing score
                                  tmp <- tmp[order(tmp$Score,decreasing=T),]
                          })
        names(out$ERG) <- colnames(Gene.score.df)

        ## Look at clusters associated
        # TODO !!


        #a) Analyze the intersection
        ###########################
        # intersect(out$ERG$AllCGIs.Lasso.Cancerous$Genes,out$ERG$AllCGIs.Ridge.Cancerous$Genes)
        #### Intersection is ~ stable

        #b) Do gene ontology
        ###################
        ### -> InterCancer
        
        #c) Verify Gene expression
        ##########################
        ## For all genes
        GE.Full <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData')))
        GE.Names <- sapply(strsplit(rownames(GE.Full),"\\|"),"[",1)
        GE.Dat <- GE.Full[match(CommonGenes, GE.Names),]
        GE.Mean <- apply(GE.Dat,1,mean)
        GE.Mean <- GE.Mean + 1e-5

        GE.clusters.full <- data.frame(GE=GE.Mean, Score=Gene.score.df$AllCGIs.Lasso.Cancerous, clusters=Clusters.GE)

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_GE_Clusters_CNV.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=GE,y=Score)) + facet_grid(~clusters) + geom_hline(yintercept=0.5, colour='blue', linetype="longdash") + geom_vline(xintercept=1, colour='red') + scale_x_log10() + ylim(0,1)    )
        dev.off()

        # median(na.omit(GE.Mean[Clusters.GE=="4up"]))

        # median(na.omit(GE.Mean[Clusters.GE=="1"]))

        ## For Interesting genes
        Interesting.Genes <-out$ERG$AllCGIs.Lasso.Cancerous$Genes ## out$ERG[[9]] = AllCGIs Lasso Cancerous
        GE.Interesting <- GE.Full[match(Interesting.Genes, GE.Names),] 
        rownames(GE.Interesting) <- Interesting.Genes 

        GE.Interesting.melted <- melt(GE.Interesting)
        GE.Interesting.melted <- data.frame(Gene= GE.Interesting.melted$Var1, GE= GE.Interesting.melted$value, cluster= Clusters.GE[as.character(GE.Interesting.melted$Var1)])

        colour_scale <- c('1'='red',
                          '2'='green',
                          '3'='black',
                          '4down'='yellow',
                          '4up'='blue')

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/GE_CNV.pdf'))
        print(ggplot(GE.Interesting.melted) + geom_boxplot(aes(x=Gene,y=GE,fill=cluster)) + theme(axis.text.x = element_text(angle = 90, hjust = 1)) + geom_hline(yintercept=1, colour='red') + scale_y_log10() + scale_fill_manual(values=colour_scale)      )
        dev.off()

        #d) r2=f(Clusters)?
        ####################
        tmp.df <- data.frame(  Gene.score.melted[Gene.score.melted$type=="Cancerous",]  ,GE=GE.Mean, Clusters=Clusters.GE)
        tmp.df$method <- factor(tmp.df$method, levels=c('LS','Ridge','Lasso'))

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_Clusters_CNV.pdf'))
        print(ggplot(tmp.df) + geom_boxplot(aes(x=Clusters,fill=analysis,y=r2.predict)) + facet_grid(~method)+ ylim(0,1))
        dev.off()

        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_GE_Clusters.pdf'))
        # print(ggplot(tmp.df) + geom_point(aes(x=GE,y=r2.predict)) + facet_grid(~method) + scale_x_log10() + geom_vline(xintercept=1, colour="red") + ylim(0,1))
        # dev.off()

        # wilcox.test(Scores.df$Scores[Scores.df$Clusters=="3up"],Scores.df$Scores[Scores.df$Clusters=="1"])$p.value

        #e) Look at Lasso predictor for interesting genes
        #################################################
        Interesting.Genes <-out$ERG$AllCGIs.Lasso.Cancerous$Genes ## out$ERG[[9]] = AllCGIs Lasso Cancerous
        # save(Interesting.Genes, file=paste0("../../big_data/GE_prediction/ERG_",DiseaseName,".RData"))
        GE.Interesting <- GE.Full[match(Interesting.Genes, GE.Names),] 
        rownames(GE.Interesting) <- Interesting.Genes 

        ## 
        Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed.RData')))[list_big_island]
        fData.big_island <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))

        library(glmnet)
        set.seed(1234)
        n.folds <- 3
        folds <- split( sample( seq(ncol(GE.Interesting)) ), seq(n.folds) )

        Predictions.CV <- lapply(1:length(Interesting.Genes), function(n){ 
                                 Index <- which(CommonGenes==Interesting.Genes[n])
                                 Y <- t(GE.Interesting[n,,drop=F])
                                 X <- t(Meth.Dat[[ Promoter.Assoc[Index] ]])

                                 prediction.fold <- lapply(seq(n.folds), function(n_fold)
                                                                    {
                                                                            Y_train <- Y[-folds[[n_fold]],,drop=F ]
                                                                            X_train <- X[-folds[[n_fold]],]

                                                                            Y_test <- Y[folds[[n_fold]],,drop=F ]
                                                                            X_test <- X[folds[[n_fold]],]

                                                                            ###### Verify if any(Y_train != Y_train[1])
                                                                            if (any(Y_train != Y_train[1]))
                                                                            {
                                                                                    ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                    lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1)$lambda.min

                                                                                    ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                    predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)

                                                                                    Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)

                                                                                    r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                            } else {
                                                                                    r2.pearson.lasso <- NA
                                                                                    r2.pearson.ridge <- NA
                                                                            }

                                                                            return(data.frame(Real=as.vector(Y_test),Predict=as.vector(Y_predict.lasso)))
                                                                    })


                                             
                                 return(Reduce('rbind',prediction.fold))


                          } )

        Predictions.df <- data.frame(Real=Reduce('rbind',Predictions.CV)$Real,
                                     Predict=Reduce('rbind',Predictions.CV)$Predict,
                                     Gene=rep(Interesting.Genes, each=ncol(GE.Interesting)))

        #### TO FINISH
        GeneList <-  split( Interesting.Genes, seq(floor(length(Interesting.Genes)/12 )))

        for (k in 1:length(GeneList))
        {
                pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Plot_Predict_Real_',k,'_CNV.pdf'))
                print(ggplot(Predictions.df[Predictions.df$Gene %in%  GeneList[[k]] , ]) + geom_point(aes(x=Real,y=Predict)) + facet_wrap( ~ Gene, scales="free", ncol=4)  )
                dev.off()
        }

        Predictors.New <- lapply(1:length(Interesting.Genes), function(n){ 
                                 Index <- which(CommonGenes==Interesting.Genes[n])
                                 Y <- t(GE.Interesting[n,,drop=F])
                                 X <- t(Meth.Dat[[ Promoter.Assoc[Index] ]])
                                 cv.lasso <- cv.glmnet(X,Y,alpha=1)      
                                 best.fit <- glmnet(X,Y,lambda=cv.lasso$lambda.min,alpha=1)
                                 return(as.vector(coef(best.fit))[-1]/norm(as.vector(coef(best.fit))[-1],"2"))
                          } )

        Predictors <- Reduce('c',Predictors.New)

        Dat <- data.frame(Predictors= Predictors,
                          position= Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ; fData.big_island[[ Promoter.Assoc[Index] ]][ ,"MAPINFO"    ]  })),
                          IslandDist= Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandDist"    ]  })),
                          CGI = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index]  ]][ ,"UCSC_CpG_Islands_Name"    ]  })),
                          Gene = rep(Interesting.Genes, sapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]);nrow(fData.big_island[[Promoter.Assoc[Index] ]])})),
                          IslandBegin = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandBegin"    ]  })),
                          IslandEnd = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandEnd"    ]  })),
                          Relation_to_UCSC_CpG_Island = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"Relation_to_UCSC_CpG_Island"    ]  })))

        Dat$Relation_to_UCSC_CpG_Island <- factor(Dat$Relation_to_UCSC_CpG_Island, levels= c('N_Shelf','N_Shore','Island','S_Shore','S_Shelf'))

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_CNV.pdf'))
        print(ggplot(Dat,aes(x=position,y=Predictors))+geom_point() 
              + geom_line()
              + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")
              + geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")
              + geom_hline(yintercept=0, colour="red")
              #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
              + facet_wrap( ~ Gene, scales="free", ncol=4)  
              + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_boxplot_CNV.pdf'))
        print(ggplot(Dat,aes(x=Relation_to_UCSC_CpG_Island,y=abs(Predictors))) 
              + geom_boxplot()
              + theme(legend.position="none"))
        dev.off()

        Dat.CGI <- Dat[(Dat$IslandDist>=0)&(Dat$IslandDist<=1),]
        Dat.Shore_Shelves <- Dat[(Dat$IslandDist<=0)|(Dat$IslandDist>=1),]

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_Resume_CGI_CNV.pdf'))
        print(ggplot(Dat.CGI,aes(x=IslandDist,y=abs(Predictors)))+geom_point() 
              + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
              + geom_vline(aes(xintercept=1),colour="black", linetype= "longdash")
              + geom_hline(yintercept=0, colour="red")
              #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
              + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Predictors_Resume_Shore_Shelves_CNV.pdf'))
        print(ggplot(Dat.Shore_Shelves,aes(x=IslandDist,y=abs(Predictors)))+geom_point() 
              + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
              + geom_hline(yintercept=0, colour="red")
              #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
              + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

        #f) Adjust for CNV Variation?
        #############################
        ### No CNV for LUAD
        if (DiseaseName != "LUAD")
        {
                Gene.CNV <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/CancerousCNV_Genes.RData')))
                Gene.CNV.Mean <- apply(Gene.CNV,1,mean)

                pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/CNV_Adjust_CNV.pdf'))
                print(qplot(Gene.CNV.Mean, Gene.score.df[,"AllCGIs.Lasso.Cancerous"])+ geom_vline(xintercept=0, colour="blue") + geom_hline(yintercept=0.5,linetype="longdash",colour="red") +ylim(0,1) )
                dev.off()

                pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/CNV_GE_CNV.pdf'))
                print(qplot(Gene.CNV.Mean, GE.Mean) + geom_vline(xintercept=0, colour="blue") + geom_hline(yintercept=1,linetype="longdash",colour="red") + scale_y_log10() )
                dev.off()
        }

        ###########################
        #### 2) Look at the statistics 
        # Mean vs Promoter Lasso
        out$Mean_LS_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"Mean.LS.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"Mean.LS.Cancerous"])))

        out$Promoter_Lasso_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"Promoter.Lasso.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"Promoter.Lasso.Cancerous"])))

        out$Promoter_Ridge_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"Promoter.Ridge.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"Promoter.Ridge.Cancerous"])))

        out$AllCGIs_Lasso_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"AllCGIs.Lasso.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"AllCGIs.Lasso.Cancerous"])))

        out$AllCGIs_Ridge_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"AllCGIs.Ridge.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"AllCGIs.Ridge.Cancerous"])))

        # Promoter Lasso vs Promoter Ridge
        out$PromoterLasso_PromoterRidge <- wilcox.test(Gene.score.df[,"Promoter.Lasso.Cancerous"], Gene.score.df[,"Promoter.Ridge.Cancerous"])$p.value

        # AllCGIs Lasso vs AllCGIs Ridge
        out$AllCGIsLasso_AllCGIsRidge <- wilcox.test(Gene.score.df[,"AllCGIs.Lasso.Cancerous"], Gene.score.df[,"AllCGIs.Ridge.Cancerous"])$p.value

        # Promoter Lasso vs AllCGIs Lasso
        out$PromoterLasso_AllCGIsLasso <- wilcox.test(Gene.score.df[MultipleCGIs,"Promoter.Lasso.Cancerous"], Gene.score.df[MultipleCGIs,"AllCGIs.Lasso.Cancerous"])$p.value

        # Promoter Ridge vs AllCGIs Ridge
        out$PromoterRidge_AllCGIsRidge <- wilcox.test(Gene.score.df[MultipleCGIs,"Promoter.Ridge.Cancerous"], Gene.score.df[MultipleCGIs,"AllCGIs.Ridge.Cancerous"])$p.value

        return(out)
}
