predict_ALL <- function(DiseaseName,type,preprocessing="Level2",MethylationAnalysis="all")
{

        # DiseaseName <- "BRCA"
        # type <- "Cancerous"
        # preprocessing <- "Level2"
        # MethylationAnalysis <- "chr"

        ## Preprocessing 
        Meth.dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,preprocessing,'_processed.RData')))
        GE.dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData')))
        fData <- get( load("../../data/processed/fData/fData450K_ordered.RData"))

        ## Load fData Infos
        load("../../data/processed/fData/CpGIslands.RData")
        load("../../data/processed/fData/CpGIslands_size.RData")
        load("../../data/processed/fData/CpGIslands_probe_size.RData")
        list_big_island <- which(CpGIslands.probesize >=20)

        # required packages
        require('ggplot2')
        require('reshape2') #for Melt for data.frame
        require('gridExtra') # for plotting several ggplots -> grid.arrange
        require('ggbio')

        load('../../big_data/GE_prediction/Tools/CommonGenes.RData')
        Genes.GE <- sapply(1:nrow(GE.dat), function(n){tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])}) 
        GE.df <- GE.dat[match(CommonGenes,Genes.GE),]


        # n.folds <- 3
        # set.seed(1234)
        # folds <- split( sample( seq(ncol(GE.df)) ), seq(n.folds) )

        if (MethylationAnalysis=="all") {
                # print('predicting GE with 1 to 1 CGI/GE association')
                print('Method : ALL')

                ### Process Methylation Data

                n.repeats <- 100
                n.folds <- 3
                set.seed(1234)

                ### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                library(doParallel)
                registerDoParallel(cores=10)

                Regression.List <- foreach(n.rep=1:n.repeats) %dopar%
                                          {
                                                  partition <- split(sample(seq(ncol(GE.df))), seq(n.folds))
                                                  print(n.rep)

                                                  Regression <- sapply(1:nrow(GE.df), function(n) 
                                                                       {
                                                                               # progress <- n*100/nrow(GE.df)
                                                                               # if (progress %/% GE.df==0)
                                                                               
                                                                               ###
                                                                               Y <- t(GE.df[n,,drop=F])
                                                                               X <- t(Meth.dat)

                                                                               ###
                                                                               pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                                                      {
                                                                                                              Y_train <- Y[-partition[[n_fold]],,drop=F ]
                                                                                                              X_train <- X[-partition[[n_fold]],]

                                                                                                              Y_test <- Y[partition[[n_fold]],,drop=F ]
                                                                                                              X_test <- X[partition[[n_fold]],]

                                                                                                              if (any(Y_train != Y_train[1]))
                                                                                                              {
                                                                                                                      ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                                                      lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min

                                                                                                                      ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                                                      predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)

                                                                                                                      Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)

                                                                                                                      r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                                                              } else {
                                                                                                                      r2.pearson.lasso <- NA
                                                                                                              }

                                                                                                              return(r2.pearson.lasso)
                                                                                                      })


                                                                               return(mean(na.omit(pearson.df)))
                                                                       })


                                                  return(Regression)
                                          }

                Regression.table$lasso <- Reduce('c',Regression.List )
                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table.RData"))

        }  else if (MethylationAnalysis=="chr") {

                print('Method : chr')

                ### Process Methylation Data

                n.repeats <- 100
                n.folds <- 3
                set.seed(1234)

                ### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
                library(glmnet)
                library(doParallel)
                registerDoParallel(cores=10)

                Regression.List <- foreach(n.rep=1:n.repeats) %dopar%
                #Regression.List <- foreach(n.rep=1:2) %dopar%
                {
                        partition <- split(sample(seq(ncol(GE.df))), seq(n.folds))
                        print(n.rep)

                        Regression <- sapply(1:nrow(GE.df), function(n) 
                        # Regression <- sapply(1:5, function(n) 
                                             {

                                                     ###
                                                     Y <- t(GE.df[n,,drop=F])
                                                     X <- t(Meth.dat)

                                                     #### Filter X on chr
                                                     GeneName <- strsplit(rownames(GE.df)[n],"\\|")[[1]][1]
                                                     chr <- fData$CHR[grep(paste0('^',GeneName,'$','|',
                                                                                  '^',GeneName,';','|',
                                                                                  ';',GeneName,';','|',
                                                                                  ';',GeneName,'$'),
                                                                                  fData$UCSC_RefGene_Name)]

                                                     if (length(unique(chr))!=1)
                                                     {
                                                             print(GeneName)
                                                             return(NA)
                                                     }

                                                     X <- t(Meth.dat[fData$CHR==unique(chr),])

                                                     ###
                                                     pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                                                            {
                                                                                    Y_train <- Y[-partition[[n_fold]],,drop=F ]
                                                                                    X_train <- X[-partition[[n_fold]],]

                                                                                    Y_test <- Y[partition[[n_fold]],,drop=F ]
                                                                                    X_test <- X[partition[[n_fold]],]

                                                                                    if (any(Y_train != Y_train[1]))
                                                                                    {
                                                                                            ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                                                                            lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1,nfolds=3)$lambda.min
                                                                                            # lambda.ridge <- cv.glmnet(X_train,Y_train,alpha=0,nfolds=3)$lambda.min

                                                                                            ## 2) do prediction of Y_test and look at correlation with real Y_test
                                                                                            predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)
                                                                                            # predictor.ridge <- glmnet(X_train,Y_train,alpha=0,lambda=lambda.ridge)

                                                                                            Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)
                                                                                            # Y_predict.ridge <- predict(predictor.ridge,newx=X_test, s= lambda.ridge)

                                                                                            r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                                                                            # r2.pearson.ridge <- cor(Y_test,Y_predict.ridge)^2
                                                                                    } else {
                                                                                            r2.pearson.lasso <- NA
                                                                                            # r2.pearson.ridge <- NA
                                                                                    }

                                                                                    return(r2.pearson.lasso)

                                                                            })


                                                     return(mean(na.omit(pearson.fold)))
                                             })

                        # Regression.df <- data.frame(t(Regression))

                        return(Regression)
                }

                Regression.table <- Reduce('cbind', Regression.List)
                save(Regression.table,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_table.RData"))

                # Regression.Final <- data.frame(sapply(Regression.table, function(x){apply(x,1,function(s){mean(s,na.rm=T)})}))
                # save(Regression.Final,file=paste0('../../big_data/GE_prediction/',DiseaseName,"_",type,"_",MethylationAnalysis,"_",n.repeats,".RData"))


        }

}
