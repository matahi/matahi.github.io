plot_gene <- function(Gene,Disease,type="Cancerous",ClinicalInfo=NULL, features=NULL,fData=fData450K_Gene)
{
        ## Library Loading 
        require(ggbio)
        require(GenomicRanges)
        source("fun/zoom_region.R")

        ### Processing 
        require(TxDb.Hsapiens.UCSC.hg19.knownGene)
        txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene

        data(genesymbol, package="biovizBase")
        gene.gr <- genesymbol[Gene]

        fData.Gene <- fData450K_Gene[[Gene]]
        if (is.null(fData.Gene)){
                return(NULL)
        } else {
                ## Data Processing 
                Dat.Gene <- t(eval(parse(text=paste0(Disease,".",type,"Genes[['",Gene,"']]"))))

                #missingSample <- which(is.na(Dat.Gene),arr.ind=TRUE)
                #if (nrow(missingSample)!=0){
                #        Betas <- Betas[,-unique(missingSample[,2])]
                #}
                Dat.Gene <- na.omit(Dat.Gene)

                melt.df <- melt(Dat.Gene)
                if (is.null(ClinicalInfo)){
                        Dat.df <- data.frame(x = rep(fData.Gene[,"MAPINFO"],each=nrow(Dat.Gene)), betas = melt.df$value, sample = melt.df$Var1)
                        p2 <- ggplot(Dat.df) + geom_line(aes(x= x, y= betas, colour=sample)) + geom_point(aes(x= x, y= betas, colour=sample)) +
                        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + 
                        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"]))) +
                        theme(legend.position="none")  

                        p1 <- autoplot(txdb, which=gene.gr)

                        pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,'.pdf'), width=10, height=10, pointsize=1)
                        print(tracks(p1, p2))
                        dev.off()

                        promoterRegion <- zoom_region(fData.Gene) # Find a way to automatize the zoom on the promoter regions

                        pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,'promoter.pdf'), width=10, height=10, pointsize=1)
                        print(tracks(p1, p2) + xlim(promoterRegion))
                        dev.off()

                } else {
                        Dat.df <- data.frame(x = rep(fData.Gene[,"MAPINFO"],each=nrow(Dat.Gene)), betas = melt.df$value, sample = melt.df$Var1)
                        NewInfo <- ClinicalInfo[as.character(Dat.df$sample),features] 
                        Dat.df <- cbind(Dat.df,NewInfo)

                        for (feature in features){
                                if (length(unique(na.omit(fData.Gene[,"IslandBegin"])))!=0){
                                        p2 <- ggplot(Dat.df, aes_string(x="x",y="betas",colour=paste0("as.factor(",feature,")"))) + geom_line(aes(group=sample)) + geom_point(aes(group=sample)) +
                                        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandBegin"]))) + 
                                        geom_vline(xintercept=unique(na.omit(fData.Gene[,"IslandEnd"])))# +
                                        #                         theme(legend.position="none")  

                                        p1 <- autoplot(txdb, which=gene.gr)

                                        pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,"_",feature,'.pdf'), width=10, height=10, pointsize=1)
                                        print(tracks(p1, p2))
                                        dev.off()


                                        promoterRegion <- zoom_region(fData.Gene) # Find a way to automatize the zoom on the promoter regions

                                        pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,"_",feature,'promoter.pdf'), width=10, height=10, pointsize=1)
                                        print(tracks(p1, p2) + xlim(promoterRegion))
                                        dev.off()
                                } else {
                                        p2 <- ggplot(Dat.df, aes_string(x="x",y="betas",colour=paste0("as.factor(",feature,")"))) + geom_line(aes(group=sample)) + geom_point(aes(group=sample)) 

                                        p1 <- autoplot(txdb, which=gene.gr)

                                        pdf(paste0('../../results/Genes/',Disease,"/",Gene,"_",type,"_",feature,'.pdf'), width=10, height=10, pointsize=1)
                                        print(tracks(p1, p2))
                                        dev.off()
                                }
                        }
                }

                # multiplot(p1,p2, cols=1)
                # grid.arrange(p1,p2,ncol=1)

                return(Betas)
        }
}
