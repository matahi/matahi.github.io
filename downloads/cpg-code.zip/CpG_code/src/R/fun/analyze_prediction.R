analyze_prediction <- function(DiseaseName)
{

        ###########################
        #### 0) Preprocessing {{{1
        # DiseaseName <- "BRCA"
        # DiseaseName <- "LUAD"
        # DiseaseName <- "Colon"

        if (DiseaseName=="Colon")
        {
                typeList <- "Cancerous"
        } else {
                typeList <- c('Normal',"Cancerous")
        }

        AnalysisList <- c('Mean','Promoter','AllCGIs')
        AnalysisList_Final <- c('Mean','Promoter')
        #AnalysisList_Final <- c('Mean','Promoter','AllCGIs')

        # Stock the p-values of tests
        out <- NULL

        # GeneNames
        CommonGenes <- get(load('../../big_data/CommonGenes.RData'))

        # GenesBigIsland
        list_big_island <- which(CpGIslands.probesize >=20)

        # CGIs Info
        AllCGIs.Assoc <- get(load('../../big_data/GE_prediction/Tools/AllCGIsAssoc.RData'))
        Assoc.Length <- sapply(AllCGIs.Assoc,length)
        MultipleCGIs <- (Assoc.Length != 1)

        # AnalysisList_Final <- c('Mean','Promoter','AllCGIs')
        # typeList <- "Cancerous"

        Gene.score.melted.Final <- Reduce('rbind',lapply(1:length(typeList), function(k)
                                                          {
                                                                  tmp <- lapply(1:length(AnalysisList_Final), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList_Final[n],'_table.RData')))})
                                                                  tmp[[1]] <- apply(tmp[[1]],1,function(x){mean(x,na.rm=T)})
                                                                  tmp[[2]]$lasso <- apply(tmp[[2]]$lasso,1,function(x){mean(x,na.rm=T)})
                                                                  tmp[[2]]$ridge <- apply(tmp[[2]]$ridge,1,function(x){mean(x,na.rm=T)})

                                                                  if (length(AnalysisList_Final)==3)
                                                                  {
                                                                          tmp[[3]]$lasso <- apply(tmp[[3]]$lasso,1,function(x){mean(x,na.rm=T)})
                                                                          tmp[[3]]$ridge <- apply(tmp[[3]]$ridge,1,function(x){mean(x,na.rm=T)})

                                                                          tmp.df <- data.frame(tmp[[1]],tmp[[2]]$lasso, tmp[[2]]$ridge,tmp[[3]]$lasso,tmp[[3]]$ridge)
                                                                          colnames(tmp.df) <- paste0(c('LS','Promoter.Lasso','Promoter.Ridge','AllCGIs.Lasso','AllCGIs.Ridge'),".",typeList[k])
                                                                          tmp.df <- tmp.df[,c(1:2,4)] ## Ridge and Lasso are redundant
                                                                          AllMethylome <- get(load('jobs/BRCA_Cancerous_all.RData'))
                                                                          tmp.df <- cbind(tmp.df,AllMethylome)
                                                                          tmp.m <- melt(tmp.df)
                                                                          tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Least Squares','Lasso','Lasso','Lasso'),each=2374), analysis=rep(c('Average','Full CGI+SS','All CGI+SS','All Methylome'),each=2374), type=typeList[k])
                                                                          tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('Average','Full CGI+SS','All CGI+SS','All Methylome'))
                                                                          tmp.melted$method <- factor(tmp.melted$method, levels=c('Least Squares','Lasso'))
                                                                  } else {
                                                                          tmp.df <- data.frame(tmp[[1]],tmp[[2]]$lasso, tmp[[2]]$ridge)
                                                                          colnames(tmp.df) <- paste0(c('LS','Promoter.Lasso','Promoter.Ridge'),".",typeList[k])
                                                                          tmp.df <- tmp.df[,c(1:2)] ## Ridge and Lasso are redundant
                                                                          tmp.m <- melt(tmp.df)
                                                                          tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('Least Squares','Lasso'),each=2374), analysis=rep(c('Average','Full CGI+SS'),each=2374), type=typeList[k])
                                                                          tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('Average','Full CGI+SS'))
                                                                          tmp.melted$method <- factor(tmp.melted$method, levels=c('Least Squares','Lasso'))

                                                                  }

                                                                  return(tmp.melted)

                                                          }))

        Gene.score.df.Final <- Reduce('cbind',lapply(1:length(typeList), function(k)
                                                          {
                                                                  tmp <- lapply(1:length(AnalysisList_Final), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList_Final[n],'_table.RData')))})
                                                                  tmp[[1]] <- apply(tmp[[1]],1,function(x){mean(x,na.rm=T)})
                                                                  tmp[[2]]$lasso <- apply(tmp[[2]]$lasso,1,function(x){mean(x,na.rm=T)})
                                                                  tmp[[2]]$ridge <- apply(tmp[[2]]$ridge,1,function(x){mean(x,na.rm=T)})
                                                                  if (length(AnalysisList_Final)==3)
                                                                  {
                                                                          tmp[[3]]$lasso <- apply(tmp[[3]]$lasso,1,function(x){mean(x,na.rm=T)})
                                                                          tmp[[3]]$ridge <- apply(tmp[[3]]$ridge,1,function(x){mean(x,na.rm=T)})

                                                                          tmp.df <- data.frame(tmp[[1]],tmp[[2]]$lasso, tmp[[2]]$ridge,tmp[[3]]$lasso,tmp[[3]]$ridge)
                                                                          colnames(tmp.df) <- paste0(c('LS','Promoter.Lasso','Promoter.Ridge','AllCGIs.Lasso','AllCGIs.Ridge'),".",typeList[k])
                                                                          tmp.df <- tmp.df[,c(1:2,4)] ## Ridge and Lasso are redundant
                                                                          AllMethylome <- get(load('jobs/BRCA_Cancerous_all.RData'))
                                                                          tmp.df <- cbind(tmp.df,AllMethylome)

                                                                  } else {
                                                                          tmp.df <- data.frame(tmp[[1]],tmp[[2]]$lasso, tmp[[2]]$ridge)
                                                                          colnames(tmp.df) <- paste0(c('LS','Promoter.Lasso','Promoter.Ridge'),".",typeList[k])
                                                                          tmp.df <- tmp.df[,c(1:2)] ## Ridge and Lasso are redundant
                                                                  }

                                                                  rownames(tmp.df) <- CommonGenes
                                                                  return(tmp.df)
                                                          }))

        # Gene.score.all <- get(load('jobs/BRCA_Cancerous_all.RData'))
        wilcox.test(Gene.score.df.Final$Promoter.Lasso.Cancerous, Gene.score.df.Final$AllMethylome)
        summary(Gene.score.df.Final$AllMethylome)

        # library(ggplot2)
        # qplot(Gene.score.df.Final$Promoter.Lasso.Cancerous, Gene.score.all) + geom_abline(a=0,b=1, col="red")

        # Gene.score.df <- Reduce('cbind',lapply(1:length(typeList), function(k)
        #                                                   {
        #                                                           tmp <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'_table.RData')))})
        #                                                           tmp[[1]] <- apply(tmp[[1]],1,function(x){mean(x,na.rm=T)})
        #                                                           tmp[[2]]$lasso <- apply(tmp[[2]]$lasso,1,function(x){mean(x,na.rm=T)})
        #                                                           tmp[[2]]$ridge <- apply(tmp[[2]]$ridge,1,function(x){mean(x,na.rm=T)})
        #                                                           tmp[[3]]$lasso <- apply(tmp[[3]]$lasso,1,function(x){mean(x,na.rm=T)})
        #                                                           tmp[[3]]$ridge <- apply(tmp[[3]]$ridge,1,function(x){mean(x,na.rm=T)})

        #                                                           #tmp.df <- data.frame(tmp[[1]],tmp[[2]]$lasso, tmp[[2]]$ridge)
        #                                                           tmp.df <- data.frame(tmp[[1]],tmp[[2]]$lasso, tmp[[2]]$ridge,tmp[[3]]$lasso,tmp[[3]]$ridge)
        #                                                           # colnames(tmp.df) <- paste0(c('LS','Promoter.Lasso','Promoter.Ridge'),".",typeList[k])
        #                                                           colnames(tmp.df) <- paste0(c('LS','Promoter.Lasso','Promoter.Ridge','AllCGIs.Lasso','AllCGIs.Ridge'),".",typeList[k])

        #                                                           # tmp.df <- tmp.df[,c(1:2)] ## Ridge and Lasso are redundant
        #                                                           tmp.df <- tmp.df[,c(1:2,4)] ## Ridge and Lasso are redundant
        #                                                           rownames(tmp.df) <- CommonGenes
        #                                                           return(tmp.df)
        #                                                   }))


        # # wilcox.test(Gene.score.df.Final$Promoter.Lasso.Cancerous, Gene.score.df.Final$LS.Cancerous,paired=T)$p.value

        # # wilcox.test(Gene.score.df.Final$Promoter.Lasso.Cancerous[MultipleCGIs], Gene.score.df.Final$AllCGIs.Lasso.Cancerous[MultipleCGIs],paired=T)$p.value
        # Dat.MultipleCGIs <- data.frame(Promoter= Gene.score.df$Promoter.Lasso.Cancerous[MultipleCGIs], AllCGIs= Gene.score.df$AllCGIs.Lasso.Cancerous[MultipleCGIs])

        # p.MultipleCGIs <- ggplot(Dat.MultipleCGIs)+ geom_point(aes(x=Promoter,y=AllCGIs)) + geom_abline(a=0,b=1,col="red", linetype="longdash") + 
        # coord_cartesian(ylim=c(-0.01,1),xlim=c(-0.01,1)) +
        # xlab("R2 Promoter CGI") + ylab("R2 All Related CGIs") +
        # scale_x_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) + scale_y_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) +
        # theme(panel.grid=element_blank(),
        #       panel.background=element_rect(fill="white", colour=NA),
        #       legend.position="none",
        #       text = element_text(size=20),
        #       axis.text=element_text(colour="black",size=rel(0.8)),
        #       axis.ticks=element_line(colour="black"),
        #       panel.border=element_rect(fill=NA, colour="black",size=0.7),
        #       axis.title.y = element_text(vjust=0.35),
        #       axis.title.x = element_text(vjust=0.35),
        #       strip.background = element_rect(colour="black",fill="white",size=0.7),
        #       axis.line = element_line(colour = "black",size=0.3))

        # ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/MultipleCGIs.pdf'), p.MultipleCGIs,dpi=300)



        # qplot(Gene.score.df$Promoter.Lasso.Cancerous[MultipleCGIs], Gene.score.df$AllCGIs.Lasso.Cancerous[MultipleCGIs]) + geom_abline(a=0,b=1,col="red")

        # boxplot(Gene.score.df$AllCGIs.Lasso.Cancerous[MultipleCGIs] - Gene.score.df$Promoter.Lasso.Cancerous[MultipleCGIs])
        # median(Gene.score.df$AllCGIs.Lasso.Cancerous[MultipleCGIs] - Gene.score.df$Promoter.Lasso.Cancerous[MultipleCGIs])
        # which.max(Gene.score.df$AllCGIs.Lasso.Cancerous[MultipleCGIs] - Gene.score.df$Promoter.Lasso.Cancerous[MultipleCGIs])

        # wilcox.test(Gene.score.df$Promoter.Lasso.Cancerous[MultipleCGIs], Gene.score.df$AllCGIs.Lasso.Cancerous[MultipleCGIs],paired=T)$p.value

        #### Look at Genes with high difference verify which CGI is good.






        # dat.df <- Gene.score.df.Final[MultipleCGIs, c('Promoter.Lasso.Cancerous','AllCGIs.Lasso.Cancerous')]

        # dat.m <- melt(dat.df)
        # ggplot(dat.m) + geom_boxplot(aes(y=value, x=variable))

        # qplot(Gene.score.df.Final$Promoter.Lasso.Cancerous[MultipleCGIs], Gene.score.df.Final$AllCGIs.Lasso.Cancerous[MultipleCGIs]) + geom_abline(a=0,b=1,col="red",linetype="longdash")

        ## Clusters Info
        Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown.RData')))
        Promoter.Assoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
        Clusters.GE <- sapply(1:length(CommonGenes), function(n) { return(Clusters.Meth[Promoter.Assoc[n]])})
        names(Clusters.GE) <- CommonGenes
        ###### Clusters.GE.All
        Clusters.CGI <- get(load('~/Desktop/Clusters_All.RData'))
        Clusters.GE.All <- sapply(1:length(CommonGenes), function(n){return(Clusters.CGI[Promoter.Assoc[n]])})
        names(Clusters.GE.All) <- CommonGenes


        # wilcox.test(tmp.df$r2.predict[tmp.df$Clusters=="4up"],tmp.df$r2.predict[tmp.df$Clusters=="1"])$p.value
        # Dat <- data.frame(Score = Gene.score.df.Final$Promoter.Lasso.Cancerous, Cluster= Clusters.GE)

        # save(Dat, file=paste0("~/Desktop/",DiseaseName,".RData"))

        ###########################
        #### 1) Plots {{{1
        ## a) Boxplot of the Scores given the different methods 
        ## Only Plot Mean vs Promoter

        # ##
        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/GeneScore.pdf'))
        # print(ggplot(Gene.score.melted) + geom_boxplot(aes(y=r2.predict,x=analysis,fill=method)) + facet_grid(~type))
        # dev.off()

        summary(Gene.score.df.Final$LS.Cancerous)
        summary(Gene.score.df.Final$Promoter.Lasso.Cancerous)

        wilcox.test(Gene.score.df.Final$Promoter.Lasso.Cancerous, Gene.score.df.Final$LS.Cancerous)
        # gg_color_hue <- function(n) {
                #           hues = seq(15, 375, length=n+1)
                #   hcl(h=hues, l=65, c=100)[1:n]
                # }


        colour_method <- c('Least Squares'='#f1a340',
                           'Lasso'='#998ec3')


        if (DiseaseName == "Colon")
        {
        p <- ggplot(Gene.score.melted.Final) + geom_boxplot(aes(y=r2.predict,x=analysis,fill=method)) + scale_fill_manual(values=colour_method) + ylab("R2 predict") + xlab("")  
        } else
        {
        p <- ggplot(Gene.score.melted.Final) + geom_boxplot(aes(y=r2.predict,x=analysis,fill=method)) + scale_fill_manual(values=colour_method) + facet_grid(~type) + ylab("R2 predict") + xlab("") 
        }

        p <- p +
        coord_cartesian(ylim=c(0, 1)) +
        scale_y_continuous(breaks=seq(0, 1.5, 0.5)) +
        theme(panel.grid=element_blank(),
              legend.position="none",
              text = element_text(size=20),
              panel.background=element_rect(fill="white"),
              axis.text=element_text(colour="black",size=rel(0.8)),
              axis.ticks=element_line(colour="black"),
              panel.border=element_rect(fill=NA, colour="black",size=0.7),
              axis.title.y = element_text(vjust=0.35),
              strip.background = element_rect(colour="black",fill="white",size=0.7),
              axis.line = element_line(colour = "black",size=0.3))




        ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/GeneScore_Final.pdf'),p, dpi=300)

        # ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/GeneScore_Final_Supplementary.pdf'),p, dpi=300)



        if (DiseaseName != "Colon")
        {
                # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatter_LS_Normal_Cancerous.pdf'))
                # print(ggplot(Gene.score.df.Final) + geom_point(aes(x=LS.Normal,y=LS.Cancerous)) + xlab("LS Normal") + ylab("LS Cancerous") + xlim(0,1) + ylim(0,1) )
                # dev.off()

                # summary(lm(LS.Cancerous ~ LS.Normal, Gene.score.df.Final))$r.squared



                #########
                ## Different Scatter plots
                # smoothScatter(Gene.score.df.Final$Promoter.Lasso.Normal, Gene.score.df.Final$Promoter.Lasso.Cancerous)

                p.scatter <- ggplot(Gene.score.df.Final)+ geom_point(aes(x=Promoter.Lasso.Normal,y=Promoter.Lasso.Cancerous)) + 
                             coord_cartesian(ylim=c(-0.01,1),xlim=c(-0.01,1)) +
                             xlab("R2 Normal") + ylab("R2 Cancerous") +
                             scale_x_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) + scale_y_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) +
                             theme(panel.grid=element_blank(),
                                   panel.background=element_rect(fill="white", colour=NA),
                                   legend.position="none",
                                   text = element_text(size=20),
                                   axis.text=element_text(colour="black",size=rel(0.8)),
                                   axis.ticks=element_line(colour="black"),
                                   panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                   axis.title.y = element_text(vjust=0.35),
                                   axis.title.x = element_text(vjust=0.35),
                                   strip.background = element_rect(colour="black",fill="white",size=0.7),
                                   axis.line = element_line(colour = "black",size=0.3))

                ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatter_Lasso_Normal_Cancerous.pdf'), p.scatter,dpi=300)

                p.scatter_alpha <- ggplot(Gene.score.df.Final, aes(x=Promoter.Lasso.Normal,y=Promoter.Lasso.Cancerous)) + geom_point(alpha=0.5)  + 
                             coord_cartesian(ylim=c(-0.01,1),xlim=c(-0.01,1)) +
                             xlab("R2 Normal") + ylab("R2 Cancerous") +
                             scale_x_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) + scale_y_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) +
                             theme(panel.grid=element_blank(),
                                   panel.background=element_rect(fill="white", colour=NA),
                                   legend.position="none",
                                   text = element_text(size=20),
                                   axis.text=element_text(colour="black",size=rel(0.8)),
                                   axis.ticks=element_line(colour="black"),
                                   panel.border=element_rect(fill=NA, colour="black",size=0.7),
                                   axis.title.y = element_text(vjust=0.35),
                                   axis.title.x = element_text(vjust=0.35),
                                   strip.background = element_rect(colour="black",fill="white",size=0.7),
                                   axis.line = element_line(colour = "black",size=0.3))

                ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatter_Lasso_Normal_Cancerous_alpha.pdf'), p.scatter_alpha,dpi=300)

                # p.scatter_hex <- ggplot(Gene.score.df.Final)+ geom_hex(aes(x=Promoter.Lasso.Normal,y=Promoter.Lasso.Cancerous),bins=70) + 
                #              scale_fill_gradient(low="#404040",high="#ca0020") +
                #              coord_cartesian(ylim=c(-0.01,1),xlim=c(-0.01,1)) +
                #              xlab("R2 Normal") + ylab("R2 Cancerous") +
                #              scale_x_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) + scale_y_continuous(breaks=c(0,0.25,0.5,0.75,1),labels=c('0','','0.5','','1')) +
                #              theme(panel.grid=element_blank(),
                #                    panel.background=element_rect(fill="white", colour=NA),
                #                    legend.position="none",
                #                    text = element_text(size=20),
                #                    axis.text=element_text(colour="black",size=rel(0.8)),
                #                    axis.ticks=element_line(colour="black"),
                #                    panel.border=element_rect(fill=NA, colour="black",size=0.7),
                #                    axis.title.y = element_text(vjust=0.35),
                #                    axis.title.x = element_text(vjust=0.35),
                #                    strip.background = element_rect(colour="black",fill="white",size=0.7),
                #                    axis.line = element_line(colour = "black",size=0.3))

                # ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatter_Lasso_Normal_Cancerous_hex.pdf'), p.scatter_hex,dpi=300)

                #pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Comparison/Scatter_Lasso_Normal_Cancerous.pdf'))
                #print(ggplot(Gene.score.df.Final) + geom_point(aes(x=Promoter.Lasso.Normal,y=Promoter.Lasso.Cancerous)) + xlab("Lasso Normal") + ylab("Lasso Cancerous") )
                #print(ggplot(Gene.score.df.Final) + geom_point(aes(x=Promoter.Lasso.Normal,y=Promoter.Lasso.Cancerous)) + xlab("Normal") + ylab("Cancerous") + xlim(0,1) + ylim(0,1)  )
                # + geom_abline(a=0,b=1,col="red",linetype="longdash")
                #dev.off()

                summary(lm(Promoter.Lasso.Cancerous ~ Promoter.Lasso.Normal, Gene.score.df.Final))$r.squared
        }

        ###########################
        #### 3) List of epigenetically regulated Genes
        #out$ERG <- data.frame(Gene= rownames(Gene.score.df.Final[ na.omit(which(Gene.score.df.Final$Promoter.Lasso.Cancerous > 0.5)), ]), Score=Gene.score.df.Final[ na.omit(which(Gene.score.df.Final$Promoter.Lasso.Cancerous > 0.5)), "Promoter.Lasso.Cancerous"])
        out$ERG <- data.frame(Gene=rownames(Gene.score.df.Final), Score=Gene.score.df.Final$Promoter.Lasso.Cancerous)
        out$ERG <- out$ERG[ order(out$ERG$Score,decreasing=T), ]

        if (DiseaseName != "Colon")
        {
                # out$ERG_Normal <- data.frame(Gene= rownames(Gene.score.df.Final[ na.omit(which(Gene.score.df.Final$Promoter.Lasso.Normal > 0.5)), ]), Score=Gene.score.df.Final[ na.omit(which(Gene.score.df.Final$Promoter.Lasso.Normal > 0.5)), "Promoter.Lasso.Normal"])
                out$ERG_Normal <- data.frame(Gene= rownames(Gene.score.df.Final), Score=Gene.score.df.Final[ ,"Promoter.Lasso.Normal"])
                out$ERG_Normal <- out$ERG_Normal[ order(out$ERG_Normal$Score,decreasing=T), ]
                ERG_Normal <- out$ERG_Normal
                save(ERG_Normal, file=paste0("../../big_data/GE_prediction/",DiseaseName,"_ERG_Normal.RData"))
        }


        ERG <- out$ERG

        save(ERG, file=paste0("../../big_data/GE_prediction/",DiseaseName,"_ERG.RData"))

        ####### Gene Ontology of ERGs ###############
        ### Convert hgnc_symbol into entrezgene
        library(biomaRt)
        mart <- useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")

        NoConvert <- get(load('~/Desktop/Translate.RData'))

        ### Cluster 3up GO

        Cluster3up.Genes <- names(Clusters.GE[Clusters.GE=="4up"])
        Cluster3upCommon.Genes <- names(Clusters.GE.All[Clusters.GE.All=="4up.Common"])
        # Cluster3up.Genes[match(names(NoConvert[names(NoConvert) %in% Cluster3up.Genes]),Cluster3up.Genes)] <- NoConvert[names(NoConvert) %in% Cluster3up.Genes]


        #######
        if (DiseaseName != "Colon")
        {
                NewGenes.Normal <- as.character(ERG_Normal$Gene)
                NewGenes.Normal[match(names(NoConvert),NewGenes.Normal)] <- NoConvert
        }

        NewGenes.Cancerous <- as.character(ERG$Gene)
        NewGenes.Cancerous[match(names(NoConvert),NewGenes.Cancerous)] <- NoConvert

        # Converter <- getBM(attributes = c("entrezgene","hgnc_symbol"), filters="hgnc_symbol", values = NewGenes, mart = mart)
        # Not.Convert <- ERG$Gene[!(ERG$Gene %in% Converter$hgnc_symbol)]

        # getBM(values= "TTC40", attributes= c('entrezgene', 'hgnc_symbol'), filters="hgnc_symbol", mart=mart)
        #AllGenes.Symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = ERG_Normal$Gene, mart = mart)[,1]
        #Normal.hgnc_symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = ERG_Normal$Gene[1:50], mart = mart)[,1]

        ###
        library(biomaRt)
        mart <- useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")
        AllGenes.Symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = NewGenes.Cancerous, mart = mart)[,1]

        #### Cluster3up
        Cluster3up.Symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = Cluster3up.Genes, mart = mart)[,1]
        Cluster3upCommon.Symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = Cluster3upCommon.Genes, mart = mart)[,1]

        library("clusterProfiler")
        enrich.Cluster3up <- enrichGO(Cluster3up.Symbol, organism="human", ont="BP", pvalueCutoff=0.05, universe= AllGenes.Symbol,readable=T)
        enrich.Cluster3upCommon <- enrichGO(Cluster3upCommon.Symbol, organism="human", ont="BP", pvalueCutoff=0.05, universe= AllGenes.Symbol,readable=T)

        write.table(summary(enrich.Cluster3up),file = paste0("../../results/clustering/",DiseaseName,"/GO_Cluster3up.txt"),row.names=F, sep="\t", quote=F) 
        write.table(summary(enrich.Cluster3up),file = paste0("../../results/clustering/InterCancer/GO_Cluster3upCommon.txt"),row.names=F, sep="\t", quote=F) 

        pdf(paste0('../../results/clustering/',DiseaseName,'/GO_Cluster3up.pdf'))
        print(plot(enrich.Cluster3up,showCategory=10,by="geneRatio"))
        dev.off()

        pdf(paste0('../../results/clustering/InterCancer/GO_Cluster3up.pdf'))
        print(plot(enrich.Cluster3upCommon,showCategory=10,by="geneRatio"))
        dev.off()







        ### GRMs Cancerous

        Cancerous.hgnc_symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = NewGenes.Cancerous[1:50], mart = mart)[,1]

        library("clusterProfiler")
        enrich.Cancerous <- enrichGO(Cancerous.hgnc_symbol, organism="human", ont="BP", pvalueCutoff=0.05, universe= AllGenes.Symbol,readable=T)

        write.table(summary(enrich.Cancerous),file = paste0("../../results/GE_prediction/",DiseaseName,"/ERG/ERG_GO_Cancerous.txt"),row.names=F, sep="\t", quote=F) 

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/ERG_GO_Cancerous.pdf'))
        print(plot(enrich.Cancerous,showCategory=100,by="geneRatio"))
        dev.off()

        if (DiseaseName != "Colon")
        {
                Normal.hgnc_symbol <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = NewGenes.Normal[1:50], mart = mart)[,1]
                enrich.Normal <- enrichGO(Normal.hgnc_symbol, organism="human", ont="BP", pvalueCutoff=0.05, universe= AllGenes.Symbol,readable=T)

                write.table(summary(enrich.Normal),file = paste0("../../results/GE_prediction/",DiseaseName,"/ERG/ERG_GO_Normal.txt"),row.names=F, sep="\t", quote=F) 

                p <-plot(enrich.Normal,showCategory=30,by="geneRatio")

                pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/ERG_GO_Normal.pdf'))
                print(plot(enrich.Normal,showCategory=30,by="geneRatio"))
                dev.off()

        }

        # PcG.Targets <- get(load('../../data/processed/TSS/PcGTargets.RData'))
        # TF <- read.table(file='../../data/raw/TF/TF.txt', sep="\t",header=T)

        # ## Avg of ERG that are PcGTargets
        # #mean(PcG.Targets[match(ERG$Gene,PcG.Targets[,3]),2],na.rm=T)
        # #mean(PcG.Targets[PcG.Targets[,3])
        # #40% vs 30%

        # #sum(ERG$Gene %in% TF$Symbol)
        # #10/45

        # TF.Info <- rep(0,length(ERG$Gene))
        # TF.Info[which(ERG$Gene %in% TF$Symbol)] <- 1


        # ERG.Info <- data.frame(PcG= PcG.Targets[match(ERG$Gene,PcG.Targets[,3]),2], TF = TF.Info)
        # overall.Info <- sapply(1:nrow(ERG.Info), function(n){ERG.Info$PcG[n] | ERG.Info$TF[n]})

        #mean(overall.Info,na.rm=T)
        # 55%

        #c) Verify Gene expression
        ##########################
        ## For all genes
        GE.Full <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData')))
        GE.Names <- sapply(strsplit(rownames(GE.Full),"\\|"),"[",1)
        GE.Dat <- GE.Full[match(CommonGenes, GE.Names),]
        GE.Mean <- apply(GE.Dat,1,mean)
        GE.Mean <- GE.Mean + 1e-5

        GE.clusters.full <- data.frame(GE=GE.Mean, Score=Gene.score.df.Final$Promoter.Lasso.Cancerous, clusters=Clusters.GE)

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_GE_Clusters.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=GE,y=Score)) + facet_grid(~clusters) + geom_hline(yintercept=0.5, colour='blue', linetype="longdash") + geom_vline(xintercept=1, colour='red') + scale_x_log10() + ylim(0,1)    )
        dev.off()

        ### Look at ALL the Genes scores vs Specific CGI Informations (#probes, CGI size, Distance to TSS)

        fData.big_island <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))
        Gene.DistToTSS <- get(load('../../data/processed/TSS/CommonGenesTSS.RData'))

        GE.clusters.full <- data.frame(GE= GE.Mean,
                                       Score= Gene.score.df.Final$Promoter.Lasso.Cancerous,
                                       clusters=Clusters.GE,
                                       probesize = sapply(1:length(CommonGenes), function(n){nrow(fData.big_island[[ Promoter.Assoc[n] ]])}),
                                       CGIsize = sapply(1:length(CommonGenes), function(n){fData.big_island[[ Promoter.Assoc[n] ]][1,"IslandEnd"] - fData.big_island[[Promoter.Assoc[n] ]][1,"IslandBegin"] }),
                                       DistToTSS = Gene.DistToTSS,
                                       classTSS = sapply(1:length(Gene.DistToTSS),function(n){   
                                                         if (is.na(Gene.DistToTSS[n]))
                                                         {
                                                                 return(NA)
                                                         } else if (Gene.DistToTSS[n] < 0)
                                                         {
                                                                 return('TSS Before')
                                                         } else if (Gene.DistToTSS[n] == 0)
                                                         {
                                                                 return('TSS In')
                                                         } else if (Gene.DistToTSS[n] > 0)
                                                         {
                                                                 return('TSS After')
                                                         } 
                                                          }))

        GE.clusters.full$classTSS <- factor(GE.clusters.full$classTSS, levels=c('TSS Before', 'TSS In', 'TSS After'))

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_vs_probesize.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=probesize,y=Score)))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_vs_probesize_zoom.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=probesize,y=Score)) + xlim(20,40))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_vs_CGIsize.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=CGIsize,y=Score)))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_vs_CGIsize_zoom.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=CGIsize,y=Score)) + xlim(0,3000))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_vs_DistToTSS.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=DistToTSS,y=Score)) )
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_vs_DistToTSS_zoom.pdf'))
        print(ggplot(GE.clusters.full) + geom_point(aes(x=DistToTSS,y=Score)) + xlim(-3000,3000))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_vs_RelativeCGI_TSS.pdf'))
        ggplot(GE.clusters.full) + geom_boxplot(aes(x=classTSS,y=Score)) + geom_jitter(aes(x=classTSS, y=Score),col="red")
        dev.off()

        # Do ANOVA?

        ## For Interesting genes
        #####
        # LETS LOOK AT THE TOP 50
        #####
        ## TopList <- 50
        ## Interesting.Genes.Normal <-out$ERG_Normal$Gene[seq(TopList)]
        ## Interesting.Genes <-out$ERG$Gene[seq(TopList)] ## Cancerous
        ## GE.Interesting <- GE.Full[match(Interesting.Genes, GE.Names),] 
        ## rownames(GE.Interesting) <- Interesting.Genes 

        ## ### Do Gene Ontology
        ## if (F)
        ## {
        ##         library(biomaRt)
        ##         mart <- useMart(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")
        ##         entrezGenes.List <- getBM(attributes = c('entrezgene'), filters= "hgnc_symbol", values= as.character(Interesting.Genes), mart=mart)[,1]
        ##         universe.List <- getBM(attributes = c('entrezgene'), filters= "hgnc_symbol", values= CommonGenes, mart=mart)[,1]

        ##         library(clusterProfiler)
        ##         ego <- enrichGO(gene = entrezGenes.List, universe= universe.List, organism = "human", ont="BP", readable=F)

        ##         if (nrow(summary(ego))!=0)
        ##         {
        ##                 pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/GO.pdf'))
        ##                 barplot(ego)
        ##                 dev.off()
        ##         }
        ## }


        ### Add Clinical features for BRCA (ER/PR/HER2)
        # png('~/Desktop/Heatmap_Regulated_Genes.png')
        # heatmap.2(GE.Interesting,hclustfun= function(x){hclust(x,method="ward")},distfun=function(x){as.dist((1-cor(t(x)))/2)},  scale="row", dendrogram="both", trace="none",col=redgreen)
        # dev.off()

        # GE.Interesting.melted <- melt(GE.Interesting)
        # GE.Interesting.melted <- data.frame(Gene= GE.Interesting.melted$Var1, GE= GE.Interesting.melted$value, cluster= Clusters.GE[as.character(GE.Interesting.melted$Var1)])

        # colour_scale <- c('1'='red',
        #                   '2'='green',
        #                   '3'='black',
        #                   '4down'='yellow',
        #                   '4up'='blue')

        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/GE.pdf'))
        # print(ggplot(GE.Interesting.melted) + geom_boxplot(aes(x=Gene,y=GE,fill=cluster)) + theme(axis.text.x = element_text(angle = 90, hjust = 1)) + geom_hline(yintercept=1, colour='red') + scale_y_log10() + scale_fill_manual(values=colour_scale)      )
        # dev.off()

        #d) r2=f(Clusters)?
        ####################
        ## GE.Full <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData')))
        ## GE.Names <- sapply(strsplit(rownames(GE.Full),"\\|"),"[",1)
        ## GE.Dat <- GE.Full[match(CommonGenes, GE.Names),]
        ## GE.Mean <- apply(GE.Dat,1,mean)
        ## GE.Mean <- GE.Mean + 1e-5

        ## tmp.df <- data.frame(  Gene.score.melted.Final[Gene.score.melted.Final$type=="Cancerous",]  ,GE=GE.Mean, Clusters=Clusters.GE)
        ## tmp.df$method <- factor(tmp.df$method, levels=c('Least Squares','Lasso'))

        ## tmp.df <- data.frame(  Gene.score.melted.Final[Gene.score.melted.Final$type=="Cancerous",]  ,GE=GE.Mean, Clusters=Clusters.GE)
        ## tmp.df$method <- factor(tmp.df$method, levels=c('Least Squares','Lasso'))

        ## pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_Clusters.pdf'))
        ## print(ggplot(tmp.df) + geom_boxplot(aes(x=Clusters,fill=analysis,y=r2.predict)) + facet_grid(~method)+ ylim(0,1))
        ## dev.off()

        # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Scores_GE_Clusters.pdf'))
        # print(ggplot(tmp.df) + geom_point(aes(x=GE,y=r2.predict)) + facet_grid(~method) + scale_x_log10() + geom_vline(xintercept=1, colour="red") + ylim(0,1))
        # dev.off()

        # tmp.df.lasso <- tmp.df[tmp.df$method=="Lasso",]

        ### Verify r2=f(Clusters)?
        # kruskal.test(r2.predict ~ Clusters, data=tmp.df.lasso)$p.value

        #### Results
        ## BRCA.Cancerous = 0.018
        ## BRCA.Normal = 

        ### Look at Median by clusters then see either if top two are different or top bottom
        # Median.Clusters <- sapply(1:length(clusters), function(n){ median(tmp.df.lasso$r2.predict[tmp.df.lasso$Clusters== clusters[n]])})
        # names(Median.Clusters) <- clusters

        # ### Top two
        # TopClust <-names(Median.Clusters)[order(Median.Clusters,decreasing=T)[1]]
        # TopClust_2 <-names(Median.Clusters)[order(Median.Clusters,decreasing=T)[2]]
        # wilcox.test(tmp.df.lasso$r2.predict[tmp.df.lasso$Clusters==TopClust],tmp.df.lasso$r2.predict[tmp.df.lasso$Clusters==TopClust_2])$p.value

        # BottomClust <-names(Median.Clusters)[order(Median.Clusters)[1]]
        # BottomClust_2 <-names(Median.Clusters)[order(Median.Clusters)[2]]
        # wilcox.test(tmp.df.lasso$r2.predict[tmp.df.lasso$Clusters==BottomClust],tmp.df.lasso$r2.predict[tmp.df.lasso$Clusters==BottomClust_2])$p.value


        ### Bottom two
        # wilcox.test(tmp.df.lasso$r2.predict[tmp.df.lasso$Clusters=="4up"],tmp.df.lasso$r2.predict[tmp.df.lasso$Clusters=="1"])$p.value

        # e) See actual prediction vs Real GE Values for top genes
        #######################################################################
        # save(Interesting.Genes, file=paste0("../../big_data/GE_prediction/ERG_",DiseaseName,".RData"))
        # GE.Interesting <- GE.Full[match(Interesting.Genes, GE.Names),,drop=F] 
        # rownames(GE.Interesting) <- Interesting.Genes 

        # ## 
        # Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed.RData')))[list_big_island]
        # fData.big_island <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))


        # n.folds <- 3
        # set.seed(1234)
        # folds <- split( sample( seq(ncol(GE.Interesting)) ), seq(n.folds) )
        # library(glmnet)

        # Predictions.CV <- lapply(1:length(Interesting.Genes), function(n){ 
        #                          Index <- which(CommonGenes==Interesting.Genes[n])
        #                          Y <- t(GE.Interesting[n,,drop=F])
        #                          X <- t(Meth.Dat[[ Promoter.Assoc[Index] ]])

        #                          prediction.fold <- lapply(seq(n.folds), function(n_fold)
        #                                                             {
        #                                                                     Y_train <- Y[-folds[[n_fold]],,drop=F ]
        #                                                                     X_train <- X[-folds[[n_fold]],]

        #                                                                     Y_test <- Y[folds[[n_fold]],,drop=F ]
        #                                                                     X_test <- X[folds[[n_fold]],]

        #                                                                     ###### Verify if any(Y_train != Y_train[1])
        #                                                                     if (any(Y_train != Y_train[1]))
        #                                                                     {
        #                                                                             ## 1) do Crossval on (X_train,Y_train) to tune lambda
        #                                                                             lambda.lasso <- cv.glmnet(X_train,Y_train,alpha=1)$lambda.min

        #                                                                             ## 2) do prediction of Y_test and look at correlation with real Y_test
        #                                                                             predictor.lasso <- glmnet(X_train,Y_train,alpha=1,lambda=lambda.lasso)

        #                                                                             Y_predict.lasso <- predict(predictor.lasso,newx=X_test, s= lambda.lasso)

        #                                                                             r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
        #                                                                     } else {
        #                                                                             r2.pearson.lasso <- NA
        #                                                                             r2.pearson.ridge <- NA
        #                                                                     }

        #                                                                     return(data.frame(Real=as.vector(Y_test),Predict=as.vector(Y_predict.lasso)))
        #                                                             })
        #                          return(Reduce('rbind',prediction.fold))
        #                   } )


        ##  Methylation vs Expression
        # Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed.RData')))[list_big_island]
        # CNV.dat <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/CancerousCNV_Genes.RData')))
        # fData.big_island <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))

        # Meth.dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed_bis.RData')))[list_big_island]
        # GE.dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed_bis.RData')))
        # CNV.dat <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/CancerousCNV_Genes.RData')))

        # # ### ERBB2 Analysis
        # Interesting.Genes <- "ERBB2"
        # GE.Interesting <- GE.dat[match(Interesting.Genes, GE.Names),,drop=F] 
        # rownames(GE.Interesting) <- Interesting.Genes 


        # Index <- which(CommonGenes==Interesting.Genes)

        # Meth.ERBB2 <- Meth.dat[[Promoter.Assoc[Index] ]]
        # Average.Meth.ERBB2 <- apply(Meth.ERBB2,2,function(x){mean(x,na.rm=T)})


        # CNV.interesting <- CNV.dat[Interesting.Genes,]

        # MethGE.df <- data.frame(Methylation=Average.Meth.ERBB2,
        #                         GeneExpression=t(GE.Interesting),
        #                         CNV = CNV.interesting)

        # Patients.Meth <- substring(colnames(Meth.dat[[1]]),1,12)
        # Patients.GE <- substring(colnames(GE.Interesting),1,12)
        # Patients.CNV <- substring(colnames(CNV.dat),1,12)

        # Clinical.processed <- get(load('../../big_data/BRCA_Clinical_Processed.RData'))
        # Patients.Clinical <- substring(rownames(Clinical.processed),1,12)

        # Clinical.processed.bis <- Clinical.processed[match(Patients.Meth, Patients.Clinical),]
        # Patients.Clinical.bis <- substring(rownames(Clinical.processed.bis),1,12)

        # MethGE.df <- cbind(MethGE.df, Clinical.processed.bis)

        # p.HER2.Methylation_Expression <- ggplot(MethGE.df) + geom_point(aes(x=Methylation, y=ERBB2, colour=interaction(ER_bis,HER2_bis)))

        # p.HER2.Expression_CNV <- ggplot(MethGE.df) + geom_point(aes(x=CNV, y=ERBB2, colour=interaction(ER_bis,HER2_bis)))

        # p.HER2.Methylation_CNV <- ggplot(MethGE.df) + geom_point(aes(x=CNV, y=Methylation, colour=interaction(ER_bis,HER2_bis)))

        # ggsave("~/Desktop/ERBB2_Methylation_Expression.pdf",p.HER2.Methylation_Expression, dpi=300)
        # ggsave("~/Desktop/ERBB2_Expression_CNV.pdf",p.HER2.Expression_CNV, dpi=300)
        # ggsave("~/Desktop/ERBB2_Methylation_CNV.pdf",p.HER2.Methylation_CNV, dpi=300)

        ## Expression vs CNV


        ### GeneList <-  split( Interesting.Genes, seq(floor(length(Interesting.Genes)/12 )))
        ### for (k in 1:length(GeneList))
        ### {
        ###         pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Plot_Predict_Real_',k,'.pdf'))
        ###         print(ggplot(Predictions.df[Predictions.df$Gene %in%  GeneList[[k]] , ]) + geom_point(aes(x=Real,y=Predict)) + facet_wrap( ~ Gene, scales="free", ncol=4) + geom_abline(a=0,b=1,col="red",linetype="longdash"))
        ###         dev.off()
        ### }

        #f) For interesting Genes look at correlation between each probes and GE
        GE.Full <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData')))
        GE.Names <- sapply(strsplit(rownames(GE.Full),"\\|"),"[",1)
        GE.Dat <- GE.Full[match(CommonGenes, GE.Names),]
        GE.Mean <- apply(GE.Dat,1,mean)
        GE.Mean <- GE.Mean + 1e-5


        TopList <- 50
        Interesting.Genes <-out$ERG$Gene[seq(TopList)]

        GE.Interesting <- GE.Full[match(Interesting.Genes, GE.Names),] 
        rownames(GE.Interesting) <- Interesting.Genes 

        ## 
        Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed.RData')))[list_big_island]

        Corr.Probes <- lapply(1:length(Interesting.Genes), function(n){ 
                                 Index <- which(CommonGenes==Interesting.Genes[n])
                                 Y <- t(GE.Interesting[n,,drop=F])
                                 X <- t(Meth.Dat[[ Promoter.Assoc[Index] ]])

                                 return(cor(X,Y))
                          } )

        Corr <- Reduce('c',Corr.Probes)

        ####
        fData.big_island <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))
        Gene.Strand <- get(load('../../data/processed/TSS/GeneStrand.RData'))
        TSS.Position <- get(load('../../data/processed/TSS/TSS_position.RData'))
        names(Gene.Strand) <- CommonGenes
        names(TSS.Position) <- CommonGenes
        Gene.Strand.Interesting <- Gene.Strand[Interesting.Genes]
        TSS.Position.Interesting <- TSS.Position[Interesting.Genes]

        Inverted_N_S <- c('N_Shelf'='S_Shelf',
                          'N_Shore'='S_Shore',
                          'Island'='Island',
                          'S_Shore'='N_Shore',
                          'S_Shelf'='N_Shelf')

        Dat <- data.frame(Correlation= Corr,
                          position= Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ; fData.big_island[[ Promoter.Assoc[Index] ]][ ,"MAPINFO"    ]  })),
                          IslandDist= Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandDist"    ]  })),
                          CGI = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index]  ]][ ,"UCSC_CpG_Islands_Name"    ]  })),
                          Clusters= Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;p <- nrow(fData.big_island[[ Promoter.Assoc[Index]  ]]);rep(Clusters.GE[as.character(Interesting.Genes[n])],p) })), 
                          Gene = rep(Interesting.Genes, sapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]);nrow(fData.big_island[[Promoter.Assoc[Index] ]])})),
                          IslandBegin = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandBegin"    ]  })),
                          IslandEnd = Reduce('c',lapply(1:length(Interesting.Genes), function(n){Index <- which(CommonGenes==Interesting.Genes[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandEnd"    ]  })),
                          Strand = Reduce('c',lapply(1:length(Interesting.Genes), function(n){ Index <- which(CommonGenes==Interesting.Genes[n]) ;p <- nrow(fData.big_island[[ Promoter.Assoc[Index]  ]]);rep(Gene.Strand.Interesting[n],p) })),
                          TSS = Reduce('c',lapply(1:length(Interesting.Genes), function(n){ Index <- which(CommonGenes==Interesting.Genes[n]) ;p <- nrow(fData.big_island[[ Promoter.Assoc[Index]  ]]);rep(TSS.Position[n],p) })),
                          Relation_to_UCSC_CpG_Island = Reduce('c',lapply(1:length(Interesting.Genes), function(n){
                                                                          Index <- which(CommonGenes==Interesting.Genes[n]) 
                                                                          if (Gene.Strand.Interesting[n]=="+")
                                                                          {
                                                                          fData.big_island[[ Promoter.Assoc[Index] ]][ ,"Relation_to_UCSC_CpG_Island"    ]
                                                                          } else if(Gene.Strand.Interesting[n]=="-")
                                                                          {
                                                                                Inverted_N_S[  fData.big_island[[ Promoter.Assoc[Index] ]][ ,"Relation_to_UCSC_CpG_Island"    ]]
                                                                          }
})))

        Dat$Relation_to_UCSC_CpG_Island <- factor(Dat$Relation_to_UCSC_CpG_Island, levels= c('N_Shelf','N_Shore','Island','S_Shore','S_Shelf'))
        Dat$Probe_To_TSS <- sapply(1:nrow(Dat), function(n)
                                   {
                                           if (Dat$Strand[n]=="+")
                                           {
                                                   return(Dat$TSS[n] - Dat$position[n])
                                           } else 
                                           {
                                                   return(Dat$position[n] - Dat$TSS[n])
                                           }
                                   })

        colour_region <- c('N_Shelf' = '#91bfdb',
                           'N_Shore' = '#ffffbf',
                           'Island' = '#fc8d59',
                           'S_Shore' = '#ffffbf',
                           'S_Shelf' = '#91bfdb')

        p.Corr <-ggplot(Dat,aes(x=Relation_to_UCSC_CpG_Island,y=Correlation,fill=Relation_to_UCSC_CpG_Island))  + geom_boxplot()+
                 geom_hline(yintercept=0, linetype="longdash",color="red") + ylim(-1,1) + xlab('Region') +
                 scale_fill_manual(values=colour_region) +
                 theme(panel.grid=element_blank(),
                       panel.background=element_rect(fill="white", colour=NA),
                       legend.position="none",
                       text = element_text(size=20),
                       panel.border=element_rect(fill=NA, colour="black"),
                       axis.text=element_text(colour="black",size=rel(0.8)),
                       axis.ticks=element_line(colour="black"),
                       panel.border=element_rect(fill=NA, colour="black",size=0.7),
                       axis.title.y = element_text(vjust=0.35),
                       axis.title.x = element_text(vjust=-1.5),
                       strip.background = element_rect(colour="black",fill="white",size=0.7),
                       axis.line = element_line(colour = "black",size=0.3),
                       plot.margin = unit(c(1, 1, 2, 0.5), "lines"))

        # p.Corr
        ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Boxplot.pdf'),p.Corr, dpi=300)
        #dev.off()


        ### Same in Normal
        if (DiseaseName != "Colon")
        {
                TopList <- 50
                Interesting.Genes.Normal <- out$ERG_Normal$Gene[seq(TopList)]
                Meth.Dat.Normal <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/NormalCGIs_processed.RData')))[list_big_island]

                GE.Full.Normal <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/NormalLevel3GE_processed.RData')))
                GE.Interesting.Normal <- GE.Full.Normal[match(Interesting.Genes.Normal, GE.Names),] 
                rownames(GE.Interesting.Normal) <- Interesting.Genes.Normal 

                Corr.Probes.Normal <- lapply(1:length(Interesting.Genes.Normal), function(n){ 
                                             Index <- which(CommonGenes==Interesting.Genes.Normal[n])
                                             Y <- t(GE.Interesting.Normal[n,,drop=F])
                                             X <- t(Meth.Dat.Normal[[ Promoter.Assoc[Index] ]])

                                             return(cor(X,Y))
              } )

                Corr.Normal <- Reduce('c',Corr.Probes.Normal)


                Gene.Strand <- get(load('../../data/processed/TSS/GeneStrand.RData'))
                TSS.Position <- get(load('../../data/processed/TSS/TSS_position.RData'))
                names(Gene.Strand) <- CommonGenes
                names(TSS.Position) <- CommonGenes
                Gene.Strand.Interesting.Normal <- Gene.Strand[Interesting.Genes.Normal]
                TSS.Position.Interesting.Normal <- TSS.Position[Interesting.Genes.Normal]
                Inverted_N_S <- c('N_Shelf'='S_Shelf',
                                  'N_Shore'='S_Shore',
                                  'Island'='Island',
                                  'S_Shore'='N_Shore',
                                  'S_Shelf'='N_Shelf')



                Dat.Normal <- data.frame(Correlation= Corr.Normal,
                                         position= Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ; fData.big_island[[ Promoter.Assoc[Index] ]][ ,"MAPINFO"    ]  })),
                                         IslandDist= Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandDist"    ]  })),
                                         CGI = Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ;fData.big_island[[ Promoter.Assoc[Index]  ]][ ,"UCSC_CpG_Islands_Name"    ]  })),
                                         Clusters= Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ;p <- nrow(fData.big_island[[ Promoter.Assoc[Index]  ]]);rep(Clusters.GE[as.character(Interesting.Genes.Normal[n])],p) })), 
                                         Gene = rep(Interesting.Genes.Normal, sapply(1:length(Interesting.Genes.Normal), function(n){Index <- which(CommonGenes==Interesting.Genes.Normal[n]);nrow(fData.big_island[[Promoter.Assoc[Index] ]])})),
                                         IslandBegin = Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandBegin"    ]  })),
                                         IslandEnd = Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ;fData.big_island[[ Promoter.Assoc[Index] ]][ ,"IslandEnd"    ]  })),
                                         Strand = Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){ Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ;p <- nrow(fData.big_island[[ Promoter.Assoc[Index]  ]]);rep(Gene.Strand.Interesting.Normal[n],p) })),
                                         TSS = Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){ Index <- which(CommonGenes==Interesting.Genes.Normal[n]) ;p <- nrow(fData.big_island[[ Promoter.Assoc[Index]  ]]);rep(TSS.Position[n],p) })),
                                         Relation_to_UCSC_CpG_Island = Reduce('c',lapply(1:length(Interesting.Genes.Normal), function(n){
                                                                                         Index <- which(CommonGenes==Interesting.Genes.Normal[n]) 
                                                                                         if (Gene.Strand.Interesting.Normal[n]=="+")
                                                                                         {
                                                                                                 fData.big_island[[ Promoter.Assoc[Index] ]][ ,"Relation_to_UCSC_CpG_Island"    ]
                                                                                         } else if(Gene.Strand.Interesting.Normal[n]=="-")
                                                                                         {
                                                                                                 Inverted_N_S[  fData.big_island[[ Promoter.Assoc[Index] ]][ ,"Relation_to_UCSC_CpG_Island"    ]]
                                                                                         }
})))

                Dat.Normal$Relation_to_UCSC_CpG_Island <- factor(Dat.Normal$Relation_to_UCSC_CpG_Island, levels= c('N_Shelf','N_Shore','Island','S_Shore','S_Shelf'))
                Dat.Normal$Probe_To_TSS <- sapply(1:nrow(Dat.Normal), function(n)
                                                  {
                                                          if (Dat.Normal$Strand[n]=="+")
                                                          {
                                                                  return(Dat.Normal$TSS[n] - Dat.Normal$position[n])
                                                          } else 
                                                          {
                                                                  return(Dat.Normal$position[n] - Dat.Normal$TSS[n])
                                                          }
                                                  })

                # pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Boxplot_Normal.pdf'))
                # print(ggplot(Dat.Normal,aes(x=Relation_to_UCSC_CpG_Island,y=Correlation)) 
                #       + geom_boxplot()
                #       #+ geom_jitter()
                #       + theme(legend.position="none"))
                # dev.off()

                p.Corr.Normal <-ggplot(Dat.Normal,aes(x=Relation_to_UCSC_CpG_Island,y=Correlation,fill=Relation_to_UCSC_CpG_Island))  + geom_boxplot()+
                scale_fill_manual(values=colour_region) +
                geom_hline(yintercept=0, linetype="longdash",color="red") + ylim(-1,1) + xlab('Region') +
                theme(panel.grid=element_blank(),
                      panel.background=element_rect(fill="white", colour=NA),
                      legend.position="none",
                      text = element_text(size=20),
                      panel.border=element_rect(fill=NA, colour="black"),
                      axis.text=element_text(colour="black",size=rel(0.8)),
                      axis.ticks=element_line(colour="black"),
                      strip.background = element_rect(colour="black") ,
                      panel.border=element_rect(fill=NA, colour="black",size=0.7),
                      axis.title.y = element_text(vjust=0.35),
                      axis.title.x = element_text(vjust=-1.5),
                      strip.background = element_rect(colour="black",fill="white",size=0.7),
                      axis.line = element_line(colour = "black",size=0.3),
                      plot.margin = unit(c(1, 1, 2, 0.5), "lines"))


                # p.Corr.Normal
                ggsave(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Boxplot_Normal.pdf'),p.Corr.Normal,dpi=300)


        } # end if DiseaseName=="Colon"

        # save(Dat, file="~/Desktop/Dat.RData")
        # Dat <- get(load('~/Desktop/Dat.RData'))
        colour_scale <- c('1'='red',
                          '2'='green',
                          '3'='black',
                          '4down'='yellow',
                          '4up'='blue')


        Dat$facet_fill_color <- colour_scale[Dat$Clusters]

        p <- ggplot(Dat,aes(x=position,y=Correlation,colour=Clusters))+geom_point() +
        geom_line() + scale_colour_manual(values=colour_scale) +
        geom_vline(aes(xintercept=IslandBegin),colour="blue",linetype = "longdash") +
        geom_vline(aes(xintercept=IslandEnd),colour="blue", linetype= "longdash") +
        geom_hline(yintercept=0, colour="black") +
        facet_wrap( ~ Gene, scales="free", ncol=4)  +
        theme(legend.position="none", axis.text.x=element_blank()) 

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Probes_Correlation.pdf'))
        print(p)
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Probe_To_TSS.pdf'))
        print(ggplot(Dat,aes(x=Probe_To_TSS,y=Correlation)) 
              + geom_point(aes(colour=Clusters) ) + scale_colour_manual(values=colour_scale)
              #+ geom_jitter()
              + theme(legend.position="none"))
        dev.off()


        #print(ggplot(Dat,aes(x=Relation_to_UCSC_CpG_Island,y=Correlation)) 
        #      + geom_boxplot(aes(fill=Clusters)) + scale_fill_manual(values=colour_scale)
        #      + theme(legend.position="none"))

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Boxplot_clusters.pdf'))
        print(ggplot(Dat,aes(x=Clusters,y=Correlation)) 
              + geom_boxplot(aes(fill=Clusters)) + scale_fill_manual(values=colour_scale) + facet_grid(~Relation_to_UCSC_CpG_Island)
              + geom_hline(yintercept=0, colour="red")
              + theme(legend.position="none"))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/ABS_Correlation_Boxplot.pdf'))
        print(ggplot(Dat,aes(x=Relation_to_UCSC_CpG_Island,y=abs(Correlation))) 
              + geom_boxplot()
              + theme(legend.position="none"))
        dev.off()

        Dat.CGI <- Dat[(Dat$IslandDist>=0)&(Dat$IslandDist<=1),]
        Dat.Shore_Shelves <- Dat[(Dat$IslandDist<=0)|(Dat$IslandDist>=1),]

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Resume_CGI.pdf'))
        print(ggplot(Dat.CGI,aes(x=IslandDist,y=Correlation))+geom_point()
              + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
              + geom_vline(aes(xintercept=1),colour="black", linetype= "longdash")
              + geom_hline(yintercept=0, colour="red")
              #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
              + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Resume_CGI_clusters.pdf'))
        print(ggplot(Dat.CGI,aes(x=IslandDist,y=Correlation))+geom_point(aes(colour=Clusters)) + scale_colour_manual(values=colour_scale) 
              + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
              + geom_vline(aes(xintercept=1),colour="black", linetype= "longdash")
              + geom_hline(yintercept=0, colour="red")
              + facet_wrap( ~ CGI, scales="free", ncol=4) + ylim(-1,1)
              + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Resume_Shore_Shelves.pdf'))
        print(ggplot(Dat.Shore_Shelves,aes(x=IslandDist,y=Correlation))+geom_point() 
              + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
              + geom_hline(yintercept=0, colour="red")
              #+ facet_wrap( ~ CGI, scales="free", ncol=4)  
              + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/Correlation_Resume_Shore_Shelves_clusters.pdf'))
        print(ggplot(Dat.Shore_Shelves,aes(x=IslandDist,y=Correlation))+geom_point(aes(colour=Clusters)) + scale_colour_manual(values=colour_scale)
              + geom_vline(aes(xintercept=0),colour="black",linetype = "longdash")
              + geom_hline(yintercept=0, colour="red")
              + facet_wrap( ~ CGI, scales="free", ncol=4)  + ylim(-1,1)
              + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

        #f) Adjust for CNV Variation?
        #############################
        Gene.CNV <- get(load(paste1('../../data/processed/CNV/TCGA/',DiseaseName,'/CancerousCNV_Genes.RData')))
        Gene.CNV.Mean <- apply(Gene.CNV,1,mean)

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/CNV_Adjust.pdf'))
        print(qplot(Gene.CNV.Mean, Gene.score.df[,"AllCGIs.Lasso.Cancerous"])+ geom_vline(xintercept=0, colour="blue") + geom_hline(yintercept=0.5,linetype="longdash",colour="red") +ylim(0,1) )
        dev.off()

        pdf(paste0('../../results/GE_prediction/',DiseaseName,'/ERG/CNV_GE.pdf'))
        print(qplot(Gene.CNV.Mean, GE.Mean) + geom_vline(xintercept=0, colour="blue") + geom_hline(yintercept=1,linetype="longdash",colour="red") + scale_y_log10() )
        dev.off()

        ###########################
        #### 2) Look at the statistics 
        # Mean vs Promoter Lasso
        out$Mean_LS_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"Mean.LS.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"Mean.LS.Cancerous"])))

        out$Promoter_Lasso_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"Promoter.Lasso.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"Promoter.Lasso.Cancerous"])))

        out$Promoter_Ridge_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"Promoter.Ridge.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"Promoter.Ridge.Cancerous"])))

        out$AllCGIs_Lasso_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"AllCGIs.Lasso.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"AllCGIs.Lasso.Cancerous"])))

        out$AllCGIs_Ridge_Median_Cancerous <- list(median= median(na.omit(Gene.score.df[,"AllCGIs.Ridge.Cancerous"])), 
                                             NA.size= sum(is.na(Gene.score.df[,"AllCGIs.Ridge.Cancerous"])))

        # Promoter Lasso vs Promoter Ridge
        #out$PromoterLasso_PromoterRidge <- wilcox.test(Gene.score.df[,"Promoter.Lasso.Cancerous"], Gene.score.df[,"Promoter.Ridge.Cancerous"])$p.value
        out$Promoter_LS <- wilcox.test(Gene.score.df.Final$Promoter.Lasso.Cancerous, Gene.score.df.Final$LS.Cancerous,paired=T)$p.value

        out$Promoter_AllCGIs <- wilcox.test(Gene.score.df.Final$Promoter.Lasso.Cancerous[MultipleCGIs], Gene.score.df.Final$AllCGIs.Lasso.Cancerous[MultipleCGIs],paired=T)$p.value

        qplot(Gene.score.df.Final$Promoter.Lasso.Cancerous[MultipleCGIs], Gene.score.df.Final$AllCGIs.Lasso.Cancerous[MultipleCGIs]) + geom_abline(a=0,b=1,col="red",linetype="longdash")

        tata.df <- data.frame(Promoter=Gene.score.df$Promoter.Lasso.Cancerous[MultipleCGIs], AllCGIs= Gene.score.df$AllCGIs.Lasso.Cancerous[MultipleCGIs])
        tata.m <- melt(tata.df)
        Genes.tata <- CommonGenes[MultipleCGIs]
        AllCGIs.ERG <- Genes.tata[ (tata.df$Promoter<0.5)&(tata.df$AllCGIs>0.5) ]

        # AllCGIs Lasso vs AllCGIs Ridge
        #out$AllCGIsLasso_AllCGIsRidge <- wilcox.test(Gene.score.df[,"AllCGIs.Lasso.Cancerous"], Gene.score.df[,"AllCGIs.Ridge.Cancerous"])$p.value

        return(out)
}

# Gene.score.melted <- Reduce('rbind',lapply(1:length(typeList), function(k)
#                                             {
#                                                     tmp <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'.RData')))})
#                                                     tmp[[1]] <- t(tmp[[1]])
#                                                     tmp.df <- Reduce('cbind',tmp)
#                                                     colnames(tmp.df) <- c('LS','Promoter.Lasso','Promoter.Ridge','AllCGIs.Lasso','AllCGIs.Ridge')
#                                                     tmp.m <- melt(tmp.df)
#                                                     tmp.melted <- data.frame(r2.predict=tmp.m$value, method=rep(c('LS','Lasso','Ridge','Lasso','Ridge'),each=2374), analysis=rep(c('Mean','Promoter','Promoter','AllCGIs','AllCGIs'),each=2374), type=typeList[k])
#                                                     tmp.melted$analysis <- factor(tmp.melted$analysis, levels=c('Mean','Promoter','AllCGIs'))
#                                                     tmp.melted$method <- factor(tmp.melted$method, levels=c('LS','Ridge','Lasso'))
#                                                     return(tmp.melted)
#                                             }))
#         Gene.score.df <- Reduce('cbind',lapply(1:length(typeList), function(k)
#                                             {
#                                                     tmp <- lapply(1:length(AnalysisList), function(n){get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',typeList[k],'_',AnalysisList[n],'.RData')))})
#                                                     tmp[[1]] <- t(tmp[[1]]) # Reposition the LS
#                                                     tmp.df <- Reduce('cbind',tmp)
#                                                     colnames(tmp.df) <- paste0(c('Mean.LS.','Promoter.Lasso.','Promoter.Ridge.','AllCGIs.Lasso.','AllCGIs.Ridge.'),typeList[k])
#                                                     rownames(tmp.df) <- CommonGenes
#                                                     return(tmp.df)
#                                             }))
# 

