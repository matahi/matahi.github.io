adaptativeMean <- function(x)
{
        if (is.null(dim(x))){
                output <- x
        } else {
                output <- apply(x,2,mean)
        }
}

plot_linear_regression = function (DiseaseName,type,preprocessing) {
        #### Loading Data
        Meth.dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,preprocessing,'_processed.RData')))
        GE.dat <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData')))

        #### Processing Meth.New and GE.New
        Meth.dat.big_island <- Meth.dat[list_big_island]

        Meth.Value <- lapply(Meth.dat.big_island,adaptativeMean)
        Meth.df <- Reduce('rbind',Meth.Value)
        rownames(Meth.df) <- names(Meth.dat.big_island)

        load("../../data/processed/fData/fData_CGI.RData") 
        fData.big_island <- fData_CGI[list_big_island]
        Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))

        # Find common genes between methylation and expression
        Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 
        CommonGenes <- intersect(Genes.GE, Genes.big_island)
        ######
        GE.New <- GE.dat[match(CommonGenes,Genes.GE),]
        load("../../big_data/AssocIslandGenes.RData")
        Meth.New <- t(sapply(1:length(CommonGenes), function(n) { return( Meth.df[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1] , ]  ) })) ### !! ## Here we only take 1 CGI associated with the gene. Ideally we need to calculate it for every CGI and see which CGI correlates better. !!!!! Careful !!!!!!!

        ### GE.New and Meth.New 
        Clusters.GE <- get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',type,'_ClustersGE_updown.RData')))

        library(reshape2)

        GE.m <- melt(GE.New)
        Meth.m <- melt(Meth.New)

        tmp <- strsplit(as.character(GE.m$Var1),"\\|")
        Gene.names <- sapply(1:length(tmp), function(n){tmp[[n]][1]})

        GE_Meth.df <- data.frame(GE=GE.m$value, Meth=Meth.m$value, patients=substring(Meth.m$Var2,1,12), gene=Gene.names)

        ###### 3up, size = 353
        index <- which(Clusters.GE=="3up")
        num_char <- 20
        index_sample <- split( index, seq(length(index)/num_char))

        print("Plotting 3up...")
        for (k in 1:length(index_sample))
        {
                dat <-GE_Meth.df[GE_Meth.df$gene %in% names(index_sample[[k]]),   ]
                pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Mean/Cluster3up_',k,'.pdf'))
                print(ggplot(dat,aes(x=Meth,y=GE))+ geom_point() + geom_smooth(method="lm",color="red") + facet_wrap(~gene,scales="free",ncol=4) +xlim(0,1)  )
                dev.off()
        }

        ###### 3down, size = 126
        index <- which(Clusters.GE=="3down")
        num_char <- 20
        index_sample <- split( index, seq(length(index)/num_char))

        print("Plotting 3down...")
        for (k in 1:length(index_sample))
        {
                dat <-GE_Meth.df[GE_Meth.df$gene %in% names(index_sample[[k]]),   ]
                pdf(paste0('../../results/GE_prediction/',DiseaseName,'/Mean/Cluster3down_',k,'.pdf'))
                print(ggplot(dat,aes(x=Meth,y=GE))+ geom_point() + geom_smooth(method="lm",color="red") + facet_wrap(~gene,scales="free",ncol=4) +xlim(0,1)  )
                dev.off()
        }

}

