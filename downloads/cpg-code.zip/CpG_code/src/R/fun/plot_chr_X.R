plot_chr_X <- function(Disease)
{
        type1 <- "Normal"
        type2 <- "Cancerous"

        load(paste0('../../big_data/CGIs/',Disease,'_',type1,'_ClustersMean.RData'))
        load(paste0('../../big_data/CGIs/',Disease,'_',type2,'_ClustersMean.RData'))
        cluster1 <- eval(parse(text=paste0(Disease,".",type1,".clustersMean")))
        cluster1[cluster1==3] <- 4
        cluster2 <- eval(parse(text=paste0(Disease,".",type2,".clustersMean")))
        load('../../data/processed/fData/fData_CGI_big_island.RData')

        Chr.Info <- sapply(1:length(fData_CGI_big_island), function(n){fData_CGI_big_island[[n]][1,"CHR"]})

        ###
        load(paste0('../../big_data/CGIs/',Disease,'_',type1,'CGIs_Mean.RData'))
        load(paste0('../../big_data/CGIs/',Disease,'_',type2,'CGIs_Mean.RData'))
        Dat.Mean.1 <- eval(parse(text=paste0(Disease,".",type1,"CGIs.Mean")))
        Dat.Mean.2 <- eval(parse(text=paste0(Disease,".",type2,"CGIs.Mean")))
        Dat.Mean_big_island.1 <- Dat.Mean.1[list_big_island]
        Dat.Mean_big_island.2 <- Dat.Mean.2[list_big_island]

        Dat.X.1 <- data.frame(methylation=Reduce('c', Dat.Mean_big_island.1[ Chr.Info=="X"  ] ) , type=type1,
                            cluster = rep(cluster1[Chr.Info=="X"], sapply(1:(sum(Chr.Info=="X")), function(n){ nrow(fData_CGI_big_island[[ which(Chr.Info=="X")[n] ]]) }) ),
                            position = Reduce('c',lapply(1:(sum(Chr.Info=="X")), function(n){fData_CGI_big_island[[ which(Chr.Info=="X")[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(which(Chr.Info=="X")), function(n){fData_CGI_big_island[[which(Chr.Info=="X")[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(which(Chr.Info=="X")), function(n){fData_CGI_big_island[[which(Chr.Info=="X")[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(which(Chr.Info=="X")), function(n){fData_CGI_big_island[[which(Chr.Info=="X")[n]]][ ,"IslandEnd"]})))

        Dat.X.2 <- data.frame(methylation=Reduce('c', Dat.Mean_big_island.2[ Chr.Info=="X"  ] ) , type=type2,
                            cluster = rep(cluster2[Chr.Info=="X"], sapply(1:(sum(Chr.Info=="X")), function(n){ nrow(fData_CGI_big_island[[ which(Chr.Info=="X")[n] ]]) }) ),
                            position = Reduce('c',lapply(1:(sum(Chr.Info=="X")), function(n){fData_CGI_big_island[[ which(Chr.Info=="X")[n]]][ ,"MAPINFO"    ]})) , 
                            CGI =  Reduce('c',lapply(1:length(which(Chr.Info=="X")), function(n){fData_CGI_big_island[[which(Chr.Info=="X")[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                            IslandBegin= Reduce('c',lapply(1:length(which(Chr.Info=="X")), function(n){fData_CGI_big_island[[which(Chr.Info=="X")[n]]][ ,"IslandBegin"]})), 
                            IslandEnd=Reduce('c',lapply(1:length(which(Chr.Info=="X")), function(n){fData_CGI_big_island[[which(Chr.Info=="X")[n]]][ ,"IslandEnd"]})))

        Dat.X <- rbind(Dat.X.1,Dat.X.2)



        ### colour_scale
        colour_scale <- c('1'='red',
                          '2'='green',
                          '3'='blue',
                          '4'='black')


        pdf(paste0("../../results/clustering/",Disease,"/Chr_X.pdf"), width=10, height=10, pointsize=10)
        print(ggplot(Dat.X,aes(x=position,y=methylation))+geom_point(aes(group=type)) + geom_line(aes(group=type,colour=factor(cluster),linetype=factor(type)))+ scale_colour_manual(values=colour_scale) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(legend.position="none", axis.text.x=element_blank()))
        dev.off()

}
