analyze_Cluster4up  = function (DiseaseName) {

        # DiseaseName <- "BRCA"

        list_big_island <-which(CpGIslands.probesize>=20)
        # Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown.RData')))

        Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown_bis.RData')))

        Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed.RData')))[list_big_island]
        # Meth.4up <- Meth.Dat[Clusters.Meth=="4up"]
        Meth.3up <- Meth.Dat[Clusters.Meth=="3up"]

        #save(Meth.4up, file="~/Desktop/Meth4up.RData")
        #Meth.4up <- get(load('~/Desktop/Meth4up.RData'))

        CGI.Sum.Methylation <- sapply(1:length(Meth.3up), function(n)
                                  {
                                          return(apply(Meth.3up[[n]],2,sum))
                                  })



        BRCA.Clinical <- get(load('../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData'))
        BRCA.Clinical.processed <- BRCA.Clinical[match(rownames(CGI.Sum.Methylation), rownames(BRCA.Clinical)),]

        BRCA.Clinical.cbioportal <- get(load('../../data/processed/ClinicalAnnotations/TCGA/BRCA_Clinical_cBioPortal.RData'))
        BRCA.Clinical.cbioportal.processed <- BRCA.Clinical.cbioportal[match(substring(rownames(CGI.Sum.Methylation),1,12), substring(rownames(BRCA.Clinical.cbioportal),1,12)),]


        Dat <- BRCA.Clinical.cbioportal.processed
        CGI.Total.Methylation <- apply(CGI.Sum.Methylation,1,sum)
        Dat$Methylation <- CGI.Total.Methylation < mean(CGI.Total.Methylation)

        ####
        library(survival)
        source('lib/ggsurv.R')
        #Dat.surv <- survfit(Surv(OS_MONTHS,OS_STATUS=="LIVING") ~ SUBTYPE, data = BRCA.Clinical.cbioportal.processed)
        Dat.surv <- survfit(Surv(OS_MONTHS,OS_STATUS!="LIVING") ~ Methylation, data = Dat)
        ggsurv(Dat.surv)

        #####
        ColSideColors <- BRCA.Clinical.processed[,c('ER','PR','HER2')]
        ColSideColors[is.na(ColSideColors)] <- "grey"
        ColSideColors[ColSideColors=="0"] <- "black"
        ColSideColors[ColSideColors=="1"] <- "white"
        ColSideColors <- as.matrix(ColSideColors)

        #####
        ColSideColors.cbioportal <- BRCA.Clinical.cbioportal.processed[,"SUBTYPE"]
        ColSideColors.cbioportal[is.na(ColSideColors.cbioportal)] <- "grey"
        ColSideColors.cbioportal[ColSideColors.cbioportal=="Claudin low"] <- "yellow"
        ColSideColors.cbioportal[ColSideColors.cbioportal=="Her2 enriched"] <- "red"
        ColSideColors.cbioportal[ColSideColors.cbioportal=="Luminal A"] <- "blue"
        ColSideColors.cbioportal[ColSideColors.cbioportal=="Luminal B"] <- "green"
        ColSideColors.cbioportal[ColSideColors.cbioportal=="basal-like"] <- "black"
        ColSideColors.cbioportal <- as.matrix(ColSideColors.cbioportal)

        ColSideColors.total <- cbind(ColSideColors, ColSideColors.cbioportal)

        source('lib/heatmap.3.R')

        ### Do Heatmap
        #pdf(paste0('../../results/clustering/',DiseaseName,'/heatmap_Cluster4up.pdf'))
        #pdf(paste0('~/Desktop/heatmap_Cluster4up.pdf'))
        heatmap.3(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},distfun=function(x){as.dist((1-cor(t(x)))/2)},  scale="row", dendrogram="both", trace="none",col=redgreen, ColSideColors=ColSideColors.total)
        heatmap.3(t(CGI.PCA.Methylation),hclustfun= function(x){hclust(x,method="ward")},distfun=function(x){as.dist((1-cor(t(x)))/2)},  scale="row", dendrogram="both", trace="none",col=redgreen)
        #dev.off()

        ### Do Full Plot
        fData.4up <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))[Clusters.Meth=="4up"]

        num_char <- 4
        n <- length(Meth.4up)
        n.folds <- ceiling(length(Meth.4up)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        Clinical.Info <- rep(NA, nrow(BRCA.Clinical.processed))

        for (k in 1:length(Clinical.Info))
        {
                if (is.na(BRCA.Clinical.processed$ER[k]))
                {
                } else if (BRCA.Clinical.processed$ER[k]==1)
                {
                        Clinical.Info[k] <- "ER+"
                } else if (is.na(BRCA.Clinical.processed$HER2[k]))
                {
                        Clinical.Info[k] <- "ER-"
                } else if ((BRCA.Clinical.processed$ER[k]==0) & (BRCA.Clinical.processed$HER2[k]==0))
                {
                        Clinical.Info[k] <- "Triple Neg"
                } else if ((BRCA.Clinical.processed$ER[k]==0) & (BRCA.Clinical.processed$HER2[k]==1))
                {
                        Clinical.Info[k] <- "ER-/HER2+"
                }
        }

        ### 

        for (k in 1:length(idx))
        {
                Index <- idx[[k]]

                Dat.4up <- data.frame(methylation=Reduce('c', Meth.4up[ Index  ] ) , 
                                      patient = rep(1:nrow(CGI.Sum.Methylation), each= sum(sapply(fData.4up[Index],nrow))),
                                      position = Reduce('c',lapply(1:length(Index), function(n){fData.4up[[ Index[n]]][ ,"MAPINFO"    ]})) , 
                                      CGI =  Reduce('c',lapply(1:length(Index), function(n){fData.4up[[Index[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                      IslandBegin= Reduce('c',lapply(1:length(Index), function(n){fData.4up[[Index[n]]][ ,"IslandBegin"]})), 
                                      IslandEnd=Reduce('c',lapply(1:length(Index), function(n){fData.4up[[Index[n]]][ ,"IslandEnd"]})),
                                      Clinical.Info= rep(Clinical.Info, each=sum(sapply(fData.4up[Index],nrow))))

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Cluster4up_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.4up,aes(x=position,y=methylation))+geom_point(aes(group=patient,colour=Clinical.Info)) + geom_line(aes(group=patient,colour=Clinical.Info)) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( Clinical.Info ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(axis.text.x=element_blank()))
                dev.off()
        }


}
