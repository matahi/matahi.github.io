adjust_CNV <- function(DiseaseName,Type,MethylationAnalysis)
{
        Gene.CNV <- get(load(paste0('../../data/processed/CNV/TCGA/',DiseaseName,'/',Type,'CNV_Genes.RData')))
        Gene.Score <- get(load(paste0('../../big_data/GE_prediction/',DiseaseName,'_',type,'_',MethylationAnalysis,'.RData')))

        #######
        # Careful the patients in Gene.CNV is a subset of the patients used to make Gene.Score

        ## Mean CNV
        Gene.CNV.Mean <- apply(Gene.CNV,1,mean)

        ## 
        # then Scatterplot
        plot(Gene.CNV.Mean,Gene.Score$lasso)
        plot(Gene.CNV.Mean,Gene.Score$ridge)

  
}
