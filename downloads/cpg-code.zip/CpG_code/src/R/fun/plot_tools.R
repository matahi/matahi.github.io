plot_karyogram <- function(Values)
{
        # load('../../big_data/CommonGenes.RData')
        gene.gr <- get(load('../../big_data/GenePosition.RData'))
        Ideo <- get(load('../../data/processed/fData/hg19.RData'))

        library(ggbio)
        library(GenomicRanges)
        colour_scale <- c('1'='red',
                          '2'='green',
                          '3up'='blue',
                          '3down'='yellow',
                          '4'='black')

        gene.gr$value <- Values
        ## Removing NA?
        NA.rows <- which(is.na(gene.gr$value))

        gene.gr.bis <- gene.gr[-NA.rows,]

        out <- NULL

        out$point <- ggplot(Ideo) + layout_karyogram(cytoband=TRUE) + layout_karyogram(data=gene.gr.bis,aes(x=start,y=value,colour=value>15), geom="point", ylim=c(10,20)) + theme(legend.position="none") #+ scale_colour_manual(values=colour_scale) 
        # out$density <- ggplot(Ideo) + layout_karyogram(cytoband=TRUE) + layout_karyogram(data=gene.gr.bis,aes(x=start,y=value,colour=value>15), geom="density", ylim=c(10,20)) + theme(legend.position="none") #+ scale_colour_manual(values=colour_scale) 

        NewNames <- as.character(seqnames(gene.gr.bis))
        NewNames <- sapply(1:length(NewNames), function(n){substring(NewNames[n],4,nchar(NewNames[n]))})
        #gene.gr.bis$seqnames2 <- factor(as.character(seqnames(gene.gr.bis)), levels=c(paste0('chr',1:22),'chrX'))
        gene.gr.bis$seqnames2 <- factor(NewNames, levels=c(1:22,'X'))

        out$density <- ggplot(gene.gr.bis) + geom_density(aes(x=start,fill=value>0.5,y=..scaled..),alpha=0.2,) + facet_grid(seqnames2~.) + theme(axis.text.y=element_blank(),axis.ticks.y=element_blank())# + scale_fill_manual(values=colour_scale)

        return(out)
}


plot_grandlinear <- function(Values)
{
        load('../../big_data/CommonGenes.RData')
        gene.gr <- get(load('../../big_data/GenePosition.RData'))
        Ideo <- get(load('../../data/processed/fData/hg19.RData'))

        library(ggbio)
        library(GenomicRanges)
        colour_scale <- c('1'='red',
                          '2'='green',
                          '3up'='blue',
                          '3down'='yellow',
                          '4'='black')

        gene.gr$value <- Values

        ## Renaming c(chr 1:22,X) in c(1:22,X)
        gene.gr.bis <- gene.gr
        NewNames <- as.character(seqnames(gene.gr.bis))
        NewNames <- sapply(1:length(NewNames), function(n){substring(NewNames[n],4,nchar(NewNames[n]))})
        #gene.gr.bis$seqnames2 <- factor(NewNames, levels=c(1:22,'X'))
        seqlevels(gene.gr.bis) <- c(1:22,'X')
        seqnames(gene.gr.bis) <- factor(NewNames, levels=c(1:22,'X'))

        ## Removing NA?
        # NA.rows <- which(is.na(gene.gr$value))

        # gene.gr.bis <- gene.gr[-NA.rows,]

        out <- plotGrandLinear(gene.gr.bis, aes(x=start,y = value, colour=value > 0.5), space.skip = 0.01) + ylim(0,1) + theme(legend.position="none")
        #out$density <- plotGrandLinear(gene.gr,geom="density", aes(x=start,y = value, colour=value > 0.5), space.skip = 0.01) + ylim(0,1) + theme(legend.position="none")

        return(out)

        #out <- plotGrandLinear(gene.gr.bis, aes(x=start,y = value, colour=value > 0.5), space.skip = 0.01) + ylim(0,1) + theme(legend.position="none")
  
}

zoom_region <- function(Values, chr, Region)
{
        load('../../big_data/CommonGenes.RData')
        gene.gr <- get(load('../../big_data/GenePosition.RData'))
        load("../../big_data/AssocIslandGenes.RData")
        Ideo <- get(load('../../data/processed/fData/hg19.RData'))

        ###### Tuning CGIs.gr
        CGIs.gr <- get(load('../../big_data/CGIs.RData'))
        Clusters <- get(load('../../big_data/CGIs/BRCA_Cancerous_ClustersMean_updown.RData'))
        CGIs <- lapply(1:length(CommonGenes), function(n) { return( Reduce('rbind',list_big_island[ Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]] ])  ) }) 
        CGIs <- unique(Reduce('c',CGIs))
        Clusters.CGIs <- Clusters[ match(CGIs,list_big_island)]
        CGIs.gr$clusters <- Clusters.CGIs

        library(ggbio)
        library(GenomicRanges)
        colour_scale <- c('1'='red',
                          '2'='green',
                          '3up'='blue',
                          '3down'='yellow',
                          '4'='black')

        gene.gr$value <- Values

        p.chr <- plotIdeogram(Ideo, chr)
        p.gene <- autoplot(gene.gr[seqnames(gene.gr)==chr]) + xlim(Region)
        p.CGIs <- autoplot(CGIs.gr[seqnames(CGIs.gr)==chr],aes(colour=clusters)) + xlim(Region) + scale_colour_manual(values=colour_scale) + theme(legend.position="none")
        p.values <- autoplot(gene.gr[seqnames(gene.gr)==chr], geom="point", aes(y=value, colour=value>0.5)) + ylim(0,1) + xlim(Region) + theme(legend.position="none")

        out <- tracks(chr = p.chr, genes = p.gene, CGIs=p.CGIs, values=p.values, heights = c(1,1,1,3))

 
}


