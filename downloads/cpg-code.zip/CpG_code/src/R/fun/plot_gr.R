plot_gr <- function(CGIs, clusters=NULL,colour_scale=NULL, Ideo=hg19, fData=fData_CGI_big_island)
{
        require('ggplot2')
        require('ggbio')
        require('GenomicRanges')

	output <- NULL
        tmp <- strsplit(CGIs,":")
        new.names <- sapply(1:length(CGIs), function(n){tmp[[n]][1]})

	if (is.null(clusters))
	{
                output$gr <- GRanges(seqnames= new.names , 
				     ranges=IRanges(start=sapply(1:length(CGIs),function(n){fData[[n]][1,"IslandBegin"]}),end=sapply(1:length(CGIs),function(n){fData[[n]][1,"IslandEnd"]}))
				     )

                output$p <- ggplot(Ideo) + layout_karyogram(cytoband=TRUE) + layout_karyogram(output$gr, geom="rect", ylim=c(11,21), color="blue") + theme(legend.position="none")

	} else {

		output$gr <- GRanges(seqnames= new.names, 
				     ranges=IRanges(start=sapply(1:length(CGIs),function(n){fData[[n]][1,"IslandBegin"]}),end=sapply(1:length(CGIs),function(n){fData[[n]][1,"IslandEnd"]})),
                                     clusters = clusters
				     )

                if (is.null(colour_scale))
                {
                        output$p <- ggplot(Ideo) + layout_karyogram(cytoband=TRUE) + layout_karyogram(output$gr, geom="rect", ylim=c(11,21), aes(color=factor(clusters))) + theme(legend.position="none")
                } else {
                        output$p <- ggplot(Ideo) + layout_karyogram(cytoband=TRUE) + layout_karyogram(output$gr, geom="rect", ylim=c(11,21), aes(color=factor(clusters))) +
                        scale_colour_manual(values=colour_scale)+ theme(legend.position="none")
                }

	}

	return(output)

}
