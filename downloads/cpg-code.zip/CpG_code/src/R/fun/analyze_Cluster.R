analyze_Cluster  = function (DiseaseName,clust) {
        DiseaseName <- "BRCA"
        # DiseaseName <- "LUAD"
        # clust <- "1"
        # clust <- "2"
        # clust <- "3down"
        clust <- "3up"

        list_big_island <-which(CpGIslands.probesize>=20)

        ##### Methylation Behaviour
        Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean_updown_bis.RData')))
        Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs_processed.RData')))[list_big_island]
        Normal.Meth <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/NormalCGIs_processed.RData')))[list_big_island]
        # Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs.RData')))[list_big_island]

        Meth.clust <- Meth.Dat[Clusters.Meth==clust]
        CGI.Sum.Methylation <- sapply(1:length(Meth.clust), function(n)
                                  {
                                          return(apply(Meth.clust[[n]],2,function(x){mean(x,na.rm=T)}))
                                  })

        CGI.PCA.Methylation <- sapply(1:length(Meth.clust), function(n)
                                      {
                                              ## Calculate PCA + Score par patient
                                              PC <- princomp(t(Meth.clust[[n]]))
                                              return(PC$scores[,1]) ## First PCA
                                      })

        Normal.clust <- Normal.Meth[Clusters.Meth==clust]

        CGI.Sum.Methylation.Normal <- sapply(1:length(Normal.clust), function(n)
                                  {
                                          return(apply(Normal.clust[[n]],2,function(x){mean(x,na.rm=T)}))
                                  })

 



        ##### 
        Clinical <- get(load(paste0('../../data/processed/ClinicalAnnotations/TCGA/',DiseaseName,'.Clinical.cancerous.RData')))
        # Clinical <- get(load(paste0('../../data/processed/ClinicalAnnotations/TCGA/',DiseaseName,'.Clinical.cancerous_2.RData')))
        Clinical.processed <- Clinical[match(rownames(CGI.Sum.Methylation), rownames(Clinical)),] # for BRCA.Clinical.cancerous.RData
        # Clinical.processed <- Clinical[match(substring(rownames(CGI.Sum.Methylation),1,12), Clinical$bcr_patient_barcode),]  # for LUAD and Colon.Clinical.Cancerous
        # Clinical.processed <- Clinical[match(substring(rownames(CGI.Sum.Methylation),1,12), substring(Clinical$bcr_followup_barcode,1,12)),] # for BRCA.Clinical.cancerous_2.Rdata

        Clinical.cbioportal <- get(load(paste0('../../data/processed/ClinicalAnnotations/TCGA/',DiseaseName,'_Clinical_cBioPortal.RData')))
        Clinical.cbioportal.processed <- Clinical.cbioportal[match(substring(rownames(CGI.Sum.Methylation),1,12), substring(rownames(Clinical.cbioportal),1,12)),]
        Clinical.cbioportal.processed <- Clinical.cbioportal.processed[, -4]

        ##### Gene Expression Behaviour
        ## CommonGenes <- get(load('../../big_data/GE_prediction/Tools/CommonGenes.RData')) 
        ## PromoterAssoc <- get(load('../../big_data/GE_prediction/Tools/PromoterAssoc.RData'))
        ## Clusters.New.cancerous <- sapply(1:length(CommonGenes), function(n) { return( Clusters.Meth[PromoterAssoc[n]]  ) })

        GE.dat.Cancerous <- get(load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData')))
        Genes.GE <- sapply(1:nrow(GE.dat.Cancerous), function(n){ tmp <- strsplit(rownames(GE.dat.Cancerous)[n],"\\|"); return(tmp[[1]][1])     } ) 
        ## GE.dat.Cancerous.common <- GE.dat.Cancerous[match(CommonGenes,Genes.GE),]
        ## GE.Clust <- GE.dat.Cancerous.common[Clusters.New.cancerous==clust,]

        ### ERBB2
        # qplot(GE.dat.Cancerous[Genes.GE=="ERBB2",],geom="density",binwidth=2) + geom_vline(xintercept=130,color="red")
        # table(GE.dat.Cancerous[Genes.GE=="ERBB2",]>130, Clinical.processed$HER2,useNA="always")
        Error.HER2 <- sapply(1:1000, function(k)
                        {
                                tmp <- table(GE.dat.Cancerous[Genes.GE=="ERBB2",]> k, Clinical.processed$HER2)
                                if ( "FALSE" %in% rownames(tmp))
                                {
                                        Error <- ( tmp["FALSE","1"] + tmp["TRUE","0"] ) / sum(tmp)
                                } else 
                                {
                                        Error <- ( tmp["TRUE","0"] ) / sum(tmp)
                                }
                        })
        CutOff.HER2 <- which.min(Error.HER2)


        Clinical.processed$HER2_bis <- 0
        Clinical.processed$HER2_bis[GE.dat.Cancerous[Genes.GE=="ERBB2",] > CutOff.HER2] <- 1

        ### ESR1
        # table(GE.dat.Cancerous[Genes.GE=="ESR1",]>5, Clinical.processed$ER)
        Error.ER <- sapply(1:100, function(k)
                        {
                                tmp <- table(GE.dat.Cancerous[Genes.GE=="ESR1",]> k, Clinical.processed$ER)
                                if ( "FALSE" %in% rownames(tmp))
                                {
                                        Error <- ( tmp["FALSE","1"] + tmp["TRUE","0"] ) / sum(tmp)
                                } else 
                                {
                                        Error <- ( tmp["TRUE","0"] ) / sum(tmp)
                                }
                        })
        CutOff.ER <- which.min(Error.ER)


        Clinical.processed$ER_bis <- 0
        Clinical.processed$ER_bis[GE.dat.Cancerous[Genes.GE=="ESR1",] > CutOff.ER] <- 1
        
        save(Clinical.processed, file="../../big_data/BRCA_Clinical_Processed.RData")

        #####
        #ColSideColors <- Clinical.processed[,c('ER','PR','HER2')]
        #ColSideColors <- Clinical.processed[,c('ER','HER2')]
        ColSideColors <- Clinical.processed[,c('ER_bis','HER2_bis')]
        ColSideColors[is.na(ColSideColors)] <- "grey"
        ColSideColors[ColSideColors=="0"] <- "#404040"
        ColSideColors[ColSideColors=="1"] <- "#ffffff"
        ColSideColors <- as.matrix(ColSideColors)

        # #####
        # ColSideColors.cbioportal <- Clinical.cbioportal.processed[,"SUBTYPE"]
        # ColSideColors.cbioportal[is.na(ColSideColors.cbioportal)] <- "grey"
        # ColSideColors.cbioportal[ColSideColors.cbioportal=="Claudin low"] <- "yellow"
        # ColSideColors.cbioportal[ColSideColors.cbioportal=="Her2 enriched"] <- "red"
        # ColSideColors.cbioportal[ColSideColors.cbioportal=="Luminal A"] <- "blue"
        # ColSideColors.cbioportal[ColSideColors.cbioportal=="Luminal B"] <- "green"
        # ColSideColors.cbioportal[ColSideColors.cbioportal=="basal-like"] <- "black"
        # ColSideColors.cbioportal <- as.matrix(ColSideColors.cbioportal)

        ##
        ColSideColors.Survival <- as.character(Clinical.processed[,"OS_STATUS"])
        ColSideColors.Survival[is.na(ColSideColors.Survival)] <- "grey"
        ColSideColors.Survival[ColSideColors.Survival=="LIVING"] <- "#ffffff"
        ColSideColors.Survival[ColSideColors.Survival=="DECEASED"] <- "#d7191c"
        ColSideColors.Survival <- as.matrix(ColSideColors.Survival)

        ## ##
        ## ColSideColors.Survival.Months <- Clinical.cbioportal.processed[,"OS_MONTHS"]
        ## ColSideColors.Survival.Months[is.na(ColSideColors.Survival.Months)] <- "grey"
        ## ColSideColors.Survival.Months[((Clinical.cbioportal.processed$OS_MONTHS<60)&(Clinical.cbioportal.processed$OS_STATUS=="DECEASED"))] <- "red"
        ## ColSideColors.Survival.Months[!((Clinical.cbioportal.processed$OS_MONTHS<60)&(Clinical.cbioportal.processed$OS_STATUS=="DECEASED"))] <- "green"
        ## ColSideColors.Survival.Months <- as.matrix(ColSideColors.Survival.Months)

        ##

        #ColSideColors.total <- cbind(ColSideColors, ColSideColors.Survival, ColSideColors.Survival.Months)
        ColSideColors.total <- cbind(ColSideColors, ColSideColors.Survival)
        colnames(ColSideColors.total) <- c('ER','HER2','Survival')

        source('lib/heatmap.3.R')
        require('RColorBrewer')
        colmap <- colorRampPalette(c('blue','black','yellow'))(100)

        ### Do Heatmap Methylation
        p <- heatmap.3(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="column", trace="none",col=colmap, ColSideColors=ColSideColors.total,Key="Methylation",
                  labRow=NA,labCol=NA)

        p.Normal <- heatmap.3(t(CGI.Sum.Methylation.Normal)[p$rowInd,], dendrogram="none",scale="none", labCol=F, labRow=F, col=colmap)

        tmp <- t(CGI.Sum.Methylation.Normal)
        color.Table <- p.Normal$colorTable
        RowSideColors <- matrix(0,nrow=ncol(p.Normal$carpet), ncol=nrow(p.Normal$carpet))

        for (k in 1:nrow(color.Table))
        {
                index <- intersect(which(tmp>color.Table[k,1]), which(tmp<= color.Table[k,2]))
                RowSideColors[index] <- as.character(color.Table[k,3])
        }


        #### Adding the Cluster 3 up
        Cluster3up <- rep('#00BA38', nrow(CGI.Sum.Methylation))  ## Low
        Cluster3up[ p$colInd[(length(labels(p$colDendrogram[[1]])) + 1): (length(labels(p$colDendrogram[[1]])) +length(labels(p$colDendrogram[[2]][[1]]))     )]  ] <- '#F8766D' ### High
        Cluster3up[ p$colInd[1:length(labels(p$colDendrogram[[1]]))]  ] <-  "#619CFF" ## Negative

        ColSideColors.total <- cbind(ColSideColors.total, Cluster3up)
        colnames(ColSideColors.total) <- c('ER','HER2','Survival','Cluster 3up')

        source('lib/heatmap.3.R')

        # pdf(paste0('../../results/clustering/',DiseaseName,'/heatmap_Cluster',clust,'.pdf'))
        #pdf(paste0('~/Desktop/',DiseaseName,'_heatmap_Cluster',clust,'.pdf'))
        pdf(paste0('../../results/clustering/',DiseaseName,'/Heatmap_Cluster',clust,'.pdf'))
        p <- heatmap.3(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="column", trace="none",col=colmap, ColSideColors=ColSideColors.total,RowSideColors= t(RowSideColors),
                       Key="Methylation",labRow=NA,labCol=NA,lhei=c(1,3))
        dev.off()


        ###
        # Clusters.CIMP <- Cluster3up
        # Clusters.CIMP[Cluster3up == "#00BA38"] <- "Intermediate"
        # Clusters.CIMP[Cluster3up == "#F8766D"] <- "High"
        # Clusters.CIMP[Cluster3up == "#619CFF"] <- "Low"

        # names(Clusters.CIMP) <- colnames(Meth.Dat[[1]])

        # save(Clusters.CIMP, file="../../big_data/Clusters_CIMP.RData")


        #### Using PCA
        # p <- heatmap.3(t(CGI.PCA.Methylation),hclustfun= function(x){hclust(x,method="ward")},  scale="row", dendrogram="both", trace="none",col=colmap, ColSideColors=ColSideColors.total,Key="Methylation",
        #                #p <- heatmap.3(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="both", trace="none",col=colmap, Key="Methylation",
        #                labRow=NA,labCol=NA)

        #CIMP.low <- labels(p$colDendrogram[[1]])
        #CIMP.high <- labels(p$colDendrogram[[2]]) 

        CIMP.low <- labels(p$colDendrogram[[1]])
        CIMP.high1 <- labels(p$colDendrogram[[2]][[1]])
        CIMP.high2 <- labels(p$colDendrogram[[2]][[2]]) 

        Dat <- cbind(Clinical.cbioportal.processed,Clinical.processed)
        Dat$CIMP <- rep(0,nrow(Clinical.cbioportal.processed))

        # Dat <- Clinical.processed
        # Dat$CIMP <- rep(0,nrow(Clinical.processed))
        #######    Dat$CIMP[ rownames(CGI.Sum.Methylation) %in% CIMP.high] <-1 
        Dat$CIMP[ rownames(CGI.Sum.Methylation) %in% CIMP.high1] <- 2  ## High
        Dat$CIMP[ rownames(CGI.Sum.Methylation) %in% CIMP.high2] <- 1  ## Low

        # all(Dat$bcr_patient_barcode == substring(rownames(CGI.Sum.Methylation),1,12),na.rm=T)

        # Dat$last_contact_days_to[Dat$last_contact_days_to == "[Not Available]"] <- NA
        # Dat$last_contact_days_to <- as.numeric(Dat$last_contact_days_to)

        # CGI.Total.Methylation <- apply(CGI.Sum.Methylation,1,sum)
        # Dat$Methylation <- CGI.Total.Methylation < mean(CGI.Total.Methylation)
        # Dat$Time <- sapply(1:nrow(Dat), function(k)
        #                    {
        #                            if (is.na(Dat$vital_status[k]))
        #                            {
        #                                    return(NA)
        #                            } else if ( (Dat$vital_status[k])=="LIVING")
        #                            {
        #                                    return(Dat$days_to_last_followup[k])
        #                            } else if (Dat$vital_status[k]=="DECEASED")
        #                            {
        #                                    return(Dat$days_to_death[k])
        #                            }
        #                    })

        Censor <- 60
        Dat$OS_MONTHS_Censor <- Dat$OS_MONTHS
        Dat$OS_MONTHS_Censor[Dat$OS_MONTHS>=Censor] <- Censor

        Dat$OS_STATUS_Censor <- Dat$OS_STATUS
        Dat$OS_STATUS_Censor[Dat$OS_MONTHS>=Censor] <- "LIVING"

        ##
        # Dat.HER2 <- Dat[((Dat$HER2_bis==1))|(Dat$SUBTYPE=="Her2 enriched"),]
        # Dat.RO <- Dat[((Dat$ER_bis==1)&(Dat$HER2_bis==0))|(Dat$SUBTYPE %in% c('Luminal A','Luminal B')),]

        library(survival)
        source('lib/ggsurv.R')
        Dat.surv.CIMP <- survfit(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ factor(CIMP), data = Dat)

        surv.diff.CIMP <- survdiff(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ CIMP, data = Dat)

        Cox.CIMP <- coxph(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ factor(CIMP), data = Dat)

        #Cox.CIMP <- coxph(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ factor(CIMP) + factor(HER2_bis) + factor(ER_bis) , data = Dat)
        Dat$Age_diagnosis <- as.numeric(Dat$Age_diagnosis)
        Cox.CIMP <- coxph(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~  factor(CIMP)  + (Age_diagnosis>50) + interaction(factor(ER_bis),factor(HER2_bis)) + factor(Size) + factor(LymphNodeCount_Class) , data = Dat)

        ### Without Non Significant Variables: Age + Size
        Cox.CIMP <- coxph(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~  factor(CIMP)  + interaction(factor(ER_bis),factor(HER2_bis)) + factor(LymphNodeCount_Class) , data = Dat)

        ### Add Meta
        Dat.TripleNeg <- Dat[(Dat$ER_bis==0)&(Dat$HER2_bis==0),]
        Dat.TripleNeg.NegLow <- Dat.TripleNeg[(Dat.TripleNeg$CIMP %in% c(0,1)),]
        # TripleNeg <- (Dat$ER_bis==0)&(Dat$HER2_bis==0)

        Dat.surv.TripleNeg.NegLow <- survfit(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ CIMP, data = Dat.TripleNeg.NegLow)

        # surv.diff.TripleNeg <- survdiff(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ CIMP, data = Dat.TripleNeg)
        Cox.TripleNeg <- coxph(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ CIMP, data = Dat.TripleNeg.NegLow)

        # Cluster3up_colours <- c('2' = '#F8766D',
        #                         '1' = '#00BA38',
        #                         '0' = '#619CFF')

        p.Surv.TripleNeg <- ggsurv(Dat.surv.TripleNeg.NegLow,  xlab="Time after diagnosis (Months)", ylab="Probability",plot.cens=F) +
        scale_colour_manual(values = Cluster3up_colours) +
        coord_cartesian(ylim=c(0, 1.02)) +
        scale_y_continuous(breaks=seq(0, 1, 0.25),labels=c('0','0.25','0.5','0.75','1')) +
        theme(panel.grid=element_blank(),
              legend.position="none",
              text = element_text(size=20),
              panel.background=element_rect(fill="white"),
              axis.text=element_text(colour="black",size=rel(0.8)),
              axis.ticks=element_line(colour="black"),
              panel.border=element_rect(fill=NA, colour="black",size=0.7),
              axis.title.y = element_text(vjust=0.35),
              strip.background = element_rect(colour="black",fill="white",size=0.7),
              axis.line = element_line(colour = "black",size=0.7))

        ggsave(paste0('../../results/clustering/',DiseaseName,'/Survival_cluster_TripleNeg_',clust,'.pdf'),p.Surv.TripleNeg, dpi=300)


        # Dat.surv.HER2 <- survfit(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ CIMP, data = Dat.HER2)
        # Cox.HER2 <- coxph(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ CIMP, data = Dat.HER2)

        # Dat.surv.RO <- survfit(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ CIMP, data = Dat.RO)
        # Cox.RO <- coxph(Surv(OS_MONTHS_Censor,OS_STATUS_Censor!="LIVING") ~ factor(CIMP), data = Dat.RO)

        #p.Surv <- ggsurv(Dat.surv.CIMP, CI=T, xlab="Time after diagnosis (Months)", ylab="Probability") +
        #p.Surv <- ggsurv(Dat.surv.CIMP,  xlab="Time after diagnosis (Months)", ylab="Probability") +

        # Cluster3up_colours <- c('1' = '#F8766D',
        #                         '0' = '#00BFC4')

        Cluster3up_colours <- c('2' = '#F8766D',
                                '1' = '#00BA38',
                                '0' = '#619CFF')


        source('lib/ggsurv.R')

        p.Surv <- ggsurv(Dat.surv.CIMP,  xlab="Time after diagnosis (Months)", ylab="Probability",plot.cens=F) +
        scale_colour_manual(values = Cluster3up_colours) +
        coord_cartesian(ylim=c(0, 1.02)) +
        scale_y_continuous(breaks=seq(0, 1, 0.25),labels=c('0','0.25','0.5','0.75','1')) +
        theme(panel.grid=element_blank(),
              legend.position="none",
              text = element_text(size=20),
              panel.background=element_rect(fill="white"),
              axis.text=element_text(colour="black",size=rel(0.8)),
              axis.ticks=element_line(colour="black"),
              panel.border=element_rect(fill=NA, colour="black",size=0.7),
              axis.title.y = element_text(vjust=0.35),
              strip.background = element_rect(colour="black",fill="white",size=0.7),
              axis.line = element_line(colour = "black",size=0.7))

        ggsave(paste0('../../results/clustering/',DiseaseName,'/Survival_cluster_',clust,'.pdf'),p.Surv, dpi=300)

        #pdf(paste0('~/Desktop/',DiseaseName,'_Survival_CIMP'.pdf))
        #print(ggsurv(Dat.surv.CIMP)+ylim(0,1))
        #dev.off()

        #pdf('~/Desktop/Survie_Cluster_4_TripleNeg.pdf')
        #print(ggsurv(Dat.surv.TripleNeg)+ylim(0,1))
        #dev.off()

        #pdf('~/Desktop/Survie_Cluster_4_HER2_enriched.pdf')
        #print(ggsurv(Dat.surv.HER2)+ylim(0,1))
        #dev.off()

        #pdf('~/Desktop/Survie_Cluster_4_RO_plus.pdf')
        #print(ggsurv(Dat.surv.RO)+ylim(0,1))
        #dev.off()

        ### Do Heatmap
        # pdf(paste0('../../results/clustering/',DiseaseName,'/heatmap_Cluster',clust,'.pdf'))
        pdf(paste0('~/Desktop/heatmap_GE_Cluster',clust,'.pdf'))
        #heatmap.3(GE.Clust,hclustfun= function(x){hclust(x,method="ward")},  scale="row", dendrogram="both", trace="none",col=greenred(100), ColSideColors=ColSideColors.total,Key="Gene Expression",
        heatmap.3(GE.Clust,hclustfun= function(x){hclust(x,method="ward")},  scale="row", dendrogram="both", trace="none",col=greenred(100), breaks=seq(-5,5,length.out=101), ColSideColors=ColSideColors.total,Key="Gene Expression",
                  labRow=NA,labCol=NA)
        dev.off()

        ### Do Full Plot
        fData.clust <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))[Clusters.Meth==clust]

        num_char <- 4
        n <- length(Meth.clust)
        n.folds <- ceiling(length(Meth.clust)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        Clinical.Info <- rep(NA, nrow(BRCA.Clinical.processed))

        for (k in 1:length(Clinical.Info))
        {
                if (is.na(BRCA.Clinical.processed$ER[k]))
                {
                } else if (BRCA.Clinical.processed$ER[k]==1)
                {
                        Clinical.Info[k] <- "ER+"
                } else if (is.na(BRCA.Clinical.processed$HER2[k]))
                {
                        Clinical.Info[k] <- "ER-"
                } else if ((BRCA.Clinical.processed$ER[k]==0) & (BRCA.Clinical.processed$HER2[k]==0))
                {
                        Clinical.Info[k] <- "Triple Neg"
                } else if ((BRCA.Clinical.processed$ER[k]==0) & (BRCA.Clinical.processed$HER2[k]==1))
                {
                        Clinical.Info[k] <- "ER-/HER2+"
                }
        }

        ### 
        # k <- 1
        # index_characteristics <- get(load(paste0('../../big_data/CGIs/',Disease,'_CancerousCGIs_characteristics.RData')))
        # Clusters.clust <- which(Clusters.Meth==clust)
        # Index <- match(index_characteristics[[clust]][1:4],Clusters.clust)

        ### ADD NORMAL as control !


        for (k in 1:length(idx))
        {
                ##
                k <- 1

                Index <- idx[[k]]

                Dat.clust <- data.frame(methylation=Reduce('c',Reduce('rbind', Meth.clust[ Index  ])) , 
                                      patient = rep(1:nrow(CGI.Sum.Methylation), each= sum(sapply(fData.clust[Index],nrow))),
                                      position = Reduce('c',lapply(1:length(Index), function(n){fData.clust[[ Index[n]]][ ,"MAPINFO"    ]})) , 
                                      CGI =  Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                      IslandBegin= Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandBegin"]})), 
                                      IslandEnd=Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandEnd"]})),
                                      Clinical.Info= rep(Clinical.Info, each=sum(sapply(fData.clust[Index],nrow))))

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Cluster",clust,"_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.clust,aes(x=position,y=methylation))+geom_point(aes(group=patient,colour=Clinical.Info)) + geom_line(aes(group=patient,colour=Clinical.Info)) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( Clinical.Info ~ CGI, scales="free", ncol=4) + ylim(0,1) + theme(axis.text.x=element_blank()))
                dev.off()
        }

        ####################################################################################################
        ####################################################################################################
        ### Use Normal as Control
        ####################################################################################################
        ####################################################################################################

        Meth.Control <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/NormalCGIs_processed.RData')))[list_big_island]
        Meth.clust.Control <- Meth.Control[Clusters.Meth==clust]

        Meth.tot <- lapply(1:length(Meth.clust), function(n){cbind(Meth.clust[[n]], Meth.clust.Control[[n]])})

        CGI.Sum.Methylation <- sapply(1:length(Meth.tot), function(n)
                                  {
                                          return(apply(Meth.tot[[n]],2,sum))
                                  })


        BRCA.Clinical <- get(load('../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData'))
        BRCA.Clinical.processed <- BRCA.Clinical[match(colnames(Meth.clust[[1]]), rownames(BRCA.Clinical)),]
        for (k in 1:ncol(BRCA.Clinical.processed))
        {
                if (is.factor(BRCA.Clinical.processed[1,k]))
                {
                        BRCA.Clinical.processed[,k] <- as.character(BRCA.Clinical.processed[,k])
                }
        }

        BRCA.Clinical.normal <- data.frame(matrix(-1,nrow=ncol(Meth.clust.Control[[1]]),ncol=ncol(BRCA.Clinical.processed)))
        colnames(BRCA.Clinical.normal) <- colnames(BRCA.Clinical.processed)
        
        BRCA.Clinical.tot <- rbind(BRCA.Clinical.processed,BRCA.Clinical.normal)


        #####
        ColSideColors <- BRCA.Clinical.tot[,c('ER','PR','HER2')]
        ColSideColors[is.na(ColSideColors)] <- "grey"
        ColSideColors[ColSideColors=="0"] <- "black"
        ColSideColors[ColSideColors=="1"] <- "white"
        ColSideColors[ColSideColors=="-1"] <- "green"
        ColSideColors <- as.matrix(ColSideColors)

        source('lib/heatmap.3.R')
        ### Do Heatmap
        pdf(paste0('../../results/clustering/',DiseaseName,'/heatmap_Cluster',clust,'.pdf'))
        heatmap.3(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},distfun=function(x){as.dist((1-cor(t(x)))/2)},  scale="row", dendrogram="both", trace="none",col=redgreen, ColSideColors=ColSideColors)
        dev.off()

        ### Do Full Plot
        fData.clust <- get(load('../../data/processed/fData/fData_CGI_big_island.RData'))[Clusters.Meth==clust]

        num_char <- 4
        n <- length(Meth.clust)
        n.folds <- ceiling(length(Meth.clust)/num_char)
        idx <- split( seq( n ), seq(n.folds) )

        Clinical.Info <- rep(NA, nrow(BRCA.Clinical.tot))

        for (k in 1:length(Clinical.Info))
        {
                if (is.na(BRCA.Clinical.tot$ER[k]))
                {
                } else if (BRCA.Clinical.tot$ER[k]==1)
                {
                        Clinical.Info[k] <- "ER+"
                } else if (BRCA.Clinical.tot$ER[k]==-1)
                {
                        Clinical.Info[k] <- "Normal"
                } else if (is.na(BRCA.Clinical.tot$HER2[k]))
                {
                        Clinical.Info[k] <- "ER-"
                } else if ((BRCA.Clinical.tot$ER[k]==0) & (BRCA.Clinical.tot$HER2[k]==0))
                {
                        Clinical.Info[k] <- "Triple Neg"
                } else if ((BRCA.Clinical.tot$ER[k]==0) & (BRCA.Clinical.tot$HER2[k]==1))
                {
                        Clinical.Info[k] <- "ER-/HER2+"
                }
        }

        ### 
        # k <- 1
        # index_characteristics <- get(load(paste0('../../big_data/CGIs/',Disease,'_CancerousCGIs_characteristics.RData')))
        # Clusters.clust <- which(Clusters.Meth==clust)
        # Index <- match(index_characteristics[[clust]][1:4],Clusters.clust)

        ### ADD NORMAL as control !


        for (k in 1:length(idx))
        {
                ##
                k <- 1

                Index <- idx[[k]]

                Dat.clust <- data.frame(methylation=Reduce('c',Reduce('rbind', Meth.tot[ Index  ])) , 
                                      patient = rep(1:nrow(CGI.Sum.Methylation), each= sum(sapply(fData.clust[Index],nrow))),
                                      position = Reduce('c',lapply(1:length(Index), function(n){fData.clust[[ Index[n]]][ ,"MAPINFO"    ]})) , 
                                      CGI =  Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"UCSC_CpG_Islands_Name"]})), 
                                      IslandBegin= Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandBegin"]})), 
                                      IslandEnd=Reduce('c',lapply(1:length(Index), function(n){fData.clust[[Index[n]]][ ,"IslandEnd"]})),
                                      Clinical.Info= rep(Clinical.Info, each=sum(sapply(fData.clust[Index],nrow))))

                pdf(paste0("../../results/clustering/",Disease,"/Mean/Cluster",clust,"_plots_sample_",k,".pdf"), width=10, height=10, pointsize=10)
                print(ggplot(Dat.clust,aes(x=position,y=methylation))+geom_point(aes(group=patient,colour=Clinical.Info)) + geom_line(aes(group=patient,colour=Clinical.Info)) + geom_vline(aes(xintercept=IslandBegin),colour="black",linetype = "longdash")+geom_vline(aes(xintercept=IslandEnd),colour="black", linetype= "longdash")+facet_wrap( Clinical.Info ~ CGI, scales="free", ncol=5) + ylim(0,1) + theme(axis.text.x=element_blank()))
                dev.off()

        }





}
