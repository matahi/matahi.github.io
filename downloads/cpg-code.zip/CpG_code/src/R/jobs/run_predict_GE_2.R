#####################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading 
## Path Setting 
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R/jobs") # for Curie Machines
#setwd(PATH)
#
## Analysis
source('predict_ALL_once.R')

# out <- predict_ALL("BRCA","Cancerous", MethylationAnalysis="all", num=2)
# out <- predict_ALL("LUAD","Cancerous", MethylationAnalysis="all", num=2)
out <- predict_ALL("Colon","Cancerous", MethylationAnalysis="all", num=2)

source('predict_chr_once.R')

# out <- predict_chr("BRCA","Cancerous", MethylationAnalysis="chr", num=2)
# out <- predict_chr("LUAD","Cancerous", MethylationAnalysis="chr", num=2)
# out <- predict_chr("Colon","Cancerous", MethylationAnalysis="chr", num=2)

source('predict_promoter_once.R')

# out <- predict_promoter("BRCA","Cancerous", MethylationAnalysis="promoter", num=2)
# out <- predict_promoter("LUAD","Cancerous", MethylationAnalysis="promoter", num=2)
# out <- predict_promoter("Colon","Cancerous", MethylationAnalysis="promoter", num=2)



# #############
# CommonGenes.Split <- split(CommonGenes, 1:4)
# 
# tmp <-CommonGenes.Split[[1]]
# save(tmp, file="CommonGenes1.RData")
# 
# tmp <-CommonGenes.Split[[2]]
# save(tmp, file="CommonGenes2.RData")
# 
# tmp <-CommonGenes.Split[[3]]
# save(tmp, file="CommonGenes3.RData")
# 
# tmp <-CommonGenes.Split[[4]]
# save(tmp, file="CommonGenes4.RData")

