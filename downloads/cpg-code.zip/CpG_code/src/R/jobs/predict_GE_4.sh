#!/bin/bash
#PBS -l nodes=1:ppn=12,mem=100gb,walltime=72:00:00
#PBS -M mmoarii@curie.fr
#PBS -m ae
#PBS -j oe
#PBS -N predict_GE_4
#PBS -q batch
#PBS -o ./predict_GE_out_4

export PATH=$PATH:/bioinfo/local/build/R/R-3.0.0/bin/

cd ~/Desktop/CpG/src/R/jobs

Rscript run_predict_GE_4.R
