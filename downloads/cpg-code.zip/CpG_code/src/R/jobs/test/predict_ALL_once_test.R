predict_ALL <- function(DiseaseName,type,preprocessing="Level2",MethylationAnalysis="all", num=1)
{

        # DiseaseName <- "BRCA"
        # type <- "Cancerous"
        # preprocessing <- "Level2"
        # MethylationAnalysis <- "chr"

        ## Preprocessing 
        Meth.dat <- get(load(paste0('../../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,preprocessing,'_processed.RData')))
        GE.dat <- get(load(paste0('../../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData')))

        CommonGenes <- get(load(paste0('CommonGenes',num,'.RData')))
        Genes.GE <- sapply(1:nrow(GE.dat), function(n){tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])}) 
        GE.df <- GE.dat[match(CommonGenes,Genes.GE),]

        n.folds <- 3
        set.seed(1234)
        partition <- split(sample(seq(ncol(GE.df))), seq(n.folds))

        ### Train a regression model of GE = f(Methylation) for each gene and calculate the performance
        library(glmnet)
        library(doParallel)
        registerDoParallel(cores=15)

        X <- t(Meth.dat)

        Regression.Genes <- foreach(n=1:nrow(GE.df)) %dopar%
                             {
                                     print(n)
                                     ###
                                     # Y <- t(GE.df[n,,drop=F])

                                     # ###
                                     # pearson.fold <- sapply(seq(n.folds), function(n_fold)
                                     #                        {
                                     #                                Y_train <- Y[-partition[[n_fold]],,drop=F ]
                                     #                                # X_train <- X[-partition[[n_fold]],]

                                     #                                Y_test <- Y[partition[[n_fold]],,drop=F ]
                                     #                                # X_test <- X[partition[[n_fold]],]

                                     #                                if (any(Y_train != Y_train[1]))
                                     #                                {
                                     #                                        ## 1) do Crossval on (X_train,Y_train) to tune lambda
                                     #                                        lambda.lasso <- cv.glmnet(X[-partition[[n_fold]],],Y_train,alpha=1,nfolds=3)$lambda.min

                                     #                                        ## 2) do prediction of Y_test and look at correlation with real Y_test
                                     #                                        predictor.lasso <- glmnet(X[-partition[[n_fold]],],Y_train,alpha=1,lambda=lambda.lasso)

                                     #                                        Y_predict.lasso <- predict(predictor.lasso,newx=X_test <- X[partition[[n_fold]],], s= lambda.lasso)

                                     #                                        r2.pearson.lasso <- cor(Y_test,Y_predict.lasso)^2
                                     #                                } else {
                                     #                                        r2.pearson.lasso <- NA
                                     #                                }

                                     #                                gc()
                                     #                                return(r2.pearson.lasso)
                                     #                        })
                                     # gc()

                                     # return(pearson.fold)
                                     return(n)
                             }

        Regression.Genes <- Reduce('rbind',Regression.Genes)

        save(Regression.Genes,file=paste0(DiseaseName,"_",type,"_",MethylationAnalysis,"_",num,".RData"))



}
