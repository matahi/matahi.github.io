#!/bin/bash
#PBS -l nodes=1:ppn=15,mem=5gb,walltime=1:00:00
#PBS -M mmoarii@curie.fr
#PBS -m ae
#PBS -j oe
#PBS -N predict_GE_1
#PBS -q batch
#PBS -o ./predict_GE_out_1

export PATH=$PATH:/bioinfo/local/build/R/R-3.0.0/bin/

cd ~/Desktop/CpG/src/R/jobs

Rscript run_predict_GE_test.R
