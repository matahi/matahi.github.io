#####################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading 
## Path Setting 
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R/jobs") # for Curie Machines
#setwd(PATH)
#
## Analysis
source('predict_ALL_once_test.R')

out <- predict_ALL("BRCA","Cancerous", MethylationAnalysis="all", num=1)
# out <- predict_ALL("LUAD","Cancerous", MethylationAnalysis="all")
# out <- predict_ALL("Colon","Cancerous", MethylationAnalysis="all")

# #############
# CommonGenes.Split <- split(CommonGenes, 1:4)
# 
# tmp <-CommonGenes.Split[[1]]
# save(tmp, file="CommonGenes1.RData")
# 
# tmp <-CommonGenes.Split[[2]]
# save(tmp, file="CommonGenes2.RData")
# 
# tmp <-CommonGenes.Split[[3]]
# save(tmp, file="CommonGenes3.RData")
# 
# tmp <-CommonGenes.Split[[4]]
# save(tmp, file="CommonGenes4.RData")

