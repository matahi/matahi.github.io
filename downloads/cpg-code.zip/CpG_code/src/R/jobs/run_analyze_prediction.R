setwd('~/Desktop/CpG/src/R/jobs/')


########################################
# Concatenate ALL
DiseaseName <- "BRCA"
Pred <- lapply(1:4, function(n)
               {
                       get(load(paste0('results/',DiseaseName,'_Cancerous_all_',n,'.RData')))
               })



Pred.All <- Reduce("rbind", Pred)


Pred.mean <- apply(Pred.All,1,function(x){mean(x,na.rm=T)})

save(Pred.mean, file=paste0("results/",DiseaseName,"_Cancerous_all.RData"))

boxplot(Pred.mean)

########################################
# Concatenate chr
DiseaseName <- "BRCA"
# DiseaseName <- "Colon"
# DiseaseName <- "LUAD"

Pred <- lapply(1:4, function(n)
               {
                       get(load(paste0('results/',DiseaseName,'_Cancerous_chr_',n,'.RData')))
               })

Pred.chr <- Reduce("rbind", Pred)

Pred.mean <- apply(Pred.chr,1,function(x){mean(x,na.rm=T)})

save(Pred.mean, file=paste0("results/",DiseaseName,"_Cancerous_chr.RData"))

########################################
# Concatenate promoter once
DiseaseName <- "BRCA"
# DiseaseName <- "Colon"
# DiseaseName <- "LUAD"

Pred <- lapply(1:4, function(n)
               {
                       get(load(paste0('results/',DiseaseName,'_Cancerous_promoter_',n,'.RData')))
               })



Pred.promoter <- Reduce("rbind", Pred)
Pred.mean <- apply(Pred.promoter,1,function(x){mean(x,na.rm=T)})

save(Pred.mean, file=paste0("results/",DiseaseName,"_Cancerous_promoter.RData"))

############
DiseaseName <- "BRCA"
DiseaseName <- "LUAD"
DiseaseName <- "Colon"
if (DiseaseName == "BRCA")
{
        Pred.all <- get(load(paste0('results/',DiseaseName,'_Cancerous_all.RData')))
}

Pred.chr <- get(load(paste0('results/',DiseaseName,'_Cancerous_chr.RData')))
# Pred.Promoter <- apply(get(load(paste0('../../../big_data/GE_prediction/',DiseaseName,'_Cancerous_Promoter_table.RData')))$lasso,1,function(x){mean(x,na.rm=T)})
# Pred.AllCGIs <- apply(get(load(paste0('../../../big_data/GE_prediction/',DiseaseName,'_Cancerous_AllCGIs_table.RData')))$lasso,1,function(x){mean(x,na.rm=T)})

# Pred.Promoter <- get(load(paste0('results/',DiseaseName,'_Cancerous_promoter.RData')))

if (DiseaseName == "BRCA")
{
        Dat.Method <- data.frame(Promoter=Pred.Promoter, AllCGIs=Pred.AllCGIs, chr=Pred.chr, all_inf=Pred.all)
} else {
        Dat.Method <- data.frame(Promoter=Pred.Promoter, AllCGIs=Pred.AllCGIs, chr=Pred.chr)
}

library(reshape2)
Method.m <- melt(Dat.Method)

library(ggplot2)
if (DiseaseName =="BRCA")
{
        Method.m$variable <- factor(Method.m$variable, levels=c('Promoter','AllCGIs','chr',"all_inf"))
} else {
        Method.m$variable <- factor(Method.m$variable, levels=c('Promoter','AllCGIs','chr'))
}

pdf(paste0('plots/',DiseaseName,'_boxplot.pdf'))
ggplot(Method.m) + geom_boxplot(aes(x=variable,y=value)) + ggtitle(DiseaseName)
dev.off()

# qplot(Dat.Method$Promoter, Dat.Method$AllCGIs)
pdf(paste0('plots/',DiseaseName,'_scatterplot.pdf'))
ggplot(Dat.Method) + geom_point(aes(x=Promoter,y=chr))
dev.off()

if (DiseaseName=="BRCA")
{
        pdf(paste0('plots/',DiseaseName,'_scatterplot_all_chr.pdf'))
        ggplot(Dat.Method) + geom_point(aes(x=chr,y=all_inf))
        dev.off()
}


#wilcox.test(Dat.Method$Promoter, Dat.Method$AllCGIs)
wilcox.test(Dat.Method$Promoter, Dat.Method$chr)

########################################
# Test
DiseaseName <- "BRCA"
Pred.Promoter <- get(load(paste0('results/',DiseaseName,'_Cancerous_promoter.RData')))
Pred.chr <- get(load(paste0('results/',DiseaseName,'_Cancerous_chr.RData')))

library(ggplot2)

pdf(paste0('plots/',DiseaseName,'_promoter_chr_once.pdf'))
print(qplot(Pred.Promoter, Pred.chr) + geom_abline(a=0,b=1,col="red") + xlim(0,1) + ylim(0,1))
dev.off()

Dat <- data.frame(Promoter=Pred.Promoter, Chr=Pred.chr)
library(reshape2)
Dat.m <- melt(Dat)

pdf(paste0('plots/',DiseaseName,'boxplot_promoter_chr_once.pdf'))
print(ggplot(Dat.m) + geom_boxplot(aes(x=variable, y=value)))
dev.off()

wilcox.test(Pred.Promoter, Pred.chr, alternative="less", paired=T)




