###############################################################################
###############################################################################
####  This is the run_all for the "CpG pattern analysis" project ##############
###############################################################################
###############################################################################

setwd('~/Documents/work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R')

##### Useful parameters
DiseaseList <- c('BRCA','Colon','LUAD')

colour_scale <- c('Cluster 1' = '#225ea8',
                  'Cluster 2' = 'gold2',
                  'Cluster 3down' = '#66c2a4',
                  'Cluster 3up' = '#238b45')


###############################################################################
###### A) Analysis of average CGI+SS Patterns
###############################################################################

load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")


#A.i) Filter CGI+SS with at least 20 probes
list_big_island <- which(CpGIslands.probesize >=20)

#A.ii) Calculate mean profiles
source('fun/calculate_Mean_PC.R')
for (DiseaseName in DiseaseList)
{
        out <- calculate_Mean_PC(Disease=DiseaseName,type="Cancerous",proc=F)
        out <- calculate_Mean_PC(Disease=DiseaseName,type="Normal",proc=F)
}


#A.iii) Perform DTW on mean profiles
source('fun/calculate_distanceMatrices.R')
for (DiseaseName in DiseaseList)
{
        out <- calculate_distanceMatrices(Disease=DiseaseName,analysis="Mean",type="Cancerous")
        out <- calculate_distanceMatrices(Disease=DiseaseName,analysis="Mean",type="Normal")
}

#A.iv) Clustering of CGIs
source('fun/CGI_analysis.R')
for (DiseaseName in DiseaseList)
{
        out <- analyze_CGI_clusters(Disease=DiseaseName,cutoff=3,type="Cancerous")
        out <- analyze_CGI_clusters(Disease=DiseaseName,cutoff=2,type="Normal")
        ## Value for cutoff (i.e number of clusters is given by the hierarchical clustering)
}

#A.v) Plot Characteristic profiles
source('fun/plot_characteristic_profiles.R')
for (DiseaseName in DiseaseList)
{
        out <- plot_characteristic_profiles(Disease=DiseaseName,type="Cancerous")
        out <- plot_characteristic_profiles(Disease=DiseaseName,type="Normal")
}

#A.vi) Compare clusters between normal and tumoral
source('fun/compare_clusters.R')
for (DiseaseName in DiseaseList)
{
        compare_clusters(Disease1=DiseaseName,type1="Cancerous", analysis="Mean")
}

#A.vii) Compare clusters between Tissues
DiseaseListbis <- c(DiseaseList, DiseaseList[1])
for (k in 1:(length(DiseaseList)-1))
{
        compare_clusters(Disease1=DiseaseList[k],Disease2=DiseaseList[k+1],type1="Normal", analysis="Mean")
        compare_clusters(Disease1=DiseaseList[k],Disease2=DiseaseList[k+1],type1="Cancerous", analysis="Mean")
}

#A.viii) Link between the CGI+SS patterns and gene expression levels
source('fun/compare_GE_clusters.R')
for (DiseaseName in DiseaseList)
{
        compare_GE_clusters(DiseaseName= DiseaseName)
}

########################################################################################
###### B) Analysis of inter-individual CGI+SS variations and link with gene expression 
########################################################################################
#B.i) Predict Gene Expression variations using DNA Methylation (mean methylation or full CGI+SS information)
source("fun/predict_GE.R")
for (DiseaseName in DiseaseList)
{
        predict_GE(DiseaseName= DiseaseName, type="Cancerous", preprocessing="CGIs", MethylationAnalysis="Mean")
        predict_GE(DiseaseName= DiseaseName, type="Normal", preprocessing="CGIs", MethylationAnalysis="Mean")


        predict_GE(DiseaseName= DiseaseName, type="Cancerous", preprocessing="CGIs", MethylationAnalysis="Promoter")
        predict_GE(DiseaseName= DiseaseName, type="Normal", preprocessing="CGIs", MethylationAnalysis="Promoter")

}

#B.ii) Summarize the results
source('fun/analyze_prediction.R')
for (DiseaseName in DiseaseList)
{
        analyze_prediction(DiseaseName)
}

#B.iii) Predict Gene Expression variations using DNA Methylation + CNV
source("fun/predict_GE_CNV.R")
for (DiseaseName in DiseaseList)
{
        predict_GE_CNV(DiseaseName= DiseaseName, type="Cancerous", preprocessing="CGIs", MethylationAnalysis="Mean")
        predict_GE_CNV(DiseaseName= DiseaseName, type="Normal", preprocessing="CGIs", MethylationAnalysis="Mean")


        predict_GE_CNV(DiseaseName= DiseaseName, type="Cancerous", preprocessing="CGIs", MethylationAnalysis="Promoter")
        predict_GE_CNV(DiseaseName= DiseaseName, type="Normal", preprocessing="CGIs", MethylationAnalysis="Promoter")

}

#B.iv) Summarize the results
source('fun/analyze_prediction_CNV.R')
for (DiseaseName in DiseaseList)
{
        analyze_prediction_CNV(DiseaseName)
}

#B.v) Compare Meth+CNV to CNV prediction
source('fun/compare_prediction_CNV_noCNV.R')
for (DiseaseName in DiseaseList)
{
        compare_prediction_CNV_noCNV(DiseaseName)
}

#B.vi) Compare normal to cancerous prediction
source('fun/compare_prediction_Normal_Cancerous.R')
for (DiseaseName in DiseaseList)
{
        compare_prediction_CNV_noCNV(DiseaseName)
}

#B.vii) Compare inter-tissue prediction 
source('fun/compare_prediction_interCancer.R')
compare_prediction_interCancer()


























