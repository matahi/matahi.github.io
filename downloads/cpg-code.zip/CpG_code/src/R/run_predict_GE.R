#####################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading 
## Path Setting 
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
#setwd(PATH)
#

# Gene processed Methylation
###   load("../../data/processed/Methylation/TCGA/BRCA/CancerousGenes_processed.RData")
###   load("../../data/processed/Methylation/TCGA/BRCA/NormalGenes_processed.RData")
###   
###   # Gene Expression
###   load("../../data/processed/GeneExpression/TCGA/BRCA/CancerousLevel3GE_processed.RData")
###   load("../../data/processed/GeneExpression/TCGA/BRCA/NormalLevel3GE_processed.RData")
###   
###   # load clinicalinfo
###   load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
###   load("../../data/processed/fData/fData450K_Gene.RData") 
###   load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
load("../../data/processed/fData/GeneList.RData")
#load("../../data/processed/fData/GeneProbesList.RData")


# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox 
## load the used packages 
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos
source("fun/predict_GE.R")
source("fun/linear_model.R")

source('fun/reduce_tools.R')
source("fun/plot_tools.R")

list_big_island <-which(CpGIslands.probesize>=20)

## Analysis 
## print("Disease=BRCA, type=Cancerous")
## out <- predict_GE(DiseaseName="BRCA",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Mean")
## out <- predict_GE(DiseaseName="BRCA",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Promoter")
## out <- predict_GE(DiseaseName="BRCA",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")
## 
## print("Disease=BRCA, type=Normal")
## out <- predict_GE(DiseaseName="BRCA",type="Normal", preprocessing="CGIs",MethylationAnalysis= "Mean")
## out <- predict_GE(DiseaseName="BRCA",type="Normal", preprocessing="CGIs",MethylationAnalysis= "Promoter")
## # out <- predict_GE(DiseaseName="BRCA",type="Normal", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")

## print("Disease=LUAD, type=Cancerous")
## out <- predict_GE(DiseaseName="LUAD",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Mean")
## out <- predict_GE(DiseaseName="LUAD",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Promoter")
## out <- predict_GE(DiseaseName="LUAD",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")
## 
## print("Disease=LUAD, type=Normal")
## out <- predict_GE(DiseaseName="LUAD",type="Normal", preprocessing="CGIs",MethylationAnalysis= "Mean")
## out <- predict_GE(DiseaseName="LUAD",type="Normal", preprocessing="CGIs",MethylationAnalysis= "Promoter")
## # out <- predict_GE(DiseaseName="LUAD",type="Normal", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")

#print("Disease=Colon, type=Cancerous")
# out <- predict_GE(DiseaseName="Colon",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Mean")
# out <- predict_GE(DiseaseName="Colon",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Promoter")
#out <- predict_GE(DiseaseName="Colon",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")

## Analysis 
source("fun/predict_GE_CNV.R")

# out <- predict_GE_CNV(DiseaseName="BRCA",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Mean")
# out <- predict_GE_CNV(DiseaseName="LUAD",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Mean")
# out <- predict_GE_CNV(DiseaseName="Colon",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Mean")
# 
# out <- predict_GE_CNV(DiseaseName="BRCA",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Promoter")
# out <- predict_GE_CNV(DiseaseName="LUAD",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Promoter")
# out <- predict_GE_CNV(DiseaseName="Colon",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "Promoter")
# 
# out <- predict_GE_CNV(DiseaseName="BRCA",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")
# out <- predict_GE_CNV(DiseaseName="LUAD",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")
# out <- predict_GE_CNV(DiseaseName="Colon",type="Cancerous", preprocessing="CGIs",MethylationAnalysis= "AllCGIs")


## Analysis
source('fun/predict_ALL_once.R')

out <- predict_ALL("BRCA","Cancerous", MethylationAnalysis="all")
# out <- predict_ALL("LUAD","Cancerous", MethylationAnalysis="all")
# out <- predict_ALL("Colon","Cancerous", MethylationAnalysis="all")

# out <- predict_ALL("BRCA","Cancerous", MethylationAnalysis="chr")
# out <- predict_ALL("LUAD","Cancerous", MethylationAnalysis="chr")
# out <- predict_ALL("Colon","Cancerous", MethylationAnalysis="chr")




###### Comparing Results
## source('fun/analyze_prediction.R')
## 
## out <- analyze_prediction("BRCA")
## save(out,file="../../big_data/GE_prediction/resume_BRCA.RData")
## out <- analyze_prediction("LUAD")
## save(out,file="../../big_data/GE_prediction/resume_LUAD.RData")
## out <- analyze_prediction("Colon")
## save(out,file="../../big_data/GE_prediction/resume_Colon.RData")
## 
## source('fun/analyze_prediction_CNV.R')
## 
## out <- analyze_prediction_CNV("BRCA")
## save(out,file="../../big_data/GE_prediction/resume_BRCA_CNV.RData")
## out <- analyze_prediction_CNV("LUAD")
## save(out,file="../../big_data/GE_prediction/resume_LUAD_CNV.RData")
## out <- analyze_prediction_CNV("Colon")
## save(out,file="../../big_data/GE_prediction/resume_Colon_CNV.RData")


## source('fun/compare_prediction_CNV_noCNV.R')
## 
## out <- compare_prediction_CNV_noCNV("BRCA")
## out <- compare_prediction_CNV_noCNV("LUAD")
## out <- compare_prediction_CNV_noCNV("Colon")
## 
## out <- compare_prediction_Normal_Cancerous("BRCA")
## out <- compare_prediction_Normal_Cancerous("LUAD")
## out <- compare_prediction_Normal_Cancerous("Colon")
## 
## out <- compare_prediction_interCancer()

# R2_Normal(BRCA/LUAD) = 0.04
# R2(BRCA/LUAD) = 0.17
# R2(LUAD/Colon) = 0.07
# R2(Colon/BRCA) = 0.06

