adaptativeMean <- function(x)
{
        if (is.null(dim(x))){
                output <- x
        } else {
                output <- apply(x,1,mean)
                # output <- apply(x,1,function(k){mean(k,na.rm=T)})
        }
}

adaptativeVar <- function(x)
{
        if (is.null(dim(x))){
                output <- 0
        } else {
                output <- apply(x,1,var)
                # output <- apply(x,1,function(k){var(k,na.rm=T)})
        }
}


##  adaptativePC1 <- function (x,cp,type="normal") {
##          if (is.null(dim(x))){
##                  output <- NULL
##                  output$PC1 <- 1
##                  output$Score <- (x-mean(x))
##          } else if (nrow(x)==1)
##          {
##                  output <- NULL
##                  output$PC1 <- 1
##                  output$Score <- (x-mean(x))
##          } else if (ncol(x)<nrow(x)) {
##                  print("more rows than columns")
##                  output <- NULL
##                  output$PC <- matrix(0,nrow=nrow(x),ncol=2)
##                  output$PC[,1] <- apply(x,1,var)
##                  output$Score <- matrix(0,nrow=ncol(x),ncol=2)
##                  output$Score[,1] <- as.vector(apply(x,1,var))%*%(x-apply(x,1,mean))/norm((apply(x,1,var)),"2")^2
##          } else {
##                  output <- NULL
##                  if (type=="normal")
##                  {
##                          tmp <- princomp(t(x))
##                  } else if (type=="robust")
##                  {
##                          tmp <- PCAgrid(t(x))
##                  }
##                  output$PC <- tmp$loadings[,cp]
##                  output$Score <- tmp$scores[,cp]
##          }
##          return(output)
##  }                
##  
##  adaptativePC2 <- function (x,cp,type="normal") {
##          if (is.null(dim(x))){
##                  #print(x)
##                  output <- NULL
##                  output$PC <- matrix(0,1,2)
##                  output$PC[,1] <- var(x)
##                  output$Score <- matrix(0,length(x),2)
##                  output$Score[,1] <- (x-mean(x))/var(x)
##          } else if (nrow(x)==1)
##          {
##                  output <- NULL
##                  output$PC <- matrix(0,1,2)
##                  output$PC[,1] <- apply(x,1,var)
##                  output$Score <- matrix(0,length(x),2)
##                  output$Score[,1] <- (x-mean(x))/apply(x,1,var)
##          } else if (ncol(x)<nrow(x)) {
##                  print("more rows than columns")
##                  output <- NULL
##                  output$PC <- matrix(0,nrow=nrow(x),ncol=2)
##                  output$PC[,1] <- apply(x,1,var)
##                  output$Score <- matrix(0,nrow=ncol(x),ncol=2)
##                  output$Score[,1] <- as.vector(apply(x,1,var))%*%(x-apply(x,1,mean))/norm((apply(x,1,var)),"2")^2
##          } else {
##                  output <- NULL
##                  if (type=="normal")
##                  {
##                          tmp <- princomp(t(x))
##                  } else if (type=="robust")
##                  {
##                          tmp <- PCAgrid(t(x))
##                  }
##                  output$PC <- tmp$loadings[,cp]
##                  output$Score <- tmp$scores[,cp]
##          }
##          return(output)
##  }                

