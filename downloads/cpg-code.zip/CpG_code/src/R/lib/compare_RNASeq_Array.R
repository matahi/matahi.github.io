RNASeq <- load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData'))
RNASeq.dat <- get(RNASeq)
Genes.GE <- sapply(1:nrow(RNASeq.dat), function(n){ tmp <- strsplit(rownames(RNASeq.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 

Array <- load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseName,'/CancerousLevel3GE_processed.RData'))
Array.dat <- get(Array)

A <- intersect(Genes.GE, rownames(Array.dat))

B <- intersect(colnames(RNASeq.dat), colnames(Array.dat))


Dat1 <- RNASeq.dat[match(A, Genes.GE), B]
Dat2 <- Array.dat[A, B]


