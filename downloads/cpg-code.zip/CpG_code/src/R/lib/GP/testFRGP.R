###########################################################################################################
# 				FUNCTIONAL REGRESSION GAUSSIAN PROCESSES Shi et al.
###########################################################################################################

### Preprocessing :
# on BIWS : 
# setwd("~/Desktop/CpG/src/R")

# on Personal Laptop :
setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R")

#################
# Loading Packages
require(MASS)
require(plyr)
require(reshape2)
require(ggplot2)

# Set a seed for repeatable plots
# set.seed(12345)

################################################################################
################################################################################
# How to cluster the signals?
# clustering of functional data analysis?
#  subset.dataframe <- example.dataframe[example.dataframe[,"sample_num"]%in% (5:10),]

######## EXAMPLE 1
################################################################################
# Generate an example
Generate_Example <- function(x=runif(100,min=-1,max=1),mode_num=1,sample_num=1,sigma0=0.1){
	if (mode_num==1){
		example.dataframe <- data.frame(x=x[order(x)],y=sin(2*pi*x[order(x)])+rnorm(1,0,sigma0),sample_num=sample_num,mode_num=mode_num)
	} else if (mode_num==2){
                #                 example.dataframe <- data.frame(x=x[order(x)],y=atan(2*pi*x[order(x)])+rnorm(1,0,sigma0),sample_num=sample_num,mode_num=mode_num)}
                example.dataframe <- data.frame(x=x[order(x)],y=sin(5*2*pi*x[order(x)])+rnorm(1,0,sigma0),sample_num=sample_num,mode_num=mode_num)}
	return(example.dataframe)
}

# Create example : 30 samples for each mode
example.dataframe <- NULL
for (k in 1:30){
	example.dataframe <- rbind(example.dataframe,Generate_Example(mode_num=1,sample_num=k))
}
for (k in 31:60){
	example.dataframe <- rbind(example.dataframe,Generate_Example(mode_num=2,sample_num=k))
}

# Plotting examples
#p <- ggplot(example.dataframe[example.dataframe[,"sample_num"]%in% (5:10),])+ geom_point(aes(x=x,y=y,color=factor(sample_num)))
p <- ggplot(example.dataframe) + geom_point(aes(x=x,y=y,color=factor(sample_num)))+ geom_line(aes(x=x,y=y,color=factor(mode_num)))


pdf("../../results/Toy/example1/data.pdf", width=10, height=10, pointsize=10)
p +xlim(-1,1) + theme(legend.position="none")
dev.off()

################################################################################
subset.dataframe <- example.dataframe[example.dataframe[,"sample_num"]%in% (5:10),]

# 1)Apply splines
spline.dataframe <- NULL
for (k in 5:10){
spline.dataframe <- rbind(spline.dataframe,data.frame(spline.x=spline(example.dataframe[example.dataframe[,"sample_num"]==k,c("x","y")])$x,spline.y=spline(example.dataframe[example.dataframe[,"sample_num"]==k,c("x","y")])$y,sample_num=k))
}

p <- ggplot(subset.dataframe)+ geom_point(aes(x=x,y=y,color=factor(sample_num)))+ geom_line(data=spline.dataframe,aes(x=spline.x,y=spline.y,color=factor(sample_num)))

pdf("../../results/Toy/example1/1_spline_test.pdf", width=10, height=10, pointsize=10)
p
dev.off()

## One idea would be to use the function splinefun and compare the functions either by mapping the points (or just using spline) and look at distance then use regular clustering methods
#ggplot(data.frame(x=c(-1, 1)), aes(x)) + stat_function(fun=tata)

################################################################################
# 2) Use stat_smooth
# Use loess
p <- ggplot(subset.dataframe,aes(x,y,colour=factor(sample_num)))+stat_smooth()+geom_point()

pdf("../../results/Toy/example1/2_loess.pdf", width=10, height=10, pointsize=10)
p
dev.off()

# Curves look the same but don't seem to match the original data

################################################################################
################################################################################
# Conclusion : Spline seems to work correctly if the data have the same mode (although we still have to compare 2 splines
# Let's perturbate the function by changing the periodicity for example
################################################################################
################################################################################

######## EXAMPLE 2

Generate_Example_modified <- function(x=runif(100,min=-1,max=1),mode_num=1,sample_num=1,sigma0=0.1){
	if (mode_num==1){
		example.dataframe <- data.frame(x=x[order(x)],y=sin(runif(1,0,10)*x[order(x)])+rnorm(1,0,sigma0),sample_num=sample_num,mode_num=mode_num)
	} else if (mode_num==2){
		example.dataframe <- data.frame(x=x[order(x)],y=atan(runif(1,0,10)*x[order(x)])+rnorm(1,0,sigma0),sample_num=sample_num,mode_num=mode_num)}
	return(example.dataframe)
}

# Create modified example : 30 samples for each mode
example_modified.dataframe <- NULL
for (k in 1:30){
	example_modified.dataframe <- rbind(example_modified.dataframe,Generate_Example_modified(mode_num=1,sample_num=k))
}
for (k in 31:60){
	example_modified.dataframe <- rbind(example_modified.dataframe,Generate_Example_modified(mode_num=2,sample_num=k))
}

p <- ggplot(example_modified.dataframe)+ geom_point(aes(x=x,y=y,color=factor(sample_num)))

pdf("../../results/Toy/example2/data.pdf", width=10, height=10, pointsize=10)
p +xlim(-1,1) + theme(legend.position="none")
dev.off()

subset_modified.dataframe <- example_modified.dataframe[example_modified.dataframe[,"sample_num"]%in% (5:10),]
################################################################################
subset_modified.dataframe <- example_modified.dataframe[example_modified.dataframe[,"sample_num"]%in% (5:10),]

# 1)Apply splines
spline_modified.dataframe <- NULL
for (k in 5:10){
spline_modified.dataframe <- rbind(spline_modified.dataframe,data.frame(spline.x=spline(example_modified.dataframe[example_modified.dataframe[,"sample_num"]==k,c("x","y")])$x,spline.y=spline(example_modified.dataframe[example_modified.dataframe[,"sample_num"]==k,c("x","y")])$y,sample_num=k))
}

p <- ggplot(subset_modified.dataframe)+ geom_point(aes(x=x,y=y,color=factor(sample_num)))+ geom_line(data=spline_modified.dataframe,aes(x=spline.x,y=spline.y,color=factor(sample_num)))

pdf("../../results/Toy/example2/1_spline_test.pdf", width=10, height=10, pointsize=10)
p
dev.off()

## One idea would be to use the function splinefun and compare the functions either by mapping the points (or just using spline) and look at distance then use regular clustering methods
#ggplot(data.frame(x=c(-1, 1)), aes(x)) + stat_function(fun=tata)

################################################################################
# 2) Use stat_smooth
# Use loess
p <- ggplot(subset_modified.dataframe,aes(x,y,colour=factor(sample_num)))+stat_smooth()+geom_point()
pdf("../../results/Toy/example2/2_loess.pdf", width=10, height=10, pointsize=10)
p
dev.off()


