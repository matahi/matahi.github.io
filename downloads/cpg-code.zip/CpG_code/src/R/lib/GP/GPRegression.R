GPRegression <- function(Dat,l){
        Borders <- c(min(Dat$location),max(Dat$location))
        mapped.positions <- sort(unique(Dat$location))
        x.star <- seq(Borders[1],Borders[2],len=50)

        sigma <- calcSigma(x.star,x.star,l=200)

        n.samples <- length(unique(Dat$patient))
        values <- matrix(0, nrow= length(mapped.positions), ncol= n.samples)

        for (i in 1:n.samples){
                values[,i] <- Dat[Dat$patient==unique(Dat$patient)[i],"betas"]
        }

        values.only <- values
        values <- cbind(x=mapped.positions,as.data.frame(values))
        values <- melt(values,id="x")

        ### Idea : lets say known points are those with very weak variability

        values.var <- apply(values.only,1,var)
        plot(mapped.positions,values.var)

        known.points <- (values.var<=0.005)
        x.star.known <- x.star[known.points]
        y.known <- apply(values.only[known.points,],1,mean)

        f <- data.frame(x=x.star.known, y=y.known)

        x <- f$x
        k.xx <- calcSigma(x,x,l=sd(x.star))
        k.xxs <- calcSigma(x,x.star, l=sd(x.star))
        k.xsx <- calcSigma(x.star,x, l=sd(x.star))
        k.xsxs <- calcSigma(x.star,x.star, l=sd(x.star))

        ##
        k.xx <- calcSigma(x,x,l=200)
        k.xxs <- calcSigma(x,x.star,l=200)
        k.xsx <- calcSigma(x.star,x,l=200)
        k.xsxs <- calcSigma(x.star,x.star,l=200)
        ##

        f.star.bar <- k.xsx%*%solve(k.xx)%*%f$y
        cov.f.star <- k.xsxs - k.xsx%*%solve(k.xx)%*%k.xxs

        fig2b <- ggplot(values,aes(x=x,y=value)) +
        geom_line(aes(group=variable), colour="grey80") +
        geom_line(data=NULL,aes(x=x.star,y=f.star.bar),colour="red", size=1) +
        geom_point(data=f,aes(x=x,y=y)) 

        fig2b

        # 3. Now assume that each of the observed data points have some
        # normally-distributed noise.

        # The standard deviation of the noise
        sigma.n <- 0.01

        # Recalculate the mean and covariance functions
        f.bar.star <- k.xsx%*%solve(k.xx + sigma.n^2*diag(1, ncol(k.xx)))%*%f$y
        cov.f.star <- k.xsxs - k.xsx%*%solve(k.xx + sigma.n^2*diag(1, ncol(k.xx)))%*%k.xxs

        # Recalulate the sample functions
        values <- matrix(rep(0,length(x.star)*n.samples), ncol=n.samples)
        for (i in 1:n.samples) {
                values[,i] <- mvrnorm(1, f.bar.star, cov.f.star)
        }
        values <- cbind(x=x.star,as.data.frame(values))
        values <- melt(values,id="x")

        # Plot the result, including error bars on the observed points
        gg <- ggplot(values, aes(x=x,y=value)) + 
        geom_line(aes(group=variable), colour="grey80") +
        geom_line(data=NULL,aes(x=x.star,y=f.bar.star),colour="red", size=1) + 
        geom_errorbar(data=f,aes(x=x,y=NULL,ymin=y-2*sigma.n, ymax=y+2*sigma.n), width=0.2) +
        geom_point(data=f,aes(x=x,y=y)) 
        gg
}
