# Data Loading {{{1
## Path Setting {{{2

setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop

require(MASS)
require(plyr)
require(reshape2)
require(ggplot2)

## Data Loading {{{2
# load("../../data/processed/Methylation/TCGA/BRCA/Cancerous.RData")
load("../../data/processed/Methylation/TCGA/BRCA/CGIs5.RData") # only the first 5 samples (for RAM issue)

# function {{{1
calcSigma <- function(X1,X2,l=1) {
        Sigma <- matrix(rep(0, length(X1)*length(X2)), nrow=length(X1))
        for (i in 1:nrow(Sigma)) {
                for (j in 1:ncol(Sigma)) {
                        Sigma[i,j] <- exp(-0.5*(abs(X1[i]-X2[j])/l)^2)
                }
        }
        return(Sigma)
}

# Processing {{{1
Sample <- 2

Dat <- CGIs[[Sample]]
#plot
source("fun/plot_loess_spline.R")
plot_loess_spline(Dat)

#
quartz()
source("lib/GP/GPRegression.R")
GPRegression(Dat,l=200)

## What we really want to do : Mixture model of modes
k <- 5 # Number of modes


