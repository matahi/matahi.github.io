#data(Hg19cytoband, package='CGHpack')
require(GenomicRanges)

Hg19cytoband <- read.csv("../../data/raw/fData/cytoBand_hg19.txt",sep="\t", header=F,colClasses=c('character','numeric','numeric','character','character'))
colnames(Hg19cytoband) <- c('chr','start','end','band','stain')

hg19 <- GRanges(
                seqnames= Rle(Hg19cytoband$chr),
                ranges= IRanges(start=Hg19cytoband$start, end=Hg19cytoband$end),
                name = Hg19cytoband$band,
                gieStain = Hg19cytoband$stain
                )

hg19 <- keepSeqlevels(hg19, paste0("chr", c(1:22,"X","Y")))
hg19 <- hg19[!(seqnames(hg19) == "chrY"),] # No ChrY for women

save(hg19, file="../../data/processed/fData/hg19.RData")

