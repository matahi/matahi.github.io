######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Preprocessing {{{1
## Path Setting {{{2
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R")
setwd("~/Desktop/CpG/src/R")

## Library Loading {{{2
library(ggbio)
library(GenomicRanges)

## Data Loading {{{2
load("../../data/fData450Knew.RData")
data(hg19IdeogramCyto, package="biovizBase")
hg19 <- keepSeqlevels(hg19IdeogramCyto, paste0("chr", c(1:22,"X","Y")))

### Processing {{{1
IndexCG <- grep("cg",rownames(fData45OK))
filterCG <- 1:nrow(fData450K) %in% IndexCG
fData450K.onlyCG <- fData450K[filterCG,]
fData450K.notCG <- fData450K[!filterCG,]
# nrow(fData450K.onlyCG) = 482421

Strand <- fData450K.onlyCG$Strand
Strand[Strand=="F"] <- "+"
Strand[Strand=="R"] <- "-"

fData450K.onlyCG.GRanges <-  GRanges(
                              seqnames=Rle(paste("chr",fData450K.onlyCG$CHR,sep="")),
                              ranges= IRanges(start=fData450K.onlyCG$MAPINFO, end=fData450K.onlyCG$MAPINFO, names=rownames(fData450K.onlyCG)),
                              strand= Rle(strand(Strand)),
                              island=fData450K.onlyCG$UCSC_CpG_Islands_Name,
                              relationIsland=fData450K.onlyCG$Relation_to_UCSC_CpG_Island,
                              gene=fData450K.onlyCG$UCSC_RefGene_Name
                              )

# Remark :  we see nothing because we have too many probes
# Plotting all the probes (red for strand, blue for anti)
p <- ggplot(hg19) + layout_karyogram(cytoband = TRUE)
p + layout_karyogram(fData450K.onlyCG.GRanges[strand(fData450K.onlyCG.GRanges)=="+",], geom="rect", ylim=c(11,21), color="red") + layout_karyogram(fData450K.onlyCG.GRanges[strand(fData450K.onlyCG.GRanges)=="-",], geom="rect", ylim=-c(0,11), color="blue")

# Plotting all the CGI probes (red for strand, blue for anti)
p <- ggplot(hg19) + layout_karyogram(cytoband = TRUE)
p + layout_karyogram(fData450K.onlyCG.GRanges.island, geom="rect", ylim=c(11,21), color="red")

# Plotting all the non CGI probes (red for strand, blue for anti)
p <- ggplot(hg19) + layout_karyogram(cytoband = TRUE)
p + layout_karyogram(fData450K.onlyCG.GRanges[fData450K.onlyCG.GRanges$gene=="",], geom="rect", ylim=c(11,21), color="red") #+ layout_karyogram(fData450K.onlyCG.GRanges[strand(fData450K.onlyCG.GRanges)=="-",], geom="rect", ylim=-c(0,11), color="blue")



