######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
# setwd("~/Documents/Work/PhD/Thesis/Projects/methylation/Human450K/CpG/src/R") # for own laptop
setwd("~/Desktop/CpG/src/R") # for Curie Machines
#args <- commandArgs(TRUE); PATH = args[1]
#setwd(PATH)

# Gene processed Methylation
###   load("../../data/processed/Methylation/TCGA/BRCA/CancerousGenes_processed.RData")
###   load("../../data/processed/Methylation/TCGA/BRCA/NormalGenes_processed.RData")
###   
###   # Gene Expression
# load("../../data/processed/GeneExpression/TCGA/BRCA/CancerousLevel3GE_processed.RData")
# load("../../data/processed/GeneExpression/TCGA/BRCA/NormalLevel3GE_processed.RData")
###   
###   # load clinicalinfo
###   load("../../data/processed/ClinicalAnnotations/TCGA/BRCA.Clinical.cancerous.RData")

# load featureData
###   load("../../data/processed/fData/fData450K_Gene.RData") 
load("../../data/processed/fData/fData450K_ordered.RData") 

# load Genes
# load CpGIslands
load("../../data/processed/fData/CpGIslands.RData")
load("../../data/processed/fData/CpGIslands_size.RData")
load("../../data/processed/fData/CpGIslands_probe_size.RData")

### Toolbox {{{1
## load the used packages {{{2
require('ggplot2')
# require('limma')
require('heatmap.plus') ## see for EMA
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
# require('CGHpack')
require('reshape2') #for Melt for data.frame
# require('gptk') #Gaussian Processes Tool-kit
require('gridExtra') # for plotting several ggplots -> grid.arrange
require('FactoMineR') # for easy PCA

## Useful functions{{{2
#function var.na
var.na <- function(x){var(x, na.rm=TRUE)}

source('lib/toolkit/multiplot.R') # multiplot function
source("fun/plot_gene_list.R") # plot_gene function
# source("fun/plot_gene_normal_vs_cancerous.R") # plot_gene function
source("fun/plot_island.R")# plot_island function
source("fun/analyze_CpG_Islands.R") # analyze_CpG_Islands
source("fun/analyze_CpG_distance.R")# analyze_CpG_distance
source("fun/find_BRCAtype.R") # extract BRCAtypes from clinicalInfos
source("fun/compare_GE_Methylation.R")

## Analysis {{{1

TSS_regions <- read.csv('../../data/raw/TSS/UCSC.txt',header=T, sep="\t",row.names=1)
Assoc_UCSC_Symbol <- read.csv('../../data/raw/TSS/Association_UCSC_Symbol.txt', header=T, sep="\t", row.names=1)
#TSS_regions <- TSS_regions[TSS_regions$chrom %in% c(paste0('chr',1:22),'chrX','chrY'),1:4 ]
TSS_regions$chrom <- sapply(as.character(TSS_regions$chrom),function(x){substring(x,4,nchar(x))})
TSS_regions <- data.frame(TSS_regions, geneSymbol=Assoc_UCSC_Symbol[rownames(TSS_regions),1])

CommonGenes <- intersect(rownames(BRCA.CancerousGE), TSS_regions$geneSymbol)

TSS_Common <- TSS_regions[match(CommonGenes, TSS_regions$geneSymbol), ]

####   Margins <- c(100,200,300,400,500,1000,2000,3000,5000)

####   for (Margin in Margins)
####   {
####           print(Margin)
####           Assoc.MethGenes <- lapply(1:nrow(TSS_Common), function(n){
####                                     #Gene <- TSS_Common$geneSymbol[n]
####                                     Good_Chr <- fData450K$CHR== TSS_Common$chrom[n]
####                                     Good_Region <- (fData450K$MAPINFO > TSS_Common$txStart[n] - Margin) & (fData450K$MAPINFO < TSS_Common$txEnd[n] + Margin)
####                                     GoodProbes <- which(Good_Region & Good_Chr)
####           })
####   
####           names(Assoc.MethGenes) <- TSS_Common$geneSymbol
####   
####   
####           save(Assoc.MethGenes, file=paste0("../../data/processed/fData/AssocMethGenes",Margin,".RData"))
####   }


