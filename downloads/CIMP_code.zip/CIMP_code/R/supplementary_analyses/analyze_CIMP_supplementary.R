analyze_CIMP_supplementary = function (DiseaseList, Interesting.MethGenes) {
        Interesting.MethGenes <- c('MLH1', 'IDH1', 'BRAF', 'TET2')
        Full.CommonGenes <- get(load('../../big_data/Tools/FullCommonGenes.RData'))
        Pos <- match(Interesting.MethGenes, Full.CommonGenes) 
        Full.PromoterAssoc <- get(load('../../big_data/Tools/FullPromoterAssoc.RData'))

        Meth.DiseaseList <- lapply(1:length(DiseaseList), function(k)
                                   {
                                           Dat.CGIs <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseList[k],'/',"CancerousCGIs.RData")))[Full.PromoterAssoc[Pos]]
                                           Mean.CGI <- sapply(1:length(Dat.CGIs), function(n)
                                                              {
                                                                      return(apply(Dat.CGIs[[n]],2,function(x){mean(x,na.rm=T)}))
                                                              })

                                           colnames(Mean.CGI) <- Interesting.MethGenes

                                           return(Mean.CGI)
                                   })

        Meth.Info <- Reduce('rbind',Meth.DiseaseList)
        DiseaseLength <- sapply(Meth.DiseaseList,nrow)

        colnames(Meth.Info) <- Interesting.MethGenes
        library(reshape2)

        Meth.m <- melt(Meth.Info)

        Disease.Info <- rep(DiseaseList,DiseaseLength)

        ##### CIMP.Info
        CIMP.DiseaseList <- lapply(1:length(DiseaseList),
                                   function(k)
                                   {
                                           clusters.CIMP <- get(load(paste0('../../big_data/CGIs/',DiseaseList[k],'_CIMP_',CIMP.Number,'.RData')))
                                   })

        clusters.CIMP <- Reduce('c',CIMP.DiseaseList)

        Meth.dataframe <- data.frame(Patient= Meth.m$Var1, Gene= Meth.m$Var2, Methylation=Meth.m$value, Disease=Disease.Info,CIMP=clusters.CIMP)

        library(ggplot2)
        pdf(paste0('../../results/1_InterCancer/InterestingGenes_CIMP_',CIMP.Number,'.pdf'))
        print(ggplot(Meth.dataframe) + geom_boxplot(aes(x=Gene,y=Methylation, fill=factor(CIMP) ) ) + facet_wrap(~ Disease))
        dev.off()


}
