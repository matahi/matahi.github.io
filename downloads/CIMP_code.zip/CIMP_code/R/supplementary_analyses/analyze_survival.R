analyze_survival = function (DiseaseList, CIMP.Number=2, var.thresh=5) {

        Pval.cens <- sapply(1:length(DiseaseList), function(k)
                            {
                                    tmp <- get(load(paste0('../../big_data/Survival/',DiseaseList[k],'_CIMP_',CIMP.Number,'_Var_',var.thresh,'.RData')))
                                    return(tmp$Pval.cens)
                            })
        names(Pval.cens) <- DiseaseList

        Pval <- sapply(1:length(DiseaseList), function(k)
                            {
                                    tmp <- get(load(paste0('../../big_data/Survival/',DiseaseList[k],'_CIMP_',CIMP.Number,'_Var_',var.thresh,'.RData')))
                                    return(tmp$Pval)
                            })
        names(Pval) <- DiseaseList


        source('lib/combinedPVal.R')
        Fisher.test(Pval.cens)
        Stouffer.test(Pval.cens)

        Fisher.test(Pval)
        Stouffer.test(Pval)

}
