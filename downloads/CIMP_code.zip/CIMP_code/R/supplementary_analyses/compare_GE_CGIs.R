compare_GE_CGIs <- function(DiseaseName,type,MethylationAnalysis='mean',Clinical=F,big_island=T)
{
        ## Preprocessing {{{1
        Meth <- load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/',type,'CGIs_processed.RData'))
        GE <- load(paste0('../../data/processed/GeneExpression/RNASeq/TCGA/',DiseaseName,'/',type,'Level3GE_processed.RData'))
        Meth.dat <- get(Meth)
        GE.dat <- get(GE)

        # load clinicalinfo
        if (Clinical) {
                #ClinicalInfo <- load(paste0("../../data/processed/ClinicalAnnotations/TCGA/",DiseaseName,".Clinical.",type,".RData"))
                #Clinical.dat <- get(ClinicalInfo)
                Clinical.dat <- eval(parse(text=paste0(DiseaseName,'.Clinical')))
        }

        if (big_island) {
                list_big_island <- which(CpGIslands.probesize >=20)
                Meth.dat <- Meth.dat[list_big_island]
                fData.big_island <- fData_CGI[list_big_island]
                Genes.big_island <- unique(Reduce('c',lapply(1:length(fData.big_island),function(n){ Reduce('c', strsplit(fData.big_island[[n]][,"UCSC_RefGene_Name"],";"))})))
                #Assoc.islandGenes <- lapply(1:length(Genes.big_island),
                #                            function(n)
                #                            {
                #                                    print(paste0(n,'/',length(Genes.big_island)))
                #                                    return( which(sapply(1:length(fData.big_island), function(k){ any(grepl(paste0('^',Genes.big_island[n],'$','|', # Contains only the genename
                #                                                                                                                   '^',Genes.big_island[n],';','|', # is of the form 'Genes.big_island[n];...'
                #                                                                                                                   ';',Genes.big_island[n],';','|', # is of the form '...;Genes.big_island[n];...'
                #                                                                                                                   ';',Genes.big_island[n],'$'),    # is of the form '...;Genes.big_island[n]'
                #                                                                                                            fData.big_island[[k]][,"UCSC_RefGene_Name"]))})))
                #                            })
                #names(Assoc.islandGenes) <- Genes.big_island
                #save(Assoc.islandGenes,file="../../big_data/AssocIslandGenes.RData")
                load("../../big_data/CGIs/AssocIslandGenes.RData")

                Assoc.info <- lapply(1:length(Assoc.islandGenes),
                                     function(n)
                                     {
                                             return( which(sapply(1:length(Assoc.islandGenes[[n]]) , function(k){ any(grepl('TSS', fData.big_island[[ Assoc.islandGenes[[n]][k] ]][,"UCSC_RefGene_Group"]))})))
                                     })

                #table(sapply(Assoc.info,length))
                ## Some Genes don't have CGIs in their TSS
        }

        Genes.GE <- sapply(1:nrow(GE.dat), function(n){ tmp <- strsplit(rownames(GE.dat)[n],"\\|"); return(tmp[[1]][1])     } ) 

        # required packages
        require('ggplot2')
        require('reshape2') #for Melt for data.frame
        require('gridExtra') # for plotting several ggplots -> grid.arrange
        require('ggbio')

        ### Statistical Analysis {{{1
        ## Preprocessing of Methylation {{{2
        if (MethylationAnalysis=="mean") { # {{{3 mean
                print('preprocessing Methylation data : using mean...')
                adaptativeMean <- function(x)
                {
                        if (is.null(dim(x))){
                                output <- x
                        } else {
                                output <- apply(x,2,mean)
                        }
                }
                Meth.Value <- lapply(Meth.dat,adaptativeMean)
                Meth.df <- Reduce('rbind',Meth.Value)
                rownames(Meth.df) <- names(Meth.dat)

                CommonGenes <- intersect(Genes.GE, Genes.big_island)

                ######
                GE.dat <- GE.dat[match(CommonGenes,Genes.GE),]

                ### Different methods for association of CGIs and Genes
                # Here we just take one of them (the first one)
                Meth.New <- Reduce('rbind', lapply(1:length(CommonGenes), function(n) { return( Meth.df[Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1],]  ) }))

                # Let's take one related to the TSS (problem: some Genes don't have CGIs in the TSS region)

                save(GE.dat,file="~/Desktop/GE.RData")
                save(Meth.New,file="~/Desktop/Meth.RData")

                corr <- sapply(1:nrow(Meth.New), function(n){cor(Meth.New[n,],GE.dat[n,])})
                save(corr,file="~/Desktop/corr.RData")

                pdf('~/Desktop/corr.pdf')
                plot(corr)
                abline(a=0, b=0,col="red")
                dev.off()

        } else if (MethylationAnalysis=="all") {

                print('preprocessing Methylation data : using all...')

                CommonGenes <- intersect(Genes.GE, Genes.big_island)

                ######
                GE.dat <- GE.dat[match(CommonGenes,Genes.GE),]
                Meth.New <- lapply(1:length(CommonGenes), function(n) { return( Meth.dat[[Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1]]]  ) })
                Meth.Names <- sapply(1:length(CommonGenes), function(n) { return( names(Meth.dat)[Assoc.islandGenes[[match(CommonGenes[n], names(Assoc.islandGenes))]][1]]  ) })

                ### Different methods for association of CGIs and Genes
                # Here we just take one of them (the first one)

                # Let's take one related to the TSS (problem: some Genes don't have CGIs in the TSS region)

                save(GE.dat,file="~/Desktop/GE.RData")
                save(Meth.New,file="~/Desktop/Meth.RData")

                ###  corr_all <- lapply(1:length(Meth.New), function(n){sapply(1:nrow(Meth.New[[n]]),function(k){cor(Meth.New[[n]][k,],GE.dat[n,])}) })
                ###  names(corr_all) <- Meth.Names
                ###  position <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"MAPINFO"]   })
                ###  CGIs <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"UCSC_CpG_Islands_Name"]   })
                ###  IslandBegin <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"IslandBegin"]   })
                ###  IslandEnd <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"IslandEnd"]   })

                corr_all <- lapply(1:length(Meth.New), function(n){sapply(1:nrow(Meth.New[[n]]),function(k){cor(Meth.New[[n]][k,],GE.dat[n,])}) })
                #Gene <- lapply(1:length(Meth.New), function(n){sapply(1:nrow(Meth.New[[n]]), function(k){Genes.GE[match(CommonGenes,Genes.GE)][n]})})
                Gene <- lapply(1:length(Meth.New), function(n){rep( Genes.GE[match(CommonGenes,Genes.GE)][n], nrow(Meth.New[[n]]))})
                position <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"MAPINFO"]   })
                CGIs <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"UCSC_CpG_Islands_Name"]   })
                IslandBegin <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"IslandBegin"]   })
                IslandEnd <- lapply(1:length(Meth.New), function(n){fData.big_island[[Meth.Names[n]]][,"IslandEnd"]   })

                corr.df <- data.frame(correlation=Reduce('c',corr_all), 
                                      position= Reduce('c',position), 
                                      Gene= Reduce('c',Gene),
                                      CGIs= Reduce('c',CGIs), 
                                      IslandBegin= Reduce('c', IslandBegin),
                                      IslandEnd= Reduce('c',IslandEnd)
                                      ) 

                save(corr_all,file="../../big_data/CGIs/BRCA_corr_all.RData")
                save(corr.df,file="../../big_data/CGIs/BRCA_corr_df.RData")

                ##  pdf('~/Desktop/corr_all.pdf')
                ##  ggplot(corr.df) + geom_line(aes(x=position, y=correlation)) + geom_hline(yintercept=0, colour="red") + geom_vline(aes(xintercept=IslandBegin), colour="black", linetype="longdash") + geom_vline(aes(xintercept=IslandEnd), colour="black", linetype="longdash") + facet_wrap( ~CGIs, scales="free") + ylim(-1,1)
                ##  dev.off()


        }

        ## Comparison of Gene Expression and Methylation {{{2
        #load('../../data/processed/fData/Associaton_Genes_CGIs.RData')
        #load('../../data/processed/fData/CommonGenes.RData')


        ### save(Meth.df,file="~/Desktop/Meth.RData")
        ### save(tata,file="~/Desktop/GE.RData")
        ### save(X,file="~/Desktop/X.RData")

        ## Look at correlation matrix

        #i <- 2
        #Gene <- CommonGenes[i]
        #pdf(paste0('~/Desktop/Test',i,'.pdf'))
        ##scatterplot(Meth.df.unique[Gene,],GE.dat[Gene,Reordering]) ## Using ggplot
        #plot(Meth.df.unique[Gene,],GE.dat[Gene,Reordering]) ## Using ggplot
        #dev.off()

}
