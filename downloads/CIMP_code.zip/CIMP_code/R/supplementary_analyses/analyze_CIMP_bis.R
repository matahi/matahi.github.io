analyze_CIMP_bis  = function (DiseaseList,CIMP.Number = 3) {

        ##################
        ## Intersection of CIMPs
        ##################
        # All.CGIs <- paste0('CGI',1:1827)
        Clusters.DiseaseList <- lapply(1:length(DiseaseList), function(k)
                                       {
                                               Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseList[k],'_Cancerous_ClustersMean.RData')))
                                               Cluster3 <- as.numeric(Clusters.Meth==3)
                                       })
        names(Clusters.DiseaseList) <- DiseaseList

        CIMP.Info <- Reduce('cbind', Clusters.DiseaseList)
        colnames(CIMP.Info) <- DiseaseList
        save(CIMP.Info, file="../../big_data/CGIs/CIMP_Info.RData")

        #### Finish !!!
        ## CIMP.Intersection <- 

        # CGI.Signature <- apply(tata,1,all)
        # table(CGI.Signature)
        ## False = 1740
        ## True = 87

        CGI.Number <- apply(CIMP.Info,1,sum)
        Disease.Number <- apply(CIMP.Info,2,sum)

        Index1 <- order(CGI.Number)
        Index2 <- order(Disease.Number)

        pdf('../../results/clust3/1_InterCancer/CIMPSignatures.pdf')
        heatmap.2(t(CIMP.Info[rev(Index1),Index2]), Rowv=NULL, Colv=NULL, dendrogram="none", trace="none") 
        dev.off()

        list_big_island <-which(CpGIslands.probesize>=20)

        ##### Methylation Behaviour
        Intersection <- (CGI.Number==ncol(CIMP.Info))
        CGI.Intersection <- lapply(1:length(DiseaseList), function(k)
                                      {
                                              print(k)
                                              # Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseName,'_Cancerous_ClustersMean.RData')))
                                              Meth.filter <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseList[k],'/CancerousCGIs.RData')))[list_big_island][Intersection]

                                              # Meth.filter <- Meth.Dat[index]
                                              CGI.Sum.Methylation <- sapply(1:length(Meth.filter), function(n)
                                                                            {
                                                                                    return(apply(Meth.filter[[n]],2,function(x){mean(x,na.rm=T)}))
                                                                            })

                                              return(CGI.Sum.Methylation)
                                      })

        save(CGI.Intersection, file="../../big_data/CGIs/CGISumMethylation_Intersection_CIMP.RData")

        Dat <- Reduce('rbind',CGI.Intersection)
        source('lib/heatmap.3.R')
        require('RColorBrewer')
        colmap <- colorRampPalette(c('blue','black','yellow'))(100)

        ###
        Disease.Col <- rep(DiseaseList, sapply(CGI.Intersection,nrow))
        source('lib/gg_color_hue.R')
        Col.Disease <- gg_color_hue(length(DiseaseList))
        names(Col.Disease) <- DiseaseList

        library(plyr)
        Disease.Col <- revalue(Disease.Col, Col.Disease)
        
        ###
        clusters.CIMP <- lapply(1:length(DiseaseList), function(k)
                                {
                                        Dat <- get(load(paste0('../../big_data/CGIs/',DiseaseList[k],'_CIMP_',CIMP.Number,'.RData')))
                                })

        CIMP.Col <-  as.character(Reduce('c', clusters.CIMP))
        Col.CIMP <- gg_color_hue(length(unique(CIMP.Col)))
        names(Col.CIMP) <- unique(CIMP.Col)

        CIMP.Col <- revalue(CIMP.Col, Col.CIMP)
        ####

        ColSideColors <- rbind(Disease.Col, CIMP.Col)

        ###
        ###

        pdf(paste0('../../results/1_InterCancer/CIMP_InterCancer_',CIMP.Number,'.pdf'))
        p <- heatmap.3(t(Dat),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="col", trace="none",col=colmap,  Key="Methylation", ColSideColors=t(ColSideColors), labRow=NA,labCol=NA,)
        legend('bottomleft', fill = Col.Disease, legend=DiseaseList)
        dev.off()

}
