analyze_CIMP_probes  = function (DiseaseName,clust,CIMP.Number = 3, topProbes = 200) {

        # DiseaseName <- "BRCA"
        # CIMP.Number <- 3

        DiseaseName <- "STAD"

        Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousLevel2.RData')))

        Var <- apply(Meth.Dat,1,var)
        Meth.Var <- Meth.Dat[ Var > quantile(Var,1 - topProbes/nrow(Meth.Dat)), ]

        source('lib/heatmap.3.R')
        require('RColorBrewer')
        colmap <- colorRampPalette(c('blue','black','yellow'))(100)

        pdf(paste0('../../results/CIMP/',DiseaseFolder[DiseaseName], '/heatmap_Probes',topProbes,'.pdf'))
        p <- heatmap.3(t(Meth.Var),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="both", trace="none",col=colmap,  Key="Methylation",labRow=NA,labCol=NA)
        dev.off()

}
