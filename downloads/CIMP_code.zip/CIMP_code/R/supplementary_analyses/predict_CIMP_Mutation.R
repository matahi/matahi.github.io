predict_CIMP_Mutation = function (DiseaseName, var.thresh, CIMP.Number=2) {

        library(spams, lib.loc="~/Desktop/Pkg")

        Dat.CIMP <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseName,'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
        Dat.Mutation <- get(load(paste0('../../data/processed/Mutation/TCGA/',DiseaseName,'/Cancerous.RData')))

        names_Meth <- substring(names(Dat.CIMP),1,12)
        names_Mutation <- substring(colnames(Dat.Mutation),1,12)

        common_names <- intersect(names_Meth,names_Mutation)

        CIMP.processed <- matrix(Dat.CIMP[match(common_names,names_Meth)],ncol=1)
        CIMP.processed[CIMP.processed==2] <- -1
        Mutation.processed <- Dat.Mutation[, match(common_names,names_Mutation)]
        W0 <- matrix(0, nrow=nrow(Mutation.processed), ncol=1)

        #######
        lambda_grid <- 10^(-5:5)
        Acc <- rep(0,length(lambda_grid))
        w_train <- vector('list',length(lambda_grid))
        for (n in 1:length(lambda_grid))
        {
                print(n)
                y_train <- CIMP.processed[1:25,,drop=FALSE]
                x_train <- Mutation.processed[,1:25,drop=FALSE]

                w_train[[n]] <- spams.fistaFlat(y_train, t(x_train), W0 = W0, loss="logistic", regul="l1", lambda1=lambda_grid[n]  )

                # w_group <- spams.fistaFlat(y_train, t(x_train), W0 = W0, loss="logistic", regul="group-lasso-l2", lambda1=1, groups=as.integer(rep(c(1,2),c(100, nrow(Mutation.processed)-100)))  )

                ## AUC
                y_predicted <- rep(0,9)

                for (k in 1:length(y_predicted))
                {
                        x_test <- Mutation.processed[,25+k]

                        p_one <- 1/(1+ exp(-1* (t(w_train[[n]]) %*% x_test)))
                        p_min_one <-1/(1+ exp(1* (t(w_train[[n]]) %*% x_test)))

                        y_predicted[k] <- ifelse(which.max(c(p_min_one,p_one))==1, -1,1)
                }

                y_test <- CIMP.processed[26:34]
                Acc[n] <- sum((y_test * y_predicted==1))/length(y_predicted)
        }


        library(ggplot2)
        qplot(lambda_grid,Acc)+ scale_x_log10()

        lambda_opt <- which.max(Acc)
        lambda_opt <- 7

        sum(w_train[[lambda_opt]] != 0)
        Index <- rownames(Mutation.processed)[w_train[[lambda_opt]] != 0]

        tmp <- t(log2(Mutation.processed[Index,]))
        library(reshape2)


        tmp.m <- melt(tmp)
        tmp.m <- cbind(tmp.m, CIMP.processed)

        ggplot(tmp.m) + geom_boxplot(aes(x=Var2,y=value, fill=factor(CIMP.processed))) + theme(axis.text.x=element_text(angle=-90))








        # do not regularize the last row of W if intercept=T add a column of 1s in X
        # w_intercept <- spams.fistaFlat(CIMP.processed, t(Mutation.processed), W0 = W0, loss="logistic", regul="l1", lambda1=1,  )




}
