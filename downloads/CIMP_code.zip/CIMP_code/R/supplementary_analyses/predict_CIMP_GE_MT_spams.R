predict_CIMP_GE_MT_par = function (DiseaseList, var.thresh, CIMP.Number=2, centered=T, scaled=F, intercept=T, folds=10, bootstrap=100, cores=10, log_exp=T, eps=2^-16) 
{

        # var.thresh <- 5
        # CIMP.Number <- 2
        # centered <- T
        # scaled <- T
        # intercept <- T
        # n.folds <- 10
        # bootstrap <- 10
        # cores <- 10
        # log_exp <- T
        # eps <- 2^-16


        library(spams, lib.loc="~/Desktop/Pkg")
        # DiseaseList <- c('BRCA','LUAD','COAD','BLCA')

        Dat.CIMP <- lapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   return(out)
                           })

        Disease.Length <- sapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   out.length <- length(out)
                                   return(out.length)
                           })
        names(Disease.Length) <- DiseaseList

        Dat.GE <- lapply(1:length(DiseaseList), function(n)
                         { 
                                 print(DiseaseList[n])
                                 #out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEprocessed.RData')))
                                 out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEter.RData')))
                                 if (log_exp)
                                 {
                                         out <- log2(out)
                                         out[out==-Inf] <- log2(eps)
                                 }
                                 return(out)
                         })

        names_Meth <- lapply(1:length(DiseaseList), function(n){ substring(names(Dat.CIMP[[n]]),1,12)})
        names_GE <- lapply(1:length(DiseaseList), function(n){substring(colnames(Dat.GE[[n]]),1,12)})

        common_names <- lapply(1:length(DiseaseList), function(n){intersect(names_Meth[[n]],names_GE[[n]])})
        size_processed <- sapply(common_names, length)
        names(size_processed) <- DiseaseList

        CIMP.processed <- lapply(1:length(DiseaseList), function(n)
                                 {
                                         tmp <- matrix(Dat.CIMP[[n]][match(common_names[[n]],names_Meth[[n]])],ncol=1)
                                         tmp[tmp==1] <- -1
                                         tmp[tmp==2] <- 1
                                         return(tmp)
                                 })

        GE.processed <- lapply(1:length(DiseaseList), function(n)
                               {
                                       return(Dat.GE[[n]][,match(common_names[[n]], names_GE[[n]])])
                               })

        #### Multi-task
        bootstrap <- 100
        folds <- 10
        cores <- 10
        library(doParallel)
        registerDoParallel(cores=cores)

        n.bootstrap <- bootstrap
        n.folds <- folds
        lambda_grid <- 2^(-10:10)

        Dat <- foreach(icount(bootstrap)) %dopar%
        {

                partition <- lapply(1:length(DiseaseList), function(n)
                                    {
                                            n.length <- ncol(GE.processed[[n]])
                                            partition <- split( sample(seq(n.length)), seq(n.folds))
                                    })

                Accuracy.Disease <- lapply(1:length(lambda_grid), function(l)
                                           {
                                                   return(matrix(0, nrow= n.folds, ncol=length(DiseaseList)))
                                           })

                Accuracy.Percent <- matrix(0, nrow=length(lambda_grid), ncol=n.folds)
                Accuracy.Numbers <- matrix(0, nrow=length(lambda_grid), ncol=n.folds)

                for (n in 1:n.folds)
                {
                        print(paste0('fold=',n,'/',n.folds))

                        ######################################
                        # Training
                        require(stats)
                        GE.processed.train <- lapply(1:length(DiseaseList), function(k)
                                                     {
                                                             tmp <- t(GE.processed[[k]][,-partition[[k]][[n]]])
                                                             tmp <- scale(tmp, center=centered, scale=scaled)
                                                             return(tmp)
                                                     })

                        CIMP.processed.train <- lapply(1:length(DiseaseList), function(k)
                                                       {
                                                               CIMP.processed[[k]][-partition[[k]][[n]],,drop=F]
                                                       })

                        #######################################
                        # Testing
                        GE.processed.test <- lapply(1:length(DiseaseList), function(k)
                                                    {
                                                            tmp <- t(GE.processed[[k]][,partition[[k]][[n]]])
                                                            if ((centered)&(scaled))
                                                            {
                                                                    tmp <- sweep(tmp, 2, attr(GE.processed.train[[k]],"scaled:center"), FUN="-")
                                                                    tmp <- sweep(tmp, 2, attr(GE.processed.train[[k]],"scaled:scale"), FUN="/")
                                                            } else if ((centered)&(!scaled))
                                                            {
                                                                    tmp <- sweep(tmp, 2, attr(GE.processed.train[[k]],"scaled:center"), FUN="-")
                                                            }
                                                            return(tmp)
                                                    })

                        CIMP.processed.test <- lapply(1:length(DiseaseList), function(k)
                                                      {
                                                              CIMP.processed[[k]][partition[[k]][[n]],,drop=F]
                                                      })

                        ######################
                        # Adding intercept
                        if (intercept)
                        {
                                GE.processed.train <- lapply(1:length(DiseaseList), function(k)
                                                             {
                                                                     cbind(GE.processed.train[[k]],1)
                                                             })
                                GE.processed.test <- lapply(1:length(DiseaseList), function(k)
                                                            {
                                                                    cbind(GE.processed.test[[k]],1)
                                                            })
                        }

                        #### Creating multitask
                        sample_size <- sapply(CIMP.processed.train, nrow)
                        y_train <- Reduce('rbind',CIMP.processed.train)

                        x_train <- matrix(0, nrow=nrow(y_train), ncol=length(DiseaseList)*ncol(GE.processed.train[[1]]))

                        for (k in 1:length(DiseaseList))
                        {
                                # print(k)
                                Idx_row <- c(0, cumsum(sample_size))
                                Idx_col <- c(0, cumsum(rep(ncol(GE.processed.train[[1]]),length(DiseaseList))))
                                x_train[(Idx_row[k]+1):Idx_row[k+1], (Idx_col[k]+1): Idx_col[k+1]    ] <- GE.processed.train[[k]]
                        }

                        for (l in 1:length(lambda_grid))
                        {
                                print(paste0('   lambda=',l,'/',length(lambda_grid)))
                                W0 <-  matrix(0,nrow=length(DiseaseList)*ncol(GE.processed.train[[1]]),ncol=1)
                                groups <- rep(1:ncol(GE.processed.train[[1]]), length(DiseaseList))

                                #### Model
                                w_train <- spams.fistaFlat(y_train, x_train,W0=W0, loss="logistic", regul="group-lasso-l2", lambda1=lambda_grid[l], group = as.integer(groups), intercept=intercept)

                                #### Prediction on test
                                w_train_mat <- matrix(w_train, nrow= ncol(GE.processed.train[[1]]), ncol= length(DiseaseList))

                                #### Verify
                                y_prediction <- lapply(1:length(DiseaseList), function(k)
                                                       {
                                                               # p_one <- sapply(1:ncol(GE.processed.test[[k]]), function(n1)
                                                               #                 {
                                                               #                         1/(1+ exp(-1 *(t(w_train) %*% GE.processed.test[[k]][,n1])))
                                                               #                 })

                                                               # p_minus_one <- sapply(1:ncol(GE.processed.test[[k]]), function(n1)
                                                               #                 {
                                                               #                         1/(1+ exp(1 *(t(w_train) %*% GE.processed.test[[k]][,n1])))
                                                               #                 })

                                                               y_predicted <-sapply(1:ncol(GE.processed.test[[k]]), function(n1)
                                                                                    {
                                                                                            p_one <- 1/(1+ exp(-1 *(t(w_train_mat[,k]) %*% GE.processed.test[[k]][,n1])))
                                                                                            p_minus_one <- 1/(1+ exp(1 *(t(w_train_mat[,k]) %*% GE.processed.test[[k]][,n1])))

                                                                                            prediction <- ifelse(which.max(c(p_minus_one,p_one))==1,-1,1)
                                                                                    })
                                                       })

                                # Accuracy.Disease[[n]][[l]]
                                Accuracy.Disease[[l]][n,] <- sapply(1:length(DiseaseList), function(k)
                                                                    {
                                                                            sum(y_prediction[[k]] * CIMP.processed.test[[k]] == 1)/length(y_prediction[[k]])
                                                                    })

                                #### Mean Accuracy
                                Accuracy.Percent[l,n] <- mean(Accuracy.Disease[[l]][n,])
                                Accuracy.Numbers[l,n] <- sum( Reduce('c',y_prediction) * Reduce('c',CIMP.processed.test) == 1)/ length(Reduce('c',y_prediction))

                        }

                }
                tmp <- NULL
                tmp$Acc_Disease <- Accuracy.Disease
                tmp$Acc_Percent <- Accuracy.Percent
                tmp$Acc_Numbers <- Accuracy.Numbers

                return(tmp)

        }

        save(Dat, file=paste0('../../big_data/Prediction/MT_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'.RData'))


}
