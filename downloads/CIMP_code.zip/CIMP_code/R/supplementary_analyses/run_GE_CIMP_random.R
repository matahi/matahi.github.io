setwd('~/Desktop/CIMP/src/R')

Accuracy.Random <- sapply(1:length(DiseaseList), function(n)
                          {
                                  Dat.CIMP <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                  Dat.GE <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEter.RData')))

                                  names_Meth <- substring(names(Dat.CIMP),1,12)
                                  names_GE <- substring(colnames(Dat.GE),1,12)

                                  common_names <- intersect(names_Meth,names_GE)

                                  CIMP.processed <- matrix(Dat.CIMP[match(common_names,names_Meth)],ncol=1)
                                  tmp <- CIMP.processed
                                  CIMP.processed[tmp == 1] <- -1
                                  CIMP.processed[tmp == 2] <- 1

                                  Proportions <- table(as.numeric(CIMP.processed))
                                  Acc.Random <- max(Proportions)/sum(Proportions)
                          })
names(Accuracy.Random) <- DiseaseList
Accuracy.Random.df <- data.frame(Accuracy=Accuracy.Random, Disease=DiseaseList, method="Random")

save(Accuracy.Random.df, file="../../big_data/Prediction/Random.RData")


