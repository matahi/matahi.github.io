######################################################################################################
#			Pattern Recognition in CpG Islands 
######################################################################################################
### Data Loading {{{1
## Path Setting {{{2
PATH <- "~/Desktop/CIMP/src/R" # for Curie Machines
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

### Toolbox {{{1
## load the used packages {{{2
require('ggplot2')
require('gplots') # heatmap.2
require('RColorBrewer') # Heatmap Colors
require('reshape2') #for Melt for data.frame
require('gridExtra') # for plotting several ggplots -> grid.arrange

## Useful functions{{{2
############################################################
#DiseaseList <- c('BRCA','LUAD','COAD','BLCA','GBM','STAD','LAML')
DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD')
DiseaseFolder <- c('BRCA' = 'Breast',
                   'LUAD' = 'Lung',
                   'COAD' = 'Colon',
                   'BLCA' = 'Bladder',
                   'GBM' = 'Glioblastoma',
                   'STAD' = 'Stomach',
                   'LAML' = 'Leukemia')

source('lib/gg_color_hue.R')
Disease.Colors <- gg_color_hue(length(DiseaseList))

### 1) Look at the CGIs and see which CGIs are varying
source('fun/analyze_CIMP_all_CGIs.R')
for (DiseaseName in DiseaseList)
{
        print(DiseaseName)
        out <- analyze_CIMP_all_CGIs(DiseaseName=DiseaseName,CIMP.Number = 2, calc.Var= T)
}

### Verify the existence for several values of cutoff and for 2 or 3 classes
var.list <- c(1,2,5,10)
source('fun/analyze_CIMP_all_CGIs.R')
for (CIMP.Number in c(2,3))
{
        for (var.thresh in var.list)
        {
                for (DiseaseName in DiseaseList)
                {
                        print(DiseaseName)
                        out <- analyze_CIMP_all_CGIs(DiseaseName=DiseaseName,CIMP.Number = CIMP.Number, calc.Var= F, var.thresh = var.thresh)
                }
        }
}

### 2.A) Look at cluster robustness
source('fun/cluster_analysis.R')
out <- cluster_analysis(DiseaseList=DiseaseList, var.thresh=var.thresh)


### 2.B) Look at cluster robustness given the var.thresh
source('fun/cluster_analysis_var.R')
DiseaseList <- c('BRCA','BLCA','COAD','LUAD','STAD')
var.list <- c(1,2,5,10)

for (Disease in DiseaseList)
{
        out <- cluster_analysis_var(DiseaseName=Disease, CIMP.Number=3, var.list= var.list)
}


### 3) Find a common panel?
source('fun/compare_panel_all_CGIs.R')
DiseaseList <- c('BRCA','BLCA','COAD','LUAD','STAD')
out <- compare_panel_all_CGIs(DiseaseList, var.thresh=var.thresh)
write(out$CGIs, file=paste0("../../results/CIMP/1_InterCancer/CommonCIMP_panel_CGIsVar",var.thresh,".txt"))
write(out$Genes, file=paste0("../../results/CIMP/1_InterCancer/CommonCIMP_panel_genesVar",var.thresh,".txt"))

### 3.B) PLOT CIMPS on common panel
source('fun/analyze_CIMP_all_CGIs_bis.R')
out <- analyze_CIMP_all_CGIs_bis(DiseaseList,CIMP.Number = 3)

# 4) CIMP = f(GE)?
# We fix the var.thresh at 5% and consider only 2 clusters for CIMP
var.thresh <- 5
CIMP.Number <- 2

# 4.A) Normal Lasso
source('fun/predict_CIMP_GE_glmnet.R')
DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD')
for (DiseaseName in DiseaseList)
{
        print(DiseaseName)
        out <- predict_CIMP_GE(DiseaseName, var.thresh=var.thresh, CIMP.Number=2, centered=T, scaled=T, intercept=T, n.folds=3, bootstrap=100, cores=10, log_exp=T, balanced=T)
}

# 4.B) Intermediate Lasso
source('fun/predict_CIMP_GE_all.R')
DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD')
out <- predict_CIMP_GE_all(DiseaseList, var.thresh=var.thresh, CIMP.Number=2, centered=T, scaled=T, intercept=T, n.folds=3, bootstrap=100, cores=10, log_exp=T, balanced=T)

# 4.C) Group Lasso
source('fun/predict_CIMP_GE_MT_par.R')
DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD')
out <- predict_CIMP_GE_MT(DiseaseList, var.thresh=var.thresh, CIMP.Number=2, centered=T, scaled=T, intercept=T,  n.folds=3, bootstrap=100, cores=10, balanced=T)

# 4.D) Analysis of predictions
DiseaseList <- c('BRCA','LUAD','STAD','COAD','BLCA')
source('fun/analyze_predict_CIMP_GE_MT.R')

### 5) CIMP = f(Mutation)??
DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD')
var.thresh <- 5
CIMP.Number <- 2

source('fun/analyze_mutations.R')
Mutation.List <- c('BRAF','KRAS','IDH1','IDH2','TET2')

analyze_mutations(DiseaseList)

### 6) Correlate with clinical information
CIMP.Number <- 2
var.thresh <- 5

DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD')
source('fun/compare_clinical.R')
for (DiseaseName in DiseaseList)
{
        print(DiseaseName)
        out <- compare_clinical(DiseaseName=DiseaseName, var.thresh=var.thresh, CIMP.Number= CIMP.Number)
}

