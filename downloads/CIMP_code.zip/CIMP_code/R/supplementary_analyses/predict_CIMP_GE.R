predict_CIMP_GE = function (DiseaseName, var.thresh, CIMP.Number=2,centered=T, scaled=F, intercept=T, n.folds=10, bootstrap=100, cores=10,log_exp=T,eps=2^-16) {

        # DiseaseName <- "BRCA"
        # DiseaseName <- "BLCA"
        # var.thresh <- 5
        # CIMP.Number <- 2
        # centered <- T
        # scaled <- T
        # intercept <- T
        # n.folds <- 10
        # bootstrap <- 10
        # cores <- 10
        # log_exp <- T
        # eps <- 2^-16

        library(spams, lib.loc="~/Desktop/Pkg")

        Dat.CIMP <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseName,'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
        Dat.GE <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseName,'/CancerousLevel3GEter.RData')))

        if (log_exp)
        {
                Dat.GE <- log2(Dat.GE)
                Dat.GE[Dat.GE==-Inf] <- log2(eps)
        }


        names_Meth <- substring(names(Dat.CIMP),1,12)
        names_GE <- substring(colnames(Dat.GE),1,12)

        common_names <- intersect(names_Meth,names_GE)

        CIMP.processed <- matrix(Dat.CIMP[match(common_names,names_Meth)],ncol=1)
        tmp <- CIMP.processed
        CIMP.processed[tmp == 1] <- -1
        CIMP.processed[tmp == 2] <- 1
        GE.processed <- Dat.GE[, match(common_names,names_GE)]

        ######
        # bootstrap <- 100
        # centered <- T
        # scaled <- T
        # intercept <- T

        ### Parallelize
        # cores <- 10
        library(doParallel)
        registerDoParallel(cores=cores)
        lambda_grid <- 2^(-10:10)

        Dat <- foreach(i=1:bootstrap) %dopar%
        {
                print(i)
                partition <- split(sample(seq(ncol(GE.processed))), seq(n.folds))

                ######
                # Accuracy.Percent <- matrix(0, nrow=length(lambda_grid), ncol=n.folds)

                for (n in 1:n.folds)
                {

                        GE.processed.train <- GE.processed[, -partition[[n]]]
                        CIMP.processed.train <- CIMP.processed[-partition[[n]],,drop=F]

                        x_train <- t(GE.processed.train)
                        require(stats)
                        ## Normalizing or not
                        x_train <- scale(x_train, center=centered,scale=scaled)
                        y_train <- CIMP.processed.train

                        GE.processed.test <- GE.processed[, partition[[n]]]
                        x_test <- t(GE.processed.test)
                        ## We have to Normalize the GE.processed.test with the train
                        if ((centered)&(scaled))
                        {
                               x_test  <- sweep(x_test, 2, attr(x_train,"scaled:center"), FUN="-")
                               x_test  <- sweep(x_test, 2, attr(x_train,"scaled:scale"), FUN="/")
                        } else if ((centered)&(!scaled))
                        {
                                x_test <- sweep(x_test, 2, attr(x_train,"scaled:center"), FUN="-")
                        }

                        CIMP.processed.test <- CIMP.processed[ partition[[n]], , drop=F]
                        if (intercept)
                        {
                                x_train <- cbind(x_train,1)
                                x_test <- cbind(x_test,1)
                        }


                        for (l in 1:length(lambda_grid))
                        {
                                W0 <- matrix(0, nrow=ncol(x_train), ncol=1)
                                w_train <- spams.fistaFlat( y_train, x_train, W0=W0, loss="logistic", regul="l1", lambda1=lambda_grid[l],intercept=intercept)

                                y_prediction <- sapply(1:nrow(x_test), function(n1)
                                                       {
                                                               p_one <- 1/(1+ exp(-1*(t(w_train) %*% x_test[n1,])))
                                                               p_minus_one <- 1/(1+ exp(1*(t(w_train) %*% x_test[n1,])))

                                                               prediction <- ifelse(which.max(c(p_minus_one, p_one))==1,-1,1)
                                                       })

                                Accuracy.Percent[l,n] <-  sum( y_prediction * CIMP.processed.test == 1)/length(y_prediction)

                        }

                }

                return(Accuracy.Percent)

        }

        save(Dat, file=paste0('../../big_data/Prediction/',DiseaseName,'log_',log_exp,'_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'.RData'))

}
