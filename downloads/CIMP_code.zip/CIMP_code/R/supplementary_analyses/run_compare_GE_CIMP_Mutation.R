
Gene.CIMP <- get(load('../../results/Genes_CIMP.RData'))
Gene.GE <- read.csv('../../results/GE_CIMP/MTL_GeneList_all_Cutoff_0.5.txt',header=F)
Gene.Mutation <- read.csv('../../results/Mutation_Genes.txt',header=F)


Dat <- list(Meth=Gene.CIMP, GE=as.character(Gene.GE[,1]), Mutation=as.character(Gene.Mutation[,1]))

venn.out <- venn.diagram(Dat, filename=NULL)

graphics.off()
grid.draw(venn.out)

