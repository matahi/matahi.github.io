##########################################################################################################
########	        CIMP : data Analysis	
##########################################################################################################
# run_find_SourceSite.R

### Preloading {{{1
# Path Setting : Put the Path according to your directories (Data, Working, ...)
PATH <- "~/Desktop/CIMP/src/R" # Curie Machines path
# args <- commandArgs(TRUE); PATH = args[1]
setwd(PATH)

# Loading Data
TissueSourceSite <- read.csv('../../data/raw/fData/tissueSourceSite.csv',header=T)

DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD') 

Center.Info <- lapply(1:length(DiseaseList), function(n)
                      {
                              print(n)
                              if (DiseaseList[n] == "LUAD")
                              {
                                      Dat <- get(load("~/Desktop/CpG/data/processed/Methylation/TCGA/LUAD/CancerousLevel2.RData"))
                              } else {
                                      Dat <- get(load(paste0("../../data/processed/Methylation/TCGA/",DiseaseList[n],"/CancerousLevel2.RData")))
                              }

                              Provenance <- sapply(1:ncol(Dat),function(k){substring(colnames(Dat)[k],6,7)})

                              Source <- data.frame(TissueSourceSite[TissueSourceSite$TSS.Code %in% Provenance,],Disease=DiseaseList[n])
                      })

Total.Info <- Reduce('rbind', Center.Info)

Sources.List <- sort(unique(Total.Info$Source.Site))

Sources.disease <- lapply(1:length(Sources.List), function(n)
                          {
                                  Indexes <- which(Total.Info$Source.Site== Sources.List[n])

                                  return(Total.Info$Disease[Indexes])

                          })
names(Sources.disease) <- Sources.List


write.csv(Total.Info, '../../results/CenterInfo.csv')





