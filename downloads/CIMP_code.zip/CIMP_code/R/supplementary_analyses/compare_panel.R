compare_panel = function (DiseaseList) {

        ###
        Clusters.DiseaseList <- lapply(1:length(DiseaseList), function(k)
                                       {
                                               Clusters.Meth <- get(load(paste0('../../big_data/CGIs/',DiseaseList[k],'_Cancerous_ClustersMean.RData')))
                                               Cluster3 <- names(Clusters.Meth)[Clusters.Meth==3]
                                       })
        names(Clusters.DiseaseList) <- DiseaseList

        #############
        # library(VennDiagram)
        # intersect.3 <- venn.diagram(Clusters.DiseaseList[1:4], filename=NULL)
        # sapply(Clusters.DiseaseList,length)
        # grid.draw(intersect.3)

        Common.CGIs <- Reduce('intersect', Clusters.DiseaseList)

        Promoter.Assoc <- get(load('../../big_data/Tools/PromoterAssoc.RData'))
        CommonGenes <- get(load('../../big_data/Tools/CommonGenes.RData'))

        tmp <- paste0("CGI",1:1827)
        Index <- which(tmp %in% Common.CGIs)

        out <- NULL
        out$CGIs <- Index
        out$Genes <- as.character(na.omit( CommonGenes[match(Index,Promoter.Assoc)]))

        save(Index, file="../../big_data/CGIs/CIMP_Intersection.RData")

        library(clusterProfiler)
        library(biomaRt)
        mart <- useMart(biomart="ensembl", dataset= "hsapiens_gene_ensembl")

        universe.genes <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = CommonGenes, mart = mart)[,1]
        signature.genes <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = out$Genes, mart = mart)[,1]

        xx_bp <- enrichGO(signature.genes, universe = universe.genes ,ont="BP")

        pdf(paste0('../../results/1_InterCancer/BP.pdf'))
        print(plot(xx_bp, showCategory=10,by="geneRatio"))
        dev.off()
        

        # xx_mf <- enrichGO(out$Genes, universe = CommonGenes ,ont="MF")

        # data(gcSample)
        # yy <- enrichGO(gcSample[[1]], organism="human", ont="BP", pvalueCutoff=0.01)

        #############

        return(out)
}
