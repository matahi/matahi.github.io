cluster_analysis = function (DiseaseList,var.thresh) {

        Consensus.DiseaseList.ml <- lapply(1:length(DiseaseList), function(k)
                                           {
                                                   Consensus <- get(load(paste0('../../big_data/CGIs/', DiseaseList[k],'_Consensus',var.thresh,'.RData' ) ))
                                                   nClust <- length(Consensus)

                                                   return(lapply(2:nClust, function(n){Consensus[[n]]$ml}))
                                           })

        source('lib/CDF.R')
        delta.MCA <- lapply(1:length(DiseaseList), function(n){CDFbis(Consensus.DiseaseList.ml[[n]])})
        names(delta.MCA) <- DiseaseList
        MCA.Dat <- Reduce('cbind',delta.MCA)
        MCA.df <- data.frame(nclust= 2:(nrow(MCA.Dat)+1), delta= as.vector(as.matrix(MCA.Dat)), tissue = rep(DiseaseList, each=nrow(MCA.Dat)))

        p <- ggplot(MCA.df) + geom_point(aes(x=nclust, y=delta, colour=tissue)) + geom_line(aes(x=nclust,y=delta, colour=tissue))
        pdf(paste0('../../results/CIMP/1_InterCancer/delta_Var',var.thresh,'.pdf'))
        print(p+  xlab("Number of clusters") + ylab(expression(Delta(K)))    +
              theme(panel.grid=element_blank(),
                    text = element_text(size=20),
                    panel.background=element_rect(fill="white"),
                    axis.text=element_text(colour="black", size=rel(0.8)),
                    axis.ticks=element_line(colour="black"),
                    panel.border=element_rect(fill=NA, colour="black", size=0.7),
                    axis.title.y=element_text(vjust=0.35),
                    strip.background=element_rect(colour="black", fill="white",size=0.7),
                    axis.line = element_line(colour="black",size=0.7))
        )
        dev.off()

}
