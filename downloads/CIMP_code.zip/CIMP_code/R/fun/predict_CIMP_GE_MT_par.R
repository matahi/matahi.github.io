predict_CIMP_GE_MT = function (DiseaseList, var.thresh, CIMP.Number=2, centered=T, scaled=T, intercept=T, n.folds=3, bootstrap=100, cores=10, log_exp=T, eps=2^-16, balanced=T, method="grpreg") 
{

        # var.thresh <- 5
        # CIMP.Number <- 2
        # centered <- T
        # scaled <- T
        # intercept <- T
        # n.folds <- 3
        # bootstrap <- 100
        # cores <- 10
        # log_exp <- T
        # eps <- 2^-16
        # balanced <- T

        # DiseaseList <- c('BRCA','LUAD','COAD','BLCA')

        Dat.CIMP <- lapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   return(out)
                           })

        Disease.Length <- sapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   out.length <- length(out)
                                   return(out.length)
                           })
        names(Disease.Length) <- DiseaseList

        Dat.GE <- lapply(1:length(DiseaseList), function(n)
                         { 
                                 print(DiseaseList[n])
                                 #out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEprocessed.RData')))
                                 out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEter.RData')))
                                 if (log_exp)
                                 {
                                         out <- log2(out)
                                         out[out==-Inf] <- log2(eps)
                                 }
                                 return(out)
                         })

        names_Meth <- lapply(1:length(DiseaseList), function(n){ substring(names(Dat.CIMP[[n]]),1,12)})
        names_GE <- lapply(1:length(DiseaseList), function(n){substring(colnames(Dat.GE[[n]]),1,12)})

        common_names <- lapply(1:length(DiseaseList), function(n){intersect(names_Meth[[n]],names_GE[[n]])})
        size_processed <- sapply(common_names, length)
        names(size_processed) <- DiseaseList

        CIMP.processed <- lapply(1:length(DiseaseList), function(n)
                                 {
                                         tmp <- matrix(Dat.CIMP[[n]][match(common_names[[n]],names_Meth[[n]])],ncol=1)
                                         tmp[tmp==1] <- -1
                                         tmp[tmp==2] <- 1
                                         return(tmp)
                                 })

        GE.processed <- lapply(1:length(DiseaseList), function(n)
                               {
                                       return(Dat.GE[[n]][,match(common_names[[n]], names_GE[[n]])])
                               })

        #### Multi-task
        bootstrap <- 100
        cores <- 10
        library(doParallel)
        registerDoParallel(cores=cores)

        Dat <- foreach(i=1:bootstrap) %dopar%
        {
                print(i)

                ##########
                ## bias partition?
                partition <- lapply(1:length(DiseaseList), function(n)
                                    {
                                            if (balanced)
                                            {
                                                    Index.pos <- which(CIMP.processed[[n]] == +1)
                                                    Index.neg <- which(CIMP.processed[[n]] == -1)

                                                    partition.pos <- split(sample(Index.pos), seq(n.folds))
                                                    partition.neg <- split(sample(Index.neg), seq(n.folds))

                                                    partition <- lapply(1:n.folds, function(k){c(partition.pos[[k]], partition.neg[[k]])})

                                            } else {
                                                    n.length <- ncol(GE.processed[[n]])
                                                    partition <- split( sample(seq(n.length)), seq(n.folds))
                                            }
                                    })

                tmp <- lapply(1:n.folds, function(n)
                              {
                                      print(paste0('fold=',n,'/',n.folds))

                                      ######################################
                                      # Training
                                      GE.processed.train <- lapply(1:length(DiseaseList), function(k)
                                                                   {
                                                                           tmp <- t(GE.processed[[k]][,-partition[[k]][[n]]])
                                                                           return(tmp)
                                                                   })

                                      CIMP.processed.train <- lapply(1:length(DiseaseList), function(k)
                                                                     {
                                                                             CIMP.processed[[k]][-partition[[k]][[n]],,drop=F]
                                                                     })

                                      #######################################
                                      # Testing
                                      GE.processed.test <- lapply(1:length(DiseaseList), function(k)
                                                                  {
                                                                          tmp <- t(GE.processed[[k]][,partition[[k]][[n]]])
                                                                          return(tmp)
                                                                  })

                                      CIMP.processed.test <- lapply(1:length(DiseaseList), function(k)
                                                                    {
                                                                            CIMP.processed[[k]][partition[[k]][[n]],,drop=F]
                                                                    })

                                      #### Creating multitask
                                      sample_size_train <- sapply(CIMP.processed.train, nrow)
                                      sample_size_test <- sapply(CIMP.processed.test, nrow)
                                      y_train <- Reduce('rbind',CIMP.processed.train)
                                      y_test <- Reduce('rbind',CIMP.processed.test)

                                      x_train <- matrix(0, nrow=nrow(y_train), ncol=length(DiseaseList)*ncol(GE.processed.train[[1]]))
                                      x_test <- matrix(0, nrow=nrow(y_test), ncol=length(DiseaseList)*ncol(GE.processed.test[[1]]))

                                      for (k in 1:length(DiseaseList))
                                      {
                                              Idx_row_train <- c(0, cumsum(sample_size_train))
                                              Idx_col_train <- c(0, cumsum(rep(ncol(GE.processed.train[[1]]),length(DiseaseList))))
                                              x_train[(Idx_row_train[k]+1):Idx_row_train[k+1], (Idx_col_train[k]+1): Idx_col_train[k+1]    ] <- GE.processed.train[[k]]

                                              Idx_row_test <- c(0, cumsum(sample_size_test))
                                              Idx_col_test <- c(0, cumsum(rep(ncol(GE.processed.test[[1]]),length(DiseaseList))))
                                              x_test[(Idx_row_test[k]+1):Idx_row_test[k+1], (Idx_col_test[k]+1): Idx_col_test[k+1]    ] <- GE.processed.test[[k]]

                                      }

                                      groups <- rep(1:ncol(GE.processed.train[[1]]), length(DiseaseList))

                                      y_train <- as.vector(y_train)
                                      Dat.train <- list(x= x_train, y=y_train)
                                      # Dat.test <- list(x= x_test, y=y_test)

                                      #### Calculating
                                      #################
                                      # ### using grpreg 
                                      # #####
                                      if (method=="grpreg")
                                      {
                                              library(grpreg)
                                              y_train[y_train==-1] <- 0

                                              cvfit <- cv.grpreg(X=x_train,y=y_train, group=as.numeric(groups), nfolds=3, family="binomial", penalty="grLasso", gmax=200)

                                              #####
                                              lambda.opt <- cvfit$lambda.min

                                              predictor <- grpreg(X=x_train,y=y_train, group=as.numeric(groups), family="binomial", penalty="grLasso", gmax=200, lambda=lambda.opt)

                                              Y.predict <- predict(predictor, x_test, type="class")

                                              #### Global Accuracy
                                              y_test[y_test==-1] <- 0
                                              Acc <- sum(Y.predict==y_test)/length(y_test)

                                              ######## Acc.Disease
                                              test.Index <- cumsum(c(0,sapply(CIMP.processed.test,length)))
                                              Pred.Disease <- lapply(1:length(DiseaseList), function(n)
                                                                     {
                                                                             Out <- Y.predict[(test.Index[n]+1):test.Index[n+1]]
                                                                     })

                                              ########
                                              Acc.Disease <- sapply(1:length(DiseaseList), function(n)
                                                                    {
                                                                            tmp <- CIMP.processed.test[[n]]
                                                                            tmp[CIMP.processed.test[[n]]==-1] <- 0
                                                                            sum(Pred.Disease[[n]] == tmp)/length(tmp)
                                                                    })


                                              #### Genes Signature
                                              Genes <- which(coef(predictor)!=0)

                                              ## Remove intercept
                                              Genes <- Genes[-1]
                                              Genes <- Genes - 1

                                              Genes.Disease <- matrix(0, nrow= ncol(GE.processed.train[[1]]), ncol=length(DiseaseList))

                                              Genes.Disease[Genes] <- 1

                                      } else if (method=="msgl")
                                      {
                                              ### using MSGL
                                              #######
                                              library(msgl)
                                              lambda <- msgl.lambda.seq(x_train,y_train, alpha=0, d=50, lambda.min=0.001)
                                              cvfit <- msgl.cv(x_train, y_train, alpha=0, fold=3, grouping=groups, lambda=lambda)

                                              lambda.opt <- lambda[which.min(Err(cvfit))]

                                              predictor <- msgl(x_train, y_train, alpha=0, lambda=lambda.opt,grouping=groups)

                                              Y.predict <- predict(predictor, x_test)

                                              ############
                                              Final.Classes <- Y.predict$classes
                                              Acc <- 1- Err(Y.predict, classes= y_test)

                                              ######## Acc.Disease
                                              test.Index <- cumsum(c(0,sapply(CIMP.processed.test,length)))
                                              Pred.Disease <- lapply(1:length(DiseaseList), function(n)
                                                                     {
                                                                             Out <- Final.Classes[(test.Index[n]+1):test.Index[n+1]]
                                                                     })

                                              ########
                                              Acc.Disease <- lapply(1:length(DiseaseList), function(n)
                                                                    {
                                                                            sum(Pred.Disease[[n]] == CIMP.processed.test[[n]])/length(CIMP.processed.test[[n]])
                                                                    })
                                              names(Acc.Disease) <- DiseaseList

                                              ######## Genes

                                              Genes <- features(predictor)[[1]]
                                              if (1 %in% Genes)
                                              { 
                                                      Genes <- Genes[-1]
                                                      Genes <- Genes - 1
                                              }

                                              Genes.Disease <- matrix(0, nrow= ncol(GE.processed.train[[1]]), ncol=length(DiseaseList))

                                              Genes.Disease[Genes] <- 1

                                              tata <- apply(Genes.Disease,1,sum)

                                      }

                                      ###
                                      # Acc <- sum(Y_predict.lasso==y_test)/length(y_test)
                                      return(list(Acc=Acc, full.Acc=Acc.Disease, Genes=Genes.Disease))

                              })

                return(tmp)
        }

        #save(Dat, file=paste0('../../big_data/Prediction/MT_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'.RData'))
        save(Dat, file=paste0('../../big_data/Prediction/MT_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_method_',method,'_all.RData'))


}
