#analyze_predict_CIMP_GE = function (DiseaseName, var.thresh, CIMP.Number, centered=T, scaled=T, intercept=T, n.folds=10, bootstrap=100, log_exp=T) {
analyze_predict_CIMP_GE = function (DiseaseList, var.thresh, CIMP.Number, centered=T, scaled=T, intercept=T, n.folds=10, bootstrap=100, log_exp=T) {

        # DiseaseName <- "BRCA"
        # var.thresh <- 5
        # CIMP.Number <- 2
        # centered <- T
        # scaled <- T
        # intercept <- T
        # n.folds <- 3
        # bootstrap <- 100
        # log_exp <- T
        # balanced <- T

        GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))

        # Ave.Sign.Size <- apply(Gene.Sign,2,sum)

        # tata <- apply(Gene.Sign,1,sum)

        # tata.df <- data.frame(genes=names(tata), Signature=tata)
        # tata.df.nozero <- tata.df[tata.df$Signature !=0, ]

        # tata.df.order <- tata.df.nozero[order(tata.df.nozero[,2],decreasing=T),]
        # tata.df.10 <- tata.df.order[1:10,]

        # ggplot(tata.df.10) + geom_bar(aes(x=genes, y=Signature), stat="identity") + theme (axis.text.x=element_text(angle=90, hjust=1))

        # topList <- 100

        ###########################
        # Signatures
        ###########################


        Signatures <- lapply(1:length(DiseaseList), function(n)
                           {
                                   tmp <- get(load(paste0('../../big_data/Prediction/',DiseaseList[n],
                                                          'log_',log_exp,'_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_balanced_',balanced,'.RData')))
                                   Gene.Signature <- lapply(1:length(tmp), function(n)
                                                            {
                                                                    Dat <- tmp[[n]]
                                                                    Genes <- sapply(1:length(Dat), function(k){  Dat[[k]]$Genes   })
                                                            })

                                   Gene.Sign <- Reduce('cbind', Gene.Signature)
                                   rownames(Gene.Sign) <- GeneList
                                   Gene.Sign <- Gene.Sign[-1,]

                                   return(Gene.Sign)

                           })

        Genes.Signatures <- lapply(1:length(DiseaseList), function(n)
                                   {
                                           tmp <- apply(Signatures[[n]],1,sum)
                                           Genes.Signatures <- rownames(Signatures[[n]])[which(tmp != 0)]
                                   })
        names(Genes.Signatures) <- DiseaseList

        Genes.Percent <- sapply(1:length(DiseaseList), function(n){ apply(Signatures[[n]],1,sum)})

        library(VennDiagram)
        # intersect.Signature <- venn.diagram(Genes.Signatures, filename=NULL)
        intersect.Signature <- venn.diagram(Genes.Signatures[c('BRCA','LUAD','STAD')], filename=NULL)

        graphics.off()
        grid.draw(intersect.Signature)

        Intersect.GeneList <- Reduce('intersect',Genes.Signatures[c('BRCA','LUAD','STAD')])

        Genes.Percent[Intersect.GeneList,]

        Ave.Sign.Size <- sapply(1:length(DiseaseList), function(n)
                                {
                                        apply(Signatures[[n]],2,sum)
                                })


        #####################################
        # Accuracy
        #####################################

        Accuracy.Disease <- sapply(1:length(DiseaseList), function(n)
                                   {
                                           tmp <- get(load(paste0('../../big_data/Prediction/',DiseaseList[n],
                                                                  'log_',log_exp,'_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_balanced_',balanced,'.RData')))

                                           CIMP.Acc <- lapply(1:length(tmp), function(n)
                                                                    {
                                                                            Dat <- tmp[[n]]
                                                                            Genes <- sapply(1:length(Dat), function(k){  Dat[[k]]$Acc   })
                                                                    })
                                           Acc.repeats <- apply(Reduce('rbind',CIMP.Acc),1,mean)
                                   })

        colnames(Accuracy.Disease) <- DiseaseList
        library(reshape2)
        Accuracy.m <- melt(Accuracy.Disease)
        Accuracy.Lasso.df <- data.frame(Accuracy=Accuracy.m$value, Disease=Accuracy.m$Var2, method="Lasso")

        Accuracy.Random.df <- get(load('../../big_data/Prediction/Random.RData'))

        Accuracy.df <- rbind(Accuracy.Lasso.df, Accuracy.Random.df)
        Accuracy.df$method <- factor(Accuracy.df$method, levels=c('Random','Lasso'))

        library(ggplot2)

        pdf('../../results/GE_CIMP/Accuracy.pdf')
        # ggplot(Accuracy.df) + geom_boxplot(aes(x=Disease,y=Accuracy,fill=method)) + ylim(0,1)
        ggplot(Accuracy.Lasso.df) + geom_boxplot(aes(x=Disease,y=Accuracy)) + geom_point(data=Accuracy.Random.df,aes(x=Disease,y=Accuracy),color="red",shape=8,size=3) + ylim(0,1)
        dev.off()







}
