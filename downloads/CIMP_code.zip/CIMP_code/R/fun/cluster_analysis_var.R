cluster_analysis_var = function (DiseaseName, CIMP.Number=3, var.list=c(1,2,5,10)) {

        CIMP.clust <- lapply(1:length(var.list), function(k)
                             {
                                        Dat <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseName,'_CIMP_',CIMP.Number,'Var',var.list[k],'.RData')))
                             })

        CIMP.cluster <- Reduce('cbind',CIMP.clust)

        ### Stability Score
        Stable <- sapply(1:nrow(CIMP.cluster), function(n)
                         {
                                 return((length(unique(CIMP.cluster[n,]))==1))
                         })
        write(sum(Stable)/length(Stable), file=paste0('../../results/CIMP/',DiseaseFolder[DiseaseName],'/Stability_CIMP_',CIMP.Number,'.txt'))

        tmp <- CIMP.cluster

        if (length(var.list)==4)
        {
                tata <- tmp[order(tmp[,1],tmp[,2],tmp[,3],tmp[,4]),]
        } else {
                tata <- tmp[order(tmp[,1],tmp[,2],tmp[,3]),]
        }

        library(reshape2)

        #CIMP.m <- melt(CIMP.cluster)
        CIMP.m <- melt(tata)
        CIMP.m$Var2 <- rep(var.list, each = nrow(CIMP.cluster))

        if (CIMP.Number == 2)
        {
                CIMP_colours <- c('1' = "#225ea8",
                                  '2' = "gold2")
        } else {
                CIMP_colours <- c('1' = "#225ea8",
                                  '2' = 'black',
                                  '3' = "gold2")
        }


        pdf(paste0('../../results/CIMP/',DiseaseFolder[DiseaseName],'/Stability_CIMP_',CIMP.Number,'Var.pdf'))
        print(
              ggplot(CIMP.m) + geom_tile(aes(x=Var1,y=factor(Var2),fill=factor(value))) +
              ylab('Ratio of most variant genes') + xlab('Cluster Assignment') +
              scale_fill_manual(values=CIMP_colours) +
              theme(panel.grid=element_blank(),
                            legend.position="none",
                            text = element_text(size=20),
                            panel.background=element_rect(fill="white"),
                            axis.text.y=element_text(colour="black", size=rel(0.8)),
                            axis.ticks.y=element_line(colour="black"),
                            axis.text.x=element_blank(),
                            axis.ticks.x=element_blank(),
                            #panel.border=element_rect(fill=NA, colour="black", size=0.7),
                            panel.border=element_blank(),
                            axis.title.y=element_text(vjust=0.35),
                            strip.background=element_rect(colour="black", fill="white",size=0.7),
                            #axis.line = element_line(colour="black",size=0.7))
                            axis.line = element_blank())
              )

        dev.off()



}
