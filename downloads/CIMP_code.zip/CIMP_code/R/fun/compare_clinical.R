compare_clinical = function (DiseaseName, var.thresh, CIMP.Number,cens=365*5) {

        # DiseaseName <- "BRCA"
        # var.thresh <- 5
        # CIMP.Number <- 2

        Dat.CIMP <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseName,'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
        Dat.Clinical <- get(load(paste0('../../data/processed/Clinical/TCGA/',DiseaseName,'/Clinical.RData')))

        names_Meth <- substring(names(Dat.CIMP),1,12)
        names_Clinical <- substring(rownames(Dat.Clinical),1,12)

        common_names <- intersect(names_Meth,names_Clinical)

        CIMP.processed <- Dat.CIMP[match(common_names,names_Meth)]
        Clinical.processed <- Dat.Clinical[match(common_names,names_Clinical),]

        Clinical.Info <- c('vital_status',"last_contact_days_to","death_days_to")

        followUp <- rep(NA, nrow(Clinical.processed))
        for (k in 1:length(followUp))
        {
                if (is.na(Clinical.processed[k,"vital_status"]))
                {
                        followUp[k] <- Clinical.processed[k,"last_contact_days_to"] # inutile mais bon
                } else if (Clinical.processed[k,"vital_status"]=="Alive")
                {
                        followUp[k] <- Clinical.processed[k,"last_contact_days_to"]
                } else if (Clinical.processed[k,"vital_status"]=="Dead")
                {
                        followUp[k] <- Clinical.processed[k,"death_days_to"]
                }
        }


        Dat.surv <- data.frame(CIMP=CIMP.processed, status= Clinical.processed$vital_status, followUp=followUp)
        Dat.surv$followUp_cens <- Dat.surv$followUp
        Dat.surv$status_cens <- Dat.surv$status

        Dat.surv$followUp_cens[Dat.surv$followUp>cens] <- cens
        Dat.surv$status_cens[Dat.surv$followUp>cens] <- "Alive"


        #### Calculating Survival
        library(survival)
        source('lib/ggsurv.R')

        Dat.surv.CIMP <- survfit(Surv(followUp, status!="Alive") ~ CIMP, data= Dat.surv)
        Cox.surv.CIMP <- coxph(Surv(followUp, status!="Alive") ~ factor(CIMP), data= Dat.surv)

        Pval <- summary(Cox.surv.CIMP)$sctest["pvalue"]

        pdf(paste0('../../results/Clinical/', DiseaseFolder[DiseaseName],'/Surv_',CIMP.Number,'Var_',var.thresh,'.pdf'))
        print(ggsurv(Dat.surv.CIMP) + ylim(0,1))
        dev.off()

        Dat.surv.CIMP.cens <- survfit(Surv(followUp_cens, status_cens!="Alive") ~ CIMP, data= Dat.surv)
        Cox.surv.CIMP.cens <- coxph(Surv(followUp_cens, status_cens!="Alive") ~ factor(CIMP), data=Dat.surv)

        Pval.cens <- summary(Cox.surv.CIMP.cens)$sctest["pvalue"]

        CIMP_colours <- c('1' = "#225ea8",
                          '2' = "gold2")

        pdf(paste0('../../results/Clinical/', DiseaseFolder[DiseaseName],'/Surv_',CIMP.Number,'Var_',var.thresh,'_cens.pdf'))
        print(ggsurv(Dat.surv.CIMP.cens, xlab="Time after diagnosis (Days)", ylab="Probability", plot.cens=F) + ylim(0,1) +
              scale_colour_manual(values=CIMP_colours) +
              coord_cartesian(ylim=c(0,1.02)) +
              scale_y_continuous(breaks=seq(0,1,0.25),labels=c('0','0.25','0.5','0.75','1'))+
              theme(panel.grid=element_blank(),
                    legend.position="none",
                    text = element_text(size=20),
                    panel.background=element_rect(fill="white"),
                    axis.text=element_text(colour="black", size=rel(0.8)),
                    axis.ticks=element_line(colour="black"),
                    panel.border=element_rect(fill=NA, colour="black", size=0.7),
                    axis.title.y=element_text(vjust=0.35),
                    strip.background=element_rect(colour="black", fill="white",size=0.7),
                    axis.line = element_line(colour="black",size=0.7))
              )
        dev.off()

        write(Pval.cens, file=paste0('../../results/Clinical/', DiseaseFolder[DiseaseName],'/Pval_Surv_',CIMP.Number,'Var_',var.thresh,'_cens.txt'))
        write(Pval, file=paste0('../../results/Clinical/', DiseaseFolder[DiseaseName],'/Pval_Surv_',CIMP.Number,'Var_',var.thresh,'.txt'))
        write.table(table(Dat.surv$CIMP, Dat.surv$status_cens), file=paste0('../../results/Clinical/', DiseaseFolder[DiseaseName],'/table_event.txt'))


        out <- NULL
        out$Pval <- Pval
        out$Pval.cens <- Pval.cens
        
        save(out, file=paste0("../../big_data/Survival/",DiseaseName,"_CIMP_",CIMP.Number,"_Var_",var.thresh,".RData"))

}
