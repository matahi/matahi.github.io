analyze_predict_CIMP_GE_MT = function (DiseaseList, var.thresh, CIMP.Number=2, centered=T, scaled=T, intercept=T, n.folds=3, bootstrap=100, cores=10, balanced=T) {

        # var.thresh <- 5
        # CIMP.Number <- 2
        # centered <- T
        # scaled <- T
        # intercept <- T
        # n.folds <- 3
        # bootstrap <- 100
        # cores <- 10
        # log_exp <- T
        # eps <- 2^-16
        # balanced <- T
        # method <- "grpreg"

        # DiseaseList <- c('BRCA','LUAD','STAD')
        DiseaseList <- c('BLCA','BRCA','COAD','LUAD','STAD')

        #####################
        # Accuracy Comparison
        #####################
        Accuracy.Disease <- sapply(1:length(DiseaseList), function(n)
                              {
                                      tmp <- get(load(paste0('../../big_data/Prediction/',DiseaseList[n],
                                                             'log_',log_exp,'_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_balanced_',balanced,'.RData')))

                                      CIMP.Acc <- lapply(1:length(tmp), function(n)
                                                         {
                                                                 Dat <- tmp[[n]]
                                                                 Genes <- sapply(1:length(Dat), function(k){  Dat[[k]]$Acc   })
                                                         })

                                      Acc.repeats <- apply(Reduce('rbind',CIMP.Acc),1,mean)
                              })
        colnames(Accuracy.Disease) <- DiseaseList
        rownames(Accuracy.Disease) <- NULL 
        Accuracy.Disease <- data.frame(Accuracy.Disease)

        PPV.Disease <- sapply(1:length(DiseaseList), function(n)
                              {
                                      tmp <- get(load(paste0('../../big_data/Prediction/',DiseaseList[n],
                                                             'log_',log_exp,'_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_balanced_',balanced,'.RData')))

                                      CIMP.PPV <- lapply(1:length(tmp), function(n)
                                                         {
                                                                 Dat <- tmp[[n]]
                                                                 Genes <- sapply(1:length(Dat), function(k){  Dat[[k]]$PPV   })
                                                         })
                                      Acc.repeats <- apply(Reduce('cbind',CIMP.PPV),2,mean)
                              })
        colnames(PPV.Disease) <- DiseaseList

        #### Combined
        Dat.combined <- get(load(paste0('../../big_data/Prediction/COMBINED_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_method_lasso_all.RData')))
        Order.Acc.combined <- c('BLCA','BRCA','COAD','LUAD','STAD')
        Accuracy.Mean.combined <- sapply(1:length(Dat.combined), function(n)
                                                {
                                                        tmp <- sapply(1:length(Dat.combined[[n]]), function(k)
                                                                               {
                                                                                       return(Dat.combined[[n]][[k]]$Acc)
                                                                               }) 
                                                        return(mean(tmp))
                                                })

        Accuracy.combined <- Reduce('rbind',lapply(1:length(Dat.combined), function(n)
                                             {
                                                     tmp <- Reduce('rbind',lapply(1:length(Dat.combined[[n]]), function(k)
                                                                                  {
                                                                                          return(Dat.combined[[n]][[k]]$full.Acc)
                                                                                  }))
                                                     tmp <- apply(tmp,2,mean)

                                                     return(tmp)
                                             }))

        colnames(Accuracy.combined) <- Order.Acc.combined
        rownames(Accuracy.combined) <- NULL
        Accuracy.combined <- data.frame(Accuracy.combined)

        ###### Group-Lasso
        # Dat <- get(load(paste0('../../big_data/Prediction/MT_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_method_',method,'.RData')))
        Dat <- get(load(paste0('../../big_data/Prediction/MT_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_method_',method,'_all.RData')))


        # Accuracy.MT <- data.frame(t(sapply(1:length(Dat), function(n){return(Dat[[n]]$full.Acc)})))
        Order.Acc.MT <- c('BRCA','LUAD','STAD','COAD','BLCA')
        Accuracy.Mean <- sapply(1:length(Dat), function(n)
                                                {
                                                        tmp <- sapply(1:length(Dat[[n]]), function(k)
                                                                               {
                                                                                       return(Dat[[n]][[k]]$Acc)
                                                                               }) 
                                                        return(mean(tmp))
                                                })


        Accuracy.MT <- Reduce('rbind',lapply(1:length(Dat), function(n)
                                             {
                                                     tmp <- Reduce('rbind',lapply(1:length(Dat[[n]]), function(k)
                                                                                  {
                                                                                          return(Dat[[n]][[k]]$full.Acc)
                                                                                  }))
                                                     tmp <- apply(tmp,2,mean)

                                                     return(tmp)
                                             }))

        colnames(Accuracy.MT) <- Order.Acc.MT
        rownames(Accuracy.MT) <- NULL
        Accuracy.MT <- data.frame(Accuracy.MT)

        ##### RANDOM
        Accuracy.Random.df <- get(load('../../big_data/Prediction/Random.RData'))

        ##### Putting everything together
        library(reshape2)
        Disease.m <- melt(Accuracy.Disease)
        Disease.m <- data.frame(Accuracy=Disease.m$value, Disease=Disease.m$variable, method="Lasso") 

        Combined.m <- melt(Accuracy.combined)
        Combined.m <- data.frame(Accuracy=Combined.m$value, Disease=Combined.m$variable, method="Combined") 

        MT.m <- melt(Accuracy.MT)
        MT.m <- data.frame(Accuracy=MT.m$value, Disease=MT.m$variable, method="Group-Lasso") 

        Full.Dat <- rbind(Disease.m, Combined.m, MT.m)

        library(ggplot2)
        pdf('../../results/GE_CIMP/MT_vs_combined_vs_lasso_all.pdf')
        print(
              ggplot(Full.Dat) + geom_boxplot(aes(x=Disease,y=Accuracy, fill=method)) + geom_point(data=Accuracy.Random.df, aes(x=Disease,y=Accuracy), color="red", shape=8,size=3) + ylim(0,1) +
              theme(panel.grid=element_blank(),
                    text = element_text(size=20),
                    legend.position="none",
                    panel.background=element_rect(fill="white"),
                    axis.text=element_text(colour="black", size=rel(0.8)),
                    axis.ticks=element_line(colour="black"),
                    panel.border=element_rect(fill=NA, colour="black", size=0.7),
                    axis.title.y=element_text(vjust=0.35),
                    strip.background=element_rect(colour="black", fill="white",size=0.7),
                    axis.line = element_line(colour="black",size=0.7))
              )
        dev.off()

        pdf('../../results/GE_CIMP/MT_vs_combined_vs_lasso_all_16_9.pdf',16,9)
        print(
              ggplot(Full.Dat) + geom_boxplot(aes(x=Disease,y=Accuracy, fill=method)) + geom_point(data=Accuracy.Random.df, aes(x=Disease,y=Accuracy), color="red", shape=8,size=3) + ylim(0,1) +
              theme(panel.grid=element_blank(),
                    text = element_text(size=20),
                    legend.position="none",
                    panel.background=element_rect(fill="white"),
                    axis.text=element_text(colour="black", size=rel(0.8)),
                    axis.ticks=element_line(colour="black"),
                    panel.border=element_rect(fill=NA, colour="black", size=0.7),
                    axis.title.y=element_text(vjust=0.35),
                    strip.background=element_rect(colour="black", fill="white",size=0.7),
                    axis.line = element_line(colour="black",size=0.7))
              )
        dev.off()


        #### 
        tmp.wilcox <- sapply(1:length(DiseaseList), function(n)
               {
                       DiseaseName <- DiseaseList[n] 
                       lasso_random = wilcox.test(Accuracy.Disease[,DiseaseName] - Accuracy.Random.df[Accuracy.Random.df$Disease==DiseaseName, "Accuracy"],alternative="greater")$p.value
                       MT_random = wilcox.test(Accuracy.MT[,DiseaseName] - Accuracy.Random.df[Accuracy.Random.df$Disease==DiseaseName,"Accuracy"],alternative="greater")$p.value
                       MT_combined = wilcox.test(Accuracy.MT[,DiseaseName] - Accuracy.combined[,DiseaseName],alternative="greater")$p.value
                       MT_lasso = wilcox.test(Accuracy.MT[,DiseaseName] - Accuracy.Disease[,DiseaseName],alternative="greater")$p.value
                       return(c('lasso_random'=lasso_random,'MT_random'=MT_random, 'MT_combined'=MT_combined, 'MT_lasso'=MT_lasso))
               })
        colnames(tmp.wilcox) <- DiseaseList
        tmp.wilcox <- data.frame(t(tmp.wilcox))

        write.table(tmp.wilcox, file="../../results/GE_CIMP/Acc_pval_wilcox.txt")

        ####
        tmp.t <- sapply(1:length(DiseaseList), function(n)
               {
                       DiseaseName <- DiseaseList[n] 
                       lasso_random = t.test(Accuracy.Disease[,DiseaseName] - Accuracy.Random.df[Accuracy.Random.df$Disease==DiseaseName,"Accuracy"],alternative="greater")$p.value
                       MT_random = t.test(Accuracy.MT[,DiseaseName] - Accuracy.Random.df[Accuracy.Random.df$Disease==DiseaseName,"Accuracy"],alternative="greater")$p.value
                       MT_combined = t.test(Accuracy.MT[,DiseaseName] - Accuracy.combined[,DiseaseName],alternative="greater")$p.value
                       MT_lasso = t.test(Accuracy.MT[,DiseaseName] - Accuracy.Disease[,DiseaseName],alternative="greater")$p.value
                       return(c('lasso_random'=lasso_random,'MT_random'=MT_random, 'MT_combined'=MT_combined, 'MT_lasso'=MT_lasso))
               })
        colnames(tmp.t) <- DiseaseList
        tmp.t <- data.frame(t(tmp.t))

        write.table(tmp.t, file="../../results/GE_CIMP/Acc_pval_t.txt")



        #################################################################################################################################################
        # Signature Comparison
        #################################################################################################################################################
        GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))
        # LASSO
        Signature.Disease <- lapply(1:length(DiseaseList), function(n)
                           {
                                   tmp <- get(load(paste0('../../big_data/Prediction/',DiseaseList[n],
                                                          'log_',log_exp,'_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_balanced_',balanced,'.RData')))
                                   Gene.Signature <- lapply(1:length(tmp), function(n)
                                                            {
                                                                    Dat <- tmp[[n]]
                                                                    Genes <- sapply(1:length(Dat), function(k){  Dat[[k]]$Genes   })
                                                            })

                                   Gene.Sign <- Reduce('cbind', Gene.Signature)
                                   Gene.Sign <- Gene.Sign[-1,]
                                   rownames(Gene.Sign) <- GeneList

                                   return(Gene.Sign)

                           })

        Genes.Signatures <- lapply(1:length(DiseaseList), function(n)
                                   {
                                           tmp <- apply(Signature.Disease[[n]],1,sum)
                                           Genes.Signatures <- rownames(Signature.Disease[[n]])[which(tmp != 0)]
                                   })
        names(Genes.Signatures) <- DiseaseList

        library(VennDiagram)
        size.txt <- c(3,3,3,3,3,    # each set
                      0,0,0,0,0,0,0,0,0,0, # intersection 2 set, size=10
                      0,0,0,0,0,0,0,0,0,0, # intersection 3 set, size=10
                      0,0,0,0,0, # intersection 4 set, size=5
                      3) # intersection 5 set, size=1

        intersect.Signature <- venn.diagram(Genes.Signatures, cat.cex=2.2, cex=size.txt, cat.fontfamily="",
                                        col= Disease.Colors,fill= Disease.Colors,  filename=NULL,
                                        cat.just= list(c(0.5,0.8),c(0,-2.5),c(1,0),c(0,0),c(1,-1.8)))

        pdf('../../results/GE_CIMP/Venn_GE_CIMP.pdf')
        grid.draw(intersect.Signature)
        dev.off()

        ###### Size Intersect <- function(CutOff)
        Genes.Signatures <- lapply(1:length(DiseaseList), function(n)
                                   {
                                           tmp <- apply(Signature.Disease[[n]],1,sum)/3
                                           Genes.Signatures <- rownames(Signature.Disease[[n]])[which(tmp != 0)]
                                           Count <- tmp[tmp !=0]
                                           return(data.frame(Count=Count, Gene=Genes.Signatures))
                                   })
        names(Genes.Signatures) <- DiseaseList

        # CutOff.List <- 0:100
        # Genes.Signatures.Cut <- sapply(1:length(CutOff.List), function(n)
        #                                {
        #                                        Genes.Sign.Cutoff <- lapply(1:length(DiseaseList), function(k)
        #                                                                    {
        #                                                                            Genes.Signatures[[k]][Genes.Signatures[[k]]$Count >= CutOff.List[n], "Gene"]
        #                                                                    })
        #                                        Intersection <- length(Reduce('intersect',Genes.Sign.Cutoff))
        #                                })

        GeneList.intersect <- Reduce('intersect',Genes.Signatures)

        ###
        GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))
        # GeneList <- GeneList[-1]

        Cutoff <- 1/2
        Genes.Count <-  lapply(1:length(DiseaseList), function(n)
                               {
                                       tmp <- apply(Signature.Disease[[n]],1,sum)

                                       Genes.hist <- data.frame(Genes=GeneList, Count=tmp/3)
                                       Genes.hist.nozero <- Genes.hist[ Genes.hist$Count != 0, ]

                                       print(nrow(Genes.hist.nozero))
                                       ### Top100

                                       Genes.hist.order <- Genes.hist.nozero[ order(Genes.hist.nozero$Count, decreasing=T),]
                                       Genes.hist.order <- data.frame(Genes=Genes.hist.order$Genes, Count=Genes.hist.order$Count, Order=1:nrow(Genes.hist.order)) 

                                       #####
                                       TopGenes <- Genes.hist.order$Genes[Genes.hist.order$Count > 100*Cutoff]

                                       return(list(Genes=Genes.hist.order, Top=TopGenes))
                               })

        Genes.Count.m <- Reduce('rbind', lapply(1:length(DiseaseList), function(n)
                                                {   
                                                        tmp <- Genes.Count[[n]]$Genes

                                                        return(data.frame(tmp, Disease=DiseaseList[n]))

                                                }))

        pdf('../../results/GE_CIMP/GenesCount.pdf')
        #ggplot(Genes.Count.m) + geom_point(aes(x=Order,y=Count)) + facet_grid(.~Disease) + geom_hline(yintercept=Cutoff*100, color="red")
        ggplot(Genes.Count.m) + geom_point(aes(x=Order,y=Count)) + facet_grid(.~Disease) 
        dev.off()

        # TopGenes.Disease
        # Intersect.Disease

        ### Combined Signature
        Dat.combined <- get(load(paste0('../../big_data/Prediction/COMBINED_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_method_lasso_all.RData')))

        Genes.Signatures.combined <- Reduce('cbind', lapply(1:length(Dat.combined), function(n)
                                                                     {
                                                                             return( sapply(1:length(Dat.combined[[n]]), function(m){Dat.combined[[n]][[m]]$Genes}))
                                                                     }))


        ### MTL Signature
        Dat <- get(load(paste0('../../big_data/Prediction/MT_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_method_',method,'_all.RData')))
        Genes.Signatures.MTL <- lapply(1:length(DiseaseList), function(k)
                                       {
                                               Reduce('cbind', lapply(1:length(Dat), function(n)
                                                                      {
                                                                              return( sapply(1:length(Dat[[n]]), function(m){Dat[[n]][[m]]$Genes[,k]}))
                                                                      }))
                                       })

        GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))

        # library(VennDiagram)
        # intersect.Signature.MTL <- venn.diagram(Genes.Signatures.MTL.bis, filename=NULL)

        # graphics.off()
        # grid.draw(intersect.Signature.MTL)

        # GeneList.intersect.MTL <- Reduce('intersect',Genes.Signatures.MTL)

        ## Verify if signatures are the same :
        # tmp <- T
        # for (k in 1:(length(Genes.Signatures.MTL)-1))
        # {
        #         tata1 <- apply(Genes.Signatures.MTL[[k]],1,sum)
        #         tata2 <- apply(Genes.Signatures.MTL[[k+1]],1,sum)

        #         if (any(tata1 != tata2))
        #                 tmp <- F
        # }

        ##
        Genes.hist.MTL <- data.frame(Genes= GeneList , Count= apply(Genes.Signatures.MTL[[1]],1,sum)/3)
        Genes.hist.combined <- data.frame(Genes= GeneList , Count= apply(Genes.Signatures.combined,1,sum)/3)

        Genes.hist.MTL.nozero <- Genes.hist.MTL[ Genes.hist.MTL$Count != 0, ]
        Genes.hist.combined.nozero <- Genes.hist.combined[ Genes.hist.combined$Count != 0, ]
        ## 2605 Genes appearing at least once in the signature

        Genes.hist.MTL.order <- Genes.hist.MTL.nozero[ order(Genes.hist.MTL.nozero$Count, decreasing=T),]
        Genes.hist.MTL.order <- data.frame(Genes=Genes.hist.MTL.order$Genes, Count=Genes.hist.MTL.order$Count, Order=1:nrow(Genes.hist.MTL.order))

        Genes.hist.combined.order <- Genes.hist.combined.nozero[ order(Genes.hist.combined.nozero$Count, decreasing=T),]
        Genes.hist.combined.order <- data.frame(Genes=Genes.hist.combined.order$Genes, Count=Genes.hist.combined.order$Count, Order=1:nrow(Genes.hist.combined.order))


        write.table(Genes.hist.MTL.order[,c("Genes","Count")],file="../../results/GE_CIMP/Genes_MT.txt", row.names=F,quote=F)

        pdf('../../results/GE_CIMP/GenesCount_MTL_all.pdf')
        ggplot(Genes.hist.MTL.order) + geom_point(aes(x=Order,y=Count)) 
        dev.off()

        ########
        ## Genes.hist.all
        #######
        Genes.hist.MTL.order <- data.frame(Genes.hist.MTL.order, Disease="Group-Lasso")
        Genes.hist.combined.order <- data.frame(Genes.hist.combined.order, Disease="Combined-Lasso")

        Genes.hist.all <- rbind(Genes.hist.MTL.order, Genes.hist.combined.order, Genes.Count.m)

        Genes.hist.all$Disease <- factor(Genes.hist.all$Disease, levels= c('BLCA','BRCA','COAD','LUAD','STAD','Combined-Lasso','Group-Lasso'))
        save(Genes.hist.all, file="~/Desktop/GeneCount.RData")
        pdf('../../results/GE_CIMP/GenesCount_group_vs_tissue.pdf',16,9)
        # pdf('~/Desktop/GeneCount.pdf')
        print(
              ggplot(Genes.hist.all) + geom_point(aes(x=Order,y=Count)) + facet_grid(.~Disease) + 
              ylab('Frequency') + xlab('Genes') +
              theme(legend.position="none",
                    text = element_text(size=20),
                    panel.grid.major = element_blank(),
                    panel.grid.minor = element_blank(),
                    panel.background = element_blank(),
                    axis.text=element_text(colour="black", size=rel(0.8)),
                    axis.ticks=element_line(colour="black"),
                    panel.border=element_rect(fill=NA, colour="black", size=0.7),
                    axis.title.y=element_text(vjust=0.35),
                    strip.background=element_rect(colour="black", fill="white",size=0.7),
                    axis.line = element_line(colour="black",size=0.7)) +
              geom_hline(yintercept=0) + geom_hline(yintercept=50,color="red",linetype="longdash")
              )
        dev.off()

        Cutoff <- 0.5
        TopGenes.MTL <- Genes.hist.MTL.order$Genes[Genes.hist.MTL.order$Count > 100*Cutoff]
        Genes.MTL <- Genes.hist.MTL.order$Genes[Genes.hist.MTL.order$Count > 1]
        write.table(TopGenes.MTL, file=paste0("../../results/GE_CIMP/MTL_GeneList_all_Cutoff_",Cutoff,".txt"), quote=F, row.names=F, col.names=F)

        Cutoff <- 0.5
        TopGenes.combined <- Genes.hist.combined$Genes[Genes.hist.combined$Count > 100*Cutoff]
        Genes.combined <- Genes.hist.combined$Genes[Genes.hist.combined$Count > 1]
        write.table(TopGenes.combined, file=paste0("../../results/GE_CIMP/combined_GeneList_all_Cutoff_",Cutoff,".txt"), quote=F, row.names=F, col.names=F)


        ### Intersection
        Prediction.signatures <- list('Combined'=TopGenes.combined,'Group'= TopGenes.MTL)

        library(VennDiagram)
        size.txt <- c(3,3,3)

        source('lib/gg_color_hue.R')
        Prediction.Colors <- gg_color_hue(3)

        intersect.Prediction.signatures <- venn.diagram(Prediction.signatures, cat.cex=2.2, cex=size.txt, cat.fontfamily="",
                                        col= Prediction.Colors[2:3],fill= Prediction.Colors[2:3],  filename=NULL,
                                        cat.just= list(c(0,-3),c(1,-3)))

        pdf('../../results/GE_CIMP/Venn_Predictions.pdf')
        #graphics.off()
        grid.draw(intersect.Prediction.signatures)
        dev.off()

        write.table(intersect(TopGenes.MTL, TopGenes.combined), file=paste0("../../results/GE_CIMP/Intersection_GeneList_all_Cutoff_",Cutoff,".txt"), quote=F, row.names=F, col.names=F )


        #############
        # intersect TopGenes.Disease and TopGenes.MTL 
        ### Size is 11 1 6, intersection = 0
        ### intersection with TopGenes.MTL = 7,0,5

        ##############
        # Gene Ontology
        Cutoff <- 0.5
        GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))
        TopGenes.MTL <- read.table(paste0("../../results/GE_CIMP/MTL_GeneList_all_Cutoff_",Cutoff,".txt"),header=F)
        TopGenes.combined <- read.table(paste0("../../results/GE_CIMP/combined_GeneList_all_Cutoff_",Cutoff,".txt"),header=F)
        Intersection.Predictions <- read.table(paste0("../../results/GE_CIMP/Intersection_GeneList_all_Cutoff_",Cutoff,".txt"),header=F)

        # save(TopGenes.MTL, file="~/Desktop/GO_CIMP/GE_CIMP_Genes.RData")
        # save(GeneList, file="~/Desktop/GO_CIMP/GE_CIMP_Universe.RData")

        library(biomaRt)
        mart <- useMart(biomart = "ensembl", dataset="hsapiens_gene_ensembl")

        Universe <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= GeneList, mart=mart)[,1]
        Signature.MTL <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= TopGenes.MTL, mart=mart)[,1]
        Signature.combined <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= TopGenes.combined, mart=mart)[,1]
        Signature.Intersection <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= Intersection.Predictions, mart=mart)[,1]

        library("clusterProfiler")
        enrich.MTL <- enrichGO(Signature.MTL, organism="human", ont="BP", pvalueCutoff=0.05, universe = Universe, readable=T)
        enrich.combined <- enrichGO(Signature.combined, organism="human", ont="BP", pvalueCutoff=0.05, universe = Universe, readable=T)
        enrich.Intersection <- enrichGO(Signature.Intersection, organism="human", ont="BP", pvalueCutoff=0.05, universe = Universe, readable=T)

        write.table(summary(enrich.MTL), file="../../results/GE_CIMP/GO_MTL.txt", row.names=F, sep="\t", quote=F)
        write.table(summary(enrich.combined), file="../../results/GE_CIMP/GO_combined.txt", row.names=F, sep="\t", quote=F)
        write.table(summary(enrich.Intersection), file="../../results/GE_CIMP/GO_intersection.txt", row.names=F, sep="\t", quote=F)

        pdf("../../results/GE_CIMP/GO_MTL.pdf")
        print(plot(enrich.MTL, showCategory=10, by="geneRatio"))
        dev.off()
        
        pdf("../../results/GE_CIMP/GO_combined.pdf")
        print(plot(enrich.combined, showCategory=10, by="geneRatio"))
        dev.off()
        
        pdf("../../results/GE_CIMP/GO_intersection.pdf")
        print(plot(enrich.Intersection, showCategory=10, by="geneRatio"))
        dev.off()



        #####
        # Gene Ontology on the intersection

        ################################################################################################################
        # do Heatmap on the genes MTL 
        ################################################################################################################
        Cutoff <- 0.5
        TopGenes.MTL <- read.csv(paste0("../../results/GE_CIMP/MTL_GeneList_all_Cutoff_",Cutoff,".txt"),header=F)
        TopGenes.MTL <- as.character(TopGenes.MTL[,1])

        Dat.CIMP <- lapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   return(out)
                           })

        log_exp <- T
        eps <- 2^-8

        Dat.GE <- lapply(1:length(DiseaseList), function(n)
                         { 
                                 print(DiseaseList[n])
                                 #out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEprocessed.RData')))
                                 out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEter.RData')))
                                 if (log_exp)
                                 {
                                         out <- log2(out)
                                         out[out==-Inf] <- log2(eps)
                                 }
                                 return(out)
                         })

        names_Meth <- lapply(1:length(DiseaseList), function(n){ substring(names(Dat.CIMP[[n]]),1,12)})
        names_GE <- lapply(1:length(DiseaseList), function(n){substring(colnames(Dat.GE[[n]]),1,12)})

        common_names <- lapply(1:length(DiseaseList), function(n){intersect(names_Meth[[n]],names_GE[[n]])})

        GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))
        GE.processed.MTL <- lapply(1:length(DiseaseList), function(n)
                               {
                                       tmp <- Dat.GE[[n]][,match(common_names[[n]], names_GE[[n]])]
                                       rownames(tmp) <- GeneList
                                       tmp <- tmp[TopGenes.MTL,   ]

                                       return(tmp)
                               })

        CIMP.processed <- lapply(1:length(DiseaseList), function(n)
                                 {
                                         tmp <- matrix(Dat.CIMP[[n]][match(common_names[[n]],names_Meth[[n]])],ncol=1)
                                         tmp[tmp==1] <- -1
                                         tmp[tmp==2] <- 1
                                         return(tmp)
                                 })

        Matrix.Gene.Status <- sapply(1:length(TopGenes.MTL), function(k)
                              {
                                      Out <- sapply(1:length(DiseaseList), function(n)
                                                    {
                                                            CIMP.Neg <- GE.processed.MTL[[n]][k, CIMP.processed[[n]]==-1 ]
                                                            CIMP.Pos <- GE.processed.MTL[[n]][k, CIMP.processed[[n]]==1 ]

                                                            if (median(CIMP.Pos) - median(CIMP.Neg) > 0)
                                                            {
                                                                    return(1)
                                                            } else {
                                                                    return(-1)
                                                            }
                                                    })

                                      return(Out)
                              })

        Matrix.Gene.Status <- sapply(1:length(TopGenes.MTL), function(k)
                              {
                                      Out <- sapply(1:length(DiseaseList), function(n)
                                                    {
                                                            CIMP.Neg <- GE.processed.MTL[[n]][k, CIMP.processed[[n]]==-1 ]
                                                            CIMP.Pos <- GE.processed.MTL[[n]][k, CIMP.processed[[n]]==1 ]

                                                            P.val.sup <- t.test(CIMP.Pos, CIMP.Neg, alternative="greater")$p.value
                                                            P.val.neg <- t.test(CIMP.Pos, CIMP.Neg, alternative="less")$p.value

                                                            if (P.val.sup < 0.05)
                                                            {
                                                                    return(1)
                                                            } else if (P.val.neg < 0.05) {
                                                                    return(-1)
                                                            } else {
                                                                    return(0)
                                                            }
                                                    })

                                      return(Out)
                              })

        Gene.Status <- sapply(1:ncol(Matrix.Gene.Status), function(n)
                              {
                                      Gene.Info <- Matrix.Gene.Status[,n]

                                      if (all(Gene.Info %in% c(0,1)))
                                      {
                                              return("Pos")
                                      } else if (all(Gene.Info %in% c(0,-1)))
                                      {
                                              return("Neg")
                                      } else {
                                              return("Undetermined")
                                      }
                              })
        names(Gene.Status) <- TopGenes.MTL

        names(Gene.Status)[Gene.Status=="Pos"]
        names(Gene.Status)[Gene.Status=="Neg"]
        names(Gene.Status)[Gene.Status=="Undetermined"]

        ###### Testing
        DiseaseNum <- 2
        library(reshape2)
        library(ggplot2)

        GE_CIMP.full <- NULL
        for (DiseaseNum in 1:length(DiseaseList))
        {
                toto <- data.frame(t(GE.processed.MTL[[DiseaseNum]]))
                toto.m <- melt(toto)

                GE_CIMP.df <- data.frame(GE=toto.m$value , Genes=toto.m$variable, Gene.Class=Gene.Status[toto.m$variable] , CIMP=CIMP.processed[[DiseaseNum]],Disease=DiseaseList[DiseaseNum])
                GE_CIMP.full <- rbind(GE_CIMP.full, GE_CIMP.df)
        }

        # ggplot(GE_CIMP.df) + geom_boxplot(aes(x=Genes, y=GE, fill=factor(CIMP)))
        pdf('../../results/GE_CIMP/GE_boxplot_TopGenes.pdf')
        ggplot(GE_CIMP.full) + geom_boxplot(aes(x=Genes, y=GE, fill=factor(CIMP)))+ facet_grid(Disease~.) + theme(axis.text.x=element_text(angle=90, hjust=1))
        dev.off()

        library(gplots)
        library(plyr)
        for (DiseaseNum in 1:length(DiseaseList))
        {

                Dat <- GE.processed.MTL[[DiseaseNum]]
                Dat <- Dat[names(sort(Gene.Status)),order(CIMP.processed[[DiseaseNum]])]

                ColSideColors <- factor(sort(CIMP.processed[[DiseaseNum]]))
                ColSideColors <- as.character(revalue(ColSideColors, c('-1' = "#225ea8",
                                                                       "1"  = "gold2")))

                # CIMP_colours <- c('Negative' = "#225ea8",
                #                   'Positive' = "gold2")


                RowSideColors <- factor(sort(Gene.Status))
                RowSideColors <- as.character(revalue(RowSideColors, c('Neg'='#1a9641',
                                                          'Pos'='#d7191c',
                                                          'Undetermined'='black')))

                # keyVal  <- (DiseaseNum == 1)
                keyVal  <- F

                pdf(paste0('../../results/GE_CIMP/Heatmap_',DiseaseList[DiseaseNum],'.pdf'))
                heatmap.2(Dat,hclust=function(x){hclust(x,method="ward.D")}, scale="row", dendrogram="none", 
                          Rowv=F,Colv=F, trace="none", ColSideColors=ColSideColors, RowSideColors=RowSideColors, 
                          labRow=F, labCol=F,key=keyVal,
                          col=greenred(100), breaks=seq(-2.5,2.5,length.out=101))
                dev.off()

                # pdf('~/Desktop/Heatmap.pdf')
                # heatmap.2(Dat,hclust=function(x){hclust(x,method="ward.D")}, scale="row", dendrogram="none", 
                #           Rowv=F,Colv=F, trace="none", ColSideColors=ColSideColors, RowSideColors=RowSideColors, 
                #           labRow=F, labCol=F,key=keyVal,
                #           col=greenred(100), breaks=seq(-2.5,2.5,length.out=101))
                # dev.off()


        }

        ################################################################################################################
        # do Heatmap on the genes intersection 
        ################################################################################################################
        Cutoff <- 0.5
        TopGenes.Intersection <- read.csv(paste0("../../results/GE_CIMP/Intersection_GeneList_all_Cutoff_",Cutoff,".txt"),header=F)
        TopGenes.Intersection <- as.character(TopGenes.Intersection[,1])

        Dat.CIMP <- lapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   return(out)
                           })

        log_exp <- T
        eps <- 2^-8

        Dat.GE <- lapply(1:length(DiseaseList), function(n)
                         { 
                                 print(DiseaseList[n])
                                 #out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEprocessed.RData')))
                                 out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEter.RData')))
                                 if (log_exp)
                                 {
                                         out <- log2(out)
                                         out[out==-Inf] <- log2(eps)
                                 }
                                 return(out)
                         })

        names_Meth <- lapply(1:length(DiseaseList), function(n){ substring(names(Dat.CIMP[[n]]),1,12)})
        names_GE <- lapply(1:length(DiseaseList), function(n){substring(colnames(Dat.GE[[n]]),1,12)})

        common_names <- lapply(1:length(DiseaseList), function(n){intersect(names_Meth[[n]],names_GE[[n]])})

        GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))
        GE.processed.Intersection <- lapply(1:length(DiseaseList), function(n)
                               {
                                       tmp <- Dat.GE[[n]][,match(common_names[[n]], names_GE[[n]])]
                                       rownames(tmp) <- GeneList
                                       tmp <- tmp[TopGenes.Intersection,   ]

                                       return(tmp)
                               })

        CIMP.processed <- lapply(1:length(DiseaseList), function(n)
                                 {
                                         tmp <- matrix(Dat.CIMP[[n]][match(common_names[[n]],names_Meth[[n]])],ncol=1)
                                         tmp[tmp==1] <- -1
                                         tmp[tmp==2] <- 1
                                         return(tmp)
                                 })

        # Matrix.Gene.Status <- sapply(1:length(TopGenes.Intersection), function(k)
        #                       {
        #                               Out <- sapply(1:length(DiseaseList), function(n)
        #                                             {
        #                                                     CIMP.Neg <- GE.processed.Intersection[[n]][k, CIMP.processed[[n]]==-1 ]
        #                                                     CIMP.Pos <- GE.processed.Intersection[[n]][k, CIMP.processed[[n]]==1 ]

        #                                                     if (median(CIMP.Pos) - median(CIMP.Neg) > 0)
        #                                                     {
        #                                                             return(1)
        #                                                     } else {
        #                                                             return(-1)
        #                                                     }
        #                                             })

        #                               return(Out)
        #                       })

        Matrix.Gene.Status <- sapply(1:length(TopGenes.Intersection), function(k)
                              {
                                      Out <- sapply(1:length(DiseaseList), function(n)
                                                    {
                                                            CIMP.Neg <- GE.processed.Intersection[[n]][k, CIMP.processed[[n]]==-1 ]
                                                            CIMP.Pos <- GE.processed.Intersection[[n]][k, CIMP.processed[[n]]==1 ]

                                                            P.val.sup <- t.test(CIMP.Pos, CIMP.Neg, alternative="greater")$p.value
                                                            P.val.neg <- t.test(CIMP.Pos, CIMP.Neg, alternative="less")$p.value

                                                            if (P.val.sup < 0.05)
                                                            {
                                                                    return(1)
                                                            } else if (P.val.neg < 0.05) {
                                                                    return(-1)
                                                            } else {
                                                                    return(0)
                                                            }
                                                    })

                                      return(Out)
                              })

        Gene.Status <- sapply(1:ncol(Matrix.Gene.Status), function(n)
                              {
                                      Gene.Info <- Matrix.Gene.Status[,n]

                                      if (all(Gene.Info %in% c(0,1)))
                                      {
                                              return("Pos")
                                      } else if (all(Gene.Info %in% c(0,-1)))
                                      {
                                              return("Neg")
                                      } else {
                                              return("Undetermined")
                                      }
                              })
        names(Gene.Status) <- TopGenes.Intersection

        names(Gene.Status)[Gene.Status=="Pos"]
        names(Gene.Status)[Gene.Status=="Neg"]
        names(Gene.Status)[Gene.Status=="Undetermined"]

        write.table(Gene.Status, file="../../results/GE_CIMP/Gene_Status_Intersection.txt")

        ###### Testing
        # DiseaseNum <- 2
        library(reshape2)
        library(ggplot2)

        library(gplots)
        library(plyr)
        for (DiseaseNum in 1:length(DiseaseList))
        {

                Dat <- GE.processed.Intersection[[DiseaseNum]]
                Dat <- Dat[names(sort(Gene.Status)),order(CIMP.processed[[DiseaseNum]])]

                ColSideColors <- factor(sort(CIMP.processed[[DiseaseNum]]))
                ColSideColors <- as.character(revalue(ColSideColors, c('-1' = "#225ea8",
                                                                       "1"  = "gold2")))

                # CIMP_colours <- c('Negative' = "#225ea8",
                #                   'Positive' = "gold2")


                RowSideColors <- factor(sort(Gene.Status))
                RowSideColors <- as.character(revalue(RowSideColors, c('Neg'='#1a9641',
                                                          'Pos'='#d7191c',
                                                          'Undetermined'='#d7191c')))
                                                         # 'Undetermined'='black')))

                # keyVal  <- (DiseaseNum == 1)
                keyVal  <- F

                pdf(paste0('../../results/GE_CIMP/Heatmap_Intersection_',DiseaseList[DiseaseNum],'.pdf'))
                heatmap.2(Dat,hclust=function(x){hclust(x,method="ward.D")}, scale="row", dendrogram="none", 
                          Rowv=F,Colv=F, trace="none", ColSideColors=ColSideColors, RowSideColors=RowSideColors, 
                          labRow=F, labCol=F,key=keyVal,
                          col=greenred(100), breaks=seq(-2.5,2.5,length.out=101))
                dev.off()

        }

#############################################################################################################################################################################################################################
#############################################################################################################################################################################################################################
#############################################################################################################################################################################################################################
#############################################################################################################################################################################################################################
#############################################################################################################################################################################################################################
#############################################################################################################################################################################################################################
#############################################################################################################################################################################################################################

        # GeneClass <- c('Pos','Neg','Undetermined')
        # for (Class in GeneClass)
        # {
        #         pdf(paste0('../../results/GE_CIMP/GE_boxplot_TopGenes_',Class,'.pdf'))
        #         ggplot(GE_CIMP.full[GE_CIMP.full$Gene.Class==Class,]) + geom_boxplot(aes(x=Disease, y=GE, fill=factor(CIMP)))+ facet_grid(Genes~.,scales="free_y") 
        #         dev.off()
        # }

        # library(gplots)
        # for (Class in GeneClass)
        # {
        #         for (DiseaseNum in 1:length(DiseaseList))
        #         {
        #                 ColSideColors <- CIMP.processed[[DiseaseNum]]
        #                 ColSideColors[CIMP.processed[[DiseaseNum]]==-1] <- "white"
        #                 ColSideColors[CIMP.processed[[DiseaseNum]]==+1] <- "black"

        #                 pdf(paste0('../../results/GE_CIMP/Heatmap_',DiseaseList[DiseaseNum],'_',Class,'.pdf'))
        #                 heatmap.2(GE.processed.MTL[[DiseaseNum]][names(Gene.Status)[Gene.Status==Class],],scale="row", trace="none", col=redgreen(100), ColSideColors=ColSideColors, hclust=function(x){hclust(x,method="ward.D")}, breaks=seq(-2.5,2.5,length.out=101))
        #                 dev.off()
        #         }
        # }


}
