predict_CIMP_GE_all = function (DiseaseList, var.thresh, CIMP.Number=2, centered=T, scaled=T, intercept=T, n.folds=3, bootstrap=100, cores=10, log_exp=T, eps=2^-16, balanced=T) 
{

        # var.thresh <- 5
        # CIMP.Number <- 2
        # centered <- T
        # scaled <- T
        # intercept <- T
        # n.folds <- 3
        # bootstrap <- 100
        # cores <- 10
        # log_exp <- T
        # eps <- 2^-16
        # balanced <- T

        Dat.CIMP <- lapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   return(out)
                           })

        Disease.Length <- sapply(1:length(DiseaseList), function(n)
                           {
                                   out <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                   out.length <- length(out)
                                   return(out.length)
                           })
        names(Disease.Length) <- DiseaseList

        Dat.GE <- lapply(1:length(DiseaseList), function(n)
                         { 
                                 print(DiseaseList[n])
                                 #out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEprocessed.RData')))
                                 out <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseList[n],'/CancerousLevel3GEter.RData')))
                                 if (log_exp)
                                 {
                                         out <- log2(out)
                                         out[out==-Inf] <- log2(eps)
                                 }
                                 return(out)
                         })

        names_Meth <- lapply(1:length(DiseaseList), function(n){ substring(names(Dat.CIMP[[n]]),1,12)})
        names_GE <- lapply(1:length(DiseaseList), function(n){substring(colnames(Dat.GE[[n]]),1,12)})

        common_names <- lapply(1:length(DiseaseList), function(n){intersect(names_Meth[[n]],names_GE[[n]])})
        size_processed <- sapply(common_names, length)
        names(size_processed) <- DiseaseList

        CIMP.processed <- lapply(1:length(DiseaseList), function(n)
                                 {
                                         tmp <- matrix(Dat.CIMP[[n]][match(common_names[[n]],names_Meth[[n]])],ncol=1)
                                         tmp[tmp==1] <- -1
                                         tmp[tmp==2] <- 1
                                         return(tmp)
                                 })

        GE.processed <- lapply(1:length(DiseaseList), function(n)
                               {
                                       return(Dat.GE[[n]][,match(common_names[[n]], names_GE[[n]])])
                               })

        #### Multi-task
        bootstrap <- 100
        cores <- 10
        library(doParallel)
        registerDoParallel(cores=cores)

        Dat <- foreach(i=1:bootstrap) %dopar%
        {
                print(i)

                ##########
                ## bias partition?
                partition <- lapply(1:length(DiseaseList), function(n)
                                    {
                                            if (balanced)
                                            {
                                                    Index.pos <- which(CIMP.processed[[n]] == +1)
                                                    Index.neg <- which(CIMP.processed[[n]] == -1)

                                                    partition.pos <- split(sample(Index.pos), seq(n.folds))
                                                    partition.neg <- split(sample(Index.neg), seq(n.folds))

                                                    partition <- lapply(1:n.folds, function(k){c(partition.pos[[k]], partition.neg[[k]])})

                                            } else {
                                                    n.length <- ncol(GE.processed[[n]])
                                                    partition <- split( sample(seq(n.length)), seq(n.folds))
                                            }
                                    })

                tmp <- lapply(1:n.folds, function(n)
                              {
                                      print(paste0('fold=',n,'/',n.folds))

                                      ######################################
                                      # Training
                                      GE.processed.train <- lapply(1:length(DiseaseList), function(k)
                                                                   {
                                                                           tmp <- t(GE.processed[[k]][,-partition[[k]][[n]]])
                                                                           return(tmp)
                                                                   })

                                      CIMP.processed.train <- lapply(1:length(DiseaseList), function(k)
                                                                     {
                                                                             CIMP.processed[[k]][-partition[[k]][[n]],,drop=F]
                                                                     })

                                      #######################################
                                      # Testing
                                      GE.processed.test <- lapply(1:length(DiseaseList), function(k)
                                                                  {
                                                                          tmp <- t(GE.processed[[k]][,partition[[k]][[n]]])
                                                                          return(tmp)
                                                                  })

                                      CIMP.processed.test <- lapply(1:length(DiseaseList), function(k)
                                                                    {
                                                                            CIMP.processed[[k]][partition[[k]][[n]],,drop=F]
                                                                    })

                                      #### Creating solo multitask 
                                      sample_size_train <- sapply(CIMP.processed.train, nrow)
                                      sample_size_test <- sapply(CIMP.processed.test, nrow)
                                      y_train <- Reduce('rbind',CIMP.processed.train)
                                      y_test <- Reduce('rbind',CIMP.processed.test)

                                      # x_train <- matrix(0, nrow=nrow(y_train), ncol=length(DiseaseList)*ncol(GE.processed.train[[1]]))
                                      # x_test <- matrix(0, nrow=nrow(y_test), ncol=length(DiseaseList)*ncol(GE.processed.test[[1]]))

                                      #######
                                      x_train <- Reduce('rbind',GE.processed.train)
                                      x_test <- Reduce('rbind',GE.processed.test)

                                      y_train <- as.vector(y_train)
                                      Dat.train <- list(x= x_train, y=y_train)

                                      #### Calculating
                                      #################
                                      # ##### using glmnet
                                      library(glmnet)

                                      #### create cv.foldid i.e for crossval put a balanced number of sample from each disease
                                      Disease.index <- cumsum(c(0,sapply(GE.processed.train,nrow)))
                                      Dis <- rep("Disease",max(Disease.index))
                                      for (n in 1:length(DiseaseList))
                                      {
                                              Dis[(Disease.index[n]+1):Disease.index[n+1]] <- DiseaseList[n]
                                      }

                                      n.folds.cv <- 3

                                      partition.pos <- lapply(1:length(DiseaseList), function(n)
                                                          {
                                                                  Index.pos <- which(y_train==1 & Dis==DiseaseList[n])
                                                                  return(split(sample(Index.pos), seq(n.folds.cv)))
                                                          })

                                      partition.neg <- lapply(1:length(DiseaseList), function(n)
                                                          {
                                                                  Index.neg <- which(y_train==-1 & Dis==DiseaseList[n])
                                                                  return(split(sample(Index.neg), seq(n.folds.cv)))
                                                          })


                                      cv.partition <- lapply(1:n.folds.cv, function(n)
                                                             {
                                                                     pos.index <- Reduce("c",lapply(1:length(DiseaseList),function(k){partition.pos[[k]][[n]]}))
                                                                     neg.index <- Reduce("c",lapply(1:length(DiseaseList),function(k){partition.neg[[k]][[n]]}))
                                                                     c(pos.index, neg.index)
                                                             })

                                      cv.foldid <- rep(0,length(y_train))
                                      for (k in 1:length(cv.partition))
                                      {
                                              cv.foldid[cv.partition[[k]]] <- k
                                      }

                                      ## to check
                                      # table(cv.foldid, Dis)

                                      ##### do crossval
                                      cvfit <- cv.glmnet(x_train,y_train, alpha=1, foldid=cv.foldid, family="binomial")

                                      #cvfit <- cv.glmnet(x_train,y_train, alpha=1, nfolds=3, family="binomial")

                                      #####
                                      lambda.opt <- cvfit$lambda.min

                                      predictor <- glmnet(x_train,y_train, alpha=1, family="binomial", lambda=lambda.opt)

                                      Y.predict <- predict(predictor, x_test, type="class")

                                      #### Global Accuracy
                                      Acc <- sum(Y.predict==y_test)/length(y_test)

                                      ######## Acc.Disease
                                      test.Index <- cumsum(c(0,sapply(CIMP.processed.test,length)))
                                      Pred.Disease <- lapply(1:length(DiseaseList), function(n)
                                                             {
                                                                     Out <- Y.predict[(test.Index[n]+1):test.Index[n+1]]
                                                             })

                                      Acc.Disease <- sapply(1:length(DiseaseList), function(n)
                                                            {
                                                                    tmp <- CIMP.processed.test[[n]]
                                                                    sum(Pred.Disease[[n]] == tmp)/length(tmp)
                                                            })

                                      #### Genes Signature
                                      Genes <- which(coef(predictor)!=0)

                                      ## Remove intercept
                                      Genes <- Genes[-1]
                                      Genes <- Genes - 1

                                      # Index vector of non-zero coefficients
                                      Genes.Disease <- rep(0, ncol(GE.processed.train[[1]]))
                                      Genes.Disease[Genes] <- 1

                                      ###
                                      return(list(Acc=Acc, full.Acc=Acc.Disease, Genes=Genes.Disease))

                              })

                return(tmp)
        }

        #save(Dat, file=paste0('../../big_data/Prediction/MT_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'.RData'))
        save(Dat, file=paste0('../../big_data/Prediction/COMBINED_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_method_lasso_all.RData'))


}
