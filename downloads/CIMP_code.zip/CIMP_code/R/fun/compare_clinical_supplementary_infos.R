Clinical.Infos <- list()

### BLCA
Clinical.Infos[["BLCA"]] <- c('birth_days_to',
                              'weight_kg_at_diagnosis',
                              'tobacco_smoking_history_indicator',
                              'histologic_subtype',
                              'ajcc_tumor_pathologic_pt',
                              'ajcc_nodes_pathologic_pn',
                              'ajcc_metastasis_pathologic_pm',
                              'histological_type',
                              'neoplasm_histologic_grade')

### BRCA
Clinical.Infos[["BRCA"]] <- c('birth_days_to',
                              'ajcc_tumor_pathologic_pt',
                              'ajcc_nodes_pathologic_pn',
                              'ajcc_metastasis_pathologic_pm',
                              'er_status_by_ihc',
                              'pr_status_by_ihc',
                              'her2_status_by_ihc')


### COAD
Clinical.Infos[["COAD"]] <- c('birth_days_to',
                              'weight_kg_at_diagnosis',
                              'ajcc_tumor_pathologic_pt',
                              'ajcc_nodes_pathologic_pn',
                              'ajcc_metastasis_pathologic_pm',
                              'microsatellite_instability')

### LUAD ### TODO
Clinical.Infos[["LUAD"]] <- c('birth_days_to',
                              'ajcc_tumor_pathologic_pt',
                              'ajcc_nodes_pathologic_pn',
                              'ajcc_metastasis_pathologic_pm')

### STAD
Clinical.Infos[["STAD"]] <- c('birth_days_to',
                              'ajcc_tumor_pathologic_pt',
                              'ajcc_nodes_pathologic_pn',
                              'ajcc_metastasis_pathologic_pm')


TumorSizes <- c('T0'='No Tumor',
                'T1'='<2cm',
                'T1a'='<2cm',
                'T1b'='<2cm',
                'T2'='between 2cm and 4cm',
                'T2a'='between 2cm and 4cm',
                'T2b'='between 2cm and 4cm',
                'T3'='>4cm',
                'T4a'='>4cm',
                'T4b'='>4cm',
                'TX'=NA)

Nodes <- c('N0'='No LymphNodes',
                'N1'='LymphNode',
                'N2'='LymphNode',
                'N3'='LymphNode',
                'N3a'='LymphNode',
                'N3b'='LymphNode',
                'NX'=NA)

Metastasis <- c('M0'='No Metastasis',
                'M1'='Metastasis',
                'MX'=NA)




