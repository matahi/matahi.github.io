predict_CIMP_GE = function (DiseaseName, var.thresh, CIMP.Number=2,centered=T, scaled=F, intercept=T, n.folds=3, bootstrap=100, cores=10,log_exp=T,eps=2^-16, balanced=T) 
{

        # DiseaseName <- "LUAD"
        # var.thresh <- 5
        # CIMP.Number <- 2
        # centered <- T
        # scaled <- T
        # intercept <- T
        # n.folds <- 3
        # bootstrap <- 100
        # cores <- 10
        # log_exp <- T
        # eps <- 2^-16
        # balanced <- T

        # library(spams, lib.loc="~/Desktop/Pkg")

        Dat.CIMP <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseName,'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
        Dat.GE <- get(load(paste0('../../data/processed/GeneExpression/TCGA/',DiseaseName,'/CancerousLevel3GEter.RData')))

        if (log_exp)
        {
                Dat.GE <- log2(Dat.GE)
                Dat.GE[Dat.GE==-Inf] <- log2(eps)
        }


        names_Meth <- substring(names(Dat.CIMP),1,12)
        names_GE <- substring(colnames(Dat.GE),1,12)

        common_names <- intersect(names_Meth,names_GE)

        CIMP.processed <- matrix(Dat.CIMP[match(common_names,names_Meth)],ncol=1)
        tmp <- CIMP.processed
        CIMP.processed[tmp == 1] <- -1
        CIMP.processed[tmp == 2] <- 1
        GE.processed <- Dat.GE[, match(common_names,names_GE)]

        ######
        # bootstrap <- 100
        # centered <- T
        # scaled <- T
        # intercept <- T

        ### Parallelize
        # cores <- 10
        library(doParallel)
        registerDoParallel(cores=cores)
        library(glmnet)

        #Dat <- lapply(1:bootstrap, function(i) 
        #Dat <- list()
        #for (i in 1:bootstrap)

        Dat <- foreach(i=1:bootstrap) %dopar%
        {
                print(i)

                ######
                ## Bias partition?
                if (balanced)
                {
                        Index.pos <- which(CIMP.processed == +1)
                        Index.neg <- which(CIMP.processed == -1)

                        partition.pos <- split(sample(Index.pos), seq(n.folds))
                        partition.neg <- split(sample(Index.neg), seq(n.folds))

                        partition <- lapply(1:n.folds, function(n){c(partition.pos[[n]], partition.neg[[n]])})
                } else {

                        partition <- split(sample(seq(ncol(GE.processed))), seq(n.folds))
                }


                Accuracy.fold <- lapply(seq(n.folds), function(n)
                                        {
                                                GE.processed.train <- GE.processed[, -partition[[n]]]
                                                CIMP.processed.train <- CIMP.processed[-partition[[n]],,drop=F]

                                                x_train <- t(GE.processed.train)
                                                y_train <- CIMP.processed.train

                                                GE.processed.test <- GE.processed[, partition[[n]]]
                                                CIMP.processed.test <- CIMP.processed[ partition[[n]], , drop=F]

                                                x_test <- t(GE.processed.test)
                                                y_test <- CIMP.processed.test

                                                ###############
                                                #
                                                if (balanced)
                                                {
                                                        Index.pos <- which(y_train == +1)
                                                        Index.neg <- which(y_train == -1)


                                                        partition.pos <- split(sample(Index.pos), seq(n.folds))
                                                        partition.neg <- split(sample(Index.neg), seq(n.folds))

                                                        cv.partition <- lapply(1:n.folds, function(n){c(partition.pos[[n]], partition.neg[[n]])})

                                                        cv.foldid <- rep(0,length(y_test))
                                                        for (k in 1:length(cv.partition))
                                                        {
                                                                cv.foldid[cv.partition[[k]]] <- k
                                                        }
                                                }


                                                ###############
                                                if (balanced)
                                                {
                                                        lambda.lasso <- cv.glmnet(x_train,y_train, alpha=1, foldid=cv.foldid, family="binomial")$lambda.min
                                                } else {
                                                        lambda.lasso <- cv.glmnet(x_train,y_train, alpha=1, nfolds=3, family="binomial")$lambda.min
                                                }
                                                predictor.lasso <- glmnet(x_train,y_train, alpha=1, lambda=lambda.lasso, family="binomial")
                                                Genes <- as.vector(coef(predictor.lasso) !=0)

                                                ##### VERIFY
                                                Y_proba.lasso <- predict(predictor.lasso, newx=x_test, s=lambda.lasso,type="response")

                                                Y_predict.lasso <- sapply(1:length(Y_proba.lasso), function(n)
                                                                          { 
                                                                                  if (Y_proba.lasso[n] > 0.5)
                                                                                  {
                                                                                          return(1)
                                                                                  } else {
                                                                                          return(-1)
                                                                                  }
                                                                          })

                                                ###
                                                Acc <- sum(Y_predict.lasso==y_test)/length(y_test)

                                                ConfMat <- table(Y_predict.lasso, y_test)
                                                # print(dim(ConfMat))

                                                if (nrow(ConfMat)==1)
                                                {
                                                        if (unique(Y_predict.lasso)==-1)
                                                        {
                                                                Sens <- 0
                                                                PPV <- 0
                                                                Spe <- ConfMat[1,1]/sum(ConfMat[,1])
                                                        } else if (unique(Y_predict.lasso)==1)
                                                        {
                                                                Sens <- ConfMat[1,2]/sum(ConfMat[,2])
                                                                PPV <- ConfMat[1,2]/sum(ConfMat[1,])
                                                                Spe <- 0
                                                        }
                                                } else {
                                                        Sens <- ConfMat[2,2]/sum(ConfMat[,2])
                                                        PPV <- ConfMat[2,2]/sum(ConfMat[2,])
                                                        Spe <- ConfMat[1,1]/sum(ConfMat[,1])
                                                }

                                                return(list(Acc=Acc, Sens=Sens, Spe=Spe, PPV=PPV, Genes=Genes))

                                                # library('ROCR')
                                                # pred <- prediction(Y_proba.lasso, y_test)

                                                # perf.AUC <- performance(pred,'tpr','fpr')
                                                # # plot(perf.AUC)
                                                # auc <- unlist(slot(performance(pred,'auc'),'y.values'))

                                                # perf.PR <- performance(pred,'prec','rec')
                                                # plot(perf.PR)
                                                # #auc <- unlist(slot(performance(pred,''),'y.values'))
                                                # # pr <- unlist(slot(performance(pred,'prec','rec'),'y.values'))
                                                # AUC <- auc

                                                #return(list(Acc=Acc, AUC=AUC))
                                        })

                return(Accuracy.fold)
                # Dat[[i]] <- Accuracy.fold

        }

        save(Dat, file=paste0('../../big_data/Prediction/',DiseaseName,'log_',log_exp,'_scaled_',scaled,'_centered_',centered,'_intercept_',intercept,'_bootstrap_',bootstrap,'_balanced_',balanced,'.RData'))

}
