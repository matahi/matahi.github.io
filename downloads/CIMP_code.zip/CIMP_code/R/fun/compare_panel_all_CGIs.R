compare_panel_all_CGIs = function (DiseaseList,var.thresh=1) {

        ###
        DiseaseList <- c('BLCA','BRCA','LUAD','COAD','STAD')
        var.thresh <- 5
        ###

        Meth.Var <- lapply(1:length(DiseaseList), function(k)
                                       {
                                               CGI.Var <- get(load(paste0('../../big_data/CGIs/',DiseaseList[k],'_Var.RData')))
                                               CIMP <- (CGI.Var > quantile(na.omit(CGI.Var), 1-var.thresh/100))
                                               return(CIMP)
                                       })
        names(Meth.Var) <- DiseaseList

        Dat <- Reduce('cbind', Meth.Var)

        Common.Index <- which(apply(Dat,1,all))
        NonCIMP <- apply(Dat,1,function(x){!any(x)})
        colnames(Dat) <- DiseaseList

        Dat.bis <- Dat*1

        source('lib/heatmap.3.R')
        pdf(paste0('../../results/CIMP/1_InterCancer/CIMP_Signature_Var',var.thresh,'.pdf'))
        heatmap.3(t(Dat.bis[!NonCIMP,]),dendrogram="none", distfun=function(x){dist(x,method="binary")}, hclustfun=function(x){hclust(x,method="ward")})
        dev.off()

        #############
        Meth.CGIs <- lapply(1:length(Meth.Var), function(n)
                            {
                                    return(which(Meth.Var[[n]]))
                            })
        names(Meth.CGIs) <- DiseaseList

        # sapply(Clusters.DiseaseList,length)

        # library(VennDiagram)
        # intersect.CGIs <- venn.diagram(Meth.CGIs, filename=NULL)
        size.txt <- c(3,3,3,3,3,    # each set
                      0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1, # intersection 2 set, size=10
                      0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1, # intersection 3 set, size=10
                      0.1,0.1,0.1,0.1,0.1, # intersection 4 set, size=5
                      3) # intersection 5 set, size=1

        size.txt <- c(3,3,3,3,3,    # each set
                      0,0,0,0,0,0,0,0,0,0, # intersection 2 set, size=10
                      0,0,0,0,0,0,0,0,0,0, # intersection 3 set, size=10
                      0,0,0,0,0, # intersection 4 set, size=5
                      3) # intersection 5 set, size=1


        #intersect.CGIs <- venn.diagram(Meth.CGIs, cat.cex=2.2, cex=3, cat.fontfamily="",
        intersect.CGIs <- venn.diagram(Meth.CGIs, cat.cex=2.2, cex=size.txt, cat.fontfamily="",
                                        col= Disease.Colors,fill= Disease.Colors,  filename=NULL,
                                        cat.just= list(c(0.5,0.8),c(0,-2.5),c(1,0),c(0,0),c(1,-1.8)))

        pdf(paste0('../../results/CIMP/1_InterCancer/Venn_CIMP.pdf'))
        grid.draw(intersect.CGIs)
        dev.off()

        ####
        # library(gplots)
        # venn(Meth.CGIs,small=0.01,simplify=T)
        # 
        # source('lib/venn_modified.R')
        # venn.improved(Meth.CGIs[1:3],color= Disease.Colors[1:3])


        fData <- get(load('../../data/processed/fData/fData_CGI.RData'))
        Genes.Common <- Reduce('c', lapply(1:length(Common.Index), function(n)
                                           {
                                                   tmp <- fData[[Common.Index[n]]]$UCSC_RefGene_Name
                                                   Dat <- unique(Reduce('c',strsplit(tmp,";")))
                                                   return(Dat)
                                           }))

        # Promoter.Assoc <- get(load('../../big_data/Tools/FullPromoterAssoc.RData'))
        # AllCGIs.Assoc <- get(load('../../big_data/Tools/FullAllCGIsAssoc.RData'))
        # CommonGenes <- get(load('../../big_data/Tools/FullCommonGenes.RData'))

        out <- NULL
        out$CGIs <- Common.Index
        # out$Genes <- as.character(na.omit( CommonGenes[match(Index,Promoter.Assoc)]))
        out$Genes <- Genes.Common

        # save(Index, file="../../big_data/CGIs/CIMP_Intersection_all_CGIs.RData")

        GeneList <- get(load("../../data/processed/fData/GeneList.RData"))

        library(clusterProfiler)
        library(biomaRt)
        mart <- useMart(biomart="ensembl", dataset= "hsapiens_gene_ensembl")

        universe.genes <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = GeneList, mart = mart)[,1]
        signature.genes <- getBM(attributes = c("entrezgene"), filters = "hgnc_symbol", values = Genes.Common, mart = mart)[,1]

        xx_bp <- enrichGO(signature.genes, universe = universe.genes ,ont="BP")
        xx_mf <- enrichGO(signature.genes, universe = universe.genes ,ont="MF")

        pdf(paste0('../../results/CIMP/1_InterCancer/BP_all_CGIsVar',var.thresh,'.pdf'))
        print(plot(xx_bp, showCategory=30,by="geneRatio"))
        dev.off()
        #############

        pdf(paste0('../../results/CIMP/1_InterCancer/MF_all_CGIsVar',var.thresh,'.pdf'))
        print(plot(xx_mf, showCategory=30,by="geneRatio"))
        dev.off()
        #############

        return(out)
}
