analyze_CIMP_all_CGIs_bis = function (DiseaseList, var.thresh) {
        Meth.Var <- lapply(1:length(DiseaseList), function(k)
                                       {
                                               CGI.Var <- get(load(paste0('../../big_data/CGIs/',DiseaseList[k],'_Var.RData')))
                                               CIMP <- (CGI.Var > quantile(na.omit(CGI.Var), 1-var.thresh/100))
                                               return(CIMP)
                                       })

        CIMP.Info <- Reduce('cbind', Meth.Var)

        Common.Index <- which(apply(CIMP.Info,1,all))
        NonCIMP <- apply(CIMP.Info,1,function(x){!any(x)})
        colnames(CIMP.Info) <- DiseaseList

        CGI.Number <- apply(CIMP.Info,1,sum)

        Dat.bis <- CIMP.Info*1

        Intersection <- (CGI.Number==ncol(CIMP.Info))

        ##### Enrich GO on Intersection
        fData <- get(load("../../data/processed/fData/fData_CGI.RData"))
        fData_Intersection <- fData[Intersection] 
        Genes.CIMP <- unique(Reduce('c',lapply(1:length(fData_Intersection), function(n)
                             {
                                     unique(Reduce('c', strsplit(fData_Intersection[[n]]$UCSC_RefGene_Name,";")))
                             })))

        save(Genes.CIMP, file="../../results/Genes_CIMP.RData")
        GeneList <- get(load('../../data/processed/fData/GeneList.RData'))

        # save(Genes.CIMP, file="~/Desktop/GO_CIMP/CIMP_Genes.RData")
        # save(GeneList, file="~/Desktop/GO_CIMP/CIMP_Universe.RData")

        library(biomaRt)
        mart <- useMart(biomart = "ensembl", dataset="hsapiens_gene_ensembl")

        Universe <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= GeneList, mart=mart)[,1]
        Signature.CIMP <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= Genes.CIMP, mart=mart)[,1]

        library("clusterProfiler")
        enrich.CIMP <- enrichGO(Signature.CIMP, organism="human", ont="BP", pvalueCutoff=0.05, universe = Universe, readable=T)

        write.table(summary(enrich.CIMP), file="../../results/CIMP/GO.txt", row.names=F, sep="\t", quote=F)

        pdf("../../results/CIMP/GO_CIMP.pdf")
        print(plot(enrich.CIMP, showCategory=10, by="pvalue"))
        dev.off()

        # enrichMap(enrich.CIMP)
        # cnetplot(enrich.CIMP)


        ###### Heatmap on CGI intersection
        CGI.Intersection <- lapply(1:length(DiseaseList), function(k)
                                   {
                                           print(k)

                                           Meth.filter <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseList[k],'/CancerousCGIs.RData')))[Intersection]

                                           ###
                                           CGI.Sum.Methylation <- sapply(1:length(Meth.filter), function(n)
                                                                         {
                                                                                 return(apply(Meth.filter[[n]],2,function(x){mean(x,na.rm=T)}))
                                                                         })

                                           return(CGI.Sum.Methylation)

                                   })

        save(CGI.Intersection, file="../../big_data/CGIs/AllCGIs_Intersection_CIMP.RData")

        Dat <- Reduce('rbind',CGI.Intersection)

        source('lib/heatmap.3.R')
        require('RColorBrewer')
        colmap <- colorRampPalette(c('blue','black','yellow'))(100)

        ###
        Disease.Col <- rep(DiseaseList, sapply(CGI.Intersection,nrow))
        source('lib/gg_color_hue.R')
        Col.Disease <- gg_color_hue(length(DiseaseList))
        names(Col.Disease) <- DiseaseList

        library(plyr)
        Disease.Col <- revalue(Disease.Col, Col.Disease)

        ###
        clusters.CIMP <- lapply(1:length(DiseaseList), function(k)
                                {
                                        print(k)
                                        #Dat <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[k],'_CIMP_',CIMP.Number,'.RData')))
                                        Dat <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[k],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                                })

        CIMP.Col <-  as.character(Reduce('c', clusters.CIMP))
        Col.CIMP <- c('blue','yellow')
        names(Col.CIMP) <- unique(CIMP.Col)

        CIMP.Col <- revalue(CIMP.Col, Col.CIMP)
        ####

        CIMP <- CIMP.Col
        Tissue <- Disease.Col 
        ColSideColors <- rbind(Tissue, CIMP)

        ###
        ###

        source('lib/heatmap.3.R')
        pdf(paste0('../../results/CIMP/1_InterCancer/CIMP_InterCancer_',CIMP.Number,'Var',var.thresh,'.pdf'))
        p <- heatmap.3(t(Dat),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="col", trace="none",col=colmap,  Key="Methylation", ColSideColors=t(ColSideColors), labRow=NA,labCol=NA)
        # p <- heatmap.3(t(Dat),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="col", trace="none",col=colmap,  Key="Methylation", labRow=NA,labCol=NA,)
        legend('bottomleft', fill = Col.Disease, legend=DiseaseList)
        dev.off()

        # source('http://bioconductor.org/biocLite.R')
        # biocLite('ConsensusClusterPlus')            
        library(ConsensusClusterPlus)

        Consensus <- ConsensusClusterPlus(d= t(Dat), maxK= 5,  reps=100, title="../../results/CIMP/1_InterCancer/Consensus", distance="euclidean", innerLinkage="complete", finalLinkage="ward",plot="pdf")
        rcc <- calcICL(Consensus, title ="../../results/CIMP/1_InterCancer/ICL", plot="pdf")



}
