compare_clinical_supplementary = function (DiseaseName, var.thresh, CIMP.Number,Clinical.Infos) {

        # DiseaseName <- "BRCA"
        # var.thresh <- 5
        # CIMP.Number <- 2

        Dat.CIMP <- get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseName,'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
        Dat.Clinical <- get(load(paste0('../../data/processed/Clinical/TCGA/',DiseaseName,'/Clinical.RData')))

        names_Meth <- substring(names(Dat.CIMP),1,12)
        names_Clinical <- substring(rownames(Dat.Clinical),1,12)

        common_names <- intersect(names_Meth,names_Clinical)

        CIMP.processed <- Dat.CIMP[match(common_names,names_Meth)]
        Clinical.processed <- Dat.Clinical[match(common_names,names_Clinical),]

        Infos <- Clinical.Infos[[DiseaseName]]

        Dat.df <- data.frame(CIMP=CIMP.processed, Clinical.processed[,Infos])
        
        save(Dat.df,file=paste0('../../big_data/Clinical/',DiseaseName,'.RData'))

        ColClasses <- sapply(2:ncol(Dat.df), function(n)
                             {
                                     class(Dat.df[,n])
                             })

        ### t.test for numeric values (e.g age, weight)
        pval.Infos <- sapply(1:length(ColClasses), function(n)
                             {

                                     print(Infos[n])
                                     if (ColClasses[n] %in% c("integer","numeric"))
                                         {
                                                 #print(t.test(Dat.df[Dat.df$CIMP==1, Infos[n]],
                                                 return(t.test(Dat.df[Dat.df$CIMP==1, Infos[n]],
                                                        Dat.df[Dat.df$CIMP==2, Infos[n]])$p.value)
                                         } else if (ColClasses[n]=="factor")
                                         {

                                                 ### chi square for categorical variables
                                                 if (grepl("pt",Infos[n]))
                                                 {

                                                         Sizes <- TumorSizes[as.character(Dat.df[,Infos[n]])]
                                                         tbl <- table(Dat.df$CIMP, Sizes)
                                                 } else if (grepl("pn",Infos[n]))
                                                 {

                                                         NodesInfo <- Nodes[as.character(Dat.df[,Infos[n]])]

                                                         tbl <- table(Dat.df$CIMP, NodesInfo)
                                                 } else if (grepl("pm",Infos[n]))
                                                 {
                                                         MetaInfo <- Metastasis[as.character(Dat.df[,Infos[n]])]

                                                         tbl <- table(Dat.df$CIMP, MetaInfo)
                                                 } else if (grepl("microsatellite_instability",Infos[n]))
                                                 {
                                                         MSI <- Dat.df[,Infos[n]]
                                                         MSI[MSI=="[Unknown]"] <- NA
                                                         MSI <- factor(MSI) 

                                                         tbl <- table(Dat.df$CIMP, MSI)
                                                         MSI.df <- data.frame(CIMP=Dat.df$CIMP, MSI=MSI)
                                                         MSI.df.NoNA <- MSI.df[!is.na(MSI.df),]
                                                         MSI.tbl <- table(MSI.df.NoNA)
                                                         MSI.n <- MSI.tbl/apply(MSI.tbl,1,sum)
                                                         MSI.percent <- data.frame(CIMP=c('negative','negative','positive','positive'),
                                                                                   MSI=c('NO','YES','NO','YES'),
                                                                                   Ratio=c(MSI.n[1,1],MSI.n[1,2],MSI.n[2,1],MSI.n[2,2]))

                                                         
                                                         library(ggplot2)
                                                         pdf('../../results/Clinical/COAD_MSI_CIMP.pdf')
                                                         print(
                                                               ggplot(MSI.percent) + geom_histogram(aes(x=factor(CIMP), fill=MSI,y=Ratio),stat="identity")+
                                                               xlab('CIMP') +
                                                               theme(panel.grid=element_blank(),
                                                                     #legend.position="none",
                                                                     text = element_text(size=20),
                                                                     panel.background=element_rect(fill="white"),
                                                                     axis.text=element_text(colour="black", size=rel(0.8)),
                                                                     axis.ticks=element_line(colour="black"),
                                                                     panel.border=element_rect(fill=NA, colour="black", size=0.7),
                                                                     axis.title.y=element_text(vjust=0.35),
                                                                     strip.background=element_rect(colour="black", fill="white",size=0.7),
                                                                     axis.line = element_line(colour="black",size=0.7))
                                                               )
                                                         dev.off()


                                                 } else if (grepl("er_status",Infos[n]))
                                                 {
                                                         ERstatus <- factor(Dat.df[,Infos[n]])
                                                         tbl <- table(Dat.df$CIMP, ERstatus)
                                                 } else if (grepl("pr_status",Infos[n]))
                                                 {
                                                         PRstatus <- factor(Dat.df[,Infos[n]])
                                                         PRstatus[PRstatus=="Indeterminate"] <- NA
                                                         PRstatus <- factor(PRstatus)

                                                         tbl <- table(Dat.df$CIMP, PRstatus)
                                                 } else if (grepl("her2_status",Infos[n]))
                                                 {
                                                         HER2status <- factor(Dat.df[,Infos[n]])
                                                         HER2status[HER2status=="Indeterminate"] <- NA
                                                         Fish <- Clinical.processed$her2_fish_status

                                                         for (k in 1:length(HER2status))
                                                         {
                                                                 if (is.na(HER2status[k]))
                                                                 {
                                                                 } else if (HER2status[k]=="Equivocal")
                                                                 {
                                                                         if (is.na(Fish[k]))
                                                                         {
                                                                                 HER2status[k] <- NA
                                                                         } else if (Fish[k] == "Indeterminate")
                                                                         {
                                                                                 HER2status[k] <- NA
                                                                         } else if (Fish[k] == "Equivocal")
                                                                         {
                                                                                 HER2status[k] <- NA
                                                                         } else if (Fish[k] == "Negative")
                                                                         {
                                                                                 HER2status[k] <- "Negative"
                                                                         } else if (Fish[k] == "Positive")
                                                                         {
                                                                                 HER2status[k] <- "Positive"
                                                                         }
                                                                 }
                                                         }


                                                         HER2status <- factor(HER2status)

                                                         tbl <- table(Dat.df$CIMP, HER2status)
                                                 } else 
                                                 {
                                                         tbl <- table(Dat.df$CIMP, Dat.df[,Infos[n]])
                                                 }

                                                 #print(chisq.test(tbl)$p.value)
                                                 return(chisq.test(tbl)$p.value)
                                         }

                             })
        names(pval.Infos) <- Infos

        if (DiseaseName =="BRCA")
        {
                #### ER Info ###
                ER.Info <- grep("er_status",Infos)
                ER <- factor(Dat.df[,Infos[ER.Info]])

                tbl <- table(Dat.df$CIMP, ER )
                ER.df <- data.frame(CIMP=Dat.df$CIMP, ER=ER)
                ER.df.NoNA <- ER.df[!is.na(ER.df),]
                ER.tbl <- table(ER.df.NoNA)
                ER.n <- ER.tbl/apply(ER.tbl,1,sum)
                ER.percent <- data.frame(CIMP=c('negative','negative','positive','positive'),
                                          ER=c('negative','positive','negative','positive'),
                                          Ratio=c(ER.n[1,1],ER.n[1,2],ER.n[2,1],ER.n[2,2]))


                library(ggplot2)
                pdf('../../results/Clinical/BRCA_ER_CIMP.pdf')
                print(
                      ggplot(ER.percent) + geom_histogram(aes(x=factor(CIMP), fill=ER,y=Ratio),stat="identity")+
                      xlab('CIMP') + scale_fill_discrete('ER status') +
                      theme(panel.grid=element_blank(),
                            #legend.position="none",
                            text = element_text(size=20),
                            panel.background=element_rect(fill="white"),
                            axis.text=element_text(colour="black", size=rel(0.8)),
                            axis.ticks=element_line(colour="black"),
                            panel.border=element_rect(fill=NA, colour="black", size=0.7),
                            axis.title.y=element_text(vjust=0.35),
                            strip.background=element_rect(colour="black", fill="white",size=0.7),
                            axis.line = element_line(colour="black",size=0.7))
                      )
                dev.off()

                #### PR Info ###
                PR.Info <- grep("pr_status",Infos)
                PR <- factor(Dat.df[,Infos[PR.Info]])
                PR[PR=="Indeterminate"] <- NA
                PR <- factor(PR)

                tbl <- table(Dat.df$CIMP, PR )
                PR.df <- data.frame(CIMP=Dat.df$CIMP, PR=PR)
                PR.df.NoNA <- PR.df[!is.na(PR.df),]
                PR.tbl <- table(PR.df.NoNA)
                PR.n <- PR.tbl/apply(PR.tbl,1,sum)
                PR.percent <- data.frame(CIMP=c('negative','negative','positive','positive'),
                                          PR=c('negative','positive','negative','positive'),
                                          Ratio=c(PR.n[1,1],PR.n[1,2],PR.n[2,1],PR.n[2,2]))


                library(ggplot2)
                pdf('../../results/Clinical/BRCA_PR_CIMP.pdf')
                print(
                      ggplot(PR.percent) + geom_histogram(aes(x=factor(CIMP), fill=PR,y=Ratio),stat="identity")+
                      xlab('CIMP') + scale_fill_discrete('PR status') +
                      theme(panel.grid=element_blank(),
                            #legend.position="none",
                            text = element_text(size=20),
                            panel.background=element_rect(fill="white"),
                            axis.text=element_text(colour="black", size=rel(0.8)),
                            axis.ticks=element_line(colour="black"),
                            panel.border=element_rect(fill=NA, colour="black", size=0.7),
                            axis.title.y=element_text(vjust=0.35),
                            strip.background=element_rect(colour="black", fill="white",size=0.7),
                            axis.line = element_line(colour="black",size=0.7))
                      )
                dev.off()

                #### HER2 Info ###
                HER2.Info <- grep("her2_status",Infos)
                HER2 <- factor(Dat.df[,Infos[HER2.Info]])
                HER2[HER2=="Indeterminate"] <- NA
                Fish <- Clinical.processed$her2_fish_status

                for (k in 1:length(HER2))
                {
                        if (is.na(HER2[k]))
                        {
                        } else if (HER2[k]=="Equivocal")
                        {
                                if (is.na(Fish[k]))
                                {
                                        HER2[k] <- NA
                                } else if (Fish[k] == "Indeterminate")
                                {
                                        HER2[k] <- NA
                                } else if (Fish[k] == "Equivocal")
                                {
                                        HER2[k] <- NA
                                } else if (Fish[k] == "Negative")
                                {
                                        HER2[k] <- "Negative"
                                } else if (Fish[k] == "Positive")
                                {
                                        HER2[k] <- "Positive"
                                }
                        }
                }

                HER2 <- factor(HER2)



                tbl <- table(Dat.df$CIMP, HER2 )
                HER2.df <- data.frame(CIMP=Dat.df$CIMP, HER2=HER2)
                HER2.df.NoNA <- HER2.df[!is.na(HER2.df),]
                HER2.tbl <- table(HER2.df.NoNA)
                HER2.n <- HER2.tbl/apply(HER2.tbl,1,sum)
                HER2.percent <- data.frame(CIMP=c('negative','negative','positive','positive'),
                                          HER2=c('negative','positive','negative','positive'),
                                          Ratio=c(HER2.n[1,1],HER2.n[1,2],HER2.n[2,1],HER2.n[2,2]))


                library(ggplot2)
                pdf('../../results/Clinical/BRCA_HER2_CIMP.pdf')
                print(
                      ggplot(HER2.percent) + geom_histogram(aes(x=factor(CIMP), fill=HER2,y=Ratio),stat="identity")+
                      xlab('CIMP') + scale_fill_discrete('HER2 status') +
                      theme(panel.grid=element_blank(),
                            #legend.position="none",
                            text = element_text(size=20),
                            panel.background=element_rect(fill="white"),
                            axis.text=element_text(colour="black", size=rel(0.8)),
                            axis.ticks=element_line(colour="black"),
                            panel.border=element_rect(fill=NA, colour="black", size=0.7),
                            axis.title.y=element_text(vjust=0.35),
                            strip.background=element_rect(colour="black", fill="white",size=0.7),
                            axis.line = element_line(colour="black",size=0.7))
                      )
                dev.off()


        }

        # table(Dat.df$CIMP, Dat.df[,Infos[2]], useNA="ifany")
        # table(Dat.df$CIMP, Dat.df[,Infos[3]], useNA="ifany")
        # table(Dat.df$CIMP, Dat.df[,Infos[4]], useNA="ifany")

        # table(Dat.df$CIMP, Sizes, useNA="ifany")
        # chisq.test(table(Dat.df$CIMP, Sizes))$p.value


        # ggplot(Dat.df) + geom_boxplot(aes(x=factor(CIMP), y=weight_kg_at_diagnosis))
        write.table(pval.Infos, file=paste0('../../results/Clinical/', DiseaseFolder[DiseaseName],'/Pval_Infos.txt'))

        return(pval.Infos)


}
