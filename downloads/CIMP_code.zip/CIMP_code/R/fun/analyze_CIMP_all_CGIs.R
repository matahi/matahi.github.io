analyze_CIMP_all_CGIs  = function (DiseaseName,CIMP.Number = 2,calc.Var=T, var.thresh=5,plotting=T) 
{
        # DiseaseName <- "BRCA"
        # CIMP.Number <- 2
        # var.thresh <- 1
        # calc.Var <- F

        ##### Methylation Behaviour
        Meth.Dat <- get(load(paste0('../../data/processed/Methylation/TCGA/',DiseaseName,'/CancerousCGIs.RData')))
        #fData <- get(load("../../data/processed/fData/fData_CGI.RData"))

        ##### Calculating the variance of each CGI
        if (calc.Var)
        {
                CGI.Var <- sapply(1:length(Meth.Dat), function(n)
                                  {
                                          print(paste0(n,'/',length(Meth.Dat)))
                                          return(mean(apply(Meth.Dat[[n]],1,function(x){var(x,na.rm=T)}),na.rm=T))

                                  })

                save(CGI.Var, file=paste0("../../big_data/CGIs/",DiseaseName,"_Var.RData"))

        } else {
                CGI.Var <- get(load(paste0("../../big_data/CGIs/",DiseaseName,"_Var.RData")))
        }

        ###### Taking the top variant CGIs
        Meth.Var <- Meth.Dat[CGI.Var > quantile(na.omit(CGI.Var), 1- var.thresh/100)]

        ###### Summarize a CGI methylation value with its mean
        CGI.Sum.Methylation <- sapply(1:length(Meth.Var), function(n)
                                      {
                                              print(paste0(n,'/',length(Meth.Var)))
                                              return(apply(Meth.Var[[n]], 2, function(x){mean(x,na.rm=T)}))
                                      })

        source('lib/heatmap.3.R')
        require('RColorBrewer')
        colmap <- colorRampPalette(c('blue','black','yellow'))(100)

        #### SAVING CIMP
        distMat <- dist(CGI.Sum.Methylation)
        hc <- hclust(distMat, "ward")
        # CIMP.Number <- 2
        clusters <- cutree(hc,CIMP.Number)

        ### We rearrange the cluster so that CIMP-high is always cluster 2
        source('fun/rearrange_clusters.R')
        clusters.CIMP <- rearrange_clusters(CGI.Sum.Methylation,clusters)
        save(clusters.CIMP, file=paste0("../../big_data/CGIs/AllCGIs_",DiseaseName,'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData'))
        clusters.CIMP <- get(load(paste0("../../big_data/CGIs/AllCGIs_",DiseaseName,'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
        #######################

        if (plotting)
        {
                CIMP.Col <- as.factor(clusters.CIMP)
                source('lib/gg_color_hue.R')
                Col.CIMP <- c('1' = '#225ea8',
                              '2' = 'gold2')

                library(plyr)
                Disease.Col <- as.character(revalue(CIMP.Col, Col.CIMP))

                ### Do Heatmap Methylation
                pdf(paste0('../../results/CIMP/',DiseaseFolder[DiseaseName], '/heatmap_Var',var.thresh,'_CIMP_',CIMP.Number,'.pdf'))
                p <- heatmap.2(t(CGI.Sum.Methylation),hclustfun= function(x){hclust(x,method="ward")},  scale="none", dendrogram="column", trace="none",col=colmap,  key=F,ColSideColors=Disease.Col, labRow=NA,labCol=NA)
                # legend('topright',fill= Col.CIMP, legend = names(Col.CIMP))
                dev.off()

                # library(clusterStab)
                # Robustness <- clusterComp(t(CGI.Sum.Methylation), cl = CIMP.Number, method="ward", distmeth="euclidean")

                library(ConsensusClusterPlus)
                Consensus <- ConsensusClusterPlus(d= t(CGI.Sum.Methylation), maxK= 6,  reps=100, title=paste0("../../results/CIMP/",DiseaseFolder[DiseaseName],"/Consensus_Var",var.thresh), distance="euclidean", innerLinkage="ward", finalLinkage="ward",plot="pdf")

                save(Consensus, file=paste0("../../big_data/CGIs/",DiseaseName,"_Consensus",var.thresh,".RData"))

        }
}
