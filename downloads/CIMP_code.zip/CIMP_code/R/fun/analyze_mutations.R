analyze_mutations = function (DiseaseList, Mutation.List=NULL, var.thresh=5, CIMP.Number=2, Cutoff=10) {

        # Mutation.List <- c('BRAF','KRAS','IDH1','IDH2','TET2')
        # Mutation.List <- NULL
        # Cutoff <- 10




        # DiseaseList <- "GBM"
        Dat.CIMP <- lapply(1:length(DiseaseList), function(n)
                           {
                                   get(load(paste0('../../big_data/CGIs/AllCGIs_',DiseaseList[n],'_CIMP_',CIMP.Number,'Var',var.thresh,'.RData')))
                           })


        Dat.Mutation <- lapply(1:length(DiseaseList), function(n)
                               {
                                       get(load(paste0('../../data/processed/Mutation/TCGA/',DiseaseList[n],'/Mutations.RData')))
                               })


        if (is.null(Mutation.List))
        {
                Disease.df <- lapply(1:length(DiseaseList), function(n)
                                     {
                                             print(DiseaseList[n])
                                             CIMP <- Dat.CIMP[[n]]
                                             Mutation <- Dat.Mutation[[n]]

                                             CIMP.Patients <- substring(names(CIMP),1,12)
                                             Mutation.Patients <- substring(unique(Mutation$Tumor_Sample_Barcode),1,12)

                                             ################################################################
                                             Patients.Processed <- unique(intersect(CIMP.Patients, Mutation.Patients))
                                             Mutation.processed <- Mutation[substring(Mutation[,"Tumor_Sample_Barcode"],1,12) %in% Patients.Processed, ]
                                             CIMP.processed <- CIMP[match(Patients.Processed, CIMP.Patients)]

                                             # tmp <- table(Mutation.processed$Hugo_Symbol)
                                             Genes.Mutated <- unique(Mutation.processed$Hugo_Symbol)
                                             # names(tmp) <- Genes.Mutated

                                             Mutation.Count <- sapply(1:length(Genes.Mutated), function(n)
                                                                      {
                                                                              return(length(unique(Mutation.processed[Mutation.processed$Hugo_Symbol==Genes.Mutated[n],"Tumor_Sample_Barcode"])))
                                                                      })
                                             names(Mutation.Count) <- Genes.Mutated

                                             Mutation.Patient <- lapply(1:length(Genes.Mutated), function(n)
                                                                      {
                                                                              return(unique(Mutation.processed[Mutation.processed$Hugo_Symbol==Genes.Mutated[n],"Tumor_Sample_Barcode"]))
                                                                      })
                                             names(Mutation.Patient) <- Genes.Mutated

                                             Cutoff <- 0.05
                                             # Cutoff <- 0.01

                                             Mutation.High <- Mutation.Count[Mutation.Count > length(CIMP.processed)*Cutoff]
                                             Mutation.Patient.High <- Mutation.Patient[Mutation.Count > length(CIMP.processed)*Cutoff]
                                             ################################################################
                                             

                                             Mutation.df <- Reduce('rbind', lapply(1:length(Mutation.High), function(k)
                                                                                   {
                                                                                           names.CIMP <- substring(names(CIMP.processed),1,12)
                                                                                           CIMP.Neg <- sum(CIMP.processed[names.CIMP %in% substring(Mutation.Patient.High[[k]],1,12)]==1)
                                                                                           CIMP.Pos <- sum(CIMP.processed[names.CIMP %in% substring(Mutation.Patient.High[[k]],1,12)]==2)

                                                                                           return(data.frame(Gene=names(Mutation.High)[k], Count=c(CIMP.Neg,CIMP.Pos), CIMP=c('Negative','Positive')))

                                                                                   }))

                                             Pval.Mutation <- sapply(1:length(Mutation.High), function(k)
                                                                     {
                                                                             names.CIMP <- substring(names(CIMP.processed),1,12)
                                                                             CIMP.Pos.Mutated <- sum(CIMP.processed[names.CIMP %in% substring(Mutation.Patient.High[[k]],1,12)]==2)
                                                                             Total.Mutated <- length(Mutation.Patient.High[[k]])
                                                                             CIMP.Pos.Total <- sum(CIMP.processed==2)
                                                                             N.Total <- length(CIMP.processed)

                                                                             pval <- phyper(CIMP.Pos.Mutated-1, CIMP.Pos.Total, N.Total-CIMP.Pos.Total, Total.Mutated,lower.tail=F)
                                                                             return(pval)
                                                                     })
                                             names(Pval.Mutation) <- names(Mutation.High)

                                             Pval.Mutation.corrected <- p.adjust(Pval.Mutation, method="fdr")

                                             return(Pval.Mutation.corrected)

                                     })

                # save(Disease.df, file="../../results/Disease_Mutation.RData")
                Disease.df <- get(load('../../results/Disease_Mutation.RData'))

                Mutation.Sig <- lapply(1:length(Disease.df), function(n)
                                       {
                                               return(names(Disease.df[[n]])[Disease.df[[n]] < 0.05])
                                       })
                names(Mutation.Sig) <- DiseaseList

                library(VennDiagram)
                intersect.CGIs <- venn.diagram(Mutation.Sig, filename=NULL)
                graphics.off()
                grid.draw(intersect.CGIs)

                size.txt <- c(3,3,3)

                intersect.CGIs <- venn.diagram(Mutation.Sig[c(3,5)], 
                                               cat.cex=2.2,
                                               cex=size.txt,
                                               cat.fontfamily="",
                                               col= Disease.Colors[c(3,5)],
                                               fill= Disease.Colors[c(3,5)],
                                               cat.just= list(c(0,-2), c(1,-2)),
                                               filename=NULL)
                graphics.off()
                pdf(paste0('../../results/Mutations/1_InterCancer/Venn_Mutations.pdf'))
                grid.draw(intersect.CGIs)
                dev.off()

                Gene.Mutation <- intersect(Mutation.Sig$COAD, Mutation.Sig$STAD)
                write.table(Gene.Mutation, file="../../results/Mutation_Genes.txt",col.names=F, row.names=F)

                Gene.Mutation <- read.csv('../../results/Mutation_Genes.txt',header=F)
                tmp <- as.character(Gene.Mutation[,1])
                save(tmp, file="~/Desktop/GO_CIMP/Mutation_Genes.RData")
                save(GeneList, file="~/Desktop/GO_CIMP/Mutation_Universe.RData")


                ##########################
                #### ENRICHMENT
                library(biomaRt)
                GeneList <- get(load('../../big_data/Prediction/GeneList.RData'))
                mart <- useMart(biomart = "ensembl", dataset="hsapiens_gene_ensembl")

                Universe <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= GeneList, mart=mart)[,1]
                # Signature.COAD <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= Mutation.Sig$COAD, mart=mart)[,1]
                # Signature.STAD <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= Mutation.Sig$STAD, mart=mart)[,1]

                Signature.Intersection <- getBM(attributes= c('entrezgene'), filters="hgnc_symbol", values= intersect(Mutation.Sig$COAD,Mutation.Sig$STAD), mart=mart)[,1]

                library("clusterProfiler")
                # enrich.COAD <- enrichGO(Signature.COAD, organism="human", ont="BP", pvalueCutoff=0.05, universe = Universe, readable=T)
                # enrich.LUAD <- enrichGO(Signature.LUAD, organism="human", ont="BP", pvalueCutoff=0.05, universe = Universe, readable=T)

                enrich.Intersection <- enrichGO(Signature.Intersection, organism="human", ont="BP", pvalueCutoff=0.05, universe = Universe, readable=T)
                write.table(summary(enrich.Intersection), file="../../results/Mutation_GO.txt", row.names=F, sep="\t", quote=F)

                pdf("../../results/Mutation_GO_plot.pdf")
                print(plot(enrich.Intersection, showCategory=10, by="geneRatio"))
                dev.off()
                ##########################







        } else {
                Disease.df <- lapply(1:length(DiseaseList), function(n)
                                     {
                                             CIMP <- Dat.CIMP[[n]]
                                             Mutation <- Dat.Mutation[[n]]

                                             CIMP.Patients <- substring(names(CIMP),1,12)
                                             Mutation.Patients <- substring(unique(Mutation$Tumor_Sample_Barcode),1,12)
                                             print(sum(Mutation.Patients %in% CIMP.Patients))

                                             Mutation.Patients.present <- Mutation.Patients[Mutation.Patients %in% CIMP.Patients]
                                             CIMP.Patients.NotPresent <- CIMP.Patients[!(CIMP.Patients %in% Mutation.Patients.present)]

                                             ########
                                             tmp <- table(Mutation$Hugo_Symbol)
                                             Genes.Mutated <- unique(Mutation$Hugo_Symbol)
                                             names(tmp) <- Genes.Mutated

                                             Mutation.Genes <- Mutation.List

                                             Mutation.Mat <- matrix(0,ncol=length(Mutation.Genes) , nrow=length(CIMP) )
                                             rownames(Mutation.Mat) <- names(CIMP)
                                             colnames(Mutation.Mat) <- Mutation.Genes

                                             ### Put NA to patients without Info
                                             Mutation.Mat[CIMP.Patients %in% CIMP.Patients.NotPresent,] <- NA
                                             Mutation.Mat <- data.frame(Mutation.Mat)

                                             for (Gene in Mutation.Genes)
                                             {
                                                     if (Gene %in% Mutation$Hugo_Symbol) ## Only if we give ourself the gene list this might not happen
                                                     {
                                                             #### Maybe see the impact of the mutation
                                                             Gene.Patients <- Mutation[Mutation$Hugo_Symbol==Gene, "Tumor_Sample_Barcode"]
                                                             Index <- which(substring(rownames(Mutation.Mat),1,12) %in% substring(Gene.Patients,1,12))
                                                             Mutation.Mat[Index , Gene ] <- 1
                                                     }
                                             }

                                             Mut.Mat <- sapply(1:ncol(Mutation.Mat), function(n)
                                                               {
                                                                       CIMP.neg <- mean(Mutation.Mat[CIMP==1,n] ,na.rm=T)
                                                                       CIMP.pos <- mean(Mutation.Mat[CIMP==2,n] ,na.rm=T)
                                                                       return(c(CIMP.neg,CIMP.pos))
                                                               })

                                             Mut.df <- data.frame(Mut.Mat)
                                             colnames(Mut.df) <- Mutation.Genes
                                             Mut.m <- melt(Mut.df)
                                             Mut.m <- data.frame(Gene= Mut.m$variable, Ratio=Mut.m$value, CIMP=c('Negative','Positive'), Disease=DiseaseList[n])

                                             ###### Look at Number of Mutations vs CIMP +/-
                                             Num.Mutation <- rep(0,length(CIMP))
                                             names(Num.Mutation) <- names(CIMP)

                                             for (i in 1:length(CIMP))
                                             {
                                                     Patient <- substring(names(CIMP)[i],1,12)
                                                     Patients.Info <- substring(Mutation[, "Tumor_Sample_Barcode"],1,12)

                                                     if (!(Patient %in% Patients.Info))
                                                     {
                                                             Num.Mutation[i] <- NA
                                                     } else {
                                                             Num.Mutation[i] <- sum(Patients.Info==Patient)
                                                     }
                                             }


                                             library(ggplot2)
                                             Num.df <- data.frame(Num=Num.Mutation, CIMP=CIMP, Disease=DiseaseList[n])

                                             pdf(paste0('../../results/Mutations/', DiseaseList[n],'/Mutations_Num_CIMP.pdf'))
                                             print(ggplot(Num.df) + geom_boxplot(aes(x=factor(CIMP),y=Num)))
                                             dev.off()

                                             return(list(Mutations=Mut.m,Number=Num.df))
                                     })

                Mutation.total <- Reduce('rbind',lapply(1:length(DiseaseList), function(n){Disease.df[[n]]$Mutations}))
                Num.total <- Reduce('rbind',lapply(1:length(DiseaseList), function(n){Disease.df[[n]]$Number}))

                CIMP_colours <- c('Negative' = "#225ea8",
                                  'Positive' = "gold2")


                library(ggplot2)
                pdf('../../results/Mutations/1_InterCancer/Common_Mutations_Ratio_CIMP.pdf')
                print(
                      ggplot(Mutation.total) + geom_histogram(aes(x=Disease, y=Ratio, fill=CIMP),stat="identity",position="dodge") + facet_grid(Gene~.) +
                      scale_fill_manual(values=CIMP_colours) +
                      theme(panel.grid=element_blank(),
                            legend.position="none",
                            text = element_text(size=20),
                            panel.background=element_rect(fill="white"),
                            axis.text=element_text(colour="black", size=rel(0.8)),
                            axis.ticks=element_line(colour="black"),
                            panel.border=element_rect(fill=NA, colour="black", size=0.7),
                            axis.title.y=element_text(vjust=0.35),
                            strip.background=element_rect(colour="black", fill="white",size=0.7),
                            axis.line = element_line(colour="black",size=0.7))
                      )
                dev.off()

                CIMP_colours_bis <- c('1' = "#225ea8",
                                      '2' = "gold2")

                pdf('../../results/Mutations/1_InterCancer/Number_Mutations_CIMP.pdf')
                # ggplot(Num.total) + geom_boxplot(aes(x=Disease, y=Num, fill=factor(CIMP))) 
                print(
                      ggplot(Num.total) + geom_boxplot(aes(x=Disease, y=Num, fill=factor(CIMP)))  + ylim(0,4500) +
                      ylab('Total number of mutations') +
                      scale_fill_manual(values=CIMP_colours_bis) +
                      theme(panel.grid=element_blank(),
                            legend.position="none",
                            text = element_text(size=20),
                            panel.background=element_rect(fill="white"),
                            axis.text=element_text(colour="black", size=rel(0.8)),
                            axis.ticks=element_line(colour="black"),
                            panel.border=element_rect(fill=NA, colour="black", size=0.7),
                            axis.title.y=element_text(vjust=0.35),
                            strip.background=element_rect(colour="black", fill="white",size=0.7),
                            axis.line = element_line(colour="black",size=0.7))
                      )
                dev.off()

        }

}

# 
#                                              ################################################################
#                                              #####
#                                              Mutation.Patients.present <- Mutation.Patients[Mutation.Patients %in% CIMP.Patients]
#                                              CIMP.Patients.NotPresent <- CIMP.Patients[!(CIMP.Patients %in% Mutation.Patients.present)]
# 
#                                              ########
#                                              tmp <- table(Mutation$Hugo_Symbol)
#                                              Genes.Mutated <- unique(Mutation$Hugo_Symbol)
#                                              names(tmp) <- Genes.Mutated
#                                              ##### Cutoff <- 10%
#                                              Mutation.Genes <- names(tmp)[tmp>=quantile(tmp,(length(Genes.Mutated)-10)/length(Genes.Mutated))]
# 
#                                              ### Always add "TP53"
#                                              Mutation.Genes <- unique(c(Mutation.Genes,"TP53"))
#                                              ###### Remove Unknown from BLCA
# 
#                                              Mutation.Mat <- matrix(0,ncol=length(Mutation.Genes) , nrow=length(CIMP) )
#                                              rownames(Mutation.Mat) <- names(CIMP)
#                                              colnames(Mutation.Mat) <- Mutation.Genes
# 
#                                              ### Put NA to patients without Info
#                                              Mutation.Mat[CIMP.Patients %in% CIMP.Patients.NotPresent,] <- NA
#                                              Mutation.Mat <- data.frame(Mutation.Mat)
# 
#                                              for (Gene in Mutation.Genes)
#                                              {
#                                                      if (Gene %in% Mutation$Hugo_Symbol) ## Only if we give ourself the gene list this might not happen
#                                                      {
#                                                              #### Maybe see the impact of the mutation
#                                                              Gene.Patients <- Mutation[Mutation$Hugo_Symbol==Gene, "Tumor_Sample_Barcode"]
#                                                              Index <- which(substring(rownames(Mutation.Mat),1,12) %in% substring(Gene.Patients,1,12))
#                                                              Mutation.Mat[Index , Gene ] <- 1
#                                                      }
#                                              }
# 
#                                              Mut.Mat <- sapply(1:ncol(Mutation.Mat), function(n)
#                                                                {
#                                                                        CIMP.neg <- mean(Mutation.Mat[CIMP==1,n] ,na.rm=T)
#                                                                        CIMP.pos <- mean(Mutation.Mat[CIMP==2,n] ,na.rm=T)
#                                                                        return(c(CIMP.neg,CIMP.pos))
#                                                                })
# 
#                                              Mut.df <- data.frame(Mut.Mat)
#                                              colnames(Mut.df) <- Mutation.Genes
#                                              Mut.m <- melt(Mut.df)
#                                              Mut.m <- data.frame(Gene= Mut.m$variable, Ratio=Mut.m$value, CIMP=c('Negative','Positive'))
# 
#                                              pdf(paste0('../../results/Mutations/', DiseaseList[n],'/Mutations_Ratio_CIMP.pdf'))
#                                              print(ggplot(Mut.m) + geom_bar(aes(x=Gene,y=Ratio,fill=factor(CIMP)), stat="identity",position="dodge") +  theme(axis.text.x= element_text(angle=90, hjust=1)))
#                                              dev.off()
# 
# 

