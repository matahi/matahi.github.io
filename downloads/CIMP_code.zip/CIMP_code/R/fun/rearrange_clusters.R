rearrange_clusters <- function(Dat,clusters)
{
        Mean.Val <- sapply(unique(clusters),function(n)
                           {
                                   mean(Dat[clusters==n,])
                           })

        new.clustering <- order(Mean.Val)

        new.clusters <- clusters
        for (k in unique(clusters))
        {
                new.clusters[clusters==k] <- new.clustering[k]
        }


        return(new.clusters)

}
