plot_clinical <- function (DiseaseList) {

        Dat.df <- lapply(1:length(DiseaseList), function(n)
                         {
                                 Dat.Clinical <- get(load(paste0('../../big_data/Clinical/',DiseaseList[n],'.RData')))
                                 Clinical.df <- data.frame(CIMP=Dat.Clinical[,"CIMP"],Age=-Dat.Clinical[,"birth_days_to"], Disease=DiseaseList[n])
                                 return(Clinical.df)
                         })

        Dat.m <- Reduce('rbind',Dat.df)
        Dat.m$CIMP <- revalue(factor(Dat.m$CIMP), c('1'='Negative','2'='Positive'))
        CIMP_colours <- c('Negative' = "#225ea8",
                          'Positive' = "gold2")


        pdf('../../results/Clinical/Age_CIMP.pdf')
        print(
              ggplot(Dat.m) + geom_boxplot(aes(x=factor(Disease), y=Age/365, fill=factor(CIMP)))+
              scale_fill_manual(values=CIMP_colours) + ylab('Age (years)') + xlab('Tissue')+ 
              theme(panel.grid=element_blank(),
                    legend.position="none",
                    text = element_text(size=20),
                    panel.background=element_rect(fill="white"),
                    axis.text=element_text(colour="black", size=rel(0.8)),
                    axis.ticks=element_line(colour="black"),
                    panel.border=element_rect(fill=NA, colour="black", size=0.7),
                    axis.title.y=element_text(vjust=0.35),
                    strip.background=element_rect(colour="black", fill="white",size=0.7),
                    axis.line = element_line(colour="black",size=0.7))
              )
        dev.off()
        
}
