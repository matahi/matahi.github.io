triangle <- function (m, mode = 1) 
{
    n = dim(m)[1]
    nm = matrix(0, ncol = n, nrow = n)
    fm = m
    nm[upper.tri(nm)] = m[upper.tri(m)]
    fm = t(nm) + nm
    diag(fm) = diag(m)
    nm = fm
    nm[upper.tri(nm)] = NA
    diag(nm) = NA
    vm = m[lower.tri(nm)]
    if (mode == 1) {
        return(vm)
    }
    else if (mode == 3) {
        return(fm)
    }
    else if (mode == 2) {
        return(nm)
    }
}


CDFbis <- function (ml, breaks = 100) 
{
    #plot(c(0), xlim = c(0, 1), ylim = c(0, 1), col = "white", 
    #    bg = "white", xlab = "consensus index", ylab = "CDF", 
    #    main = "consensus CDF", las = 2)
    k = length(ml)
    this_colors = rainbow(k - 1)
    areaK = c()
    for (i in 1:length(ml)) {
        v = triangle(ml[[i]], mode = 1)
        h = hist(v, plot = FALSE, breaks = seq(0, 1, by = 1/breaks))
        h$counts = cumsum(h$counts)/sum(h$counts)
        thisArea = 0
        for (bi in 1:(length(h$breaks) - 1)) {
            thisArea = thisArea + h$counts[bi] * (h$breaks[bi + 
                1] - h$breaks[bi])
            bi = bi + 1
        }
        areaK = c(areaK, thisArea)
    #    lines(h$mids, h$counts, col = this_colors[i - 1], lwd = 2, 
    #        type = "l")
    }
    #legend(0.8, 0.5, legend = paste(rep("", k - 1), seq(2, k, 
    #    by = 1), sep = ""), fill = this_colors)
    deltaK = areaK[1]
    for (i in 1:(length(areaK))) {
        deltaK = c(deltaK, (areaK[i] - areaK[i - 1])/areaK[i - 
            1])
    }
    #plot(1 + (1:length(deltaK)), y = deltaK, xlab = "k", ylab = "relative change in area under CDF curve", 
    #    main = "Delta area", type = "b")

    out <- deltaK 
}
